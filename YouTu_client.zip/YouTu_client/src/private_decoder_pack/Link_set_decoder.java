package private_decoder_pack;

import java.io.UnsupportedEncodingException;
import java.util.List;

import Message.Private.Link_set;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

public class Link_set_decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> list) throws Exception {
		
		   buf.readerIndex(0);
		   
		   if(buf.readableBytes()==0) {return;}
		   
		   int protocol_code = buf.readInt();
		   
	if(protocol_code==122) {
		
		int type = buf.readInt();
		
		if(type==1) {decode_type1(buf, list);}
		else if(type==2){decode_type2(buf, list);}
		else if(type==3){decode_type3(buf, list);}
		else if(type==4) {decode_type4(buf, list);}
		else if(type==5) {decode_type5(buf, list);}
		else if(type==6) {decode_type6(buf, list);}
		else if(type==7) {decode_type7(buf, list);}
		else if(type==8) {decode_type8(buf, list);}
		else if(type==9) {decode_type9(buf, list);}
		else if(type==10) {decode_type10(buf, list);}
	}
	else {
		buf.retain();
		ctx.fireChannelRead(buf);
	}
	}

public void decode_type1(ByteBuf buf, List<Object> list) {
		
	 byte[] native_account = null;
	 boolean privet = true;
	 byte[] new_group = null;
	 
	 native_account = new byte[buf.readInt()];
	 buf.readBytes(native_account);
	 privet = buf.readBoolean();
	 new_group = new byte[buf.readInt()];
	 buf.readBytes(new_group);
	 
	 Link_set link_set = new Link_set(1);
	 try {
		link_set.setNative_count(new String(native_account,"UTF-8"));
		link_set.setPrivat(privet);
		link_set.setNew_group(new String(new_group,"UTF-8"));
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	 
	 list.add(link_set);
	}
public void decode_type2(ByteBuf buf, List<Object> list) {
	
	 byte[] native_account = null;
	 boolean privet = true;
	 byte[] old_group = null;
	 byte[] new_group = null;
	 
	 native_account = new byte[buf.readInt()];
	 buf.readBytes(native_account);
	 privet = buf.readBoolean();
	 old_group = new byte[buf.readInt()];
	 buf.readBytes(old_group);
	 new_group = new byte[buf.readInt()];
	 buf.readBytes(new_group);
	 
	 Link_set link_set = new Link_set(2);
	 try {
		link_set.setNative_count(new String(native_account,"UTF-8"));
		link_set.setPrivat(privet);
		link_set.setOld_group(new String(old_group,"UTF-8"));
		link_set.setNew_group(new String(new_group,"UTF-8"));
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	 
	 list.add(link_set);
}
public void decode_type3(ByteBuf buf, List<Object> list) {
	
	 byte[] native_account = null;
	 boolean privet = true;
	 byte[] old_group = null;
	 byte[] new_group = null;
	 
	 native_account = new byte[buf.readInt()];
	 buf.readBytes(native_account);
	 privet = buf.readBoolean();
	 old_group = new byte[buf.readInt()];
	 buf.readBytes(old_group);
	 new_group = new byte[buf.readInt()];
	 buf.readBytes(new_group);
	 
	 Link_set link_set = new Link_set(3);
	 try {
		link_set.setNative_count(new String(native_account,"UTF-8"));
		link_set.setPrivat(privet);
		link_set.setOld_group(new String(old_group,"UTF-8"));
		link_set.setNew_group(new String(new_group,"UTF-8"));
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	 
	 list.add(link_set);
}
public void decode_type4(ByteBuf buf, List<Object> list) {
	
	 byte[] native_account = null;
	 byte[] link_account = null;
	 byte[] new_group = null;

	 native_account = new byte[buf.readInt()];
	 buf.readBytes(native_account);
	 link_account = new byte[buf.readInt()];
	 buf.readBytes(link_account);
	 new_group = new byte[buf.readInt()];
	 buf.readBytes(new_group);
	 
	 Link_set link_set = new Link_set(4);
	 try {
		link_set.setNative_count(new String(native_account,"UTF-8"));
		link_set.setLink_account(new String(link_account,"UTF-8"));
		link_set.setNew_group(new String(new_group,"UTF-8"));
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	 
	 list.add(link_set);
}
public void decode_type5(ByteBuf buf, List<Object> list) {
	
	 byte[] native_account = null;
	 byte[] link_account = null;
	 
	 native_account = new byte[buf.readInt()];
	 buf.readBytes(native_account);
	 link_account = new byte[buf.readInt()];
	 buf.readBytes(link_account);

	 Link_set link_set = new Link_set(5);
	 try {
		link_set.setNative_count(new String(native_account,"UTF-8"));
		link_set.setLink_account(new String(link_account,"UTF-8"));
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	 
	 list.add(link_set);
}
public void decode_type6(ByteBuf buf, List<Object> list) {
	
	 byte[] native_account = null;
	 byte[] link_account = null;
	 byte[] new_remark = null;
	 
	 native_account = new byte[buf.readInt()];
	 buf.readBytes(native_account);
	 link_account = new byte[buf.readInt()];
	 buf.readBytes(link_account);
	 new_remark = new byte[buf.readInt()];
	 buf.readBytes(new_remark);

	 Link_set link_set = new Link_set(6);
	 try {
		link_set.setNative_count(new String(native_account,"UTF-8"));
		link_set.setLink_account(new String(link_account,"UTF-8"));
		link_set.setNew_remark(new String(new_remark,"UTF-8"));
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	 
	 list.add(link_set);
}
public void decode_type7(ByteBuf buf, List<Object> list) {
	
	 byte[] native_account = null;
	 byte[] link_account = null;
	 byte[] inform_type = null;
	 
	 native_account = new byte[buf.readInt()];
	 buf.readBytes(native_account);
	 link_account = new byte[buf.readInt()];
	 buf.readBytes(link_account);
	 inform_type = new byte[buf.readInt()];
	 buf.readBytes(inform_type);

	 Link_set link_set = new Link_set(7);
	 try {
		link_set.setNative_count(new String(native_account,"UTF-8"));
		link_set.setLink_account(new String(link_account,"UTF-8"));
		link_set.setInform_type(new String(inform_type,"UTF-8"));
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	 
	 list.add(link_set);
}
public void decode_type8(ByteBuf buf, List<Object> list) {
		
	 byte[] native_account = null;
	 byte[] state = null;
	 
	 native_account = new byte[buf.readInt()];
	 buf.readBytes(native_account);
	 state = new byte[buf.readInt()];
	 buf.readBytes(state);

	 Link_set link_set = new Link_set(8);
	 try {
		link_set.setNative_count(new String(native_account,"UTF-8"));
		link_set.setState(new String(state,"UTF-8"));
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}	 
	
	 list.add(link_set);
}

public void decode_type9(ByteBuf buf, List<Object> list) {
	
	 byte[] native_account = null;
	 byte[] link_account = null;
	 
	 native_account = new byte[buf.readInt()];
	 buf.readBytes(native_account);
	 link_account = new byte[buf.readInt()];
	 buf.readBytes(link_account);
	
	 Link_set link_set = new Link_set(9);
	 try {
		link_set.setNative_count(new String(native_account,"UTF-8"));
		link_set.setLink_account(new String(link_account,"UTF-8"));
		
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	 
	 list.add(link_set);
}
public void decode_type10(ByteBuf buf, List<Object> list) {
	
	 byte[] native_account = null;
	 byte[] remote_ip = null;
	 
	 native_account = new byte[buf.readInt()];
	 buf.readBytes(native_account);
	 remote_ip = new byte[buf.readInt()];
	 buf.readBytes(remote_ip);

	 Link_set link_set = new Link_set(10);
	 try {
		link_set.setNative_count(new String(native_account,"UTF-8"));
		link_set.setRmeote_ip(new String(remote_ip,"UTF-8"));
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}	 
	
	 list.add(link_set);
}
}
