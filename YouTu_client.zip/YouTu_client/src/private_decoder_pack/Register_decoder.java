package private_decoder_pack;

import java.io.UnsupportedEncodingException;

import java.util.List;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import io.netty.handler.codec.MessageToMessageDecoder;
import message_login_register.Register_message;

public class Register_decoder extends ByteToMessageDecoder{
     
	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> list) throws Exception {
	  
		
		buf.readerIndex(0);
		if(buf.readableBytes()==0) {return;}
	//	System.out.println("client Register_decoder capcity: "+buf.readableBytes());
		int protocal_code = buf.readInt();
		if(protocal_code==311) {
		
		int step = buf.readInt();
	//	if(step==1) {decode1(buf, list);}
		if(step==2) {decode2(buf, list);}
	//	else if(step==3) {decode3(buf, list);}
		else if(step==4) {decode4(buf, list);}
		
		}
		else {
			buf.retain();
			ctx.fireChannelRead(buf);
		}
	}

	public void decode1( ByteBuf buf, List<Object> list) {
		
		byte[] email = null;
		byte[] password = null;
		Register_message register_message = null;
		
		email = new byte[buf.readInt()];
		buf.readBytes(email);
		
		password = new byte[buf.readInt()];
	    buf.readBytes(password);
	    
	    try {
			register_message = new Register_message(1, new String(email, "UTF-8"), new String(password, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	
	    list.add(register_message);
	}
	
   public void decode2( ByteBuf buf, List<Object> list) {
		
	    byte[] verify_code = null;
		Register_message register_message = null;
		
		verify_code = new byte[buf.readInt()];
		buf.readBytes(verify_code);
	    
	    try {
			register_message = new Register_message(2, new String(verify_code, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	    
	  
	    list.add(register_message);
	}
   
   public void decode3( ByteBuf buf, List<Object> list) {
	
	   Register_message register_message = null;
	    byte[] head_icon = null;
		byte[] name = null;
		byte[] sex=null;
		byte[] birth=null;
		byte[] blood=null;
		byte[] home=null;
		byte[] phone=null;

		byte[] e_mail=null;
		byte[] signature=null;
		byte[] state=null;
		
		head_icon = new byte[buf.readInt()];
		buf.readBytes(head_icon);
		
		name = new byte[buf.readInt()];
		buf.readBytes(name);
		
		sex = new byte[buf.readInt()];
		buf.readBytes(sex);
		
		birth = new byte[buf.readInt()];
		buf.readBytes(birth);
		
		blood = new byte[buf.readInt()];
		buf.readBytes(blood);
		
		home = new byte[buf.readInt()];
		buf.readBytes(home);
		
		phone = new byte[buf.readInt()];
		buf.readBytes(phone);
		
		e_mail = new byte[buf.readInt()];
		buf.readBytes(e_mail);
		
		signature = new byte[buf.readInt()];
		buf.readBytes(signature);
		
		state = new byte[buf.readInt()];
		buf.readBytes(state);
		
		try {
			register_message = new Register_message(3, head_icon, new String(name, "UTF-8"), new String(sex, "UTF-8"), new String(birth, "UTF-8"), new String(blood, "UTF-8"), new String(home, "UTF-8"), new String(phone, "UTF-8"), new String(e_mail, "UTF-8"), new String(signature, "UTF-8"), new String(state, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
	
		list.add(register_message);
}
   public void decode4( ByteBuf buf, List<Object> list) {
	
	   Register_message register_message = null;
	    byte[] account = null;
		byte[] password = null;	
		byte[] ip = null;
		int port = 0;
		
		account = new byte[buf.readInt()];
		buf.readBytes(account);
		
		password = new byte[buf.readInt()];
		buf.readBytes(password);
		
		ip = new byte[buf.readInt()];
		buf.readBytes(ip);
		
		port = buf.readInt();
		
		try {
			register_message = new Register_message(4, new String(account, "UTF-8"), new String(password, "UTF-8"), new String(ip, "UTF-8"), port);
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		list.add(register_message);
}
}
