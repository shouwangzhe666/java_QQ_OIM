package private_decoder_pack;

import java.util.List;

import Message.Private.Private_Chat_Message;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

public class Private_Chat_Decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> list) throws Exception {
	
		buf.readerIndex(0);
		if(buf.readableBytes()==0) {return;}
		
		int protocol_code = buf.readInt();
		
		if(protocol_code==111) {
			
			    Private_Chat_Message chat_Message  = general_decoder(buf);
				int type = chat_Message.getType();
				
				if(type==1) {
					 byte[] bytes = new byte[buf.readInt()];
				     buf.readBytes(bytes);
					 chat_Message.setBytes(bytes,true);}
				
				else if(type==2) {
					byte[] bytes = new byte[buf.readInt()];
					buf.readBytes(bytes);
					chat_Message.setBytes(bytes,false);}
				
				list.add(chat_Message);	
		}
		else {
			buf.retain();
			ctx.fireChannelRead(buf);
		}
	}
   
	public Private_Chat_Message general_decoder(ByteBuf buf) {
		
		int type = buf.readInt();
		int from_account = buf.readInt();
		int to_account  = buf.readInt();
		long send_time = buf.readLong();
		
		boolean online = buf.readBoolean();
		boolean reply = buf.readBoolean();
		long time_code = buf.readLong();
				
		Private_Chat_Message chat_Message = new Private_Chat_Message(type, from_account, to_account, send_time);
		chat_Message.setOnline(online);
		chat_Message.setReply(reply);
		chat_Message.setTime_code(time_code);
		
		return chat_Message;
	}	
}
