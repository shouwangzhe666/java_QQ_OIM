package private_decoder_pack;

import java.util.List;

import com.sun.jndi.toolkit.ctx.StringHeadTail;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import message_login_register.Ping_Pong;
import tool_Frame.Warn_frame;

public class Ping_Pong_Decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext arg0, ByteBuf buf, List<Object> arg2) throws Exception {
		
		buf.readerIndex(0);
		
		if(buf.readableBytes()==0) {
		   System.out.println("client Ping_Pong_Decoder return;");
			return;}
		
		int pro_code = buf.readInt();
		
		if(pro_code==310) {
		int account = buf.readInt();
		arg2.add(new Ping_Pong());}
		else {
			buf.retain();
			arg0.fireChannelRead(buf);
		}
	}

}
