package Group_chat;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import Frame.File_frame;
import Frame.Group_info_frame;
import Frame.Main_Frame;
import Message.Group.Group_info_message;
import cc.EditDesktop;
import custom_component.Roundrec_button;
import group_info_pane.Group_file_pane;
import tool_Frame.Warn_frame;
import tools.FileUtills;


public class File_send_pane extends JPanel implements ActionListener{

	private static final long serialVersionUID = 1L;
	Socket so =null;
	FileInputStream fileInputStream = null;
	DataOutputStream dataOutputStream=null;
	
	int group_count = 0;
	String file_path = null;
	long file_code = 0l;
	
	String file_name=null;
	long file_lenth = 0l;
	String file_progress_format = "0";
	String file_size = null;
	String speed = "0kb";
	String time_left = "0s";
	
	double file_progress=0;
	double size=0;
	int progress_x=0;
	File file=null;
	RandomAccessFile read_File = null;
	RandomAccessFile write_File = null;
	volatile boolean waiting = true;
	volatile boolean start=true;

	boolean over = false;
	boolean reply = false;
	
	volatile boolean transfer = false;
	Roundrec_button quite_button = null;
	
	int time = 60;
	int port=0;
	Image image = null;
	Font font = null;
	Color blue_color = null;
	
	public File_send_pane(String file_path,String file_name,long send_time,int group_count){
		
		setLayout(null);				 
	    setBackground(Color.LIGHT_GRAY);
		setPreferredSize(new Dimension(400,100));
		setMinimumSize(new Dimension(400,100));
		setMaximumSize(new Dimension(400,100));
		
		Init_content(file_path, file_name, send_time, group_count);
		Init_buttons();
		
		new Timer_thread().start();
	 }
	 
	public void Init_content(String file_path,String file_name,long send_time,int group_count) {
		
		 this.file_path  = file_path;
		 this.file = new File(file_path);
		 this.file_code = send_time;
		 this.group_count = group_count;
		 
		 image = new ImageIcon("tool_image/file_transfer.png").getImage();
		 font = new Font("宋体", Font.PLAIN, 12);
		 blue_color = new Color(18, 183, 245);
		
		 this.file_name=file_name;
		 size=file.length();
		 this.file_lenth = file.length();
		 file_size= FileUtills.file_size_format((long)size);
	}
	
	public void Init_buttons() {
				
		quite_button = new  Roundrec_button(70, 25, 5, new Color(0, 180, 245), "取消", 14, Color.white);		
		quite_button.setBounds(320,75,70, 25);
		super.add(quite_button);
		quite_button.addActionListener(this);
		
	}
		
	 public void start_transfer(Group_info_message group_info_message) {
		
		 String ip_port = group_info_message.getIp_port();
		 String ip = ip_port.split(",")[0];
		 int port = Integer.parseInt(ip_port.split(",")[1]);
		 
		 System.out.println("start_group_Sendfile ip_port:"+ip_port);
		 
		 reply = true;
		 transfer = true;
		 
		 start = true;
		 waiting = false;
		 
		 String desktopImage_path = EditDesktop.get_DesktopBackground();
		 String dir = new File(desktopImage_path).getParentFile().getAbsolutePath();
		 String nati_filePath = dir+"\\"+file_name;
		 FileUtills.create_new_file(nati_filePath);
		 
		 try {
			 read_File =  new RandomAccessFile(file, "rw");
			 write_File = new RandomAccessFile(new File(nati_filePath), "rw");
		} catch (FileNotFoundException e2) {
			// TODO AYouTu-generated catch block
			e2.printStackTrace();
		}
		 
		  try {
	//		so = new Socket(InetAddress.getByName("25488m1i23.wicp.vip"), 54907);
			so = new Socket(InetAddress.getByName(ip), port);
		} catch (UnknownHostException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
		  
		  try {
			dataOutputStream = new DataOutputStream(so.getOutputStream());
		} catch (IOException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
		  
		  new File_transfer_thread().start();  // 开启文件发送线程
		  new Transfer_speed_thead().start();		  
		  
	 } // start_transfer
	 
	 
	 @Override
		protected void paintComponent(Graphics g) {
			// TODO AYouTu-generated method stub
			super.paintComponent(g);
	
			Graphics2D g2 =(Graphics2D) g;
			
			g2.setColor(new Color(230, 230, 230));
			g2.fillRect(0, 60, 400, 10);

			g2.drawImage(image, 5, 5, null);
			
			g2.setColor(blue_color);
			g2.fillRect(0, 60, progress_x, 10);
			
			g2.setColor(Color.BLACK);
			g2.setFont(font);
			
			g2.drawString("文件："+file_name, 30, 15);
			g2.drawString("大小："+file_progress_format+"/"+file_size,250, 15);
			
			if(waiting) {g2.drawString("等待中...     "+time+"s", 150, 90);}
			else {
			
				g2.drawString("速度："+speed+"/s",250, 40);
				g2.drawString("预估剩余："+time_left, 30, 40);
			}
		}
	 
	 public void File_termination_manager() {
		 
		 // 文件发送中断处理 （文件线程结束后）
		 		 
		 if(over) {
			 String sender = Main_Frame.getMessage_pane().get_link_info(String.valueOf(group_count)).getSignature();
			 
			 ArrayList<Object> f = new ArrayList<>();
			 f.add(file_name);
			 f.add(file_lenth);
			 f.add(sender);
			 f.add(file_code);
			 
			Group_file_pane file_pane = Group_info_frame.get_file_pane();
			file_pane.put_file(f);
			file_pane.update_forTime();
		     
//		     Play_sound.play_message_sound();
		     new Warn_frame("提示","文件上传完成！").set_aYouTu_click(3);
		     
			} // if over
		 
		 else {  new Warn_frame("提示","文件上传失败！").set_aYouTu_click(3);}		 
		 
			try {
				dataOutputStream.close();
				so.close();
			} catch (IOException e) {
				return;
			}
			
			 try {
					read_File.close();
					write_File.close();
				} catch (IOException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
			 
			 
			 File_frame.remove_file_pane(file_code);			
		
	 }
	 
	 private class File_transfer_thread extends Thread{
		 
		 // 文件发送线程
		 
		 int len=0;
		 byte[] by = new byte[10240];
			
		 @Override
		public void run() {
							
				while(start) {
					
					try {
						if((len=read_File.read(by))!=-1) {

							dataOutputStream.write(by,0,len);
							write_File.write(by, 0, len);
							
							file_progress+=len;
					//		System.out.println("len: "+len);		
						}
						else {							
							 over=true;
							 break;
						}
					} catch (IOException e) {
						// TODO AYouTu-generated catch block
						e.printStackTrace();
						start = false;
						break;
					}
					
				}  // while !quite
				
				File_termination_manager();
			 
		} // run
	 }
	 
	 private class Transfer_speed_thead extends Thread{
		 
		  // 文件传输速度测试线程
		 
		 @Override
		public void run() {

			    double bin=0l;
				long total=0l;
				long time = 0l;
				
					while(true) {
						
						if(file_progress>file.length()) {file_progress = file.length();}
						
						file_progress_format = FileUtills.file_size_format((long) file_progress);
						double par = file_progress/size;
						progress_x=(int) (400*par);
						
						bin=file_progress;
						
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							// TODO AYouTu-generated catch block
							e.printStackTrace();
						}
						
						total=(long) (file_progress-bin);
						if(total==0) {continue;}
						
						speed = FileUtills.file_size_format(total);
						
						time=(long) ((size-file_progress)/total);
		
						time_left = time_format(time);
						
						repaint();
						
						if(!start||over) {break;}
						
					}  // while true

		} // run
	 }
	 
	 private class Timer_thread extends Thread{
         
			
			@Override
			public void run() {
				
				while(time>0) {
					
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO AYouTu-generated catch block
						e.printStackTrace();
					}
					if(over) {break;}
					repaint();
					time--;
				}
				
				if(!reply) {
					
					File_frame.remove_file_pane(file_code);
				}
			}
		}
    
	public String time_format(long time) {
		
		if(time<60) {return time+"s";}
		
		else if(time<3600) {
			long m = time/60;
			long s = time%60;
			return m+"分"+s+"秒";
        }
		else {
			long h = time/3600;
			long m = (time%3600)/60;
			return h+"小时"+m+"分";
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
	
		 if(e.getSource()==quite_button) {
			if(transfer) {start = false;}
			else { File_frame.remove_file_pane(file_code);}
		}
	}
	
	public static void main(String[] args) {
		
		 String file_path = "C:\\ProgramData\\Users\\Administrator\\Desktop\\视频.temp";
		 String path = "C:\\ProgramData\\Users\\Administrator\\Desktop\\视频.zip";
		 System.out.println(new File(file_path).length());
	}
}
