package Group_chat;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JScrollBar;
import Frame.Main_Frame;
import Item.Group_Chat_Item;
import Item.Private_Chat_Item;
import Message.Group.Group_chat_message;
import Message.Private.Private_Chat_Message;
import custom_component.My_ScrollPane;
import ss.Group_Chat_Client;
import tool_Frame.Warn_frame;
import tools.Icon_tools;
import tools.My_Object_IO;

public class Group_show_pane extends My_ScrollPane {
    
	Dimension dimension = null;
	int type = 0;
	int all_y = 0;
	int[]po_x=null;
	int[]po_y=null;
	
	HashMap<Long,Group_Chat_Item> all_chat_item = null;
	HashMap<Integer,Image> all_image = null;
	ArrayList<Object> row_list=null;
	HashMap<Long, ArrayList<Object>> all_dataArrayList=null;	
	
	 int h = 0;
	 long send_time = 0l;
	 String file_path = null;
   	 
	 Font font = null;
	 Write_pane write_pane = null;	 
	 Cursor cursor = null;
	 Main_Show_pane main_Show_pane = null;
	 
	 SimpleDateFormat dateFormat = null;
	 SimpleDateFormat timeFormat = null;
	 SimpleDateFormat datetimeFormat = null;
	 
	 int group_account = 0;
	 String native_id = null;
	 
	public Group_show_pane(int group_account,String ip_port,String native_id, Write_pane write_pane) {
	
		this.group_account = group_account;
		this.native_id = native_id;
		dimension = Toolkit.getDefaultToolkit().getScreenSize();
		
		setPreferredSize(new Dimension(500,330));
		setMinimumSize(new Dimension(500, 330));
		setMaximumSize(dimension);	
		
		Init_content(group_account, native_id, write_pane);
		
		main_Show_pane = new Main_Show_pane(this);
		setViewportView(main_Show_pane);
		
		load_all_chat_content();

	}
		
	public void Init_content(int group_account,String native_id, Write_pane write_pane) {
		
		this.group_account = group_account;
		this.native_id = native_id;
		this.write_pane = write_pane;
		font = new Font("宋体", Font.PLAIN, 12);
		cursor = new Cursor(Cursor.DEFAULT_CURSOR);
		
		file_path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\chat_history\\group_chat\\"+group_account+".db";
		
		po_x=new int[3];
		po_y=new int[3];
		
		dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		timeFormat = new SimpleDateFormat("HH:mm:ss");
		datetimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		all_image = new HashMap<>();
		all_chat_item = new HashMap<>();
		all_dataArrayList = new HashMap<>();
				
		byte[] self_by = Icon_tools.get_IconBytes(Integer.parseInt(Main_Frame.getNative_count()));	
		Image self_icon = new ImageIcon(self_by).getImage();	
		
		all_image.put(Integer.parseInt(Main_Frame.getNative_count()), self_icon);
	}		
 
	public void update_group_head_icon(int member_account,byte[] icon_bytes) {
		
		 main_Show_pane.update_group_head_icon(member_account, icon_bytes);
	}
	public void update_group_member_remark(int member_account,String member_remark) {
		
		 main_Show_pane.update_group_member_remark(member_account, member_remark);
	}
 public void put_chat_Message(Group_chat_message chat_message,boolean save) throws IOException {
	 
		boolean self = false;
		int member_account = chat_message.getMember_account();
		String id = chat_message.getGroup_id();
		String group_remark = chat_message.getGroup_remark();
		
		// check the member'head_image
		if(all_image.get(member_account)==null) {
			byte[] member_byte =  Icon_tools.get_IconBytes(member_account);
			Image image = new ImageIcon(member_byte).getImage();
			all_image.put(member_account, image);
		}
		
		if(String.valueOf(member_account).equals(Main_Frame.getNative_count())) {self = true;}
		
		Group_Chat_Item chat_Item = new Group_Chat_Item(group_account, native_id, chat_message, write_pane, this);
//		String content = chat_Item.get_popu_message();
		long send_time = chat_message.getSend_time();
		
		if(send_time-this.send_time>120000) {      // draw time_Item
			
			all_y+=30;
			boolean today = dateFormat.format(new Date()).equals(dateFormat.format(send_time));
			
			row_list = new ArrayList<Object>();
			row_list.add(8);
			row_list.add(today);
			row_list.add(send_time);
			row_list.add(all_y-20);			
			
			all_dataArrayList.put(send_time-100, row_list);
			
		}
		
		this.send_time = send_time;
		
	    write_chat_message(chat_message, save);
	   
		all_chat_item.put(send_time, chat_Item);
		
		int w=chat_Item.get_total_width();
		h=chat_Item.get_total_height();
		
		int x = 0;
		if(self) {x = getWidth()-55-w;}
		else {x= 55;}
	    
		row_list = new ArrayList<Object>();
		row_list.add(chat_message.getType());
		row_list.add(self);
		row_list.add(x);
		row_list.add(all_y);
		row_list.add(w);
		row_list.add(h);
		
		row_list.add(member_account);
		row_list.add(id);
		row_list.add(group_remark);
		
		all_dataArrayList.put(send_time, row_list);
		
		chat_Item.setBounds(x, all_y, w, h);	
		main_Show_pane.add(chat_Item);
		
		all_y+=h+15;
	
		update(getGraphics());
			     
				if(save&&get_difference_value()<50) {
				 int maxHeight = getVerticalScrollBar().getMaximum();  
		         getViewport().setViewPosition(new Point(0, maxHeight));  
		      
			   }
        
	    if(save) {check_history_size();}
	}
 
 public void remove_Item(Group_chat_message chat_Message,boolean save) throws IOException {
		
		long time_code = chat_Message.getTime_code();
		
		Group_Chat_Item item = all_chat_item.get(time_code);
		if(item==null) {return;}
		
		main_Show_pane.remove(item);		
		all_chat_item.remove(time_code);
		
		write_chat_message(chat_Message, save);
		
		row_list = all_dataArrayList.get(time_code);
		row_list.set(0, 3);
		row_list.set(1, chat_Message.get_popu_message());
		row_list.set(2, all_y);
		
		all_y+=30;
		
		update(getGraphics());
	}
 
 public void update_shutup(Group_chat_message chat_message,boolean save) {
	 
	 int member_account = chat_message.getMember_account();
	 boolean shutup = chat_message.isOpen_shutup();
	 
	 for(Group_Chat_Item item:all_chat_item.values()) {
		 
		if(item.get_member_account()==member_account) { item.set_shutup(shutup);}
	 }
	 
	write_chat_message(chat_message, save);
	
	row_list = new ArrayList<>();
	row_list.add(4);
	row_list.add(chat_message.get_popu_message());
	row_list.add(all_y);
	
	all_y+=30;
	
	long send_time = chat_message.getSend_time();
	all_dataArrayList.put(send_time, row_list);
	
	update(getGraphics());
    
	if(save&&get_difference_value()<50) {
	 int maxHeight = getVerticalScrollBar().getMaximum();  
     getViewport().setViewPosition(new Point(0, maxHeight));  
  
   }
 }
 
public void update_id(Group_chat_message chat_message,boolean save) {
	
	int member_account = chat_message.getMember_account();
	int nati_account = Integer.parseInt(Main_Frame.getNative_count());
	String group_id = chat_message.getGroup_id();
	 
	if(member_account==nati_account) {this.native_id = group_id;}
	
	 for(Group_Chat_Item item:all_chat_item.values()) {
		 
		if(member_account==item.get_member_account()) {item.set_groupid(group_id);}
		if(member_account==nati_account) {item.set_nativeid(group_id);}
	 }
	 
	 write_chat_message(chat_message, save);
	 
	    row_list = new ArrayList<>();
		row_list.add(chat_message.getType());
		row_list.add(chat_message.get_popu_message());
        row_list.add(all_y);
		
		all_y+=30;
		
		long send_time = chat_message.getSend_time();
		all_dataArrayList.put(send_time, row_list);
		
		update(getGraphics());
	     
		if(save&&get_difference_value()<50) {
		 int maxHeight = getVerticalScrollBar().getMaximum();  
         getViewport().setViewPosition(new Point(0, maxHeight));  
      
	   }
 }

public void remove_member(Group_chat_message chat_message,boolean save) {
	
	   write_chat_message(chat_message, save);
	 
	    row_list = new ArrayList<>();
		row_list.add(7);
		row_list.add(chat_message.get_popu_message());
        row_list.add(all_y);
		
		all_y+=30;
		
		long send_time = chat_message.getSend_time();
		all_dataArrayList.put(send_time, row_list);
		
		update(getGraphics());
	     
		if(save&&get_difference_value()<50) {
		 int maxHeight = getVerticalScrollBar().getMaximum();  
         getViewport().setViewPosition(new Point(0, maxHeight));  
      
	   }
}

	public void delete_screen() {
	    
	    try {
			new FileOutputStream(new File(file_path), false).close();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		};
		
		main_Show_pane.removeAll();
		
	    all_chat_item = new HashMap<>();
	    all_dataArrayList = new HashMap<>();	    
	    all_y = 0;
	    
	    main_Show_pane.delete_screen();
	    
	    main_Show_pane.repaint();
		
		main_Show_pane.setPreferredSize(new Dimension(getWidth(), 0));
		main_Show_pane.setMinimumSize(new Dimension(getWidth(), 0));
		main_Show_pane.setMaximumSize(new Dimension(getWidth(),0));
		
		new Warn_frame("提示", "清屏后相关聊天记录将会同步删除").set_aYouTu_click(3);
	}	
	
	public void write_chat_message(Group_chat_message chat_Message,boolean save) {
		
//		if(!save) {return;}
//		
//		ObjectOutputStream objectOutputStream  = My_Object_IO.get_ObjectoutputStream(file_path, true);
//		try {
//			objectOutputStream.writeObject(chat_Message);
//			objectOutputStream.flush();
//			objectOutputStream.close();
//		} catch (IOException e) {
//			// TODO AYouTu-generated catch block
//			e.printStackTrace();
//		}		
	}
	
	public int get_all_y() {
		return all_y;
	//	return main_Show_pane.getHeight();
	}
	
public void check_history_size() {
		
	     int max_size = 50;
	     
		if(all_chat_item.size()>max_size) {
			long[] all_code = get_sorted_array(all_dataArrayList.keySet());
			long code = 0l;
			Group_Chat_Item chat_Item = null;
			
			for(int i=0;i<all_code.length-max_size;i++) {
				code = all_code[i];
				chat_Item = all_chat_item.get(code);
				
				if(chat_Item==null) {continue;}
				
				main_Show_pane.remove(chat_Item);
				all_chat_item.remove(code);
				all_dataArrayList.remove(code);
			}
			
			main_Show_pane.repaint();
		} // if size>10
	}
	public long[] get_sorted_array(Set<Long> set) {
		
		Iterator<Long> it = set.iterator();
		long value = 0l;
				
		long[] all_int = new long[set.size()];
		
		int i = 0 ;
		while(it.hasNext()) {
			
			value = it.next();
			all_int[i] = value;
			i++;
		}
		
		Arrays.sort(all_int);
		
		return all_int;
	}
public void load_all_chat_content() {
		
        File f = new File(this.file_path);
		
		if(!f.exists()||f.length()<5) {return;}
		     
		     int type = 0;
			 ObjectInputStream objectInputStream = My_Object_IO.get_ObjectInputStream(file_path);
			 Group_chat_message chat_Message = null;
			 ArrayList<Group_chat_message> all_message = new ArrayList<>();
			 int max_size = 50;
			
       while(true) {
				 
				 try {
					chat_Message = (Group_chat_message) objectInputStream.readObject();
					all_message.add(chat_Message);
				
				} catch (ClassNotFoundException e) {
				//	e.printStackTrace();
					break;
				} catch (IOException e) {
				//	e.printStackTrace();
					break;
				}
				
       }
             
       if(all_message.size()>max_size) {
    	   ArrayList<Group_chat_message> all = new ArrayList<>();
    	   ObjectOutputStream objectOutputStream = My_Object_IO.get_ObjectoutputStream(file_path, false);
    	 
    	    for(int i=all_message.size()-max_size;i<all_message.size();i++) {
    	    	
    	    	chat_Message = all_message.get(i);
    	    	all.add(chat_Message);
    	    	try {
					objectOutputStream.writeObject(chat_Message);
				} catch (IOException e) {
					e.printStackTrace();
				}
    	    }
    	    all_message = all;
    	    all = null;
    	    try {
				objectOutputStream.close();
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
       }
			
            for(int i=0;i<all_message.size();i++) {
            	
            	 chat_Message = all_message.get(i);				
				 type = chat_Message.getType();
				 
				 try {
					 if(type==1||type==2) {put_chat_Message(chat_Message, false);}
					 else if(type==3) {remove_Item(chat_Message, false);}
					 else if(type==4) {update_shutup(chat_Message,false);}
					 else if(type==5||type==6) {update_id(chat_Message, false);}
					 else if(type==7) {remove_member(chat_Message, false);}
				} catch (Exception e) {
					e.printStackTrace();
				
				}				
				} // while	
            
            all_message = null;
	}

public void lock_location(long time_code) {
		
		ArrayList<Object> row_list =  all_dataArrayList.get(time_code);
		
		if(row_list==null) { 
		int maxHeight = getVerticalScrollBar().getMaximum();  
        getViewport().setViewPosition(new Point(0, maxHeight));  return;}
		
		int y = (int) row_list.get(3);
		getVerticalScrollBar().setValue(y);
		
	}
public int get_difference_value() {
	
	  JScrollBar scrollBar = getVerticalScrollBar();
      int difference_value = main_Show_pane.getHeight()-scrollBar.getValue()-getHeight()-h;
      
      return difference_value;
}

public int get_difference_height() {
	
	return main_Show_pane.getHeight()-getHeight();
}
}