package Group_chat;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

public class Tip_Bottom_pane extends JPanel{

	String remark = null;
	String content = null;
	boolean tip_message = true;
	Group_show_pane show_pane = null;
	
	public Tip_Bottom_pane(Group_show_pane show_pane) {
		
		   setVisible(false);
	       setLayout(new BorderLayout());
	       setBackground(new Color(0,181, 245));
	       this.show_pane = show_pane;
	       
	        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			setPreferredSize(new Dimension(430, 26));
			setMinimumSize(new Dimension(430, 26));
			setMaximumSize(new Dimension(dimension.width,26));
			
			Init_mouselistioner();
	}
	
	public void Init_mouselistioner() {
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				 show_pane.lock_location(0l);
				 setVisible(false);
			}
		});
	}
	public void load_message(String content) {
		
		setVisible(true);
		tip_message = true;
		removeAll();
		this.content = content;
		repaint();
	}
	
	public void load_audio() {
		
		setVisible(true);
		tip_message = false;
		
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		if(!tip_message) {return;}
		if(content==null) {return;}
		
		g2.setColor(new Color(50,50, 50));
		g2.setFont(new Font("宋体",Font.PLAIN,14));
		g2.drawString(content,20,20);
	}
}
