package Group_chat;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;

import custom_component.Box_pane;
import custom_component.Roundrec_button;

public class Send_pane extends Box_pane implements ActionListener{

	Dimension dimension = null;
	int width = 0 ;
	Roundrec_button send_button = null;
	Write_pane write_pane = null;
	Cursor cursor = null;
	
	public Send_pane(Write_pane write_pane) {
		super(BoxLayout.X_AXIS);
		
		cursor = new Cursor(Cursor.DEFAULT_CURSOR);
		this.write_pane = write_pane;
		setOpaque(false);
		dimension = Toolkit.getDefaultToolkit().getScreenSize();
		width = (int) dimension.getWidth();
		setPreferredSize(new Dimension(400, 40));
		setMinimumSize(new Dimension(400, 40));
		setMaximumSize(new Dimension(width, 40));
	
		send_button   = new  Roundrec_button(70, 25, 5, new Color(0, 180, 245), "发送", 14, Color.white);
		
		add(Box.createHorizontalGlue());
		
		add(send_button);
		add(Box.createHorizontalStrut(15));
		
		send_button.addActionListener(this);
		
		addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				setCursor(cursor);
			};
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		 if(e.getSource()==send_button) {
			 write_pane.Send_message();}
	}

}
