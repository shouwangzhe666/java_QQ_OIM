package Group_chat;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import Item.W_pane;
import custom_component.My_ScrollPane;

public class Face_pane extends My_ScrollPane{

	  boolean entered=false;
	  JPopupMenu popupMenu=null;
	  W_pane write_pane = null;
	 
	public  Face_pane(JPopupMenu popupMenu, W_pane write_pane) {
		
		setOpaque(true);
		
	    this.popupMenu=popupMenu;
	    this.write_pane = write_pane;
		
	    getVerticalScrollBar().setBlockIncrement(160);
		getVerticalScrollBar().setUnitIncrement(160);
		
		setPreferredSize(new Dimension(370,160));
		setMinimumSize(new Dimension(370,160));
		setMaximumSize(new Dimension(370,160));
		 
		 Face_Icon_pane face_Icon_pane = new Face_Icon_pane();
	     setViewportView(face_Icon_pane);
		
	}
	
	private class Face_Icon_pane extends JPanel{
		
		public Face_Icon_pane() {
			
		//	setOpaque(false);
			setBackground(Color.WHITE);
			setPreferredSize(new Dimension(360,320));
			setMinimumSize(new Dimension(360,320));
			setMaximumSize(new Dimension(360,320));
			
			setLayout(new GridLayout(8, 9));
			
			for(int i =1;i<73;i++) {
				Face_pane_button f = new Face_pane_button(i);
				super.add(f);
			}
		}
	}
	
	private class Face_pane_button extends  JButton{
		
		ImageIcon i1 =null;
		
		private Face_pane_button(int num) {
			
			setContentAreaFilled(false);
			setOpaque(false);
			setBackground(Color.WHITE);
			setBorderPainted(false);
			setBorder(null);
			
			i1 = new ImageIcon(getClass().getResource("/little_emoji/"+num+".png"));		
			setIcon(i1);
			
			setPreferredSize(new Dimension(30,30));
			setMinimumSize(new Dimension(30,30));
			setMaximumSize(new Dimension(30,30));
			
			addMouseListener(new MouseAdapter() {
				
				@Override
				public void mouseEntered(MouseEvent e) {
					setOpaque(true);
					setBackground(new Color(230,230,230));
					
				}
				
				
				public void mouseExited(MouseEvent e) {
					setOpaque(false);
					setBackground(Color.WHITE);
				}; 
				
			});
			
			addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
				
					setBackground(Color.WHITE);
				//	popupMenu.setVisible(false);
					write_pane.Insert_face(i1);
				}
			});
		}
		
	}
}
