package Group_chat;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import Item.File_Item;
import Item.Group_Chat_Item;
import sun.swing.SwingUtilities2;
import tools.Icon_tools;

public class Main_Show_pane extends JPanel{
	
    /**
     * all_dataArrayList
     * 
     * type1  图文
     * type2  图片
     * type3  撤销
     * type4  禁言
     * type5  管理员
     * type6  封ID
     * type7  踢出
     * type8  时间
     */
	
	Color oval_color = null;
	int all_y = 0;
	int[]po_x=null;
	int[]po_y=null;
	
	HashMap<Integer,Image> all_image = null;
	HashMap<Long, Group_Chat_Item> all_chat_item = null;
	
	ArrayList<Object> row_list=null;
	HashMap<Long, ArrayList<Object>> all_dataArrayList=null;
	
	 SimpleDateFormat dateFormat = null;
	 SimpleDateFormat timeFormat = null;
	 SimpleDateFormat datetimeFormat = null;
	 Font font = null;
	 Color red_color = null;
	 Color green_color = null;
	 Group_show_pane group_show_pane = null;
	 
	public Main_Show_pane( Group_show_pane group_show_pane) {
		
		setOpaque(false);
		setLayout(null);
		oval_color = new Color(230, 230, 230);
		red_color = new Color(252,104,87);
		green_color = new Color(52,202,120);
		this.group_show_pane = group_show_pane;
		
		Init_content();
	}
	
	public void Init_content() {
		
		font = new Font("宋体", Font.PLAIN, 12);
		this.all_y = group_show_pane.all_y;
		this.po_x = group_show_pane.po_x;
		this.po_y = group_show_pane.po_y;
		
		this.all_image = group_show_pane.all_image;
		this.all_chat_item = group_show_pane.all_chat_item;
		this.all_dataArrayList = group_show_pane.all_dataArrayList;
		
		this.dateFormat = group_show_pane.dateFormat;
		this.datetimeFormat = group_show_pane.datetimeFormat;
		this.timeFormat = group_show_pane.timeFormat;
		
	}
	
	public void update_group_head_icon(int member_account,byte[] icon_bytes) {
		
		Image image = new ImageIcon(icon_bytes).getImage();
		all_image.remove(member_account);
		all_image.put(member_account, image);
		
	    repaint();
	}
	
	public void update_group_member_remark(int member_account,String member_remark) {
		
		for(ArrayList<Object> arrayList:all_dataArrayList.values()) {
			int type = (int) arrayList.get(0);
			if(type==1||type==2){
				int member_count = (int) arrayList.get(6);
				if(member_count==member_account) {arrayList.set(8, member_remark);}
			}					
		}
		
	    repaint();
	}
	
	@Override
	protected void paintComponent(Graphics g) {		
	//	super.paintComponent(g);
	    Graphics2D g2 = (Graphics2D) g;
	    
	    update_all();
	    
	    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	    g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		g2.setColor(Color.LIGHT_GRAY);
		g2.setFont(font);
		
		Set<Long> set = all_dataArrayList.keySet();
		long[] all_key = get_sorted_array(set);
		
	    long key = 0;
	    int type = 1;
	    
		for(int i=0;i<all_key.length;i++) {
			
			key = all_key[i];
		
			row_list = all_dataArrayList.get(key);
		    type = (int) row_list.get(0);
          
           if(type==1||type==2) {draw_normal_bubble(g2);}
           else if(type==8) {draw_time_bubble(g2);}
           else {draw_oval_bubble(g2);}
                     
		}// for
	
}
public void update_all() {
		
		int chat_width = group_show_pane.getWidth();
		
		setSize(chat_width, all_y);
				
		Set<Long> set = all_dataArrayList.keySet();
		long[] all_key = get_sorted_array(set);
		if(all_key.length==0) {return;}

			all_y = 0;
			long key  = 0;
			int type = 1;
			Object object = null;
					
		for(int i=0;i<all_key.length;i++) {
				
				key = all_key[i];
				row_list = all_dataArrayList.get(key);
				type = (int) row_list.get(0);
							
			   if(type==1)	{object = all_chat_item.get(key);update_chat_Item(object);}
			   else if(type==2) {object = all_chat_item.get(key);update_Icon_Item(object);}
			   else if(type==8) {update_time_Item();}
			   else{update_oval_Item();}			  
				
			}  //for

		  setPreferredSize(new Dimension(getWidth(),all_y));
		  setMinimumSize(new Dimension(getWidth(),all_y));
		  setMaximumSize(new Dimension(getWidth(),all_y));
		   
		}


		public void update_chat_Item(Object object) {
		  
		    Group_Chat_Item chat_Item = (Group_Chat_Item) object;
		    
		    chat_Item.update_Chat_Item(getWidth());
			
		    int x = 0;
			int w=chat_Item.get_total_width();
			int h=chat_Item.get_total_height();
			
			boolean self = (boolean) row_list.get(1);
			if(self) {x = getWidth()-w-55;}
			else {x = 55;}
			
			row_list.set(2, x);
		    row_list.set(3, all_y);
			row_list.set(4, w);
			row_list.set(5, h);
			
			if(self) {chat_Item.setBounds(x, all_y, w, h);all_y+=h+25;}
			else{chat_Item.setBounds(x, all_y+15, w, h);all_y+=h+25+16;}
								
		}

		public void update_Icon_Item(Object object) {
		 
		    Group_Chat_Item chat_Item = (Group_Chat_Item) object;
		    
		    chat_Item.update_Chat_Item(getWidth());
			
		    int x = 0;
			int w=chat_Item.get_total_width()+20;
			int h=chat_Item.get_total_height()+20;
			
			boolean self = (boolean) row_list.get(1);
			if(self) {x = getWidth()-w-55-20;}
			else {x = 50;}
			
			row_list.set(2, x);
		    row_list.set(3, all_y);
			row_list.set(4, w);
			row_list.set(5, h);
			
			if(self) {chat_Item.setBounds(x+25, all_y+10, w-20, h-20);all_y+=h+25;}
			else {chat_Item.setBounds(x+10, all_y+10+15, w-20, h-20);all_y+=h+25+16;}
			
		}
		
		public void  update_oval_Item() {
		 
		   row_list.set(2, all_y);
		   all_y+=30;
		}

		public void update_time_Item() {
		 
		   all_y+=30;
		   row_list.set(3, all_y-20);
		 
		}
		
		
		
public void draw_normal_bubble(Graphics2D g2) {
    
   // 适用于除撤回消息以外的其他一切气泡
 
 boolean isself=(boolean) row_list.get(1);
 int y = (int) row_list.get(3);
 int rec_width=(int) row_list.get(4);
 int rec_height=(int) row_list.get(5);
 
 int member_account = (int) row_list.get(6);
 String id = (String) row_list.get(7);
 String group_remark = (String) row_list.get(8);
 
 Image head_image = all_image.get(member_account);

if(isself) {
	po_x[0]=po_x[1]=getWidth()-60;po_x[2]=getWidth()-55;
	po_y[0]=y+5;po_y[1]=y+15;po_y[2]=y+10;
	
	g2.setColor(Color.green);
	g2.fillRoundRect(getWidth()-60-rec_width, y, rec_width, rec_height,10,10);
	g2.fillPolygon(po_x, po_y, 3);
	g2.drawImage(head_image, getWidth()-50, y, null);
	
}

else {
	po_x[0]=45; po_x[1]=po_x[2]=50;
	po_y[0]=y+10+15;po_y[1]=y+5+15;po_y[2]=y+15+15;
	
	g2.setColor(Color.white);
	g2.fillRoundRect(50, y+15, rec_width, rec_height,10,10);
	g2.fillPolygon(po_x, po_y, 3);
	
	g2.drawImage(head_image, 5, y, null);
	
	    
	if(id.equals("成员")) {
		g2.setColor(Color.gray);
		g2.drawString(group_remark,60, y+8);
	} // 成员
	else if(id.equals("群主")) {
		g2.setColor(red_color);
		g2.fillRect(0, y-18, 30, 15);
		g2.setColor(Color.white);
		g2.drawString("群主",3, y-7);
		g2.setColor(Color.gray);
		g2.drawString(group_remark,60, y+8);
	} // 成员
	else {
		g2.setColor(green_color);
		g2.fillRect(0, y-18, id.length()*14, 15);
		g2.setColor(Color.white);
		g2.drawString(id,3, y-7);
		g2.setColor(Color.gray);
		g2.drawString(group_remark,60, y+8);
	}
}
}

public void draw_oval_bubble(Graphics2D g2) {
 
 String text = (String) row_list.get(1);
 int  y = (int) row_list.get(2);
 
 int string_len = text.length()*14;
 int center_x = (getWidth()-string_len)/2;
 
   g2.setColor(oval_color);
   g2.fillRoundRect(center_x, y, string_len, 20,10,10);
   
   g2.setColor(Color.BLACK);
   g2.drawString(text, center_x+11, y+14);
  
}

public void draw_time_bubble(Graphics2D g2) {
 
 String remark = null;
 boolean today = (boolean) row_list.get(1);
 long that_time = (long) row_list.get(2);
 int string_len = 0 ;
 
if(today) {
	remark = timeFormat.format(that_time);
	string_len = remark.length()*9;
}
else {
	remark = datetimeFormat.format(that_time);
	string_len = remark.length()*7;
}

 int center_x = (getWidth()-string_len)/2;
 int y = (int) row_list.get(3);
 
   g2.setColor(oval_color); 
   g2.fillRoundRect(center_x, y, string_len, 17,10, 10);
   
   g2.setColor(Color.BLACK);
   g2.drawString(remark, center_x+10, y+13);
  
}

public void delete_screen() {
	
	 this.all_y = group_show_pane.all_y;
	 all_chat_item = group_show_pane.all_chat_item;
	 all_dataArrayList = group_show_pane.all_dataArrayList;
}

public long[] get_sorted_array(Set<Long> set) {
	
	Iterator<Long> it = set.iterator();
	long value = 0l;
			
	long[] all_int = new long[set.size()];
	
	int i = 0 ;
	while(it.hasNext()) {
		
		value = it.next();
		all_int[i] = value;
		i++;
	}
	
	Arrays.sort(all_int);
	
	return all_int;
}
} //Main_Show_pane

