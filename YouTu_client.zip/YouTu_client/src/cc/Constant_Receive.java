package cc;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import com.sun.image.codec.jpeg.ImageFormatException;
import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;

import Frame.Only_frame;
import VA_Pack_UDP.Audio_Chat;
import cc.EditDesktop;
import tcp_pack.TCP_P2P_Pointer;
import tool_Frame.Warn_frame;
import java.net.*;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JPanel;

import custom_component.Roundrec_button;
public class Constant_Receive extends Thread{

	Robot robot=null;
	Rectangle rectangle=null;
	int width = 0;
	int height = 0;
	ServerSocket serverSocket=null;
	Socket socket=null;
	
	JPEGImageEncoder encoder=null;
	DataInputStream dataInputStream = null;
	DataOutputStream dataOutputStream = null;

	volatile BufferedImage last_image1 = null;
	volatile BufferedImage last_image2 = null;
	 volatile boolean start = true;
	 long time = 0;
	 
	 Only_frame only_frame = null;
	 Show_pane show_pane = null;
	 int p2p_type = 1;
	 int server_port = 0;
	 ConstantQuite_KeyListioner constantQuite_KeyListioner = null;
	/**
	 * mode_1  Mouse_pressed  动态抓取
	 * mode_2  Mouse_released/Enter_leased 全屏抓去
	 * mode_3  Key_released   横条抓取
	 * @param remote_ip
	 */
	public Constant_Receive(int p2p_type,int server_port) {
		this.p2p_type = p2p_type;
		this.server_port = server_port;
	}	
	public void Init_frame() {
		
		show_pane = new Show_pane();
		new Thread(show_pane).start();
		
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (int) ((dimension.getWidth()-600)/2);
	    only_frame = new Only_frame(show_pane,40);
	//	only_frame.set_Size(true,600, 100);
	    only_frame.set_Bounds(x, 10,600, 100);
		only_frame.set_Title("正在被对方远程控制",new Font("微软雅黑", Font.PLAIN, 20), new Color(0, 131, 253));
		only_frame.get_max_button().setVisible(false);
		only_frame.get_min_button().setVisible(false);
		
		only_frame.set_Resizable(false);
		only_frame.setVisible(true);
		only_frame.setAlwaysOnTop(true);
		
		only_frame.change_quite_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				close_constant();
			}
		});
	}
	
	public void Init_keyListioner() {
		
		constantQuite_KeyListioner = new ConstantQuite_KeyListioner(this);
		constantQuite_KeyListioner.startListion();
	}
	
  public void close_constant() {
	  
	  Audio_Chat.ReleaseVAOccupy();
	  
	  try {
			 dataOutputStream.close();
			 dataInputStream.close();
			 if(!socket.isClosed()) {socket.close();}
			
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		start = false;
		constantQuite_KeyListioner.stopListion();
		only_frame.dispose();
	}
	@Override
	public void run() {
		
		if(p2p_type==1||p2p_type==2) {
			  TCP_P2P_Pointer p2p_Pointer = new TCP_P2P_Pointer("TCP_Pointer", server_port);
			  p2p_Pointer.start();
			  socket = p2p_Pointer.get_socket(60);
			}
			else if(p2p_type==3) {
				try {
					socket = new Socket(InetAddress.getByName("115.28.186.188"), server_port);
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		 if(socket==null) {
			 Audio_Chat.ReleaseVAOccupy();
			 new Warn_frame("提示", "远程桌面连接异常").set_aYouTu_click(5);				
			 return;
		 }
//		 ServerSocket serverSocket = null;
//		 try {
//			serverSocket = new ServerSocket(10000);
//			socket = serverSocket.accept();
//		} catch (IOException e1) {
//			// TODO AYouTu-generated catch block
//			e1.printStackTrace();
//		}
		 
         EditDesktop.pre_setBackground();
		
		try {
			robot =new Robot();
		} catch (AWTException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		rectangle = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
		this.width = (int) rectangle.getWidth();
		this.height = (int) rectangle.getHeight();
		last_image1 = robot.createScreenCapture(new Rectangle(0,0,width, height-40));
		last_image2 = robot.createScreenCapture(new Rectangle(0,height-40,width,40));
		
		 Init_net(socket);
		 	
	     try {
	    	 Send_SizeData();
			 Send_FirstImage();
		} catch (Exception e) {
			e.printStackTrace();
			close_constant();
		}
		 
	     Init_frame();
	     Init_keyListioner();
	     
		 new Receive_conmand().start();
	     new Send_image().start();
	     
	//     new Check_thread().start();
	}
	public void Init_net(Socket socket) {
		try {
		
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
			dataInputStream = new DataInputStream(socket.getInputStream());
			
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	}
	public void Send_SizeData() throws Exception{
	
			dataOutputStream.writeInt((int) rectangle.getWidth());
			dataOutputStream.writeInt((int) rectangle.getHeight());
		
	}
	public void Send_FirstImage() throws Exception{
		 byte[] by = null;
		 Rectangle rectangle = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
		 BufferedImage bufferedImage = robot.createScreenCapture(rectangle);
		
			
		   by = JPEGImageEncoder(bufferedImage);
			
			  dataOutputStream.writeInt(by.length);
			  dataOutputStream.write(by, 0, by.length);
		
	}
	private class Receive_conmand extends Thread {
		byte eventType = 1;
		int x = 0;
		int y = 0;
		
		@Override
		public void run() {
			
         try {
			while((eventType=dataInputStream.readByte())!=-1) {			
				   if(eventType==1) {
					   x = dataInputStream.readShort();
					   y = dataInputStream.readShort();
					   action_MouseMoveEvent(x, y);
				   }
				   else if(eventType==2||eventType==3) {action_MousePressReleasedEvent(eventType,dataInputStream.readShort());}
				   else if(eventType==4) {action_MouseWheelEvent(dataInputStream.readShort());}
				   else {action_KeyEvent(eventType,dataInputStream.readShort());}
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
         
              close_constant();
             EditDesktop.last_setBackground();		   
		}
	
		public void action_MouseMoveEvent(int x,int y) {
		
			robot.mouseMove(x, y);
		}
		
		public void action_MousePressReleasedEvent(int mouseType,int button) {
			// EventType=3
			int robot_button = get_RobotButton(button);
			
			if(mouseType==2) {
			
				robot.mousePress(robot_button);}
			else if(mouseType==3) {
				
				robot.mouseRelease(robot_button);}
		}
		public void action_MouseWheelEvent(int MouseWheel_value) {
		
			robot.mouseWheel(MouseWheel_value);
		}
		public void action_KeyEvent(int keyType,int key_code) {
			
				if(keyType==5) {robot.keyPress(key_code);}
				else if(keyType==6) {robot.keyRelease(key_code);}	
		}	
	}	

	public int get_RobotButton(int type) {
		
		if(type==MouseEvent.BUTTON1) {
			return InputEvent.BUTTON1_MASK;
		}
		
		else if(type==MouseEvent.BUTTON2) {
			
			return InputEvent.BUTTON2_MASK;
		}
		
		else if(type==MouseEvent.BUTTON3) {
			
			return InputEvent.BUTTON3_MASK;
		}
		return type;
		
	}
	private  class Send_image extends Thread{
		
		long time = 0;
		Rectangle rectangle = null;
		
		public Send_image() {
			rectangle = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
		}
	@Override
	public void run() {
		
		try {
				 while(true) {
					//       time = System.currentTimeMillis();
						   BufferedImage current_image  = robot.createScreenCapture(rectangle);
					       Write_Image1(current_image);
					       Write_Image2(current_image);
					//       System.out.println(System.currentTimeMillis()-time);
				         }
			  } catch (Exception e) {
				    e.printStackTrace();
			 }
			           close_constant();
		}						
	}
	
	
	public synchronized void Write_Image1(BufferedImage current_image) throws Exception{
		  // 动态抓取
		   BufferedImage capture_image = null;
		   int w = 0;
		   int h = 0;
		   int x1 = width; int y1 = height;
		   int x2 = 0; int y2 = 0;
		   int i = 0;
	//大多数时候可以，有时候不可以	   
		   for(int x=0;x<width;x++) {
			   for(int y=0;y<height-40;y+=10) {
				   if((current_image.getRGB(x, y)^last_image1.getRGB(x, y))!=0) {
					 					  
					   if(x<x1) {x1=x;}
					   if(y<y1) {y1=y;}
					   if(x>x2) {x2=x;}
					   if(y>y2) {y2=y;}
				   } // if
			   }
		   }		   
		   
		   x1-=2;
		   y1-=10;
		  
		   x1 = x1<0?0:x1;
		   y1 = y1<0?0:y1;
		   
		   w = x2-x1+4;
		   h = y2-y1+20;
		   
		   w = x1+w>width?x2-x1+1:w;
		 //  h = y1+h>height?y2-y1+15:h;
		   
		   if(w<1||h<1) {return;}
	
			   capture_image = current_image.getSubimage(x1,y1,w,h);
			   last_image1 = current_image.getSubimage(0, 0,width,height-40);

	//	  System.out.println(x1+","+y1+","+w+","+h);
		  
		   time = System.currentTimeMillis();
		   byte[] by = null;

			  by = JPEGImageEncoder(capture_image);
			  
			  dataOutputStream.writeShort(x1);
			  dataOutputStream.writeShort(y1);
			  dataOutputStream.writeInt(by.length);
			  dataOutputStream.write(by, 0, by.length);		
	  }
	public synchronized void Write_Image2(BufferedImage current_image) throws Exception{
		  // 动态抓取
		   BufferedImage capture_image = null;
		   int w = 0;
		   int h = 0;
		   int x1 = width;
		   int x2 = 0; 
		
	//大多数时候可以，有时候不可以	   
		   for(int x=0;x<width;x+=2) {
			   for(int y=height-40,last_y=0;y<height&&last_y<41;y+=10,last_y+=10) {
				   if((current_image.getRGB(x, y)^last_image2.getRGB(x,last_y))!=0) {
					 					  
					   if(x<x1) {x1=x;}
					   if(x>x2) {x2=x;}
					   
				   } // if
			   }
		   }		   
		   
			   w = x2-x1;
			   if(w<1) {return;}
			   
			   x1-=1;			 
			   w = x2-x1+2;
			   
			   x1 = x1<0?0:x1;
			   w = w>width?width:w;			  
		
			     last_image2 = current_image.getSubimage(0,height-40,width,40);
			     capture_image = current_image.getSubimage(x1,height-40,w,40);
		   
		   time = System.currentTimeMillis();
		   byte[] by = null;

			  by = JPEGImageEncoder(capture_image);
			  
			  dataOutputStream.writeShort(x1);
			  dataOutputStream.writeShort(height-40);
			  dataOutputStream.writeInt(by.length);
			  dataOutputStream.write(by, 0, by.length);
	  }
	public synchronized void Write_TempImage() throws Exception{
		  //全局抓取
		 
		 BufferedImage capture_image = last_image2.getSubimage(0,0,40,40);
		 
		   time = System.currentTimeMillis();
		   byte[] by = null;

			  by = JPEGImageEncoder(capture_image);
			  
			  dataOutputStream.writeShort(0);
			  dataOutputStream.writeShort(height-40);
			  dataOutputStream.writeInt(by.length);
			  dataOutputStream.write(by, 0, by.length);
	  }
	public byte[] JPEGImageEncoder(BufferedImage image) throws Exception{
		 
	        ByteArrayOutputStream baos = new ByteArrayOutputStream();
	        //压缩器压缩，先拿到存放到byte输出流中
	        JPEGImageEncoder jpegd = JPEGCodec.createJPEGEncoder(baos);
	        //将iamge压缩
	        jpegd.encode(image);
	        //转换成byte数组

	        return baos.toByteArray();  		 	        
	}
 
 private class Check_thread extends Thread{
	 
	  @Override
	public void run() {
		  while(start) {
			  try {
				Thread.sleep(25000);
			} catch (InterruptedException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
			  if(System.currentTimeMillis()-time>25000) {
				  try {
					Write_TempImage();
				} catch (Exception e) {
					e.printStackTrace();
					break;
				}
			  }
		  }
	}
 }
 private class Show_pane extends JPanel implements Runnable{		
		String text = "";
		Font font = null;
		int second = 0;
		
		public Show_pane() {
			setLayout(null);
			font = new Font("宋体", Font.PLAIN, 18);
			
		}
		@Override
		public void run() {
			 while(start) {
				  second++;
				  String time = time_conveter(second);
				  paint_time(time);
				  try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
			 }
		}
		public String time_conveter(int second) {
			int s = second%60;
			int m = (second%3600)/60;
			int h = second/3600;
			
			String time = h+" : "+m+" : "+s;
			return time;
		}
		public void paint_time(String time) {
			this.text = "通话时长： "+time+"    按 ESC键 关闭远程桌面";
			repaint();
		}
		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
			g2.setFont(font);
			g2.drawString(text, 150, 25);
		}
	}
 public static void main(String[] args) {
		//118.190.134.102
		//192.168.31.203
//		 Socket socket = null;
//		 try {
//			socket = new Socket(InetAddress.getByName("115.28.186.188"),3322);
//		} catch (UnknownHostException e) {
//			// TODO AYouTu-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO AYouTu-generated catch block
//			e.printStackTrace();
//		}

//	 Scanner scanner = new Scanner(System.in);
//	
//	 System.out.println("server port: ");
//	 int server_port1 = scanner.nextInt();
//	 
//	 long time = System.currentTimeMillis();
//	  
//	 TCP_P2P_Pointer p2p_Pointer = new TCP_P2P_Pointer("TCP_Pointer", server_port1);
//	 p2p_Pointer.start();
//	 Socket socket = p2p_Pointer.get_socket(60);
	 
	   new Constant_Receive(1,10000).start();
}
}
