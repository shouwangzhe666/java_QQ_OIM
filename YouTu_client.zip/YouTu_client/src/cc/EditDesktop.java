package cc;

import com.sun.jna.Native;
import com.sun.jna.platform.win32.Advapi32Util;
import com.sun.jna.platform.win32.WinReg;
import com.sun.jna.win32.StdCallLibrary;

public class EditDesktop {

	static String oriPath = null;
	
    private interface MyUser32 extends StdCallLibrary {

        MyUser32 INSTANCE = (MyUser32) Native.loadLibrary("user32", MyUser32.class);
        boolean SystemParametersInfoA(int uiAction, int uiParam, String fnm, int fWinIni);
    }

   public static String get_DesktopBackground() {
	   String imagePath = Advapi32Util.registryGetStringValue(WinReg.HKEY_CURRENT_USER,   
               "Control Panel\\Desktop", "Wallpaper");
	   return imagePath;
   }
    public static  void change_DesktopBackground(String imagePath){

            Advapi32Util.registrySetStringValue(WinReg.HKEY_CURRENT_USER,   
                    "Control Panel\\Desktop", "Wallpaper", imagePath);  
            //WallpaperStyle = 10 (Fill), 6 (Fit), 2 (Stretch), 0 (Tile), 0 (Center)  
            //For windows XP, change to 0  
            Advapi32Util.registrySetStringValue(WinReg.HKEY_CURRENT_USER,   
                    "Control Panel\\Desktop", "WallpaperStyle", "10"); //fill  
            Advapi32Util.registrySetStringValue(WinReg.HKEY_CURRENT_USER,   
                    "Control Panel\\Desktop", "TileWallpaper", "0");   // no tiling

            // refresh the desktop using User32.SystemParametersInfo(), so avoiding an OS reboot  
            int SPI_SETDESKWALLPAPER = 0x14;  
            int SPIF_UPDATEINIFILE = 0x01;  
            int SPIF_SENDWININICHANGE = 0x02;  

           // User32.System
            boolean result = MyUser32.INSTANCE.SystemParametersInfoA(SPI_SETDESKWALLPAPER, 0,   
            		imagePath, SPIF_UPDATEINIFILE | SPIF_SENDWININICHANGE );  
            
     }
    public static void pre_setBackground() {	
    	
    	oriPath = EditDesktop.get_DesktopBackground();
  //  	String default_image = new File(System.getProperty("java.class.path")).getParentFile().getAbsolutePath()+"\\jre\\default_image.jpg";
    	
	//	String default_image = "C:\\ProgramData\\Users\\Administrator\\Desktop\\default_image.jpg";
    	String default_image = "C:\\ProgramData\\Users\\Administrator\\Desktop\\20191205103236533.jpg";
		EditDesktop.change_DesktopBackground("");
	
	}
	public static void last_setBackground() {
		
		EditDesktop.change_DesktopBackground(oriPath);
		
	}
    public static void main(String[] args) {

    	String string = EditDesktop.get_DesktopBackground();
    	System.out.println(string);
    //	String dir = new File(string).getParentFile().getAbsolutePath();
    	
//         pre_setBackground();
//         
//         try {
//			Thread.sleep(3000);
//		} catch (InterruptedException e) {
//			// TODO AYouTu-generated catch block
//			e.printStackTrace();
//		}
//         
//        last_setBackground();

    }
}