package private_encoder_pack;
import java.io.UnsupportedEncodingException;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

public class Login_Pass_encoder extends MessageToByteEncoder<message_login_register.Login_pass_message>{

	@Override
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
		
		super.channelActive(ctx);
	}
	
	@Override
	protected void encode(ChannelHandlerContext ctx, message_login_register.Login_pass_message login_pass_message, ByteBuf buf) throws Exception {
	
		int type = login_pass_message.getType();
		
		if(type==1) {encode_type1(login_pass_message, buf);}
		else if(type==2) {encode_type2(login_pass_message, buf);}
		else if(type==3) {encode_type3(login_pass_message, buf);}
		else if(type==4) {encode_type4(login_pass_message, buf);}
		else if(type==5) {encode_type5(login_pass_message, buf);}
		
	}

	public void encode_type1(message_login_register.Login_pass_message login_pass_message, ByteBuf buf) {
		
		 buf.writeInt(312); 
		 buf.writeInt(1); 
		 
		 byte[]b1 = null;
		 byte[]b2 = null;
		 
		 try {
			b1 = login_pass_message.getAccount().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		 try {
				b2 = login_pass_message.getPassword().getBytes("UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
		 
		 buf.writeBoolean(login_pass_message.isNativeImage_exist());
		 
		 buf.writeInt(b1.length);
		 buf.writeBytes(b1);
		 
		 buf.writeInt(b2.length);
		 buf.writeBytes(b2);
	}
	
   public void encode_type2(message_login_register.Login_pass_message login_pass_message, ByteBuf buf) {
		
	    buf.writeInt(312);
		buf.writeInt(2);
		 
		 byte[]b1 = null;
		 byte[]b2 = null;
		 
		 try {
			b1 = login_pass_message.getAccount().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		 try {
				b2 = login_pass_message.getEmail().getBytes("UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
		 
		 buf.writeInt(b1.length);
		 buf.writeBytes(b1);
		 
		 buf.writeInt(b2.length);
		 buf.writeBytes(b2);
		
	}
   
  public void encode_type3(message_login_register.Login_pass_message login_pass_message, ByteBuf buf) {
	
	     buf.writeInt(312);
		 buf.writeInt(3);
		 
		 byte[]b1 = null;
		 byte[]b2 = null;
		 byte[]b3 = null;
		 
		 try {
			b1 = login_pass_message.getAccount().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		 try {
				b2 = login_pass_message.getPassword().getBytes("UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
		 try {
				b3 = login_pass_message.getNew_password().getBytes("UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
		 
		 buf.writeInt(b1.length);
		 buf.writeBytes(b1);
		 
		 buf.writeInt(b2.length);
		 buf.writeBytes(b2);
		 
		 buf.writeInt(b3.length);
		 buf.writeBytes(b3);
	
}
  public void encode_type4(message_login_register.Login_pass_message login_pass_message, ByteBuf buf) {
	
	     buf.writeInt(312);
		 buf.writeInt(4);
		 	
		 byte[]b1 = null;
		
		 int result_type = login_pass_message.getResult_type();
		 boolean scuess  = login_pass_message.isScuess();
		 try {
			b1 = login_pass_message.getResult().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	      
		 buf.writeInt(result_type);
		 buf.writeBoolean(scuess);
		 buf.writeInt(b1.length);
		 buf.writeBytes(b1);
  }
  public void encode_type5(message_login_register.Login_pass_message login_pass_message, ByteBuf buf) {
	  
	     buf.writeInt(312);
		 buf.writeInt(5);
		 
		 buf.writeInt(login_pass_message.getTcp_port1());
		 buf.writeInt(login_pass_message.getTcp_port2());
  }
}
