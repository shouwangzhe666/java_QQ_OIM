package private_encoder_pack;

import java.io.UnsupportedEncodingException;

import Message.Private.Link_set;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

public class Link_set_encoder extends MessageToByteEncoder<Link_set>{

	@Override
	protected void encode(ChannelHandlerContext arg0, Link_set link_set, ByteBuf buf) throws Exception {
	
		int type = link_set.getType();
		if(type==1) {encode_type1(link_set, buf);}
		else if(type==2) {encode_type2(link_set, buf);}
		else if(type==3) {encode_type3(link_set, buf);}
		else if(type==4) {encode_type4(link_set, buf);}
		else if(type==5) {encode_type5(link_set, buf);}
		else if(type==6) {encode_type6(link_set, buf);}
		else if(type==7) {encode_type7(link_set, buf);}
		else if(type==8) {encode_type8(link_set, buf);}
		else if(type==9) {encode_type9(link_set, buf);}
		else if(type==10) {encode_type10(link_set, buf);}
	}

public void encode_type1(Link_set link_set, ByteBuf buf) {
	
	 byte[] native_account = null;
	 boolean privet = true;
	 byte[] new_group = null;
	    try {
			native_account = link_set.getNative_count().getBytes("UTF-8");
			privet = link_set.isPrivat();
			new_group = link_set.getNew_group().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	    
	    buf.writeInt(122);
	    buf.writeInt(1);
	    
	    buf.writeInt(native_account.length);
	    buf.writeBytes(native_account);
	    buf.writeBoolean(privet);
	    buf.writeInt(new_group.length);
	    buf.writeBytes(new_group);
	}
public void encode_type2(Link_set link_set, ByteBuf buf) {
		
	 byte[] native_account = null;
	 boolean privet = true;
	 byte[] old_group = null;
	 byte[] new_group = null;
	    try {
			native_account = link_set.getNative_count().getBytes("UTF-8");
			privet = link_set.isPrivat();
			old_group = link_set.getOld_group().getBytes("UTF-8");
			new_group = link_set.getNew_group().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	    
	    buf.writeInt(122);
	    buf.writeInt(2);
	    
	    buf.writeInt(native_account.length);
	    buf.writeBytes(native_account);
	    buf.writeBoolean(privet);
	    buf.writeInt(old_group.length);
	    buf.writeBytes(old_group);
	    buf.writeInt(new_group.length);
	    buf.writeBytes(new_group);
	}
public void encode_type3(Link_set link_set, ByteBuf buf) {
	
	 byte[] native_account = null;
	 boolean privet = true;
	 byte[] old_group = null;
	 byte[] new_group = null;
	    try {
			native_account = link_set.getNative_count().getBytes("UTF-8");
			privet = link_set.isPrivat();
			old_group = link_set.getOld_group().getBytes("UTF-8");
			new_group = link_set.getNew_group().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	    
	    buf.writeInt(122);
	    buf.writeInt(3);
	    
	    buf.writeInt(native_account.length);
	    buf.writeBytes(native_account);
	    buf.writeBoolean(privet);
	    buf.writeInt(old_group.length);
	    buf.writeBytes(old_group);
	    buf.writeInt(new_group.length);
	    buf.writeBytes(new_group);
}
public void encode_type4(Link_set link_set, ByteBuf buf) {
	
	 byte[] native_account = null;
	 byte[] link_account = null;
	 byte[] new_group = null;
	    try {
			native_account = link_set.getNative_count().getBytes("UTF-8");
			link_account = link_set.getLink_account().getBytes("UTF-8");
			new_group = link_set.getNew_group().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	    
	    buf.writeInt(122);
	    buf.writeInt(4);
	    
	    buf.writeInt(native_account.length);
	    buf.writeBytes(native_account);
	    buf.writeInt(link_account.length);
	    buf.writeBytes(link_account);
	    buf.writeInt(new_group.length);
	    buf.writeBytes(new_group);
}
public void encode_type5(Link_set link_set, ByteBuf buf) {
	
	 byte[] native_account = null;
	 byte[] link_account = null;
	
	    try {
			native_account = link_set.getNative_count().getBytes("UTF-8");
			link_account = link_set.getLink_account().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	    
	    buf.writeInt(122);
	    buf.writeInt(5);
	    
	    buf.writeInt(native_account.length);
	    buf.writeBytes(native_account);
	    buf.writeInt(link_account.length);
	    buf.writeBytes(link_account);
	   
}
public void encode_type6(Link_set link_set, ByteBuf buf) {
	
	byte[] native_account = null;
	byte[] link_account = null;
	byte[] new_remark = null;
	
	 try {
			native_account = link_set.getNative_count().getBytes("UTF-8");
			link_account = link_set.getLink_account().getBytes("UTF-8");
			new_remark = link_set.getNew_remark().getBytes("UTF-8");;
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	 
	    buf.writeInt(122);
	    buf.writeInt(6);
	    
	    buf.writeInt(native_account.length);
	    buf.writeBytes(native_account);
	    buf.writeInt(link_account.length);
	    buf.writeBytes(link_account);
	    buf.writeInt(new_remark.length);
	    buf.writeBytes(new_remark);
}
public void encode_type7(Link_set link_set, ByteBuf buf) {
	
	byte[] native_account = null;
	byte[] link_account = null;
	byte[] inform_type = null;
	
	 try {
			native_account = link_set.getNative_count().getBytes("UTF-8");
			link_account = link_set.getLink_account().getBytes("UTF-8");
			inform_type = link_set.getInform_type().getBytes("UTF-8");;
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	 
	    buf.writeInt(122);
	    buf.writeInt(7);
	    
	    buf.writeInt(native_account.length);
	    buf.writeBytes(native_account);
	    buf.writeInt(link_account.length);
	    buf.writeBytes(link_account);
	    buf.writeInt(inform_type.length);
	    buf.writeBytes(inform_type);
	
}
public void encode_type8(Link_set link_set, ByteBuf buf) {
	
	byte[] native_account = null;
	byte[] state = null;
	
	 try {
			native_account = link_set.getNative_count().getBytes("UTF-8");
			state = link_set.getState().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	 
	    buf.writeInt(122);
	    buf.writeInt(8);
	    
	    buf.writeInt(native_account.length);
	    buf.writeBytes(native_account);
	    buf.writeInt(state.length);
	    buf.writeBytes(state);
	 
	   
}
public void encode_type9(Link_set link_set, ByteBuf buf) {
	
	byte[] native_account = null;
	byte[] link_account = null;
	
	 try {
			native_account = link_set.getNative_count().getBytes("UTF-8");
			link_account = link_set.getLink_account().getBytes("UTF-8");
	
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	 
	    buf.writeInt(122);
	    buf.writeInt(9);
	    
	    buf.writeInt(native_account.length);
	    buf.writeBytes(native_account);
	    buf.writeInt(link_account.length);
	    buf.writeBytes(link_account);
	
}
public void encode_type10(Link_set link_set, ByteBuf buf) {
	
	byte[] native_account = null;
	byte[] remote_ip = null;
	
	 try {
			native_account = link_set.getNative_count().getBytes("UTF-8");
			remote_ip = link_set.getRmeote_ip().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	 
	    buf.writeInt(122);
	    buf.writeInt(10);
	    
	    buf.writeInt(native_account.length);
	    buf.writeBytes(native_account);
	    buf.writeInt(remote_ip.length);
	    buf.writeBytes(remote_ip);
	   
}
}
