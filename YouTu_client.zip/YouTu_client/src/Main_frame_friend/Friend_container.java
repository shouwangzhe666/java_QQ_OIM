package Main_frame_friend;

import java.awt.Color;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import javax.swing.BoxLayout;

import Frame.Main_Frame;
import Frame.Only_frame;
import Message.Private.Link_info;
import custom_component.Box_pane;

public class Friend_container extends Box_pane {
	
	Friend_name  name_pane = null;
	HashMap<String, Friend_Item> all_item = null;
	
	Color focus_color = null;
	
	int width = 280;
	int height = 35;
	int total_item_num = 0;
	int pane_height = 0 ;
	boolean focus = false;
	
	Box_pane main_pane = null;
	Only_frame only_frame = null;
	
	public Friend_container(String name) {
		super(BoxLayout.Y_AXIS);
		setOpaque(false);
		all_item = new HashMap<>();
		focus_color = new Color(160, 160, 160);
	    
	    name_pane = new Friend_name(this, name, true);
	    add(name_pane);
	    
	    update_pane_size();
		
	}
	
	public String get_group() {
		return name_pane.get_group();
	}
  public Set get_all_linkMan() {
	  return all_item.keySet();
  }
  
  public void update_online_num(boolean add) {
	  name_pane.update_online_num(add);
  }
  
  public int get_total_item() {
	  
	  return total_item_num;
  }
  
  public void put_new_group(String group_name) {
	  for(Friend_Item item:all_item.values()) {
		  item.put_new_group(group_name);
	  }
  }
  
  public void rename_All_Item_group(String old_group,String new_group) {
	  
	  if(name_pane.get_group().equals(old_group)) {name_pane.update_group(new_group);}
	  
	  for(Friend_Item friend_Item:all_item.values()) {
		  friend_Item.rename_group(old_group, new_group);
	  }
  }
  public void delete_All_Item_groups(String delete_group,String new_group) {
	  
	//  if(name_pane.get_group().equals(delete_group)) {name_pane.update_group(new_group);}
	  
	  for(Friend_Item friend_Item:all_item.values()) {
		  friend_Item.delete_group(delete_group, new_group);
	  }
  }
  public  Friend_Item get_Friend_Item(String link_count) {
	  
	  return all_item.get(link_count);
  }
  
  public void put_new_Item(String link_account,Friend_Item friend_Item) {
	  
		all_item.put(link_account, friend_Item);
		add(friend_Item);
		
		// total_item_num++;
		total_item_num = all_item.size();
		 if(focus) {
			
			 Main_Frame.getFriend_pane().update_size(true,1);
		 }
		
	     update_pane_size();
	     
	    if(friend_Item.is_online()) {name_pane.update_online_num(true);}
	     name_pane.update_total_num(total_item_num);	     
  }
  public void put_new_Item(Link_info link_info) {
		
		String link_count = link_info.getLink_count();
		Friend_Item friend_Item = new Friend_Item(link_info);
		
		all_item.put(link_count, friend_Item);
		add(friend_Item);
		
		 total_item_num++;
		 if(focus) {
			
			 Main_Frame.getFriend_pane().update_size(true,1);
		 }
		
	     update_pane_size();
	     
	     if(friend_Item.is_online()) {name_pane.update_online_num(true);}
	     name_pane.update_total_num(total_item_num);
	}
	
	public void remova_Item(String link_count) {
			   
		Friend_Item friend_Item = all_item.get(link_count);
		if(friend_Item==null) {return;}
		
		all_item.remove(link_count);
		this.remove(friend_Item);
		
		 total_item_num--;
		 if(focus) {
	//		if(total_item_num==0) {show_all(false);}
			 Main_Frame.getFriend_pane().update_size(false,1);
		 }
		
	     update_pane_size();
	     name_pane.update_total_num(total_item_num);
	     if(friend_Item.is_online()) {name_pane.update_online_num(false);}
	}
	
	public void show_all(boolean show) {
		
		this.focus = show;
		
		java.util.Set<String> set = all_item.keySet();
		Iterator<String> it = set.iterator();
		Friend_Item friend_Item = null;
		
		while(it.hasNext()) {
			
			String count = (String)it.next();
			friend_Item = all_item.get(count);
			friend_Item.setVisible(show);
			
		}
				
	    Main_Frame.getFriend_pane().update_size(show,total_item_num);
				
	     update_pane_size();
	}  

	public void update_pane_size() {
				
		if(focus) {
			pane_height = 35+60*total_item_num;
		}
		else {
			pane_height = 35;
		}
		
		setPreferredSize(new Dimension(280, pane_height));
		setMinimumSize(new Dimension(260, pane_height));
	    setMaximumSize(new Dimension(595, pane_height));
	  
	}
   public void do_click() {
	   
	   focus = !focus;
	   show_all(focus);
	   focus = !focus;
	   show_all(focus);
	   
	   name_pane.repaint();
   }
}