package Main_frame_friend;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;

import Frame.Main_Frame;
import Main_frame_Item.Main_JMenuItem;
import custom_component.Box_pane;
import ss.Private_Chat_Client;
import tool_Frame.TextFild_Frame;
import tool_Frame.Warn_frame;
import Main_frame_friend.*;
import Message.Private.Link_set;
class Friend_name extends Box_pane implements ActionListener{
	
	Image imageright = null;
	Image imagedown = null;
	JTextField jTextField = null;
	boolean enter = false;
	boolean focus = false;
	JPopupMenu popupMenu = null;
	Main_JMenuItem add_group = null;
	Main_JMenuItem rename_group = null;
	Main_JMenuItem delete_group = null;
	
	Cursor cursor = null;
	Color focus_color = null;
	Font font = null;
	FontRenderContext frc = null;
	TextFild_Frame add_frame = null;
	TextFild_Frame rename_frame = null;
	TextFild_Frame delete_frame = null;
	
	Friend_container friend_container = null;
	String name = null;
	int online_num = 0;
	int total_num = 0;
	int count_x = 0 ;
	boolean privat = true;
	
public Friend_name(Friend_container friend_container,String name,boolean privat) {
	
		super(BoxLayout.X_AXIS);	
		
		setOpaque(false);
		
		Init_content(friend_container, name, privat);
		update_count_x();
		Init_pane_listioner();
		
}

public void Init_content(Friend_container friend_container,String name,boolean privat) {
	
	cursor = new Cursor(Cursor.DEFAULT_CURSOR);
	focus_color = new Color(160, 160, 160);
	font = new Font("宋体", Font.PLAIN, 14);
	frc = new FontRenderContext(new AffineTransform(),true,true);
	this.friend_container = friend_container;
	this.name = name;
	this.privat = privat;
	imageright = new ImageIcon(getClass().getResource("/tool_image/group_right.png")).getImage();
	imagedown = new ImageIcon(getClass().getResource("/tool_image/group_down.png")).getImage();
	
	setPreferredSize(new Dimension(280, 35));
	setMinimumSize(new Dimension(260, 35));
	setMaximumSize(new Dimension(595, 35));
}

public void update_count_x() {
	
	 Rectangle rec = font.getStringBounds(name, frc).getBounds();
     int str_width= rec.width;
     count_x = str_width+70;
}

public void Init_componnet() {
	
	popupMenu = new JPopupMenu();
	popupMenu.setBackground(Color.white);
	
	add_group = new Main_JMenuItem("添加分组", null);
	rename_group = new Main_JMenuItem("重命名", null);
	delete_group = new Main_JMenuItem("删除分组", null);
	
	popupMenu.add(add_group);
	popupMenu.add(rename_group);
	popupMenu.add(delete_group);
	
	add_group.addActionListener(this);
	rename_group.addActionListener(this);
	delete_group.addActionListener(this);
	
}

public void Init_pane_listioner() {
	
	addMouseListener(new MouseAdapter() {
		@Override
		public void mouseEntered(MouseEvent e) {
			enter = true;
			repaint();
		}
		@Override
		public void mouseExited(MouseEvent e) {
			enter = false;
			repaint();
		}
		@Override
		public void mousePressed(MouseEvent e) {
			
				if(e.getButton()==1) {
					focus = !focus;
					repaint();
					friend_container.show_all(focus);
					
				}//button = 0;
				
				else if(e.getButton()==3) {
					Init_componnet();
					popupMenu.show(Friend_name.this, e.getX(), e.getY());
			}			
		}
	});
}
public void Init_add_frame() {
	
	add_frame =  new TextFild_Frame("添加分组", "请输入新分组名称：");
	
	add_frame.alter_ActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			
			String new_group = add_frame.get_input_text();
			add_frame.dispose_frame();
			
			if(new_group.length()==0) {return;}
			if(new_group.length()>20) {new Warn_frame("提示", "不能超过20字").set_aYouTu_click(5);return;}
			
			Main_Frame.getFriend_pane().put_group(false, new_group);
			Main_Frame.update_UI();
			
		    Link_set alter_group_message = new Link_set(1);
		    alter_group_message.setNative_count(Main_Frame.getNative_count());
		    alter_group_message.setPrivat(privat);
			alter_group_message.setNew_group(new_group);
			
			Private_Chat_Client.send_message(alter_group_message);
		}  //actionPerformed
	});	
}
public void Init_rename_frame() {
		
	rename_frame =  new TextFild_Frame("分组重命名", "请输入新分组名称：");
	rename_frame.alter_ActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			
			String old_group = name;
			String new_group = rename_frame.get_input_text();
			rename_frame.dispose_frame();
			
			if(old_group.length()==0) {return;}
			if(new_group.length()>20) {new Warn_frame("提示", "不能超过20字").set_aYouTu_click(5);return;}
			
			Main_Frame.getFriend_pane().rename_group_name(old_group, new_group); 
			Main_Frame.update_UI();
			
			Link_set link_set = new Link_set(2);			
			link_set.setNative_count(Main_Frame.getNative_count());
			link_set.setPrivat(privat);
			link_set.setOld_group(old_group);
			link_set.setNew_group(new_group);
			
			Private_Chat_Client.send_message(link_set);
			
		}  //actionPerformed
	});	
}

public String get_group() {
	return this.name;
}

public void update_group(String new_group) {
	this.name = new_group;
	update_count_x();
	repaint();
}

public void update_online_num(boolean add) {
	
	if(add) {this.online_num++;}
	else {this.online_num--;}
	
	repaint();
}
public void update_total_num(int total_num) {
	
	this.total_num = total_num;
	repaint();
}

	@Override
	protected void paintComponent(Graphics g) {		
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		if(enter){
			g2.setColor(focus_color);
			g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
			g2.fillRect(0, 0, 600, 60);
		}
		
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
		
		if(!focus) {
			
			g2.drawImage(imageright, 10, 0, null);}
		else {
			
			g2.drawImage(imagedown, 10, 0, null);}
		
		g2.setColor(Color.black);
		g2.setFont(font);
		g2.drawString(name, 35, 15);
		g2.drawString(online_num+"/"+total_num, count_x, 15);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
	
       if(e.getSource()==add_group) {
			
			popupMenu.setVisible(false);
			Init_add_frame();
			popupMenu.removeAll();
			popupMenu = null;
		} // if add_group
       else if(e.getSource()==rename_group) {
			
			popupMenu.setVisible(false);
		    Init_rename_frame();
		    popupMenu.removeAll();
			popupMenu = null;
		} // if rename_group
       else if(e.getSource()==delete_group) {
			
			popupMenu.setVisible(false);
			String old_group = this.name;
			
			String new_group = Main_Frame.getFriend_pane().delete_group_name(old_group) ; // new_group
			if(new_group==null) {
				new Warn_frame("提示", "分组："+this.name+" 无法删除！").set_aYouTu_click(5);
				return;
			}
									
			 Link_set link_set = new Link_set(3);
			 link_set.setNative_count(Main_Frame.getNative_count());
			 link_set.setPrivat(privat);
			 link_set.setOld_group(old_group);
			 link_set.setNew_group(new_group);
			 
			 Private_Chat_Client.send_message(link_set);
			 
			 popupMenu.removeAll();
			 popupMenu = null;
		} // if add_group
	}
}