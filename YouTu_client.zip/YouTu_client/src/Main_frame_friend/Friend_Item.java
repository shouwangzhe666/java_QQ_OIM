package Main_frame_friend;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.color.ColorSpace;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.awt.image.ColorConvertOp;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JPopupMenu;

import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;

import Frame.Chat_frame;
import Frame.Look_info_frame;
import Frame.Main_Frame;
import Main_frame_Item.Main_JMenu;
import Main_frame_Item.Main_JMenuItem;
import Message.Private.Link_info;
import Message.Private.Link_set;
import Message.Private.Private_info;
import custom_component.Box_pane;
import ss.Private_Chat_Client;
import sun.reflect.generics.tree.VoidDescriptor;
import tool_Frame.TextFild_Frame;
import tool_Frame.Warn_frame;
import tools.Icon_tools;

class Friend_Item extends Box_pane implements ActionListener{
    
	Link_info link_info = null;
	String link_count = null;
	Image image = null;
	BufferedImage grayImage = null;
	
	String name = null;
	String signature = null;
	String inform_type = null;
    String state = null;
    String group = null;
    String []group_names = null; 
	boolean enter = false;
	boolean online = false;
	
	JPopupMenu popupMenu = null;
	Main_JMenuItem send_item = null;
	Main_JMenuItem info_item = null;
	Main_JMenuItem remark_item = null;
	Main_JMenu set_menu = null;
	Main_JMenu group_menu = null;
	Main_inform_RadioItem accept_remaind_item = null;
	Main_inform_RadioItem accept_item = null;
	Main_inform_RadioItem block_item = null;	
	Main_JMenuItem delete_item = null;
	Main_JMenuItem blacklist_item = null;
	
	TextFild_Frame textFild_Frame = null;
	Cursor cursor = null;
	Color focus_color = null;
	
public Friend_Item(Link_info link_info) {
	
         super(BoxLayout.X_AXIS);
         
         setOpaque(false);
         
         Init_content(link_info);
		 Init_pane_listioner();

}

public void Init_content(Link_info link_info) {
	
	cursor = new Cursor(Cursor.DEFAULT_CURSOR);
	focus_color = new Color(160, 160, 160);
	
	this.link_info = link_info;
	this.link_count = link_info.getLink_count();
	this.name = link_info.getRemark();
	this.signature = link_info.getSignature();
	this.group  = link_info.getGroup();
	this.group_names = link_info.getGroup_names();
    this.inform_type = link_info.getInform_type();
    
    this.state  = link_info.getState();
    this.online = is_online(state);
    
    update_state(state);
    
    String icon_path =  "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\image\\head_image\\"+link_count+".png";
    byte[] icon_bytes = Icon_tools.get_IconBytes(icon_path);
    
    update_head_image(icon_bytes);
    
    Main_Frame.getMessage_pane().update_head_image(link_count, icon_bytes);
    
    Main_Frame.getMessage_pane().update_state(link_count, state);
    
    setPreferredSize(new Dimension(280, 60));
	setMinimumSize(new Dimension(260, 60));
	setMaximumSize(new Dimension(595, 60));
}
public void Init_component() {
	
	 popupMenu = new JPopupMenu();
	 popupMenu.setBackground(Color.white);
     
     send_item = new Main_JMenuItem("发送消息", null);
     info_item = new Main_JMenuItem("查看资料",null);
     remark_item = new Main_JMenuItem( "修改备注",null);
     set_menu  = new Main_JMenu("提醒类型");
     group_menu = new Main_JMenu("移动分组");
     blacklist_item = new Main_JMenuItem("加入黑名单", null);
     delete_item = new Main_JMenuItem("删除好友", null);
     
     popupMenu.add(send_item);
     popupMenu.add(info_item);
     popupMenu.add(remark_item);
     popupMenu.add(set_menu);    
     popupMenu.add(group_menu);
     popupMenu.add(blacklist_item);
     popupMenu.add(delete_item);
     
     accept_remaind_item = new Main_inform_RadioItem(group, link_count, "接收消息并提醒", inform_type);
     accept_item = new Main_inform_RadioItem(group, link_count, "接收消息但不提醒", inform_type);
     block_item = new Main_inform_RadioItem(group, link_count, "屏蔽消息", inform_type);
  
     set_menu.add(accept_remaind_item);
     set_menu.add(accept_item);
     set_menu.add(block_item);
     
     for(int i=0;i<group_names.length;i++) {   	 
    	 put_group(group_names[i]);
     }
         // popupMenu.updateUI();
}
public void Init_pane_listioner() {
	
	addMouseListener(new MouseAdapter() {
		@Override
		public void mousePressed(MouseEvent e) {
			if(e.getButton()==1&&e.getClickCount()==2) {open_chat_frame();}
			else if(e.getButton()==3) {
				Init_component();
				Init_item_listioner();
				popupMenu.show(Friend_Item.this, e.getX(), e.getY());
			}
		}
		@Override
		public void mouseEntered(MouseEvent e) {
			enter = true;
			repaint();
		}
		@Override
		public void mouseExited(MouseEvent e) {
			enter = false;
			repaint();
		}
	});
}
public void Init_item_listioner() {
	
	send_item.addActionListener(this);
	info_item.addActionListener(this);
	remark_item.addActionListener(this);
	set_menu.addActionListener(this);
	group_menu.addActionListener(this);
	blacklist_item.addActionListener(this);
	delete_item.addActionListener(this);
}
public void Init_tool_frame() {
	
	  textFild_Frame = new TextFild_Frame("修改备注名","请输入新备注名：");
	  textFild_Frame.alter_ActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String new_remark = textFild_Frame.get_input_text();
				textFild_Frame.dispose_frame();
				name = new_remark;
				link_info.setRemark(new_remark);
				repaint();
				
	    		if(new_remark.trim().length()==0) {return;}	 
	    		
	    		Link_info link_account = Main_Frame.getMessage_pane().get_link_info(link_count);
	    		if(link_info==null) {return;}
	    		link_account.setRemark(new_remark);
	    		 
	    		Main_Frame.getMessage_pane().rename_remark(link_count, new_remark);
	    		
		        Link_set link_set = new Link_set(6);
		        link_set.setNative_count(Main_Frame.getNative_count());
		        link_set.setLink_account(link_count);
		        link_set.setNew_remark(new_remark);
		        
		        Private_Chat_Client.send_message(link_set);
		   }
		});
}

public  BufferedImage getGrayImage(){
	
	BufferedImage originalImage = null;
	try {
		originalImage = ImageIO.read(new FileInputStream("C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\image\\head_image\\"+link_count+".png"));
	} catch (FileNotFoundException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	
	int rgb = 0 ;
	Color color = null;
	int green = 0,red = 0,blue = 0;
	int imageWidth = originalImage.getWidth();
	int imageHight = originalImage.getHeight();
	BufferedImage routeImage = new BufferedImage(imageWidth,imageHight,BufferedImage.TYPE_4BYTE_ABGR);
	for(int i = originalImage.getMinX();i < imageWidth;i++){
		for(int j = originalImage.getMinY();j < imageHight;j++){
			//获取该点像素，用Object类型标识
			
			rgb = originalImage.getRGB(i, j);
			color = new Color(rgb);
			
			red = color.getRed();
			green = color.getGreen();
			blue = color.getBlue();
			red = (red*3+green*6+blue*1)/10;
			green = red;
			blue = green;
						
			rgb = (red*256 +green)*256 +blue;
			if(rgb>8388608){
				rgb = rgb - 256*256*256;
			}
			
			if(red<2&&green<2&&blue<2) {color = new Color(0, 0, 0,0);}
			else {color = new Color(red, green, blue);}
			//将rgb值写回图片
			routeImage.setRGB(i, j, color.getRGB());
		}
	}
	
	Graphics2D g2 = (Graphics2D) routeImage.getGraphics();
	g2.setColor(Color.LIGHT_GRAY);
	g2.setStroke(new BasicStroke(2f));
	g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	g2.drawOval(-1,-1, imageWidth+1, imageHight+1);
	
	return routeImage;
}
public boolean is_online() {

	return this.online;
}
public boolean is_online(String state) {

	if(state.equals("离线")||state.equals("隐身")) {return false;}
	return true;
}
public void update_inform_type(String inform_type) {
	 this.inform_type = inform_type;
}
public void update_state(String state) {
	
	if(state.equals("隐身")) {this.state = "离线";}
	else {this.state = state;}
	
	if(this.state.equals("离线")) {this.online = false;}
	else {this.online = true;}
	
	repaint();
	
}

public void update_head_image(byte[] icon_bytes) {
	
	 this.image = new ImageIcon(icon_bytes).getImage();
	 this.grayImage = getGrayImage();
	 repaint();
}
public void update_selectedgroup(String new_group_name) {
	 this.group = new_group_name;
}
public void put_group(String new_group_name) {
	
	 Main_group_Radio_Item group_item = new Main_group_Radio_Item(new_group_name, link_count, group.equals(new_group_name));
	 group_menu.add(group_item);
	 
}
public void put_new_group(String new_group_name) {
	 
	String[] temp_group = new String[group_names.length+1];
	
	for(int i=0;i<group_names.length;i++) {
		temp_group[i] = group_names[i];
	}
	temp_group[temp_group.length-1] = new_group_name;
	this.group_names = temp_group;
}
public void rename_group(String old_group,String new_group) {
		 
		    if(old_group.equals(this.group)) {
		    	
		    	this.group = new_group;
		    	Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_count);
		    	link_info.setGroup(this.group);		    
		    }
		    
	 replace_array(group_names, old_group, new_group);
}
public void replace_array(String[] array,String oldValue,String newValue) {
	 int index = 0;
	 
	 for(int i=0;i<array.length;i++) {
		 if(array[i].equals(oldValue)) {index = i;}
	 }
	 array[index] = newValue;
}
public void delete_group(String delete_group,String new_group) {
	
		if(delete_group.equals(this.group)) {
			
			this.group = new_group;
			Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_count);
	    	link_info.setGroup(this.group);			
		} // if  
		
		this.group_names = deleteArray_element(group_names, delete_group);
}
public String[] deleteArray_element(String[] array,String delete_value) {
	  String[] temp_array = new String[array.length-1];
	  int index = 0;
	  
	   for(int i=0;i<array.length;i++) {
		  if(!array[i].equals(delete_value)) {
			  temp_array[index] = array[i];
			  index++;
		  }
	  }
	  return temp_array;
}
public void open_chat_frame() {
	
	     Main_Frame.setCurrent_link_count(link_count);
		 
		 Main_Frame.update_pane(1);
		 Main_Frame.get_control_pane().click_message_button();
		 
		 Main_Frame.getMessage_pane().put_send_message_item(link_count);
		 Main_Frame.getMessage_pane().update_state(link_count, state);
		 
		 Chat_frame.put_select_Item(link_count);
		 Chat_frame.update_state(link_count, state);		 
		
}

public void rename_group_name(String old_group,String new_group) {
  
	String[] groups = new String[group_names.length];
	String s = null;
	
	for(int i=0;i<group_names.length;i++) {
		
		s  = group_names[i];
		if(s.equals(old_group)) {
			
			groups[i] = new_group;
			continue;
		}		
		groups[i] = group_names[i];
	}	
}

public void rename_remark(String remark) {
	
	this.name = remark;
	repaint();
}

	@Override
	protected void paintComponent(Graphics g) {	
		super.paintComponent(g);
		Graphics2D  g2 = (Graphics2D) g;
		
		if(enter){
			g2.setColor(focus_color);
			g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
			g2.fillRect(0, 0, 600, 60);
		}
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
		
		if(image!=null) {
		   if(online) {g2.drawImage(image, 10, 10, null);}
		   else {g2.drawImage(grayImage, 10, 10, null);}
		}
		
		if(name!=null) {
		g2.setColor(Color.RED);
		g2.setFont(new Font("宋体", Font.PLAIN, 18));
		g2.drawString(name, 60, 25);}
		
		if(signature!=null) {
		g2.setColor(Color.black);
		g2.setFont(new Font("Microsoft Yahei", Font.PLAIN, 14));
		g2.drawString(signature, 60, 46);}
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
     if(e.getSource()==send_item) {
    	 open_chat_frame();
    	 popupMenu.removeAll();
		 popupMenu = null;
     }
	 else if(e.getSource()==info_item) {
		  
		   Private_info private_info = new Private_info();
		   private_info.setType(3);
		   private_info.setCount(link_count);
		   
		   Private_Chat_Client.send_message(private_info);
		   
		   popupMenu.removeAll();
		   popupMenu = null;
	  } // if info
	 else if(e.getSource()==remark_item) {
	    	 Init_tool_frame();
	    	 popupMenu.removeAll();
			 popupMenu = null;
	  } // remark_item
	 else if(e.getSource()==blacklist_item) {
		 
		 delete_item.doClick();
		 
		 Link_set link_set = new Link_set(9);
		 link_set.setNative_count(Main_Frame.getNative_count());
		 link_set.setLink_account(link_count);
		 Private_Chat_Client.send_message(link_set);
		
		 new Warn_frame("提示","加入黑名单后，将自动屏蔽对方添加请求\n只有主动添加对方，才会移出黑名单").set_aYouTu_click(10);
		 popupMenu.removeAll();
		 popupMenu = null;
	 }
	 else if(e.getSource()==delete_item) {
		 
		 Main_Frame.getFriend_pane().remove_link_Item(link_count);
		 Main_Frame.getMessage_pane().remove_message_item(link_count);
		 Main_Frame.getMessage_pane().remove_link_man(link_count);
		 Chat_frame.remove_Item(link_count);
		 
		 Link_set link_set = new Link_set(5);
		 link_set.setNative_count(Main_Frame.getNative_count());
		 link_set.setLink_account(link_count);
		 
		 Private_Chat_Client.send_message(link_set);
		 
		 popupMenu.removeAll();
		 popupMenu = null;
	 }
	}
   } //friend_Item