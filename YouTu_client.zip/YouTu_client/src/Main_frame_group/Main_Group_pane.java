package Main_frame_group;

import java.awt.Dimension;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import Frame.Main_Frame;
import Message.Private.Link_info;
import custom_component.Box_pane;
import custom_component.My_ScrollPane;
import tool_Frame.Warn_frame;

public class Main_Group_pane  extends My_ScrollPane{

	int width = 600;
    int height = 520;
    
    int group_num = 0;
    int show_item_num = 0;
    Box_pane list_pane = null;
   
    ConcurrentHashMap<String, Group_container> all_group = null;
    Main_Frame main_Frame = null;
  
  public Main_Group_pane(Main_Frame main_Frame) {
	    this.main_Frame = main_Frame;
	 
	    getVerticalScrollBar().setUnitIncrement(50);
		getVerticalScrollBar().setBlockIncrement(50);
		
	    list_pane = new Box_pane(BoxLayout.Y_AXIS);
        list_pane.setOpaque(false);		
		setViewportView(list_pane);
		
	    all_group = new ConcurrentHashMap<>();
	  
	    setPreferredSize(new Dimension(290, 490));
	    setMinimumSize(new Dimension(265, 320));
	    setMaximumSize(new Dimension(595, 1000));
		
	}
  
 public void put_group(boolean ori_group,String group_name) {
	  
	  if(all_group.get(group_name)!=null) {
		  new Warn_frame("提示", "分组："+group_name+" 已存在！").set_aYouTu_click(5);
		  return;
		  }
	  
    	Group_container group_container = new Group_container(group_name);
       
    	all_group.put(group_name, group_container);
    	list_pane.add(group_container);  	

    	  if(!ori_group) {   
    	   for(Group_container container:all_group.values()) {
    		   container.put_new_group(group_name);
    	   }
    	  }// if !ori
    	  
        group_num++;
    	update_pane_size();
    	
    	group_container.do_click();   	
    }
  
 public void rename_group_name(String old_group,String new_group) {
	 
	 Group_container group_container = null;
	  
	  if(all_group.get(new_group)!=null) {
		  new Warn_frame("提示", "分组："+new_group+" 已存在！").set_aYouTu_click(5);
		  return;
		  }
	  
	  group_container = all_group.get(old_group);
	  
	  for(Group_container container:all_group.values()) {
		
		  container.rename_All_Item_group(old_group, new_group);
		  
	  }// for
	  
	  all_group.remove(old_group);
	  all_group.put(new_group, group_container);	
 } 
 
 public String delete_group_name(String delete_group) {
	 
	 if(all_group.size()==1) {return null;}	
	 
		String new_group = get_new_group(delete_group);
		
		
		 for(Group_container container:all_group.values()) {			
			  container.delete_All_Item_groups(delete_group, new_group); //update friend_item's radio_item
		  }// for	
		 
		  Group_container old_container = all_group.get(delete_group);
		  Group_container new_container = all_group.get(new_group);
		  move_group_items(old_container, new_container);  // update and move friend_item
		  
		  all_group.remove(delete_group);
		  list_pane.remove(old_container);
		  
		 int container_show_num = old_container.get_total_item();
		 this.group_num--;
		 this.show_item_num-=container_show_num;
		 update_pane_size();
		// return new_selected_group
		return new_group;
	  }


 public String get_new_group(String delete_group) {
	 
	 for(String new_group:all_group.keySet()) {
		 if(!new_group.equals(delete_group)) {return new_group;}
	 }
	 
	 return null;
 }
 
public void move_group_items(Group_container container, Group_container new_container) {
	 
	 Iterator<String> iterator = container.get_all_linkMan().iterator();
	 String link_account = null;
	
	  while(iterator.hasNext()) {
		  
		 link_account = iterator.next();
		 Group_Item friend_Item = container.get_Friend_Item(link_account);

		 new_container.put_new_Item(link_account, friend_Item);   	
		 new_container.do_click();
	 }
 }

 public void move_link_group(String old_group,String link_account,String new_group) {
 	
		Group_container container = all_group.get(old_group);
	 	if(container==null) {System.out.println("group_container: "+old_group+"==null");return;}
	 	Group_Item friend_Item = container.get_Friend_Item(link_account);
	 	container.remova_Item(link_account);
	 	container.do_click();
	 	
	 	Group_container new_container = all_group.get(new_group);	
	 	new_container.put_new_Item(link_account, friend_Item); 
	 	friend_Item.update_selectedgroup(new_group);
	 	new_container.do_click();
 }
    public void put_Linkman_Item(String group,String link_account) {
    	
    	Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_account);
    	link_info.setGroup(group);
    	
    	Group_container group_container = all_group.get(group);
    	
    	group_container.put_new_Item(link_info);
     	group_container.do_click();
    }
    public void put_Linkman_Item(Link_info link_info) {
    	
    	String group = link_info.getGroup();
    	String link_account = link_info.getLink_count();
    	put_Linkman_Item(group, link_account);
    }
   
    public void remove_link_Item(String link_count) {
    	
    	Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_count);
    	String group = link_info.getGroup();
    	
    	Group_container container = all_group.get(group);
    	container.remova_Item(link_count);
    	Main_Frame.update_UI();

    }    
    
    public void update_size(boolean add,int item_num) {
    	
          if(add) {this.show_item_num+=item_num;}
          else {this.show_item_num-=item_num;}
          
          update_pane_size();
     	
    }
     
    public void update_inform_type(String group,String link_account,String inform_type) {
    	
    	Group_container friend_container = all_group.get(group);
    	Group_Item friend_Item = friend_container.get_Friend_Item(link_account);
        friend_Item.update_inform_type(inform_type);
    	
    }
   
    public void update_state(String link_account,String state) {
    	
    	Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_account);
		if(link_info==null) {return;}
		link_info.setState(state);
		
    	// do something
    }
    public void put_component(JComponent jComponent) {
    	list_pane.add(jComponent);
    }
    
    public void update_pane_size() {
    	
       int height = group_num*35+show_item_num*60;
    	
    	list_pane.setPreferredSize(new Dimension(280, height));
    	list_pane.setMinimumSize(new Dimension(260, height));
    	list_pane.setMaximumSize(new Dimension(595, height));
    	
   }
 public void update_head_image(String link_account,byte[] icon_bytes) {
    	
    	Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_account);
    	String group = link_info.getGroup();
    	
    	Group_container container = all_group.get(group);
		Group_Item group_Item = container.get_Friend_Item(link_account);
		group_Item.update_head_image(icon_bytes);
    }
}
