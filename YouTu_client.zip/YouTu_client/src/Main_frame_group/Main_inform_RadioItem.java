package Main_frame_group;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JMenuItem;

import Frame.Main_Frame;
import Main_frame_friend.*;
import Message.Private.Link_info;
import Message.Private.Link_set;
import ss.Private_Chat_Client;


public class Main_inform_RadioItem extends JMenuItem implements ActionListener{
    
	String group=null;
	String link_account=null;
	String inform_type=null;
	boolean selected = false;
	boolean enter = false;
	
	Image image  = null;
	int x = 0;
	Font font = null;
	Color enter_color = null;
	
	public Main_inform_RadioItem(String group, String link_account, String inform_type,String selected_type) {
		setOpaque(false);

		this.group = group;
		this.link_account = link_account;
		this.inform_type = inform_type;
		this.selected = inform_type.equals(selected_type)?true:false;
		
		this.image = new ImageIcon(getClass().getResource("/tool_image/right.png")).getImage();
		font = new Font("宋体", Font.PLAIN, 14);
		enter_color = new Color(238, 238, 238);
		FontRenderContext frc = new FontRenderContext(new AffineTransform(),true,true);
	    Rectangle rec = font.getStringBounds(inform_type, frc).getBounds();
	    int width = (int) rec.getWidth();
		x = (170-width)/2+10;
		
		setPreferredSize(new Dimension(160, 30));
		setMinimumSize(new Dimension(160,30));
		setMaximumSize(new Dimension(160, 30));
		
	     setBorderPainted(false);
	     setBorder(null);
		
	     Init_listioner();
	}
    
    public void Init_listioner() {
    	addMouseListener(new MouseAdapter() {
    		@Override
    		public void mouseEntered(MouseEvent e) {
    			enter = true;
    			repaint();
    		}
    		@Override
    		public void mouseExited(MouseEvent e) {
    			enter = false;
    			repaint();
    		}
		});
    	
    	addActionListener(this);
    }
	
    @Override
    protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		if(enter) {g2.setColor(enter_color);}
		else {g2.setColor(Color.white);}
		
		g2.fillRect(0, 0, 160, 30);
		
		if(this.selected) {g2.drawImage(image, 5,5, null);}
		
		g2.setFont(font);
		g2.setColor(Color.black);
		g2.drawString(inform_type, x, 20);
    	
    }
    
	@Override
	public void actionPerformed(ActionEvent e) {
		
		Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_account);
		link_info.setInform_type(inform_type);
		
		Main_Frame.getGroup_pane().update_inform_type(group,link_account, inform_type);
		if(!Private_Chat_Client.is_channel_active()) {return;}
		
		Link_set link_set = new Link_set(7);
		link_set.setNative_count(Main_Frame.getNative_count());
		link_set.setLink_account(link_account);
		link_set.setInform_type(inform_type);
		Private_Chat_Client.send_message(link_set);
	}
}
