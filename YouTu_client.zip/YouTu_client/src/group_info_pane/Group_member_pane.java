package group_info_pane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import javax.swing.Box;
import javax.swing.BoxLayout;
import Frame.Only_frame;
import Message.Group.Group_info_message;
import custom_component.Box_pane;
import custom_component.Icon_button;
import custom_component.My_ScrollPane;
import custom_component.Roundrec_button;
import custom_component.Roundrec_textFiled;
import group_info_item.Group_file_item;
import group_info_item.Group_member_Item;
import tool_Frame.Warn_frame;

public class Group_member_pane extends My_ScrollPane {

	Only_frame only_frame = null;
	List_pane list_pane = null;
	Fuction_pane fuction_pane = null;	
	 
	ArrayList<Group_member_Item> all_item = null;
	HashMap<Long,Group_member_Item> join_hash = null;
	HashMap<Long,Group_member_Item> last_hash = null;
     
	public Group_member_pane(Group_info_message info_message) {
		getVerticalScrollBar().setBlockIncrement(200);
		getVerticalScrollBar().setUnitIncrement(200);
		
		Init_components(info_message);
		update_member_pane();	
	}
	
	public void Init_components(Group_info_message info_message) {
		
		list_pane = new List_pane();
		setViewportView(list_pane);
		
		fuction_pane = new Fuction_pane();
		list_pane.add(fuction_pane);
		list_pane.add(Box.createVerticalStrut(45));
		
		all_item = new ArrayList<>();
		join_hash = new HashMap<>();
		last_hash = new HashMap<>();
		
		ArrayList<ArrayList<Object>> all_members = info_message.getAll_members();
		ArrayList<Object> member = null;
		Group_member_Item item = null;
		
		for(int i=0;i<all_members.size();i++) {
			member = all_members.get(i);
			item = new Group_member_Item(i,member,this);
			
			list_pane.add(item);
			all_item.add(item);
			join_hash.put(item.get_join_time(), item);
			last_hash.put(item.get_last_time(), item);
		}
		
	}   // Init_components
	
	 public void callin_frame(Only_frame only_frame) {
		 this.only_frame = only_frame;
	 }
	 
	public void remove_member(int index) {
		
		Group_member_Item item = all_item.get(index);
		long join_time = item.get_join_time();
		long last_time = item.get_last_time();
		
		list_pane.remove(item);
		all_item.remove(item);
		join_hash.remove(join_time);
		last_hash.remove(last_time);
	}
	
	public void update_member_pane() {
		
		list_pane.removeAll();
		list_pane.add(fuction_pane);
		list_pane.add(Box.createVerticalStrut(45));
		
		Group_member_Item item = null;
		String group_id = null;
		
		for(int i=0;i<all_item.size();i++) {
			item = all_item.get(i);
			group_id = item.get_group_id();
			if(group_id.equals("管理员")||group_id.equals("群主")) {list_pane.add(item);}
		}  // for
		for(int i=0;i<all_item.size();i++) {
			item = all_item.get(i);
			group_id = item.get_group_id();
			if(group_id.equals("管理员")||group_id.equals("群主")) {continue;}
			list_pane.add(item);
		}  // for
		
		int height = all_item.size()*45+90;
		list_pane.setPreferredSize(new Dimension(700,height));
		list_pane.setMinimumSize(new Dimension(700,height));
		list_pane.setMaximumSize(new Dimension(700,height));
		
		if(only_frame!=null) {only_frame.update_frame();}
	}
	
public boolean searchFor_account(int member_account) {
      boolean find = false;
		
		list_pane.removeAll();
		list_pane.add(fuction_pane);
		list_pane.add(Box.createVerticalStrut(50));
		
		for(Group_member_Item item:join_hash.values()) {
			
			if(item.get_member_account()==member_account) {
				find = true;
				list_pane.add(item);
				item.set_enter(true);
			}
		}  // for	
		
		for(Group_member_Item item:join_hash.values()) {
			if(item.get_member_account()==member_account) {continue;}
				list_pane.add(item);
				item.set_enter(false);
			}  // for
	 
			only_frame.update_frame();
			
		return find;
	}
 public boolean searchFor_remark(String group_remark) {
		boolean find = false;
		
		list_pane.removeAll();
		list_pane.add(fuction_pane);
		list_pane.add(Box.createVerticalStrut(50));
		
		for(Group_member_Item item:join_hash.values()) {
			
			if(item.get_group_remark().contains(group_remark)) {
				find = true;
				list_pane.add(item);
				item.set_enter(true);
			}
		}  // for	
		
		for(Group_member_Item item:join_hash.values()) {
				if(item.get_group_remark().contains(group_remark)) {continue;}
				list_pane.add(item);
				item.set_enter(false);
			}  // for
	 
			only_frame.update_frame();
			
		return find;
	}
public void sorted_join_time(boolean up) {
	
	list_pane.removeAll();
	list_pane.add(fuction_pane);
	list_pane.add(Box.createVerticalStrut(45));
	
	long[] join_array = get_sorted_array(join_hash.keySet());
	long time = 0l;
	Group_member_Item item = null;
	
	if(up) {
		for(int i=0;i<join_array.length;i++) {
			time = join_array[i];
			item = join_hash.get(time);
			list_pane.add(item);
			}
		} // if up	
else {
	for(int i=join_array.length-1;i>-1;i--) {
		time = join_array[i];
		item = join_hash.get(time);
		list_pane.add(item);
		}
}  // if down
	
	only_frame.update_frame();
}
public void sorted_last_time(boolean up) {
	list_pane.removeAll();
	list_pane.add(fuction_pane);
	list_pane.add(Box.createVerticalStrut(45));
	
	long[] join_array = get_sorted_array(last_hash.keySet());
	long time = 0l;
	Group_member_Item item = null;
	
	if(up) {
		for(int i=0;i<join_array.length;i++) {
			time = join_array[i];
			item = last_hash.get(time);
			list_pane.add(item);
			}
		} // if up	
 else {
	for(int i=join_array.length-1;i>-1;i--) {
		time = join_array[i];
		item = last_hash.get(time);
		list_pane.add(item);
		}
}  // if down
	only_frame.update_frame();
}
public long[] get_sorted_array(Set<Long> set) {
		
		Iterator<Long> it = set.iterator();
		long value = 0l;
				
		long[] all_int = new long[set.size()];
		
		int i = 0 ;
		while(it.hasNext()) {
			
			value = it.next();
			all_int[i] = value;
			i++;
		}
		
		Arrays.sort(all_int);
		
		return all_int;
	}
	private class List_pane extends Box_pane{
         Font font = null;
        
		public List_pane() {
			super(BoxLayout.Y_AXIS);
//			setOpaque(true);
//			setBackground(Color.white);
			
			font = new Font("宋体", Font.PLAIN, 16);
		}
		
		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
			
			g2.setColor(Color.LIGHT_GRAY);
			g2.fillRect(0,40, 700,35);
			
			g2.setColor(Color.black);
			g2.setFont(font);
			
			g2.drawString("排序：",300, 30);
			g2.drawString("头像", 10, 65);
			g2.drawString("昵称", 70, 65);
			g2.drawString("ID", 230, 65);
			g2.drawString("入群时间", 370, 65);
			g2.drawString("最后发言时间", 530, 65);
		}
	} // List_pane
	
	private class Fuction_pane extends Box_pane implements ActionListener{

		 Roundrec_textFiled search_fild = null;
	     Roundrec_button search_button = null;
	     
	     Icon_button joinUp_button = null;
	     Icon_button joinDown_button = null;
	     Icon_button lastUp_button = null;
	     Icon_button lastDown_button = null;
	     
		public Fuction_pane() {
			super(BoxLayout.X_AXIS);
			setOpaque(false);
			
			Init_componets();
			Init_textListioner();
			
			setPreferredSize(new Dimension(700,45));
			setMinimumSize(new Dimension(700,45));
			setMaximumSize(new Dimension(700,45));
		}
		public void Init_componets() {
			search_fild = new Roundrec_textFiled(210, 30, 1.5f,Color.LIGHT_GRAY, new Color(0, 131, 245), 16, Color.black);
			search_fild.set_watermark("请输入昵称或账号：");
			add(search_fild);
			
			search_button = new Roundrec_button(60, 30, 15, new Color(0, 131, 245), "搜索", 16, Color.white);
			add(search_button);
			search_button.addActionListener(this);
			
			joinDown_button = new Icon_button(getClass().getResource("/main_frame_image/down_trans.png"), "降序");
			joinUp_button = new Icon_button(getClass().getResource("/main_frame_image/up_trans.png"), "升序");
			lastDown_button = new Icon_button(getClass().getResource("/main_frame_image/down_trans.png"), "降序");
			lastUp_button = new Icon_button(getClass().getResource("/main_frame_image/up_trans.png"), "升序");			
			
			add(Box.createHorizontalStrut(90));
			add(joinDown_button);
			add(joinUp_button);
			add(Box.createHorizontalStrut(110));
			add(lastDown_button);
			add(lastUp_button);
			add(Box.createHorizontalStrut(90));
			
			joinDown_button.addActionListener(this);
			joinUp_button.addActionListener(this);
			lastDown_button.addActionListener(this);
			lastUp_button.addActionListener(this);
		}
		 public void Init_textListioner() {
			 
			 search_fild.addKeyListener(new KeyAdapter() {
				 @Override
				public void keyReleased(KeyEvent e) {
					if(e.getKeyCode()==KeyEvent.VK_ENTER) {search_button.doClick();}
					only_frame.update_frame();
				}
			});
			
		 }
	@Override
	public void actionPerformed(ActionEvent e) {
		
        if(e.getSource()==search_button) {		   
            String search_content = search_fild.getText();
		    if(search_content.length()==0) {return;}
		    
		    boolean find = false;
		    if(search_content.matches("\\d+")) {find = searchFor_account(Integer.parseInt(search_content));}
		    else {find = searchFor_remark(search_content);}
		    
		    if(!find) {
		    	new Warn_frame("提示", "找不这个成员！").set_aYouTu_click(3);
		    	update_member_pane();}
		    } // search_button
        else  if(e.getSource()==joinDown_button) {sorted_join_time(false);}		   
        else  if(e.getSource()==joinUp_button) {sorted_join_time(true);}		   
        else  if(e.getSource()==lastDown_button) {sorted_last_time(false);}		   
        else  if(e.getSource()==lastUp_button) {sorted_last_time(true);}	
        
		} // actionPerformed
		
	}  // Fuction_pane
	
}
