package group_info_pane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import javax.swing.Box;
import javax.swing.BoxLayout;

import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;

import Frame.File_frame;
import Frame.Group_info_frame;
import Frame.Main_Frame;
import Frame.Only_frame;
import Message.Group.Group_info_message;
import custom_component.Box_pane;
import custom_component.My_ScrollPane;
import custom_component.Roundrec_button;
import custom_component.Roundrec_textFiled;
import group_info_item.Group_file_item;
import ss.Group_Chat_Client;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;

public class Group_file_pane extends My_ScrollPane{
	Only_frame only_frame = null;

	HashMap<Long,Group_file_item> all_item = null;
	List_pane list_pane = null;
	Fuction_pane fuction_pane = null;	
	
	public Group_file_pane(Group_info_message info_message) {
		   
		   fuction_pane = new Fuction_pane();
		   list_pane = new List_pane();
		   setViewportView(list_pane);		   
		  
		   Init_all_files(info_message);
		   update_forTime(); 
	}
	
	public void Init_all_files(Group_info_message info_message) {
		
		 all_item = new HashMap<>();
		 ArrayList<ArrayList<Object>> all_files = info_message.getAll_files();
		 ArrayList<Object> file = null;
		 
		 list_pane.add(fuction_pane);
		 list_pane.add(Box.createVerticalStrut(50));
			
		 for(int i=0;i<all_files.size();i++) {
			 file = all_files.get(i);
			 put_file(file);
		
		 }
	}
	public void callIn_frame(Only_frame only_frame) {
		
		  this.only_frame = only_frame;
	
	}
	public void put_file(ArrayList<Object> file) {
		 Group_file_item item = new Group_file_item(this,file);
		 all_item.put(item.get_send_time(),item);
		 list_pane.add(item);
	}
	public void remove_file(long send_time){
		Group_file_item item = all_item.get(send_time);
		list_pane.remove(item);
		all_item.remove(send_time);
		
		update_pane_size();
	}
	public void update_pane_size() {
		
		int pane_height = all_item.size()*40+90;
		 
		list_pane.setPreferredSize(new Dimension(700,pane_height));
		list_pane.setMinimumSize(new Dimension(700,pane_height));
		list_pane.setMaximumSize(new Dimension(700,pane_height));
		
		  if(only_frame!=null) {only_frame.update_frame();}
	}
	public void update_forTime() {
		
		Group_file_item item = null;
		long[] all_time = get_sorted_array(all_item.keySet());
		long time = 0l;
		
		list_pane.removeAll();
		list_pane.add(fuction_pane);
		list_pane.add(Box.createVerticalStrut(50));
		
		for(int i=all_time.length-1;i>-1;i--) {
		      time = all_time[i];	
		      item = all_item.get(time);
		      list_pane.add(item);
		}
		
		update_pane_size();
	}
	
public long[] get_sorted_array(Set<Long> set) {
		
		Iterator<Long> it = set.iterator();
		long value = 0l;
				
		long[] all_int = new long[set.size()];
		
		int i = 0 ;
		while(it.hasNext()) {
			
			value = it.next();
			all_int[i] = value;
			i++;
		}
		
		Arrays.sort(all_int);
		
		return all_int;
}
public boolean searchFor_name(String name) {
	boolean find = false;
	
	list_pane.removeAll();
	list_pane.add(fuction_pane);
	list_pane.add(Box.createVerticalStrut(50));
	
	for(Group_file_item item:all_item.values()) {
		if(item.get_fileName().contains(name)) {
			find = true;
			list_pane.add(item);
			item.set_enter(true);
		}
	}  // for
	
	for(Group_file_item item:all_item.values()) {
			if(item.get_fileName().contains(name)) {continue;}
			list_pane.add(item);
			item.set_enter(false);
		}  // for
		
		only_frame.update_frame();

	return find;
}
public String check_file_name(String file_name) {
	String new_name = file_name;
	
	for(Group_file_item item:all_item.values()) {
		if(item.get_fileName().equals(file_name)) {
	
			int i = file_name.lastIndexOf(".");
			if(file_name.substring(0,i).endsWith(")")) {new_name = alter2(file_name);}
			else {new_name = alter1(file_name);}
			new_name = check_file_name(new_name);
		}
	}  // for
	
	return new_name;
}
public String alter1(String file_name) {
	int index = file_name.lastIndexOf(".");
	String s1 = file_name.substring(0, index);
	String s2 = file_name.substring(index);
	file_name = s1+"(1)"+s2;
	
	return file_name;
}
public String alter2(String file_name) {
	int i1= file_name.lastIndexOf("(");
	int i2= file_name.lastIndexOf(")");
	String num = file_name.substring(i1+1, i1+2);
	int n = Integer.parseInt(num)+1;
	
	String s1 = file_name.substring(0, i1+1);
	String s2 = file_name.substring(i2);
	file_name = s1+n+s2;
	
	return file_name;
}

private class List_pane extends Box_pane{
    Font font = null;
   
	public List_pane() {
		super(BoxLayout.Y_AXIS);
		
		font = new Font("宋体", Font.PLAIN, 16);
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		g2.setColor(Color.LIGHT_GRAY);
		g2.fillRect(0,40, 700,35);
		
		g2.setColor(Color.black);
		g2.setFont(font);
		
		g2.drawString("文件：",10, 60);
		g2.drawString("大小", 220, 60);
		g2.drawString("上传者", 350, 60);
		g2.drawString("上传时间", 550, 60);

	}
} // List_pane

private class Fuction_pane extends Box_pane implements ActionListener{

	Roundrec_textFiled search_fild = null;
    Roundrec_button search_button = null;
    Roundrec_button send_button = null;
    
	public Fuction_pane() {
		super(BoxLayout.X_AXIS);
		
		setPreferredSize(new Dimension(700,40));
		setMinimumSize(new Dimension(700,40));
		setMaximumSize(new Dimension(700,40));
		
		Init_componets();
		Init_textListioner();
		if(Group_info_frame.is_file_unload()||Group_info_frame.get_group_id().equals("群主")) {Init_button();}
		add(Box.createHorizontalGlue());
	
	}
	public void Init_componets() {
		search_fild = new Roundrec_textFiled(210, 30, 1.5f,Color.LIGHT_GRAY, new Color(0, 131, 245), 16, Color.black);
		search_fild.set_watermark("请输入文件名：");
		add(Box.createHorizontalStrut(60));
		add(search_fild);
		
		search_button = new Roundrec_button(60, 30, 15, new Color(0, 131, 245), "搜索", 16, Color.white);
		add(Box.createHorizontalStrut(10));
		add(search_button);
		search_button.addActionListener(this);
		
	}
public void Init_button() {
		
		send_button = new Roundrec_button(90,30,10,new Color(0, 131, 245),"上传文件", 16, Color.white);
		send_button.addActionListener(this);
		add(Box.createHorizontalStrut(60));
		add(send_button);
		
	}
	 public void Init_textListioner() {
		 
		 search_fild.addKeyListener(new KeyAdapter() {
			 @Override
			public void keyReleased(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_ENTER) {search_button.doClick();}
				only_frame.update_frame();
			}
		});
		
	 }
@Override
public void actionPerformed(ActionEvent e) {
	
   if(e.getSource()==search_button) {		   
       String search_content = search_fild.getText();
	    if(search_content.length()==0) {return;}
	    
	    boolean find = false;
	    find = searchFor_name(search_content);
	    
	    if(!find) {
	    	new Warn_frame("提示", "找不这个文件！").set_aYouTu_click(3);
	    	update_forTime();}
	    } // search_button
   
   else if(e.getSource()==send_button) {
	    FileDialog fileDialog = new FileDialog(only_frame);
		fileDialog.setVisible(true);
		
		String nati_file_name = fileDialog.getFile();
		if(fileDialog.getDirectory()==null||nati_file_name==null) {return;}
		
		String checked_file_name = check_file_name(nati_file_name);   //check_file_name
		System.out.println("remote_file_name: "+checked_file_name);
		
		String file_path = fileDialog.getDirectory()+nati_file_name;
		File file = new File(file_path);
		String sender = Main_Frame.getMessage_pane().get_link_info(String.valueOf(Group_info_frame.get_group_account())).getSignature();
		long send_time = System.currentTimeMillis();
		
		if(!File_frame.is_init()) {new File_frame();}
		File_frame.put_Group_Sendfile_pane(file_path,checked_file_name,send_time, Group_info_frame.get_group_account());
		
		Group_info_message info_message = new Group_info_message(55,Group_info_frame.get_group_account());
		info_message.setFile_name(checked_file_name);
		info_message.setFile_size(file.length());
		info_message.setSender(sender);
		info_message.setSend_time(send_time);
		Group_Chat_Client.send_message(Group_info_frame.get_group_account(), info_message);
		
		 new Warn_frame("提示","等待中。。。").set_aYouTu_click(30);
   }  // send_button
	} // actionPerformed
	
}  // Fuction_pane
public static void main(String[] args) {
	
     File file = new File("D:\\桌面\\a.txt");
     System.out.println(file.getParentFile().getAbsolutePath());
}
}
