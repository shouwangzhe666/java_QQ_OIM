package group_info_pane;

import java.util.ArrayList;

import javax.swing.Box;
import javax.swing.BoxLayout;
import custom_component.Box_pane;
import group_info_item.Group_list_item;
public class Item_list_pane extends Box_pane{

	ArrayList<Group_list_item> all_item = null;
	
	public Item_list_pane() {
		super(BoxLayout.Y_AXIS);
		
		setOpaque(false);
		setBorder(null);
		
		Init_all_item();
	}
	
	public void Init_all_item() {
		
		all_item = new ArrayList<>();
		String[] names = {"主页","成员","通告","相册","文件","设置"};
		
		for(int i=0;i<names.length;i++) {
			Group_list_item item = new Group_list_item(this, names[i]);
			if(names[i].equals("主页")) {item.set_selected(true);}
			
			all_item.add(item);
			add(item);
		}
		add(Box.createVerticalGlue());
	}
	
	public void set_all_unselected() {
		
		Group_list_item item = null;
		
		for(int i=0;i<all_item.size();i++) {
			item = all_item.get(i);
			item.set_selected(false);
		}
	}
}
