package group_info_pane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import Frame.Group_info_frame;
import Frame.Only_frame;
import Message.Group.Group_chat_message;
import Message.Group.Group_info_message;
import custom_component.My_ScrollPane;
import custom_component.My_checkbox;
import custom_component.My_radiobutton;
import custom_component.Roundrec_button;
import custom_component.Roundrec_textFiled;
import ss.Group_Chat_Client;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;

public class Group_set_pane extends My_ScrollPane {
	String sender = null;
	
	Only_frame only_frame = null;
	List_pane list_pane = null;
	Font font = null;
	
	public Group_set_pane(Group_info_message info_message) {	    
		font = new Font("宋体", Font.PLAIN, 16);
		   
		   list_pane = new List_pane(info_message);
		   setViewportView(list_pane);
	}
	 public void callin_frame(Only_frame only_frame) {
		 this.only_frame = only_frame;
	 }
	 
	public Group_info_message get_set_message() {
		 
	    Group_info_message info_message = list_pane.get_set_message();
	    
		return info_message;
	 }
	private class List_pane extends JPanel implements ActionListener{
		
		Group_info_message info_message = null;
		int group_type = 1;
		ButtonGroup group = null;
		
		My_radiobutton any_item = null;
		My_radiobutton nobody_item = null;
		My_radiobutton verify_item = null;
		My_radiobutton question_item = null;
		My_radiobutton pay_item = null;
		
		Roundrec_textFiled quest_fild = null;
		Roundrec_textFiled answer_fild = null;
		Roundrec_textFiled day_fild = null;
		Roundrec_textFiled money_fild = null;
		
		My_checkbox temp_box = null;
		My_checkbox stop_box = null;
		My_checkbox file_unload_box = null;
		My_checkbox file_load_box = null;
		My_checkbox icon_box = null;
		
		Roundrec_button confirm_button = null;
		
		public List_pane(Group_info_message info_message) {
		    setOpaque(false);
		    setLayout(null);
			
		    this.info_message = info_message;
			this.group_type = info_message.getGroup_type();
			
			Init_radioButton();
			Init_textFiled(info_message);
			Init_KeyListioner();
			Init_checkBox();
			Init_button();
			
			setPreferredSize(new Dimension(700,750));
			setMinimumSize(new Dimension(700,750));
			setMaximumSize(new Dimension(700,750));
			
			if(Group_info_frame.get_group_id().equals("群主")) {set_enable(true);}
			else {set_enable(false);}
		}
		
		public void set_enable(boolean enable) {
			
			any_item.setEnabled(enable);
			nobody_item.setEnabled(enable);
			verify_item.setEnabled(enable);
			question_item.setEnabled(enable);
			pay_item.setEnabled(enable);
			
			quest_fild.setEnabled(enable);
			answer_fild.setEnabled(enable);
			day_fild.setEnabled(enable);
			money_fild.setEnabled(enable);
			
			temp_box.setEnabled(enable);
			stop_box.setEnabled(enable);
			file_unload_box.setEnabled(enable);
			file_load_box.setEnabled(enable);
			icon_box.setEnabled(enable);
			
			confirm_button.setEnabled(enable);
		}
		public void Init_radioButton() {
			
			group = new ButtonGroup();
			any_item = new My_radiobutton(group_type==1);
			nobody_item = new My_radiobutton(group_type==2);
			verify_item = new My_radiobutton(group_type==3);
			question_item = new My_radiobutton(group_type==4);
			pay_item = new My_radiobutton(group_type==5);
			
			group.add(any_item);
			group.add(nobody_item);
			group.add(verify_item);
			group.add(question_item);
			group.add(pay_item);
			
			any_item.setBounds(50, 70, 30, 30);
			nobody_item.setBounds(50, 120, 30, 30);
			verify_item.setBounds(50, 170, 30, 30);
			question_item.setBounds(50, 220, 30, 30);
			pay_item.setBounds(50, 270, 30, 30);
			
			add(any_item);
			add(nobody_item);
			add(verify_item);
			add(question_item);
			add(pay_item);
		}
		
		public void Init_textFiled(Group_info_message info_message) {
			
			quest_fild =  new Roundrec_textFiled(210, 25, 1.5f,Color.LIGHT_GRAY, new Color(0, 131, 245), 16, Color.black);
			answer_fild =  new Roundrec_textFiled(210, 25, 1.5f,Color.LIGHT_GRAY, new Color(0, 131, 245), 16, Color.black);
			day_fild =  new Roundrec_textFiled(60, 25, 1.5f,Color.LIGHT_GRAY, new Color(0, 131, 245), 16, Color.black);
			money_fild =  new Roundrec_textFiled(60, 25, 1.5f,Color.LIGHT_GRAY, new Color(0, 131, 245), 16, Color.black);
		//	quest_fild.set_watermark("请输入验证信息");
			
			quest_fild.setText(info_message.getQuestion());
			answer_fild.setText(info_message.getAnswer());
			day_fild.setText(String.valueOf(info_message.getPay_days()));
			money_fild.setText(String.valueOf(info_message.getPay_money()));
						
			quest_fild.setBounds(350, 175, 210, 25);
			answer_fild.setBounds(350, 225, 210, 25);
			day_fild.setBounds(350, 275, 60, 25);
			money_fild.setBounds(550, 275, 60, 25);
			
			add(quest_fild);
			add(answer_fild);
			add(day_fild);
			add(money_fild);
		}
		
		public void Init_KeyListioner() {
			
			quest_fild.addKeyListener(new KeyAdapter() {
				@Override
				public void keyReleased(KeyEvent e) {
					only_frame.update_frame();
				}
			});
			answer_fild.addKeyListener(new KeyAdapter() {
				@Override
				public void keyReleased(KeyEvent e) {
					only_frame.update_frame();
				}
			});
			day_fild.addKeyListener(new KeyAdapter() {
				@Override
				public void keyReleased(KeyEvent e) {
					only_frame.update_frame();
				}
			});
			money_fild.addKeyListener(new KeyAdapter() {
				@Override
				public void keyReleased(KeyEvent e) {
					only_frame.update_frame();
				}
			});
		}
		public void Init_checkBox() {
			
			temp_box = new My_checkbox(info_message.isTemporary_chat());
			stop_box = new My_checkbox(info_message.isStop_all_chat());
			file_unload_box = new My_checkbox(info_message.isFile_upload_all());
			file_load_box = new My_checkbox(info_message.isFile_load_all());
			icon_box = new My_checkbox(info_message.isIcon_upload_all());
			
			temp_box.setBounds(50,385, 30, 30);
			stop_box.setBounds(50,435, 30, 30);
			file_unload_box.setBounds(50,530,30, 30);
			file_load_box.setBounds(50,580,30, 30);
			icon_box.setBounds(50, 630,30, 30);
			
			add(temp_box);
			add(stop_box);
			add(file_unload_box);
			add(file_load_box);
			add(icon_box);
		}
		
		public void Init_button() {
			
			confirm_button = new Roundrec_button(120, 35, 15, new Color(0, 131, 245), "提交", 16, Color.white);
			confirm_button.addActionListener(this);
			confirm_button.setBounds(240, 700,120, 35);
			add(confirm_button);
	}
		public int get_group_type() {
			
			int group_type = any_item.isSelected()?1:nobody_item.isSelected()?2:verify_item.isSelected()?3:question_item.isSelected()?4:pay_item.isSelected()?5:1;
			return group_type;
		}
		public int get_paydays() {
			
			int paydays = 1;
			String text = day_fild.getText();
			if(text.length()>0&&text.matches("\\d+")) {paydays = Integer.parseInt(text);}
			return paydays;
		}
       public int get_paymoney() {
			
			int paymoney = 1;
			String text = money_fild.getText();
			if(text.length()>0&&text.matches("\\d+")) {paymoney = Integer.parseInt(text);}
			return paymoney;
		}
       public String get_question() {
    	   
    	   String text = quest_fild.getText();
    	   if(text.length()==0) {text = "请输入验证信息";}
    	   return text;
       }
 public String get_answer() {
    	   
    	   String text = answer_fild.getText();
    	   if(text.length()==0) {text = "回答正确";}
    	   return text;
       }
 
 public Group_info_message get_set_message() {
	 
	    Group_info_message info_message = new Group_info_message(13, Group_info_frame.get_group_account());
		info_message.setGroup_type(get_group_type());
		info_message.setPay_days(get_paydays());
		info_message.setPay_money(get_paymoney());
		info_message.setQuestion(get_question());
		info_message.setAnswer(get_answer());
		
		info_message.setTemporary_chat(temp_box.isSelected());
		info_message.setStop_all_chat(stop_box.isSelected());
		info_message.setFile_upload_all(file_unload_box.isSelected());
		info_message.setFile_load_all(file_load_box.isSelected());
		info_message.setIcon_upload_all(icon_box.isSelected());
		 
		 return info_message;
	 }
		@Override
		protected void paintComponent(Graphics g) {	
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
			g2.setFont(font);
		
		//	g2.setColor(Color.GRAY);
			g2.setColor(new Color(100, 100, 100));
			
			g2.drawString("加群方式", 120, 40);
			g2.drawString("允许任何人", 95, 90);
			g2.drawString("不允许任何人", 95, 140);
			g2.drawString("需要验证消息", 95, 190);       g2.drawString("问题：",300, 190);
			g2.drawString("需要正确回答问题", 95, 240);   g2.drawString("答案：", 300, 240);
			g2.drawString("付费入群", 95, 290);          g2.drawString("天数：",300, 290);     g2.drawString("金额（元）：",450, 290);
			
			g2.drawString("会话权限", 120, 350);
			g2.drawString("允许群成员发起临时会话", 95, 405);
			g2.drawString("全员禁言", 95, 455);
			
			g2.drawString("应用权限", 120, 510);
			g2.drawString("允许所有人上传文件（关闭后只有群主可以上传）", 95, 550);			
			g2.drawString("允许所有人下载文件（关闭后只有群主可以下载）", 95, 600);
			g2.drawString("允许所有人上传相册（关闭后只有群主可以上传）", 95, 650);
		} // paintComponent

		@Override
		public void actionPerformed(ActionEvent e) {
		
			Group_info_message info_message = Group_info_frame.get_info_message();	 		
		    Group_Chat_Client.send_message(Group_info_frame.get_group_account(), info_message);
		    
		    Group_chat_message chat_message = new Group_chat_message(12, Group_info_frame.get_group_account(), 0, "", "", 0);
		    chat_message.setAll_shutup(info_message.isStop_all_chat());
		    chat_message.setTemp_chat(info_message.isTemporary_chat());
		    Group_Chat_Client.send_message(Group_info_frame.get_group_account(), chat_message);
		    
			new Warn_frame("提示","发送成功！").set_aYouTu_click(3);
			Group_info_frame.set_visiable(false);
		}
	}
}
