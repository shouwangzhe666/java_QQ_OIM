package group_info_pane;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import Frame.Edit_head_icon_frame;
import Frame.Group_info_frame;
import Frame.Main_Frame;
import Frame.Only_frame;
import Message.Group.Group_chat_message;
import Message.Group.Group_info_message;
import custom_component.Roundrec_button;
import custom_component.Roundrec_textArear;
import custom_component.Roundrec_textFiled;
import ss.Group_Chat_Client;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;
import tools.Icon_tools;

public class Group_home_pane extends JPanel implements ActionListener{

	Font font = null;
	byte[] icon_bytes = null;
	Image head_image = null;
	String icon_path = null;
	String name = null;
	String account = null;
	String introduce = null;
	
	Edit_head_icon_frame icon_frame = null;
	Only_frame only_frame = null;
	Roundrec_button icon_button = null;
	Roundrec_button confirm_button = null;
	Roundrec_textFiled name_fild = null;
	Roundrec_textArear textArear = null;
	int name_num = 0;
	int introduce_num = 0;
	
	public Group_home_pane(Group_info_message info_message) {		
		setOpaque(false);
		setLayout(null);
		
		this.account = ""+info_message.getGroup_account();
		icon_path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\image\\head_image\\tempbig.png";
		this.font = new Font("宋体", Font.PLAIN, 16);
		this.icon_bytes = info_message.getGroup_head_icon();
		Icon_tools.Write_image(icon_path, icon_bytes);
		
		ImageIcon imageIcon = new ImageIcon(icon_bytes);
		this.head_image = Icon_tools.get_head_image(imageIcon, 70);
		this.name = info_message.getGroup_name();
		this.name_num = name.length();
		
		this.introduce = info_message.getGroup_introduce();
		this.introduce_num = introduce.length();
		
		Init_components();
		Init_textListioner();
		
		if(Group_info_frame.get_group_id().equals("群主")) {
			Init_owner_components();
		}
		else {
			name_fild.setEditable(false);
			textArear.setEditable(false);
			}
	}
	
	public void Init_components() {
		
		name_fild = new Roundrec_textFiled(210, 30, 1.5f,Color.LIGHT_GRAY, new Color(0, 131, 245), 16, Color.black);
		name_fild.set_watermark("请输群昵称：");
		name_fild.setText(name);
		name_fild.setBounds(100,120,210, 30);
	    add(name_fild);
	    name_fild.setColumns(12);
	    
	    textArear = new Roundrec_textArear(400, 220, 1.5f,Color.LIGHT_GRAY, new Color(0, 131, 245), 16, Color.black);
	    textArear.set_watermark("请输群介绍：");
	    textArear.setLineWrap(true);
	    textArear.setBorder(BorderFactory.createEmptyBorder(5,10, 5,10));
	    textArear.setText(introduce);	   
	    textArear.setBounds(100, 230, 400, 220);
	    add(textArear);
	}
	public void Init_owner_components() {
		
		icon_button = new Roundrec_button(120, 35, 15, new Color(0, 131, 245), "更改头像", 16, Color.white);
		icon_button.setBounds(210, 50, 120, 35);
		add(icon_button);
		icon_button.addActionListener(this);
		
		confirm_button = new Roundrec_button(120, 35, 15, new Color(0, 131, 245), "提交", 16, Color.white);
		confirm_button.setBounds(240, 450, 120, 35);
		add(confirm_button);
		confirm_button.addActionListener(this);
	}
	 public void Init_textListioner() {
		 
		 name_fild.addKeyListener(new KeyAdapter() {
			 @Override
			public void keyReleased(KeyEvent e) {
				name_num = name_fild.getText().length();
				if(name_num>12) {
					name_fild.setText(name_fild.getText().substring(0, 12));
					name_num=12;
				}
				only_frame.update_frame();
			}
		});
		 textArear.addKeyListener(new KeyAdapter() {
			 @Override
			public void keyReleased(KeyEvent e) {
				introduce_num = textArear.getText().length();
				if(introduce_num>250) {
					textArear.setText(textArear.getText().substring(0,250));
					introduce_num = 250;
				}
				only_frame.update_frame();
			}
		});
	 }
	 public void callin_frame(Only_frame only_frame) {
		 this.only_frame = only_frame;
	 }
	 
	 public void Init_icon_frame() {
		 
		    icon_frame = new Edit_head_icon_frame(new ImageIcon(icon_bytes));
			icon_frame.set_visiable(false);
			icon_frame.add_confirmButton_listionner(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
				
				    BufferedImage bufferedImage = icon_frame.get_selected_head_image();				  
				    Icon_tools.Write_image(bufferedImage, 0.6f, icon_path);
				    
				    icon_bytes = Icon_tools.get_IconBytes(icon_path);
				    ImageIcon imageIcon = new ImageIcon(bufferedImage);
					head_image = Icon_tools.get_head_image(imageIcon, 70);
					icon_frame.set_visiable(false);
					repaint();
				}
			});
	 }
	 
	 public Group_info_message get_home_message() {
		 
		 if(name_fild.getText().length()==0||textArear.getText().length()==0) {
		      new Warn_frame("提示", "输入框不能为空！").set_aYouTu_click(3);	
		      return null;
		 }
		 
		 Group_info_message group_info_message  = new Group_info_message(13,Group_info_frame.get_group_account());
		 group_info_message.setGroup_name(name_fild.getText());
		 group_info_message.setGroup_head_icon(icon_bytes);
		 group_info_message.setGroup_introduce(textArear.getText());
		 
		 return group_info_message;
	 }
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
	    
		g2.setColor(Color.black);
		g2.setFont(font);
		
		g2.drawImage(head_image, 100, 20, null);
		g2.drawString("群头像:",5,60);
		g2.drawString("群昵称:",5,140);  g2.drawString(name_num+"字/12",320,140);
		g2.drawString("群账号:     "+account,5,200); 
		g2.drawString("群介绍",5,250);   g2.drawString(introduce_num+"字/250",430,470);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==icon_button) {
			if(icon_frame==null) {Init_icon_frame();}
			icon_frame.set_visiable(true);
		} // icon_button
		else {
			 Group_info_message info_message = Group_info_frame.get_info_message();
			 if(info_message==null) {return;}

			 Group_Chat_Client.send_message(Group_info_frame.get_group_account(), info_message);
		     new Warn_frame("提示","发送成功！").set_aYouTu_click(3);
		     Group_info_frame.set_visiable(false);
		     
		     byte[] headIcon_bytes = Icon_tools.compress_head_image(icon_bytes);
		     Group_chat_message chat_message = new Group_chat_message(11, Group_info_frame.get_group_account(), 0, "", "", 0);
		     chat_message.setIcon_bytes(headIcon_bytes);
		     Group_Chat_Client.send_message(Group_info_frame.get_group_account(), chat_message);
		}
	}
}
