package Message.Group;

public class Group_Ping_Pong {

	int member_account = 0;
	
	public Group_Ping_Pong(int member_account) {
		
		 this.member_account = member_account;
	}

	public int getMember_account() {
		return member_account;
	}

	public void setMember_account(int member_account) {
		this.member_account = member_account;
	}
	
	
}
