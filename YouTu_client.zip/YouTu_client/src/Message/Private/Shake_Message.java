package Message.Private;

import java.io.Serializable;

import javax.swing.JFrame;

import Frame.Only_frame;

public class Shake_Message implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	String from_count = null;
	String to_count = null;
	
	public Shake_Message(String from_count, String to_count) {
		
		this.from_count = from_count;
		this.to_count = to_count;
	}

	public static void shake_frame(Only_frame only_frame) {
		
		only_frame.setVisible(true);
		only_frame.setExtendedState(JFrame.NORMAL); 
		
		int x = only_frame.getX();
		int y = only_frame.getY();
		int width = only_frame.get_frame_width();
		int height = only_frame.get_frame_height();
		
		
	
		for(int i=0;i<8;i++) {
			
		
			x+=15; 
			only_frame.set_Bounds(x, y, width, height);
			try {
				Thread.sleep(30);
			} catch (InterruptedException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
			
	
				y+=15; 
				only_frame.set_Bounds(x, y, width, height);
				try {
					Thread.sleep(30);
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
				
				
				x-=15; 
				only_frame.set_Bounds(x, y, width, height);
				try {
					Thread.sleep(30);
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
				
			
				y-=15; 
				only_frame.set_Bounds(x, y, width, height);
				try {
					Thread.sleep(30);
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}}
	}
	
	public String getFrom_count() {
		return from_count;
	}

	public void setFrom_count(String from_count) {
		this.from_count = from_count;
	}

	@Override
	public String toString() {
		// TODO AYouTu-generated method stub
		return this.to_count;
	}

	public void setTo_count(String to_count) {
		this.to_count = to_count;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
