package ssl_test;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;

public class SSLSocket_Client extends Thread{

	SSLSocket socket = null;
	
	public SSLSocket_Client() {
		
		SSLContext sslContext = SslContextFactory.get_client_sslContext();
		try {
			socket = (SSLSocket) sslContext.getSocketFactory().createSocket(InetAddress.getLocalHost(), 6666);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		byte[] by = null;
		try {
			by = "hello,word!".getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			socket.getOutputStream().write(by, 0, by.length);
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	public static void main(String[] args) {
		
		new SSLSocket_Client().start();
	}
}
