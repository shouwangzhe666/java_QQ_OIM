package Main_frame_pane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

import Frame.Chat_frame;
import Frame.Edit_basic_info_frame;
import Frame.Main_Frame;
import Message.Group.Group_chat_message;
import Message.Private.Private_info;
import custom_component.Icon_button;
import ss.Group_Chat_Client;
import ss.Private_Chat_Client;
import tools.Icon_tools;

public class Main_self_pane extends JPanel implements ActionListener{

	Main_Frame main_Frame = null;
	String native_count = null;
	Private_info private_info = null;
	String icon_path = null;
	ImageIcon imageIcon = null;
	
	byte[] icon_bytes = null;
	Icon_button head_button = null;
	String name = null;
	String signature =null;
	
	Font font1 = null;
	Font font2 = null;
	Color signture_color = null;
	
	public Main_self_pane(Private_info private_info) {
		
		setLayout(null);
		setOpaque(false);
		
		font1 = new Font("正楷", Font.BOLD, 18);
		font2 = new Font("微软雅黑", Font.PLAIN, 14);
		signture_color = new Color(110, 110, 110);		
		
		setPreferredSize(new Dimension(280, 70));
		setMinimumSize(new Dimension(265, 70));
		setMaximumSize(new Dimension(595, 70));
	    
		this.private_info = private_info;
		this.native_count = private_info.getCount();
		this.name = private_info.getName();
		this.signature = private_info.getSignature();
		
		 this.icon_bytes = private_info.getIcon_bytes();
		 icon_path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\image\\head_image\\native.jpg";
		 
		if(icon_bytes.length==0) {	 
		 this.icon_bytes = Icon_tools.get_IconBytes(icon_path);
		
		}
		else {Icon_tools.Write_image(icon_path, icon_bytes);}
	
		head_button = new Icon_button(new ImageIcon(icon_bytes), "编辑资料", 60);
	    head_button.addActionListener(this);
	    head_button.setBounds(10, 10, 60, 60);
	    add(head_button);
	    
		update_name(name);
		update_signature(signature);
		
	}
	  public void update_head_icon() {
		  
		 remove(head_button);
		 imageIcon = new ImageIcon(icon_bytes);
		 
	    head_button = new Icon_button(imageIcon, "编辑资料", 60);
	    head_button.addActionListener(this);
	    head_button.setBounds(10, 10, 60, 60);
	    add(head_button);
	    	      
	  }
	  
	public void update_name(String name) {
		this.name = name;
		private_info.setName(name);
		repaint();
	}
   public void update_signature(String signature) {
		this.signature = signature;
		private_info.setSignature(signature);
		repaint();
	}
 
   public void Init_listioner(Edit_basic_info_frame edit_basic_info_frame) {
	   
	   edit_basic_info_frame.add_cancle_listioner(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
		      edit_basic_info_frame.set_visiable(false);
		}
	});
	   edit_basic_info_frame.add_confirm_listioner(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
		
			if(edit_basic_info_frame.is_corrct()) {
				Private_info info = edit_basic_info_frame.get_Private_info();
				info.setType(1);
				String name = info.getName();
				String signature = info.getSignature();
				
				icon_bytes = info.getIcon_bytes();
				update_head_icon();
				update_name(name);
				update_signature(signature);
				
				edit_basic_info_frame.dispose();
				
				byte[] small_icon_bytes = Icon_tools.compress_head_image(icon_bytes);
				
				Icon_tools.Write_head_image(String.valueOf(Main_Frame.getNative_count()), small_icon_bytes);
				Chat_frame.update_private_self_icon(small_icon_bytes);  //更新自己头像
				Chat_frame.update_group_selficon(small_icon_bytes);
				
				Private_Chat_Client.send_message(info);
		        
				int member_account = Integer.parseInt(Main_Frame.getNative_count());
				Group_chat_message chat_message = new Group_chat_message(10, member_account, 0, "", "", 0);
				chat_message.setIcon_bytes(small_icon_bytes);
				
				ArrayList<Integer> all_group = Main_Frame.getMessage_pane().get_all_group_account();
				
				for(int i=0;i<all_group.size();i++) {
					int group_account = all_group.get(i);
					Group_Chat_Client.send_message(group_account, chat_message);
				}
			}
		}
	});
   }

	@Override
	protected void paintComponent(Graphics g) {	
	//	super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		g2.setColor(Color.white);
		g2.setFont(font1);
		g2.drawString(name, 90, 30);
		
		g2.setColor(Color.black);
		g2.setFont(font2);
		g2.drawString(signature, 80, 60);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==head_button) {
			
			private_info.set_icon_bytes(icon_bytes);
			Edit_basic_info_frame edit_basic_info_frame = new Edit_basic_info_frame(private_info);
			Init_listioner(edit_basic_info_frame);
			
			edit_basic_info_frame.set_visiable(true);
			edit_basic_info_frame.Init_all_contents(private_info);
		}
	}
}