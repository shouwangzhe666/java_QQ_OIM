package Main_frame_pane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import net.coobird.thumbnailator.Thumbnails;


public class Icon_show_pane extends JPanel{

	int start_x = 0;
	int start_y = 0;
	int x = 0;
	int y =0;
	double bi = 1f;
	BufferedImage ori_image = null;
	BufferedImage capture_image = null;
	
	public Icon_show_pane(ImageIcon imageIcon) {
	    setBackground(Color.white);
	    
		int icon_width = imageIcon.getIconWidth();
		int icon_height = imageIcon.getIconHeight();
		
		ori_image = new BufferedImage(icon_width,icon_height, BufferedImage.TYPE_4BYTE_ABGR);
		ori_image.getGraphics().drawImage(imageIcon.getImage(), 0, 0, null);
		capture_image = ori_image;
		
		Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
		x=(size.width-icon_width)/2;
		y=(size.height-icon_height)/2;
		
		Init_mouse_listioner();
		Init_mouse_Motion_listioner();
		Init_WheelListener();
		
	}
	
	public void Init_mouse_listioner() {
		
		addMouseListener(new MouseAdapter() {
	 		@Override
	 		public void mousePressed(MouseEvent e) {
	 			
	 			start_x = e.getX();
	 			start_y = e.getY();
	 		}
		});
	}
	public void Init_mouse_Motion_listioner() {
		
		addMouseMotionListener(new MouseMotionAdapter() {
			@Override
	 		public void mouseDragged(MouseEvent e) {
	 			
	 			int gap_x=e.getX()-start_x;
	 			int gap_y=e.getY()-start_y;
	 			
	 			start_x = e.getX();
	 			start_y =e.getY();
	 			
	 			x+=gap_x;
	 			y+=gap_y;
	 			repaint();
	 		}
		});
	}
	
	public void Init_WheelListener() {
		
          addMouseWheelListener(new MouseWheelListener() {
			
			@Override
			public void mouseWheelMoved(MouseWheelEvent e) {
			
				if(e.getWheelRotation()==-1) {
					
				  bi-=0.05f;
				  try {
					capture_image = Thumbnails.of(ori_image).scale(bi).asBufferedImage();
				} catch (IOException e1) {
					// TODO AYouTu-generated catch block
					e1.printStackTrace();
				}
				 
				}  // if
				
				else {
					 bi+=0.05f;
					  try {
						capture_image = Thumbnails.of(ori_image).scale(bi).asBufferedImage();
					} catch (IOException e1) {
						// TODO AYouTu-generated catch block
						e1.printStackTrace();
					}
					 
				} // else
				
				x = (getWidth()-capture_image.getWidth())/2;
				y = (getHeight()-capture_image.getHeight())/2;
				
				 repaint();
			}
		});
	}
	
	public void re_paint() {
		
		x = (getWidth()-capture_image.getWidth())/2;
		y = (getHeight()-capture_image.getHeight())/2;
		
		 repaint();
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(capture_image, x, y, null);
	}
}
