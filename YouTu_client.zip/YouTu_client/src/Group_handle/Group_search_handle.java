package Group_handle;

import java.awt.Image;

import javax.swing.ImageIcon;

import org.omg.CORBA.CTX_RESTRICT_SCOPE;

import Frame.Main_Frame;
import Frame.Search_frame;
import Message.Group.Group_chat_message;
import Message.Group.Group_search_message;
import Message.Private.Link_info;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import message_login_register.List_message;
import ss.Group_Chat_Client;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;
import tools.Icon_tools;

public class Group_search_handle extends SimpleChannelInboundHandler<Group_search_message>{

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Group_search_message search_message) throws Exception {
		
		int type = search_message.getType();
		
		if(type==2) {handle_type2(search_message);}
		else if(type==4) {handle_type4(search_message);}
		else if(type==5) {handle_type5(search_message);}
		else if(type==6) {handle_type6(ctx,search_message);}
	}

	public void handle_type2(Group_search_message search_message) {
		
		System.out.println("client Group_search_message handle_type2");
		boolean scuess = search_message.isScuess();
		String group_account = search_message.getGroup_account();
		
		if(scuess) {
			new Warn_frame("提示", "恭喜您建群成功！").set_aYouTu_click(3);
			Main_Frame.getMessage_pane().put_accept_message_item(group_account, System.currentTimeMillis(), "恭喜您建群成功！");
		}
	} // handle_type2
	
	public void handle_type4(Group_search_message search_message) {
		
		String group_type = search_message.getGroup_type();
		
		if(group_type.equals("0")) {new Warn_frame("提示", "此群聊不存在！").set_aYouTu_click(5);}
		else {
			Search_frame search_frame = new Search_frame();
			search_frame.put_group_show_pane(search_message);
		}
	}  // handle_type4
	
	public void handle_type5(Group_search_message search_message) {
		 //  show add request
		
		String native_account = search_message.getNative_account();
		String group_account = search_message.getGroup_account();
//		byte[] icon_bytes = link_info.getHead_icon_bytes();
		ImageIcon head_image = new ImageIcon(search_message.getNative_icon());
		
		String name = search_message.getNative_name();
		String verify_message = search_message.getVerify_message();
		long system_time = System.currentTimeMillis();
		
		List_message list_message = new List_message(4, native_account, head_image, "", name, verify_message,system_time, 0);	
		list_message.setGroup_account(group_account);
		
		Main_Frame.getMessage_pane().put_request_message_item(false,list_message);
			
		Main_Frame.update_UI();
	}
 public void handle_type6(ChannelHandlerContext ctx,Group_search_message search_message) {
	//  add group scuessfully
	  
//		try {
//			Link_info link_info = new Link_info(1);
//			link_info.setGroup_account(Integer.parseInt(search_message.getGroup_account()));
//			link_info.Init_reques_head_image();
//			ctx.writeAndFlush(link_info);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}

		Link_info link_info = new Link_info(10);   // 请求加载该群所有成员头像（包括群头像）
		link_info.setGroup_account(Integer.parseInt(search_message.getGroup_account()));
		ctx.writeAndFlush(link_info);
		
		String group_account = search_message.getGroup_account();		
		Main_Frame.getMessage_pane().put_accept_message_item(group_account,System.currentTimeMillis(), "加群成功");		
		Main_Frame.update_UI();
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
				// 将自己的头像更新至群全员
				int member_account = Integer.parseInt(Main_Frame.getNative_count());
				Group_chat_message chat_message = new Group_chat_message(10, member_account, 0, "", "", 0);
				chat_message.setIcon_bytes(Icon_tools.get_IconBytes(member_account));
				Group_Chat_Client.send_message(Integer.parseInt(group_account), chat_message);
			}
		}).start();
	}
}
