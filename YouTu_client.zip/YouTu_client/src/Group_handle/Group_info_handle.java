package Group_handle;

import Frame.File_frame;
import Frame.Group_info_frame;
import Message.Group.Group_info_message;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

public class Group_info_handle extends SimpleChannelInboundHandler<Group_info_message>{

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Group_info_message group_info) throws Exception {
		
		int type = group_info.getType();
		
		switch (type) {
		
		case 14:handle_info_result(group_info);break;
		case 24:handle_member_result(group_info);break;
		case 34:handle_notice_result(group_info);break;
		case 44:handle_icon_result(group_info);break;
		
		case 54:handle_file_result(group_info);break;
		case 57:handle_Sendfile_result(group_info);break;
		case 58:handle_Acceptfile_result(group_info);break;
		
		default:System.out.println("client 无法处理的 Group_info_message");break;
		}
	}

public void handle_info_result(Group_info_message group_info) {
		Group_info_frame.load_home_set_pane(group_info);
	}
public void handle_member_result(Group_info_message group_info) {
	Group_info_frame.load_member_pane(group_info);
	}
public void handle_notice_result(Group_info_message group_info) {
	Group_info_frame.load_notice_pane(group_info);
	
}
public void handle_icon_result(Group_info_message group_info) {
	Group_info_frame.load_icon_pane(group_info);
}
public void handle_file_result(Group_info_message group_info) {
	Group_info_frame.load_file_pane(group_info);
}
public void handle_Sendfile_result(Group_info_message group_info) {
	
	File_frame.start_Group_Sendfile(group_info);
}
public void handle_Acceptfile_result(Group_info_message group_info) {
//	System.out.println("handle_Acceptfile_result");
//	File_frame.start_Group_AcceptFilePane(group_info);  // this is discarded
}
}
