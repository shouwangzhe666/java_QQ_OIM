package Group_handle;

import java.io.File;
import Frame.File_frame;
import Frame.Main_Frame;
import Message.Group.Group_file_message;
import cc.EditDesktop;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import tools.GroupSendFile_thread;

public class Group_file_message_handle extends SimpleChannelInboundHandler<Group_file_message>{

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Group_file_message file_message) throws Exception {
		
		int type = file_message.getType();
		
		if(type==1) {handle_type1(ctx,file_message);}
		else if(type==2) {handle_type2(ctx,file_message);}
		else if(type==3) {handle_type3(ctx,file_message);}
		else if(type==4) {handle_type4(ctx,file_message);}
	}

public void handle_type1(ChannelHandlerContext ctx,Group_file_message file_message) {
		
	String file_name = file_message.getFile_name();
	String string = EditDesktop.get_DesktopBackground();
	String dir = new File(string).getParentFile().getAbsolutePath();
	
	File file = new File(dir+"\\"+file_name);
	System.out.println("群文件查询 file_name: "+file_name+"  exist? "+file.exists());
	
	if(file.exists()) {

		file_message.setType(2);
		file_message.setReply_account(Integer.parseInt(Main_Frame.getNative_count()));
		file_message.setReply_ip(Main_Frame.get_NativeIp());
		
		ctx.writeAndFlush(file_message);
		System.out.println("群文件回复");
	}
}
public void handle_type2(ChannelHandlerContext ctx,Group_file_message file_message) {
		// server accept
	}
public void handle_type3(ChannelHandlerContext ctx,Group_file_message file_message) {
	  System.out.println("准备接受群文件");
	  File_frame.start_Group_AcceptFilePane(file_message);	
}
public void handle_type4(ChannelHandlerContext ctx,Group_file_message file_message) {
	 System.out.println("开始群文件转发");
	 new GroupSendFile_thread(file_message).start();
}
}
