package Group_handle;

import java.io.IOException;
import java.io.ObjectOutputStream;

import Frame.Chat_frame;
import Frame.Main_Frame;
import Group_chat.Group_show_pane;
import Message.Group.Group_chat_message;
import Message.Private.Link_info;
import chat_frame_pane.Group_chat_pane;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import tool_Frame.Warn_frame;
import tools.Icon_tools;
import tools.My_Object_IO;

public class Group_chat_handle extends SimpleChannelInboundHandler<Group_chat_message>{

	int group_account = 0;
	
	public Group_chat_handle(int group_account) {
		this.group_account = group_account;
		
	}
	
	public void write_group_chat_message(Group_chat_message chat_message) {
		String file_path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\chat_history\\group_chat\\"+group_account+".db";
		ObjectOutputStream objectOutputStream = My_Object_IO.get_ObjectoutputStream(file_path, true);
		try {
			objectOutputStream.writeObject(chat_message);
			objectOutputStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	@Override
	protected void messageReceived(ChannelHandlerContext arg0, Group_chat_message chat_message) throws Exception {					
		
		Group_chat_pane chat_pane = Chat_frame.get_Group_chat_jpane(group_account);
		
		int type = chat_message.getType();
		if(type!=3&&type<8) {write_group_chat_message(chat_message);}
		
		if(type==1||type==2) {
			
			if(chat_message.getMember_account()==Integer.parseInt(Main_Frame.getNative_count())) {return;}
			
			String popu_message  = chat_message.get_popu_message();
			Main_Frame.getMessage_pane().put_accept_message_item(String.valueOf(group_account),chat_message.getSend_time(),popu_message);
			Chat_frame.update_item_content(String.valueOf(group_account),popu_message);	

			if(chat_pane==null) {return;}
			chat_pane.put_chat_Message(chat_message, true);
		}
		else if(type==3) {
			if(chat_message.isSelf()&&chat_message.getMember_account()==Integer.parseInt(Main_Frame.getNative_count())) {return;}
			
			if(chat_pane==null) {return;}
			chat_pane.remove_chat_item(chat_message, true);
			}
		else if(type==4) {
			if(chat_pane==null) {return;}
			chat_pane.update_shutup(chat_message, true);}
		else if(type==5) {
			if(chat_pane==null) {return;}
			chat_pane.update_administer(chat_message, true);}
		else if(type==6) {
			if(chat_pane==null) {return;}
			chat_pane.update_id(chat_message, true);}
		else if(type==7) {
			if(chat_message.getMember_account()==Integer.parseInt(Main_Frame.getNative_count())) {
				
				 Main_Frame.getGroup_pane().remove_link_Item(String.valueOf(group_account));
				 Main_Frame.getMessage_pane().remove_message_item(String.valueOf(group_account));
				 Main_Frame.getMessage_pane().remove_link_man(String.valueOf(group_account));
				 Chat_frame.remove_Item(String.valueOf(group_account));
				 
				 new Warn_frame("", "你已被移出群聊").set_aYouTu_click(5);
			}
			else{chat_pane.remove_member(chat_message, true);}
		} // if type==7
		else if(type==8) {
			// 更新群成员昵称
			int member_account  = chat_message.getMember_account();
			String member_remark = chat_message.getGroup_remark();
			
			Chat_frame.update_group_member_remark(group_account, member_account, member_remark);
		}
		else if(type==9) {
			// 更新群昵称
			// 与群备注冲突，和群备注保持一致
		}
		else if(type==10) {
			// 更新群成员头像
			int member_account  = chat_message.getMember_account();
			if(Integer.parseInt(Main_Frame.getNative_count())==member_account) {return;}
			
			String link_account = String.valueOf(member_account);
			byte[] icon_bytes = chat_message.getIcon_bytes();
			Icon_tools.Write_head_image(link_account, icon_bytes);
			
			Chat_frame.update_group_othericon(group_account,member_account,icon_bytes);
		}  // if type==10
		else if(type==11) {
			// 更新群头像
			String link_account = String.valueOf(chat_message.getMember_account());
			byte[] icon_bytes = chat_message.getIcon_bytes();
			Icon_tools.Write_head_image(link_account, icon_bytes);
			
			Main_Frame.getGroup_pane().update_head_image(link_account, icon_bytes);
			Main_Frame.getMessage_pane().update_head_image(link_account, icon_bytes);
			Chat_frame.update_item_head_icon(link_account, icon_bytes);
		}
		else if(type==12) {
			if(chat_pane==null) {return;}
			chat_pane.set_all_shutup(chat_message.isAll_shutup());
		//	chat_pane.set_Temp_chat(chat_message.isTemp_chat());
			
		}
	} 
}
