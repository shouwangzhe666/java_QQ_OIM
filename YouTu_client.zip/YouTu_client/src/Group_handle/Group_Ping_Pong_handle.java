package Group_handle;

import java.net.InetAddress;

import Frame.Main_Frame;
import Message.Group.Group_Ping_Pong;
import Private_handle_pack.Ping_Pong_Handle;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import message_login_register.Ping_Pong;
import ss.Group_Chat_Client;

public class Group_Ping_Pong_handle extends SimpleChannelInboundHandler<Group_Ping_Pong>{

	    Group_Chat_Client client  = null;
	    InetAddress inetAddress = null;
	    int port = 0 ;
	    int native_member_account = 0;
	    
	    public Group_Ping_Pong_handle(Group_Chat_Client client,InetAddress inetAddress,int port) {
	    	
			this.client = client;
			this.inetAddress = inetAddress;
			this.port = port;
			this.native_member_account = Integer.parseInt( Main_Frame.getNative_count());
		}
	    @Override
	    public void channelActive(ChannelHandlerContext ctx) throws Exception {
	            ctx.writeAndFlush(new Group_Ping_Pong(native_member_account));
	    }
	    @Override
		protected void messageReceived(ChannelHandlerContext arg0, Group_Ping_Pong arg1) throws Exception {
		
        // 	System.out.println("群成员收到心跳消息！");
		}

	 
		@Override
		public void channelInactive(ChannelHandlerContext ctx) throws Exception {
			
			 System.out.println("客户端链路中断。。。");
			 client.re_connect(inetAddress, port);
			
		}
		@Override
		public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {		
		 //   System.out.println("exceptionCaught channel().close()");
			System.out.println("客户端 发生异常。。。");
			cause.printStackTrace();
			ctx.channel().close().sync();
			
		}
		
		@Override
		public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
			
			if(evt instanceof IdleStateEvent) {
				IdleStateEvent idleStateEvent = (IdleStateEvent) evt;
				
				if(idleStateEvent.state().equals(IdleState.READER_IDLE)) {
				
					System.out.println("pingpong timedout channel().close()");
					ctx.channel().close().sync();
						
					//	}
				} // if
				
				else if(idleStateEvent.state().equals(IdleState.WRITER_IDLE)) {
					ctx.writeAndFlush(new Group_Ping_Pong(native_member_account));
				//	ctx.writeAndFlush(new Group_Ping_Pong(0));
				}
			}
		}
}
