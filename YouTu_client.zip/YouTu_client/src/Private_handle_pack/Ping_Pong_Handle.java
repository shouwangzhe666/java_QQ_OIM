package Private_handle_pack;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import message_login_register.Ping_Pong;
import ss.Private_Chat_Client;

public class Ping_Pong_Handle extends SimpleChannelInboundHandler<Ping_Pong>{

    Private_Chat_Client client  = null;
   
    public Ping_Pong_Handle( Private_Chat_Client client) {
    	
		this.client = client;
	}
    
	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Ping_Pong arg1) throws Exception {
		
	//	System.out.println("客户端收到心跳消息！");
	 
	}

	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
		
		 System.out.println("客户端链路中断。。。");
		 
		 if(ctx.channel().isActive()) {
			  ctx.channel().close().sync();
			}
		 
		 client.re_connect();

	}
	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {	
		System.out.println("客户端 发生异常。。。");
		cause.printStackTrace();	
       
	}
	
	@Override
	public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
		
		if(evt instanceof IdleStateEvent) {
			IdleStateEvent idleStateEvent = (IdleStateEvent) evt;
			
			if(idleStateEvent.state().equals(IdleState.READER_IDLE)) {
			
				System.out.println("客户端心跳超时");
				
				if(ctx.channel().isActive()) {
				   ctx.channel().close().sync();
				}
			} // if
			
			else if(idleStateEvent.state().equals(IdleState.WRITER_IDLE)) {
				ctx.writeAndFlush(new Ping_Pong());
			}
		}
	}
}
