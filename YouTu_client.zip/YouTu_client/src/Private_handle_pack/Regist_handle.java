package Private_handle_pack;


import java.io.File;

import Frame.Regist_frame;
import io.netty.channel.ChannelHandlerAdapter;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import message_login_register.Register_message;
import tool_Frame.Warn_frame;

public class Regist_handle extends SimpleChannelInboundHandler<Register_message>{

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Register_message register_message) throws Exception {

		int step = register_message.getStep();
		
		if(step==2) {heandle_type2(ctx, register_message);}
		else if(step==4) {heandle_type4(ctx, register_message);}
	}
	
	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {	
		ctx.channel().close().sync();
	}
	
	public  void heandle_type2(ChannelHandlerContext ctx, Register_message register_message) {
		
		String verify_code = register_message.getVerify_code();
		if(verify_code.contains("regist")) {
			String email = verify_code.split(",")[0];
			String content = "邮箱账号  “"+email+"” 已经注册,\n现在您可以使用与该邮箱关联的YouTu账号直接登录,\n若忘记密码，\n您可以通过该邮箱找回密码。";
			new Warn_frame("提示", content);
		//	Regist_frame.dis_pose();
		}
		
		else {
			String email = verify_code.split(",")[0];
			String code = verify_code.split(",")[1];          //YouTu验证码
			String content = "YouTu验证码已发送至邮箱："+email+",\n请注意查收！";
			new Warn_frame("提示", content);
			
			Regist_frame.set_code(code);
		}
	}
	
public  void heandle_type4(ChannelHandlerContext ctx, Register_message register_message) {
		 
	          String account = register_message.getAccount();
	          String password = register_message.getPassword();
	          String ip = register_message.getIp();
	          int port = register_message.getPort();
	         
	          if(account.length()==0) {  new Warn_frame("提示", "注册时间超过5分钟，请重新注册！").set_aYouTu_click(5);return;}
	          
	          String icon_path = "C:\\ProgramData\\YouTu\\image\\private_head_image\\native.jpg";
	          File file = null;
	          file = new File(icon_path);
	          if(file.exists()) {file.renameTo(new File("C:\\ProgramData\\YouTu\\image\\private_head_image\\"+account+".jpg"));}
	          
	          String content = "恭喜您注册成功！\nYouTu账号: "+account+"\nYouTu密码："+password+"\n\n请截屏保存好账号密码信息！";
			  new Warn_frame("提示", content);
	}


}
