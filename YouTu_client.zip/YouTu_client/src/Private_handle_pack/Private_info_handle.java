package Private_handle_pack;

import Frame.Chat_frame;
import Frame.Login_frame;
import Frame.Look_info_frame;
import Frame.Main_Frame;
import Message.Private.Link_info;
import Message.Private.Private_info;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;
import tools.Icon_tools;

public class Private_info_handle extends SimpleChannelInboundHandler<Private_info>{

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Private_info private_info) throws Exception {
	
		int type = private_info.getType();
		
	if(type==1) {
		
		String name  = private_info.getName();
		String account = private_info.getCount();
		byte[] head_bytes = private_info.getIcon_bytes();	
		
		if(head_bytes.length==0) {
			String icon_path = "C:\\ProgramData\\YouTu\\YouTu_"+account+"\\image\\head_image\\native.jpg";
			head_bytes = Icon_tools.get_IconBytes(icon_path);
			}
		
		  Login_frame.login_success(name,head_bytes);
			
		// 初始化主面板...
			try {
				new Main_Frame(private_info);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			new Chat_frame();			
			
		}
		else if(type==2) {
			
			String result = private_info.getResult();
			new Warn_frame("提示", result).set_aYouTu_click(3);
		}
		else if(type==4) {
			
			String account  = private_info.getCount();
			String name = private_info.getName();
			
			if(name.length()==0) {new Warn_frame("提示", "无法查询到账号："+account+" 的信息").set_aYouTu_click(5);}
			
			else {				
				        new Look_info_frame(private_info);
			}
		} //if(type==4)
	}

	
}
