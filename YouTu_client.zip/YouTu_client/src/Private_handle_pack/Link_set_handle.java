package Private_handle_pack;

import java.util.TimerTask;

import javax.management.timer.Timer;

import Frame.Chat_frame;
import Frame.Main_Frame;
import Message.Private.Link_info;
import Message.Private.Link_set;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

public class Link_set_handle extends SimpleChannelInboundHandler<Link_set>{

	@Override
	protected void messageReceived(ChannelHandlerContext arg0, Link_set link_set) throws Exception {
		
		int type = link_set.getType();
		
		if(type==5) {handle_type5(link_set);}
		else if(type==8) {handle_type8(link_set);}
		else if(type==10) {handle_type10(link_set);}
	}

	public void handle_type5(Link_set link_set) {
		
        String link_account = link_set.getNative_count();
		
		if(link_account.length()==8) {Main_Frame.getFriend_pane().remove_link_Item(link_account);}
		else if(link_account.length()==9) {Main_Frame.getGroup_pane().remove_link_Item(link_account);}
		
		Main_Frame.getMessage_pane().remove_message_item(link_account);
		Main_Frame.getMessage_pane().remove_link_man(link_account);
		
	    Chat_frame.remove_Item(link_account);
		
		Main_Frame.update_UI();
	}
	
	public void handle_type8(Link_set link_set) {
		
		String link_account = link_set.getNative_count();
		String state = link_set.getState();
                
		Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_account);
		link_info.setState(state);

		Main_Frame.getMessage_pane().update_state(link_account, state);
		Main_Frame.getFriend_pane().update_state(link_account, state);
		Chat_frame.update_state(link_account, state);		
		
	}
public void handle_type10(Link_set link_set) {
		
		String link_account = link_set.getNative_count();
		String remote_ip = link_set.getRmeote_ip();
                
		Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_account);
		link_info.setRemote_ip(remote_ip);	
		
	}
}
