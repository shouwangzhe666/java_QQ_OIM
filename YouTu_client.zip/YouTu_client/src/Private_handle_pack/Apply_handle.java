package Private_handle_pack;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.concurrent.ConcurrentHashMap;

import javax.swing.filechooser.FileSystemView;

import Frame.Audio_chat_frame;
import Frame.File_frame;
import Frame.Main_Frame;
import Frame.Wait_frame;
import MainThread_pack.Audio_thread;
import Message.Private.Apply_Message;
import Message.Private.Link_info;
import VA_Pack_UDP.Audio_Chat;
import VA_Pack_UDP.Audio_Transfer_Server;
import VA_Pack_UDP.Video_Chat;
import cc.Constant_Receive;
import cc.Constant_Sender;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelOutboundHandlerAdapter;
import io.netty.channel.SimpleChannelInboundHandler;
import ss.Private_Chat_Client;
import tcp_pack.TCP_P2P_Pointer;
import tcp_pack.TCP_Transfer_Pointer;
import tool_Frame.Confirm_frame;
import tool_Frame.Warn_frame;
import tools.FileUtills;

public class Apply_handle  extends SimpleChannelInboundHandler<Apply_Message>{

@Override
protected void messageReceived(ChannelHandlerContext arg0,Apply_Message apply_Message) throws Exception {
		
	int protocal_code = apply_Message.getProtocal_code();
	
	if(protocal_code==131) {handle_file(apply_Message);}
	else if(protocal_code==132) {handle_video_chat(apply_Message);}
	else if(protocal_code==133) {handle_audio_chat(apply_Message);}
	else if(protocal_code==134) {handle_constant(apply_Message);}
	else if(protocal_code==135) {handle_audio(apply_Message);}
	
	else if(protocal_code==136) {handle_TcpRequest(apply_Message);}
	else if(protocal_code==137) {handle_UdpRequest(apply_Message);}
}
	
public boolean check_infomType(Apply_Message apply_Message) {
	
	String from_account = String.valueOf(apply_Message.getFrom_account());
    Link_info link_info = Main_Frame.getMessage_pane().get_link_info(from_account);
    String inform_type = link_info.getInform_type();
          
    if(inform_type.equals("屏蔽消息")) {apply_Message=null;return false;}
    return true;
}
public void handle_file(Apply_Message apply_Message) {
	if(!check_infomType(apply_Message)) {return;}
	
	  if(apply_Message.getType()==1) {              // file request

		     String name_tip = "文件名称："+apply_Message.getFile_name();
		     String size_tip = "文件大小:"+FileUtills.file_size_format(apply_Message.getFile_size());
		     String content = "是否接受来自对方的文件？\n"+name_tip+"\n"+size_tip;
		     
		     showAnd_handle_confirmFrame(apply_Message, content);
	  }
	  else if(apply_Message.getType()==2) {              // file reply
		  
		  boolean accept = apply_Message.isAccept();
		  if(accept) {File_frame.start_file_transfer(apply_Message);}
		  else {File_frame.stop_file_transfer(apply_Message);}
	  }
	  else if(apply_Message.getType()==3) {         // file reply`s reply
		  File_frame.put_Accept_file_pane(apply_Message);		
	  }
	}
public void handle_video_chat(Apply_Message apply_Message) {
   if(apply_Message.getType()==1) {       
	   // video_chat request
	     showAnd_handle_confirmFrame(apply_Message, "是否接受来自对方的视频通话？");
   }
   else if(apply_Message.getType()==2){                                               // video_chat reply
	   
	   Wait_frame.setFrame_visiable(false);
	   
	   if(apply_Message.isAccept()) {
		   if(apply_Message.getP2p_type()==1) {
				
				Video_Chat video_Chat = new Video_Chat(apply_Message.getUdp_server_port1(),apply_Message.getFrom_account()); 
				new Thread(video_Chat).start();
	            Main_Frame.set_Video_Chat(video_Chat);
			}
			else if(apply_Message.getP2p_type()==2) {
				 Audio_Chat audio_Chat = new Audio_Chat(apply_Message.getUdp_server_port1(),apply_Message.getFrom_account()); 
				 audio_Chat.start();	
				
				new VA_Pack_TCP.Video_Chat(apply_Message.getTcp_server_port(), audio_Chat).start();
			}		
	   } // isAccept
	   else {
		    new Warn_frame("提示", "对方拒绝了你的视频通话请求").set_aYouTu_click(6);
		    Audio_Chat.ReleaseVAOccupy();
	   }       // is not Accept
   }           // type==2
   else if(apply_Message.getType()==3){ 
	   
	   if(!Audio_Chat.isVAOccupy()) {Audio_Chat.VAOccupy();}
	   
	   if(apply_Message.getP2p_type()==1) {
			
			Video_Chat video_Chat = new Video_Chat(apply_Message.getUdp_server_port1(),apply_Message.getFrom_account()); 
			new Thread(video_Chat).start();
            Main_Frame.set_Video_Chat(video_Chat);
		}
		else if(apply_Message.getP2p_type()==2) {
			 Audio_Chat audio_Chat = new Audio_Chat(apply_Message.getUdp_server_port1(),apply_Message.getFrom_account()); 
			 audio_Chat.start();	
			
			new VA_Pack_TCP.Video_Chat(apply_Message.getTcp_server_port(), audio_Chat).start();
		}		
   }          // type==3
 else if(apply_Message.getType()==4) {
	   
	   Main_Frame.get_Video_Chat().flush_video_chat();
   }
 else if(apply_Message.getType()==5) {
	   
	   Main_Frame.get_Video_Chat().close_video_chat();
   }
}
public void handle_audio_chat(Apply_Message apply_Message) {
 if(apply_Message.getType()==1) {               // audio_chat request
	
	  showAnd_handle_confirmFrame(apply_Message, "是否接受来自对方的语音通话？");
 }
 else if(apply_Message.getType()==2){              // audio_chat reply
	 
	    Wait_frame.setFrame_visiable(false);
	 
	   if(apply_Message.isAccept()) {
		    Audio_Chat audio_Chat = new Audio_Chat(apply_Message.getUdp_server_port1(),apply_Message.getFrom_account()); 
			audio_Chat.start();			
			Main_Frame.set_Audio_Chat(audio_Chat);
			
			Audio_chat_frame audio_chat_frame = new Audio_chat_frame(audio_Chat);
			audio_Chat.import_Audio_chat_frame(audio_chat_frame);
			
	   } // isAccept
	   else {
		    new Warn_frame("提示", "对方拒绝了你的视语音话请求").set_aYouTu_click(6);
		    Audio_Chat.ReleaseVAOccupy();
	   } // is not Accept
 } // type==2
 else if(apply_Message.getType()==3){ 
	 
	 if(!Audio_Chat.isVAOccupy()) {Audio_Chat.VAOccupy();}
	 
	   Audio_Chat audio_Chat = new Audio_Chat(apply_Message.getUdp_server_port1(),apply_Message.getFrom_account()); 
	   audio_Chat.start();			
	   Main_Frame.set_Audio_Chat(audio_Chat);	
		
		Audio_chat_frame audio_chat_frame = new Audio_chat_frame(audio_Chat);
		audio_Chat.import_Audio_chat_frame(audio_chat_frame);
 }
 else if(apply_Message.getType()==4) {
	   
	   Main_Frame.get_Audio_Chat().flush_audio();
 }
else if(apply_Message.getType()==5) {
	   
	 Main_Frame.get_Audio_Chat().close_audio_chat();
 }
}
public void handle_constant(Apply_Message apply_Message) {
  if(apply_Message.getType()==1) {               // constant request

	 showAnd_handle_confirmFrame(apply_Message, "是否接受来自对方的远程桌面？");
  }
  else if(apply_Message.getType()==2){         // audio_chat reply
	  
	   Wait_frame.setFrame_visiable(false);
	  
 	   if(apply_Message.isAccept()) {
 		  System.out.println("start Constant_Sender");
 		  new Thread(new Constant_Sender(apply_Message.getP2p_type(),apply_Message.getTcp_server_port())).start();
 	   } // isAccept
 	   else {
 		    Audio_Chat.ReleaseVAOccupy();
 		    new Warn_frame("提示", "对方拒绝了你的远程桌面请求").set_aYouTu_click(6);
 	   } // is not Accept
  } //   type==2
  else if(apply_Message.getType()==3){  
	        Audio_Chat.VAOccupy();
	       new Constant_Receive(apply_Message.getP2p_type(),apply_Message.getTcp_server_port()).start();
  }  //   type==3
}
public void handle_audio(Apply_Message apply_Message) {
	 int p2p_type = apply_Message.getP2p_type();
	 int server_port = apply_Message.getTcp_server_port();
	 Socket socket = null;
	 
	 if(p2p_type==1||p2p_type==2) {
		  TCP_P2P_Pointer p2p_Pointer = new TCP_P2P_Pointer("TCP_Pointer", server_port);
		  p2p_Pointer.start();
		  socket = p2p_Pointer.get_socket(60);
		}
	else if(p2p_type==3) {
			try {
				socket = new Socket(InetAddress.getByName("115.28.186.188"), server_port);
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	 
	 if(socket==null) {System.err.println("语音消息连接失败！");return;}
	 
	 int link_account = apply_Message.getFrom_account();
	 ConcurrentHashMap<Integer,Audio_thread> all_audio_thread = Main_Frame.get_all_audio_thread();
	 Audio_thread audio_thread = all_audio_thread.get(link_account);
	 
	 if(audio_thread==null) {        // accept point
		 audio_thread = new Audio_thread();
		 audio_thread.start_ThreadPoolExecYouTur();
		 all_audio_thread.put(link_account, audio_thread);
	 }		 	 
	 
	 audio_thread.start_thread(link_account,p2p_type,socket);
}
public void handle_TcpRequest(Apply_Message apply_Message) {
    System.out.println("handle_TcpRequest");
	new TCP_Transfer_Pointer().connect_And_transfer(apply_Message.getTcp_server_port());
}
public void handle_UdpRequest(Apply_Message apply_Message) {
	
	new Audio_Transfer_Server(apply_Message.getUdp_server_port1(), apply_Message.getUdp_server_port2()).start();
}
public String get_remark(Apply_Message apply_Message) {
	
	int link_account = apply_Message.getFrom_account();
	Link_info link_info = Main_Frame.getMessage_pane().get_link_info(String.valueOf(link_account));
	String remark = link_info.getRemark();
	
	return remark;
}
public long  get_File_binLocation(String file_name) {
	
	 String home_path = FileSystemView.getFileSystemView().getHomeDirectory().getAbsolutePath();
	 String file_path = home_path+"\\"+file_name;
	 long start_position = 0l;
	 
	if(new File(file_path).exists()) {start_position = new File(file_path).length();}
	else {
		 int index = file_name.lastIndexOf(".");
		 file_path = home_path+"\\"+file_name.substring(0, index)+".temp";
		 start_position = new File(file_path).length();
	}
	 
	return start_position;
}
public void showAnd_handle_confirmFrame(Apply_Message apply_Message,String content) {
	
	 String remark = get_remark(apply_Message);
	 Confirm_frame confirm_frame = new Confirm_frame(remark, content);
	 
	 confirm_frame.add_confirm_listioner(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			
			Apply_Message message = get_ApplyMessage(apply_Message, true);
			
			String file_name = apply_Message.getFile_name();
			String file_path = FileSystemView.getFileSystemView() .getHomeDirectory().getAbsolutePath()+"\\"+file_name;
			long start_position = 0; 
			 
			 if(new File(file_path).exists()) {start_position = new File(file_path).length();}
			 else {
				 int index = file_name.lastIndexOf(".");
				 file_path = FileSystemView.getFileSystemView() .getHomeDirectory().getAbsolutePath()+"\\"+file_name.substring(0,index)+".temp";
				 if(new File(file_path).exists()) {start_position = new File(file_path).length();}
               }
			message.setFilebin_location(start_position);
			Private_Chat_Client.send_message(message);	
		
		}
	});
	 confirm_frame.add_quite_listioner(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			Apply_Message message = get_ApplyMessage(apply_Message, false);
			Private_Chat_Client.send_message(message);
		
		}
	});
}
public Apply_Message get_ApplyMessage(Apply_Message apply_Message,boolean accept) {
	
	int from_account = apply_Message.getFrom_account();
	int to_account   = apply_Message.getTo_account();
	
	apply_Message.setFrom_account(to_account);
	apply_Message.setTo_account(from_account);
	apply_Message.setType(2);
	apply_Message.setAccept(accept);
	
	return apply_Message;
}
}
