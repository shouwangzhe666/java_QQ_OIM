package tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Decoder_Builder {
	File infile = null;
	File outfile = null;
	PrintWriter writer = null;
	
	public Decoder_Builder() {
	
		infile = new File("C:\\ProgramData\\Users\\Administrator\\Desktop\\src.txt");
		
		FileUtills.create_new_file("C:\\ProgramData\\Users\\Administrator\\Desktop\\decoder.txt");
		outfile = new File("C:\\ProgramData\\Users\\Administrator\\Desktop\\decoder.txt");
		
		try {
			writer = new PrintWriter(outfile);
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	}
	
	public void generate() {
		
		String message_name = null;
		BufferedReader reader = null;
		String fild_string = null;
		String type = null;
		String name = null;
		
		if(!infile.exists()) {
			writer.close();
			System.err.println("file: src.txt not found");
			return;}
		
		try {
			reader = new BufferedReader(new FileReader(infile));
		} catch (FileNotFoundException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		try {
			message_name = reader.readLine();
		} catch (IOException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
		try {
			while((fild_string=reader.readLine())!=null) {
					
				type = fild_string.split(" ")[0];
				name = fild_string.split(" ")[1];
				
				if(type.equals("int")) {generate_int(message_name, name);}
				else if(type.equals("String")) {generate_String(message_name, name);}
				else if(type.equals("bytes")) {generate_bytes(message_name, name);}
				
			}
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}  // while
		
		writer.close();
		try {
			reader.close();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("over!");
	}  //generate
	
public void generate_int(String message_name,String name) {
		
	     String s1 = "buf.readInt()";
	     String s2 = message_name+".set_"+name+"("+s1+")";
	     writer.println(s2);
	     writer.println();
	}
	
public void generate_String(String message_name,String name) {
	   
	    String s1 = "buf.readInt()";
	    String s2 = "byte[] by = new byte["+s1+"]";
	    String s3 = "buf.readBytes(by)";
	    String s4 = message_name+".set_"+name+"(new String(by,\"UTF-8\"))";
	   
//	    writer.println(" try {");
	    writer.println(s2);
	    writer.println(s3);
	    writer.println(s4);
//	    writer.println("} catch (Exception e) {\r\n" + 
//	    		"			// TODO: handle exception\r\n" + 
//	    		"		}");
	    writer.println();
		
	}

public void generate_bytes(String message_name,String name) {
	
	 String s1 = "buf.readInt()";
	 String s2 = "byte[] by = new byte["+s1+"]";
	 String s3 = "buf.readBytes(by)";
	 String s4 = message_name+".set_"+name+"(by)";
	  
//	    writer.println(" try {");
	    writer.println(s2);
	    writer.println(s3);
	    writer.println(s4);
//	    writer.println("} catch (Exception e) {\r\n" + 
//	    		"			// TODO: handle exception\r\n" + 
//	    		"		}");
	    writer.println();
}

public static void main(String[] args) {
	
	    new Decoder_Builder().generate();
}
}
