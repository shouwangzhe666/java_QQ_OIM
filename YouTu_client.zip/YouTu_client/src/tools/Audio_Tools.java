package tools;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;

import javax.media.CannotRealizeException;
import javax.media.ConfigureCompleteEvent;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.DataSink;
import javax.media.Format;
import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.NoDataSinkException;
import javax.media.NoPlayerException;
import javax.media.NoProcessorException;
import javax.media.Player;
import javax.media.PrefetchCompleteEvent;
import javax.media.Processor;
import javax.media.RealizeCompleteEvent;
import javax.media.control.TrackControl;
import javax.media.format.AudioFormat;
import javax.media.protocol.DataSource;
import javax.media.protocol.FileTypeDescriptor;

import Frame.Main_Frame;

public class Audio_Tools {
	Player player = null;
	Processor audio_processor = null;
	DataSource audio_datasourse = null;
	DataSink dataSink = null;
	boolean complate = false;
	Object sync2 = new Object();
	int link_account = 0;
	String audio_path = null;
	
	public Audio_Tools(int link_account,long send_time) {
		this.link_account = link_account;
		audio_path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\chat_history\\private_chat\\audio\\"+link_account+"\\"+send_time+".wav";
	//	System.out.println("audio_path: "+audio_path);
	}
	
	public String get_audio_path() {
		return audio_path;
	}
	
	public void start_record() {
		
	//	 long time = System.currentTimeMillis();
		  audio_processor = Create_Processor();
		  Configure__Processor(audio_processor);
		  
		   create_dataSink();	
	//       System.out.println(System.currentTimeMillis()-time);
		   System.out.println("recording....");
	}
	public void save_record() {
		 stop_record();		
	}
	public void cancle_record() {
		stop_record();
		new File(audio_path).delete();
	}
	public void stop_record() {
		 
		 audio_processor.stop();
		 audio_processor.close();
		 
		 try {
			dataSink.stop();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		 dataSink.close();	
	 }
	public Processor Create_Processor() {
		Processor audio_processor = null;
         try {
				audio_processor = Manager.createProcessor(new MediaLocator("javasound://44100"));
			} catch (NoProcessorException e) {
				e.printStackTrace();
				System.err.print("获取麦克风失败，请检查麦克风是否正确连接。");
			} catch (IOException e) {
				e.printStackTrace();
				System.err.print("获取麦克风失败，请检查麦克风是否正确连接。");
			}    
         
         return audio_processor;
}
	 public void Configure__Processor(Processor audio_processor) {
		   	
		   audio_processor.configure();
	       waitForState(audio_processor, javax.media.Processor.Configured);  
	       
	       Configure_Audio_Processor(audio_processor);
	       
	       audio_processor.realize();
	       waitForState(audio_processor, javax.media.Processor.Realized); 
	      
	       audio_processor.start();
	   }
	 public void create_dataSink() {
		 
		 MediaLocator mediaLocator = null;;
		
		try {			
			mediaLocator = new MediaLocator(new File(audio_path).toURI().toURL());
		} catch (MalformedURLException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
		 System.out.println(mediaLocator==null);
		 try {
			dataSink = Manager.createDataSink(audio_processor.getDataOutput(), mediaLocator);
		} catch (NoDataSinkException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		 try {
			dataSink.open();
			dataSink.start();
		} catch (SecurityException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
	 }
	 public boolean Configure_Audio_Processor(Processor audio_processor) {
		  
	     
	      // encode_name  file_size	     
	      //  GSM_MS      84 KB
	      //  IMA4_MS     420 KB
	      //  ULAW        830 KB
	      //  LINEAR      1.6 M	      

	      AudioFormat audioFormat =  new AudioFormat(AudioFormat.GSM_MS);

//          System.out.println(audioFormat.getSampleRate());
//          System.out.println(audioFormat.getSampleSizeInBits());
//          System.out.println(audioFormat.getChannels());
          
          FileTypeDescriptor descriptor = new FileTypeDescriptor(FileTypeDescriptor.WAVE);
	      audio_processor.setContentDescriptor(descriptor); 
	      
          TrackControl[] tracks = audio_processor.getTrackControls();  
          
		   for (int i = 0; i < tracks.length; i++) {  

			   Format supportedFormats[] = tracks[i].getSupportedFormats();  
	             
	             if(supportedFormats.length>0) {tracks[i].setEnabled(true);tracks[i].setFormat(audioFormat);}
				 else {tracks[i].setEnabled(false);}              

	     } // for
		   return true;
	  }
	 public void waitForState(Processor p, int state) {  
		  
		   int i = 0;
		   p.addControllerListener(new ControllerListener() {
			
			@Override
			public void controllerUpdate(ControllerEvent arg0) {
			
				 if(arg0 instanceof ConfigureCompleteEvent || arg0 instanceof PrefetchCompleteEvent||arg0 instanceof RealizeCompleteEvent) {
					   if(p.getState()==state) {
						   synchronized (sync2) {
							   complate = true;						  
							   sync2.notify();
						}
					 }
				 }
			}
		});
	     
		   synchronized (sync2) {
			  while(!complate) {
				  try {
					  sync2.wait();
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
			}
		}
		   complate = false;
 }    
  public void start_playSound() {
	  
	  MediaLocator mediaLocator = null;
	  try {
		mediaLocator = new MediaLocator(new File(audio_path).toURI().toURL());
	} catch (MalformedURLException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	  try {
		player = Manager.createRealizedPlayer(mediaLocator);
	} catch (NoPlayerException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	} catch (CannotRealizeException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	
	  player.start();
  }
  public void stop_playSound() {
	  player.stop();
	  player.close();
  }
}
