package tools;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class My_object_outputstream extends ObjectOutputStream{

	 static File f=null;
     
	public My_object_outputstream(FileOutputStream fout,File f) throws IOException {
		super(fout);
		
			}

	@Override
	protected void writeStreamHeader() throws IOException {
	
		
		if(f.length()==0) {super.writeStreamHeader();}
		else{super.reset();}
		
	}
	
	public static My_object_outputstream create_My_object_outputstream(String file_path,boolean append) {
		
		File file = new File(file_path);
		
		My_object_outputstream.f = file;
		
		FileOutputStream fout  = null;
		try {
			fout  = new FileOutputStream(file,append);
		} catch (FileNotFoundException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
		
		try {
			return new My_object_outputstream(fout,f);
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
