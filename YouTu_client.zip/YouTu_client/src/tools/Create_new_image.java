package tools;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.FileDialog;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;

import jdk.internal.org.objectweb.asm.tree.IntInsnNode;
import tool_Frame.Icon_show_frame;
import tool_Frame.Warn_frame;

import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

import com.sun.org.apache.xerces.internal.util.SynchronizedSymbolTable;

import Frame.Edit_head_icon_frame;

public class Create_new_image {

	BufferedImage bufferedImage=null;
	int i=0;
	int x=80;
	int h=30;
	FileOutputStream fOutputStream=null;
	Image image=null;
	String name = null;
	
	public Create_new_image() {
		
		 BufferedImage bufferedImage = new BufferedImage(30, 30, BufferedImage.TYPE_4BYTE_ABGR);
	        Graphics2D g2 =(Graphics2D) bufferedImage.createGraphics();
	  //      bufferedImage.set
	        //把图片切成一个圆
//	        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
//	            graphics.setComposite(AlphaComposite
//	    			    .getInstance(AlphaComposite.SRC_OVER, 0.4f));
	            
	           // graphics.setColor(Color.red);
	           // graphics.fillRect(0, 0, 25, 25);
//	            
	           
//	            graphics.setComposite(AlphaComposite
//	    			    .getInstance(AlphaComposite.SRC_OVER, 1.0f));
	            
	        BasicStroke basicStroke = new BasicStroke(1f);
	        g2.setStroke(basicStroke);
	        
//               g2.setColor(Color.lightGray);
//               g2.fillRect(0, 0, 30, 30);
	         
               g2.setColor(Color.black);
               g2.drawRect(7, 8, 15, 13);
          
               
	            int ran =(int)(Math.random()*30000*10000);
	            String file_name=ran+".png";
	            String file_path= "C:\\ProgramData\\Users\\Administrator\\Desktop\\"+file_name;
	            File f = new File(file_path);
	            
		  try {
			ImageIO.write(bufferedImage, "png", f);
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		  JButton jButton = null;
		 jButton = new JButton();
		
	//	new Icon_show_frame(new ImageIcon(bufferedImage));
		System.out.println("over!");
	}
	  
	public void getGrayPicture(String icon_path)  {  
		
		File file = null;
		file = new File(icon_path);
		if(!file.exists()) {new Warn_frame("提示", "图片路径： "+icon_path+" 不存在！").set_aYouTu_click(5);}
		
		BufferedImage routeImage = null;
		 try {
			routeImage = ImageIO.read(new FileInputStream(file));
		} catch (FileNotFoundException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		 
        int green=0,red=0,blue=0,rgb;  
        int imageWidth = routeImage.getWidth();  
        int imageHeight = routeImage.getHeight();  
        for(int i = routeImage.getMinX();i < imageWidth ;i++)  
            {  
                for(int j = routeImage.getMinY();j < imageHeight ;j++)  
                {  
//图片的像素点其实是个矩阵，这里利用两个for循环来对每个像素进行操作  
                    Object data = routeImage.getRaster().getDataElements(i, j, null);//获取该点像素，并以object类型表示  
                    red = routeImage.getColorModel().getRed(data);  
                    blue = routeImage.getColorModel().getBlue(data);  
                    green = routeImage.getColorModel().getGreen(data);  
                    red = (red*3 + green*6 + blue*1)/10;  
                    green = red;  
                    blue = green;  
/* 
这里将r、g、b再转化为rgb值，因为bufferedImage没有提供设置单个颜色的方法，只能设置rgb。rgb最大为8388608，当大于这个值时，应减去255*255*255即16777216 
*/  
                    rgb = (red*256 + green)*256+blue;  
                    if(rgb>8388608)  
                    {  
                        rgb = rgb - 16777216;  
                    }  
//将rgb值写回图片  
    routeImage.setRGB(i, j, rgb);  
                }  
                  
            }  
             
                     new Icon_show_frame(new ImageIcon(routeImage));
                     
                     return;
    }  
	
	public void get_select_color_image(BufferedImage bufferedImage,int r,int g,int b) {
		
		int rgb = (r*256 + g)*256+b;  
		int image_rgb = 0;
		int width = bufferedImage.getWidth();
		int height = bufferedImage.getHeight();
		 if(rgb>8388608)  {   rgb = rgb - 16777216;   }  
		 //System.out.println("存在相同像素");
		 
		for(int y=0;y<height;y++) {
			for(int x=0;x<width;x++) {
				
				image_rgb = bufferedImage.getRGB(x, y);
				if(image_rgb>8388608)  {   image_rgb = image_rgb - 16777216;   }  
		//		System.out.println(image_rgb);
				if(rgb==image_rgb) {}
				else {bufferedImage.setRGB(x, y, 0);}
			}
		}
		
		new Icon_show_frame(new ImageIcon(bufferedImage));
	}
	public static void main(String[] args) {
		
	//	new Create_new_image().getGrayPicture("C:\\ProgramData\\Users\\Administrator\\Desktop\\QQ截图20190812182149_副本.png");
		File f = new File("C:\\ProgramData\\Users\\Administrator\\Pictures\\QQ截图2019081320442.png");
		RandomAccessFile raf=null;
		try {
			raf = new RandomAccessFile(f, "rw");
		} catch (FileNotFoundException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		FileChannel fc = raf.getChannel();
		FileLock fl=null;
		try {
			fl = fc.tryLock();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		if (fl.isValid()) {
		try {
			Thread.sleep(30000);
		} catch (InterruptedException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} //do something here, 这时用notepad打开无法修改.
		try {
			fl.release();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		}
		try {
			raf.close();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	}

}
