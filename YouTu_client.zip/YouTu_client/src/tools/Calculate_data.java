package tools;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.sun.org.apache.xerces.internal.util.SynchronizedSymbolTable;

public class Calculate_data {

	static int year = 0;
	static int month = 0;
	static int day = 0;
	static String age=null;
	String string =null;
	
	public static String Calculate_data(String data) {
		
		String[] strings = data.split(",");
		
		year =Integer.parseInt(data.substring(0, 4));
		month =Integer.parseInt(data.substring(6, 8));
		day =Integer.parseInt(data.substring(10, 12));
		 
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("YYYY");
		String string= simpleDateFormat.format(new Date());
		age =""+( Integer.parseInt(string)-year);
		
		String xing = get_constellation(month,day);
		String sheng = get_animals(year);
		
		String s = age+"岁 "+strings[1]+strings[2]+"(公历) "+xing+" "+sheng;
		
		return s;
		
	}
	
	public static String get_constellation(int month,int day) {
		
		
		    if (month == 1 && day >= 20 || month == 2 && day <= 18) {  
	         return "水瓶座";  
	        }  
		    else if (month == 2 && day >= 19 || month == 3 && day <= 20) {  
	        	return "双鱼座";  
	        }  
		    else  if (month == 3 && day >= 21 || month == 4 && day <= 19) {  
	        	return "白羊座";  
	        }  
		    else  if (month == 4 && day >= 20 || month == 5 && day <= 20) {  
	        	return "金牛座";  
	        }  
		    else  if (month == 5 && day >= 21 || month == 6 && day <= 21) {  
	        	return "双子座";  
	        }  
		    else  if (month == 6 && day >= 22 || month == 7 && day <= 22) {  
	        	return "巨蟹座";  
	        }  
		    else  if (month == 7 && day >= 23 || month == 8 && day <= 22) {  
	        	return "狮子座";  
	        }  
		    else if (month == 8 && day >= 23 || month == 9 && day <= 22) {  
	        	return "处女座";  
	        }  
		    else if (month == 9 && day >= 23 || month == 10 && day <= 23) {  
	        	return "天秤座";  
	        }  
		    else if (month == 10 && day >= 24 || month == 11 && day <= 22) {  
	        	return "天蝎座";  
	        }  
		    else  if (month == 11 && day >= 23 || month == 12 && day <= 21) {  
	        	return "射手座";  
	        }  
		    else  if (month == 12 && day >= 22 || month == 1 && day <= 19) {  
	        	return "摩羯座";  
	        }  
	        
		return "";
	}
	
	public static String get_animals(int birth_year) {
		
		int i =(birth_year-1911)%12;
		
		if(i==1) {return "属鼠";}
		else if(i==2) {return "属牛";}
		else if(i==3) {return "属虎";}
		else if(i==4) {return "属兔";}
		else if(i==5) {return "属龙";}
		else if(i==6) {return "属蛇";}
		else if(i==7) {return "属马";}
		else if(i==8) {return "属羊";}
		else if(i==9) {return "属猴";}
		else if(i==10) {return "属鸡";}
		else if(i==11) {return "属狗";}
		else if(i==0) {return "属猪";}
		
		return "";
		
	}
	
}
