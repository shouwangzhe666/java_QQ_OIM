package tools;

import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledExecutorService;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

import net.coobird.thumbnailator.Thumbnails;
import net.coobird.thumbnailator.geometry.Positions;
import tool_Frame.Icon_show_frame;

public class BackGround_Tools {
	
	int screen_width = 0;
	int screen_height = 0;
	
	public static BufferedImage get_back_ground(String icon_path) {
		
		BufferedImage back_image = get_back_image(icon_path);
		BufferedImage fore_image = get_fore_image(icon_path);
		
		Graphics2D g2 = (Graphics2D) back_image.getGraphics();
		g2.drawImage(fore_image, 0, 0, null);
		g2.dispose();
		
		return back_image;
	} // method
	
	private static BufferedImage get_fore_image(String icon_path) {
		
        BufferedImage fore_image = null;
		
		try {
			fore_image = ImageIO.read(new File(icon_path));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		int border_width = 60;
		fore_image = Gaussian_Blur.eclosion_right_border(fore_image, border_width);
		fore_image = Gaussian_Blur.eclosion_bottom_border(fore_image, border_width);
	//	fore_image = Gaussian_Blur.get_image(fore_image, border_width);
	 //fore_image = Gaussian_Blur.eclosion_corner(fore_image,20, 120);
		
		return fore_image;
	}
	
	private static BufferedImage get_back_image(String icon_path) {
		
	//	first to use Gaussian_Blur to get the main_color of image
		
		BufferedImage image = null;
		 try {
			 image = Gaussian_Blur.gaussian_blur(ImageIO.read(new File(icon_path)), 200);
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		 
		 Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		 int screen_width = (int) dimension.getWidth();
		 int screen_height = (int) dimension.getHeight();
		 
		 float b1 = (float)image.getHeight()/(float)image.getWidth();
		 float b2 = (float)screen_height/(float)screen_width;
		 
		// second to adjust icon_size to screen_size
		
		 //压缩至指定图片尺寸，保持图片不变形，多余部分裁剪掉
		  //压缩至指定图片尺寸（例如：横400高300），保持图片不变形，多余部分裁剪掉(这个是引的网友的代码)
		  
		  int imageWidth = image.getWidth();
		  int imageHeitht = image.getHeight();
		  
		  try {
			  if ((float)screen_width / screen_height != (float)imageWidth / imageHeitht) {
				  
			//	  image = Thumbnails.of(image).width(screen_width).asBufferedImage();
				  
					if (b1<b2) {  
						image = Thumbnails.of(image).height(screen_height).asBufferedImage();
						}
					else { 
						image = Thumbnails.of(image).width(screen_width).asBufferedImage();
						} 
					 
					image = Thumbnails.of(image).scale(1f).sourceRegion(Positions.TOP_LEFT, screen_width, screen_height).asBufferedImage();}
			  
			//	}  // try
		} catch (Exception e) {
			
			 e.printStackTrace();
		}
		  
		  //scale 参数是浮点数,大于1表示放大,小于1表示缩小//outputQuality 参数是浮点数,质量压缩,0-1之间
		  //keepAspectRatio 在调整尺寸时保持比例,默认为true,如果要剪裁到特定的比例,设置为false即可
		  //注意：scale、width|height、size三者不能同时共存，但必须要有一个

		 return image;
	} // get_back_image
	
	public static void complete_tasks() {
		
		String path1 = "C:\\ProgramData\\Users\\Administrator\\Desktop\\background_image\\";
		String path2 = "C:\\ProgramData\\Users\\Administrator\\Desktop\\";
		BufferedImage bufferedImage = null;
		
		for(int i=31;i<37;i++) {
		     
			path1 = "C:\\ProgramData\\Users\\Administrator\\Desktop\\background_image\\"+i+".jpg";
			bufferedImage = BackGround_Tools.get_back_ground(path1);
			
			path2 = "C:\\ProgramData\\Users\\Administrator\\Desktop\\"+i+".jpg";
			try {
				ImageIO.write(bufferedImage, ".jpg", new FileOutputStream(path2));
			} catch (FileNotFoundException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("全部做完！");
	}
	
	public static void main(String[] args) {
		
//		BackGround_Tools.complete_tasks();
		
		FileDialog fileDialog = new FileDialog(new JFrame());
		fileDialog.setVisible(true);
		
		String icon_path = fileDialog.getDirectory()+fileDialog.getFile();
		BufferedImage back_image = BackGround_Tools.get_back_ground(icon_path);
	//	BufferedImage back_image = BackGround_Tools.get_fore_image(icon_path);
		
		try {
			ImageIO.write(back_image, "jpg",new File("C:\\ProgramData\\Users\\Administrator\\Desktop\\dd.jpg"));
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
//		new Icon_show_frame(new ImageIcon(back_image));
	}
}
