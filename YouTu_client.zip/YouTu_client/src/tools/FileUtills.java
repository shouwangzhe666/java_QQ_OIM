package tools;

import java.io.*;
import java.nio.channels.FileChannel;
import java.text.DecimalFormat;

public class FileUtills {
	
	//param file or directory
	public static long getFileSize(File file) {
		if(!file.exists()) {return 0;}
		
        if (file.isFile())
            return file.length();
        final File[] children = file.listFiles();
        long total = 0;
        if (children != null)
            for (final File child : children)
                total += getFileSize(child);
        return total;
    }
	
	public  static void create_new_file(String file_path) {
		
		File file = null;
		file = new File(file_path);
		
		file.getParentFile().mkdirs();
		if(!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
		}
		
}// create_file_method
	
// public static void copyFile(String frompath,String topath) {
//		FileInputStream fileInputStream = null;
//		FileOutputStream fileOutputStream = null;
//		FileChannel inChannel = null;
//		FileChannel outChannel = null; 
//		try {
//			fileInputStream = new FileInputStream(frompath);
//			fileOutputStream = new FileOutputStream(topath);
//			
//			inChannel = fileInputStream.getChannel();
//			outChannel = fileOutputStream.getChannel();
//			inChannel.transferTo(0, inChannel.size(), outChannel);
//			
//			fileInputStream.close();
//			inChannel.close();
//			fileOutputStream.close();
//			outChannel.close();
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//	}
	public static void copyFile(String frompath,String topath) {
		File srcfile = new File(frompath);
		File toFile = new File(topath);
		FileInputStream fileInputStream = null;
		FileOutputStream fileOutputStream = null;
		
		if(!srcfile.exists()) {try {
			throw new IOException("file not found: "+frompath);
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}}
		if(!toFile.exists()) {try {
			toFile.createNewFile();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}}
		
		try {
			fileInputStream = new FileInputStream(srcfile);
			fileOutputStream = new FileOutputStream(toFile);
		} catch (FileNotFoundException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		byte[] by = new byte[1024*8];
		int len = 0;
		try {
			while((len=fileInputStream.read(by))!=-1) {
				fileOutputStream.write(by, 0, len);
			}
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		try {
			fileOutputStream.close();
			fileInputStream.close();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	}
	
	public static String file_size_format(long size) {
    	
    	DecimalFormat decimalFormat = new DecimalFormat("#.0");
    	
    	if(size<1000) {return size+"b";}
    	
    	else if(size<1000*1000) {
    		
    		double s = (double)size/1000;
    		
    		return decimalFormat.format(s)+"kb";
    	}
    	
    else if(size<1000*1000*1000) {
    		
    	double s = (double)size/(1000*1000);
    		
    		return decimalFormat.format(s)+"M";
    	}
    	
    else {
		
    	double s = (double)size/(1000*1000*1000);
		
		return decimalFormat.format(s)+"G";
	}	
}
	
 public static boolean Globlelist_files(String des_fileName) {
		  File[] roots = File.listRoots();
		  
		  for(File file:roots) {
			 String root_path = file.getAbsolutePath();
			 boolean exist = list_files(root_path, des_fileName);
			 if(exist) {return true;}
	         else {continue;}
		  }
		  
		  return false;
	 }
 public static boolean list_files(String dir_path,String des_fileName) {
		
		 File dir_file = new File(dir_path);
		 if(!dir_file.exists()) {return false;}
		 
		 File[] files = dir_file.listFiles();
		 if(files!=null) {
			 for(File file:files) {
				 
				 if(file.isDirectory()) {
	             boolean exist =  list_files(file.getAbsolutePath(),des_fileName);
	               if(exist) {return true;}
	               else {continue;}
				 }
				 else {
					
					 if(file.getName().equals(des_fileName)) {return true;}
				}
			 }
		 }
		return false;
	 }
 
 public static void main(String[] args) {
	 
	 System.out.println("start");
	 long time = System.currentTimeMillis();
	 FileUtills.copyFile("E:\\原workspace.zip", "D:\\桌面\\原workspace.zip");
	 System.out.println(System.currentTimeMillis()-time);
	 System.out.println("over");
}
}
