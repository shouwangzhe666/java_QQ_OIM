package tools;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import com.sun.org.apache.bcel.internal.generic.NEW;

import Frame.Main_Frame;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import net.coobird.thumbnailator.Thumbnails;

public class Icon_tools {

public static Image get_client_head_image(String account) {
	
	String icon_path =  "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\image\\head_image\\"+account+".png";
	ImageIcon imageIcon = new ImageIcon(icon_path);
	
	if(!new File(icon_path).exists()) {imageIcon = new ImageIcon(Icon_tools.class.getResource("/background_image/default_HeadImage.png"));}
	
	return imageIcon.getImage();
}

public static byte[] get_IconBytes(int account) {
	String icon_path =  "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\image\\head_image\\"+account+".png";
	return get_IconBytes(icon_path);
}
public static byte[] get_IconBytes(String icon_path) {
		
    	FileInputStream fileInputStream = null;
    	try {
		
			if(!new File(icon_path).exists()) {
				//fileInputStream = new FileInputStream(Icon_tools.class.getResource("/background_image/default_image.png").toString().substring(6));
				return null;
			}
			
			else{fileInputStream = new FileInputStream(icon_path);}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
    	
    	ByteBuf buf = Unpooled.buffer(50*1024,2*1024*1024);
    	byte[] by = new byte[1024];
    	int len = 0;
    	
    	try {
			while((len = fileInputStream.read(by))!=-1) {
				buf.writeBytes(by, 0, len);
			}
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
    	
    	by = new byte[buf.readableBytes()];
    	buf.readBytes(by);
    	
    	try {
			fileInputStream.close();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
    	
    	buf.release();
    	
    	return by;
	}
	
 public static void Write_head_image(String link_account,byte[] head_icon_bytes) {
	 
	  String icon_path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\image\\head_image\\"+link_account+".png";
	 
	  Write_image(icon_path, head_icon_bytes);
	  
	  return;
 }
 
 public static void Write_image(String icon_path,byte[] icon_bytes) {
	 
	 FileUtills.create_new_file(icon_path);
	  
	  FileOutputStream fileOutputStream = null;
	  try {
		fileOutputStream = new FileOutputStream(icon_path);
	} catch (FileNotFoundException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	  try {
		fileOutputStream.write(icon_bytes, 0, icon_bytes.length);
		  fileOutputStream.close();
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	  try {
		fileOutputStream.close();
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
 }
 
 public static void Write_image(BufferedImage bufferedImage,float qulity,String out_file) {
		
	     FileUtills.create_new_file(out_file);
		
		 try {
				Thumbnails.of(bufferedImage).scale(1f).outputQuality(qulity).toFile(out_file);
			} catch (IOException e1) {
				// TODO AYouTu-generated catch block
				e1.printStackTrace();
			}
}
 
 public static  String compress_image(String icon_path,float image_qulity) {
		
	    if(icon_path.endsWith("jpg")) {return icon_path;}
	    
		int index = icon_path.lastIndexOf(".");
		String to_path = icon_path.substring(0, index)+".jpg";
		
		try {
			Thumbnails.of(icon_path).scale(1f).outputQuality(image_qulity).toFile(to_path);
		} catch (IOException e) {
			
			e.printStackTrace();	
		}
		
		return to_path;
	}
 
 public static BufferedImage get_head_image(ImageIcon imageIcon,int icon_width) {
		
		BufferedImage ori_image = new BufferedImage(imageIcon.getIconWidth(), imageIcon.getIconHeight(), BufferedImage.TYPE_4BYTE_ABGR);
		Graphics2D g2  = (Graphics2D) ori_image.getGraphics();
		g2.drawImage(imageIcon.getImage(), 0, 0, null);
		g2.dispose();
		
		 BufferedImage formatAvatarImage = new BufferedImage(icon_width, icon_width, BufferedImage.TYPE_4BYTE_ABGR);
	        Graphics2D graphics =(Graphics2D) formatAvatarImage.createGraphics();
	        //把图片切成一个圓
	            graphics.setStroke(new BasicStroke(0.1f));
	            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	            //留一个像素的空白区域，这个很重要，画圆的时候把这个覆盖
	            int border = 1;
	            //图片是一个圆型
	            Ellipse2D.Double shape = new Ellipse2D.Double(0, 0,icon_width, icon_width);
	            //需要保留的区域
	            graphics.setClip(shape);
	            graphics.drawImage(ori_image, 0, 0,icon_width, icon_width, null);
	            graphics.dispose();
	          
	            Graphics2D graphics1 = (Graphics2D)formatAvatarImage.createGraphics();
	            graphics1.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	          
	            //画笔是4.5个像素，BasicStroke的使用可以查看下面的参考文档
	            //使画笔时基本会像外延伸一定像素，具体可以自己使用的时候测试
	            Stroke s = new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
	            graphics1.setStroke(s);
	            
	            int average_rgb = get_average_rgb(ori_image, icon_width/2);
	            graphics1.setColor(new Color(average_rgb));
	            graphics1.drawOval(0,0, icon_width-1, icon_width-1);
	           
	            graphics1.dispose();
	            
	            return formatAvatarImage;
	            
	            }
	
 public static int get_average_rgb(BufferedImage ori_image,int ovl_r) {
	  //get_average_rgb of rang of the circle of ori_image
	  
	    int width = ori_image.getWidth();
	    int height = ori_image.getHeight();
	    
	    int o_x = width/2;
	    int o_y = height/2;
	    int b_x = 0;
	    int b_y = 0;
	    int average_rgb = 0;
	    
	    for(int i=0;i<360;i++) {
	    	b_x = get_point_x(o_x, o_x-1, i);
	    	b_y = get_point_y(o_y, o_x-1, i);
	    	average_rgb+=ori_image.getRGB(b_x, b_y);
	    }
	    
	    return average_rgb/360;
}
 
public static  int get_point_x(int o_x,int r,int angle) {
		// get point_x of circle 
		int x1   =   (int) (o_x + r *Math.cos(Math.toRadians(angle)));
		return x1;
	}
	
public static  int get_point_y(int o_y,int r,int angle) {
	// get point_y of circle 
		int y1   =   (int) (o_y + r *Math.sin(Math.toRadians(angle)));
		return y1;
	}

public static BufferedImage copy_buffedImage(BufferedImage bufferedImage) {
	
	int width = bufferedImage.getWidth();
	int height = bufferedImage.getHeight();
	
	BufferedImage back_image = new BufferedImage(width, height, BufferedImage.TYPE_4BYTE_ABGR);
	
	for(int x=0;x<width;x++) {
		for(int y=0;y<height;y++) {
			
			back_image.setRGB(x, y, bufferedImage.getRGB(x, y));
		}
	}
	return back_image;
}

public static byte[] compress_head_image(byte[] head_icon) {
			
	 String smal_head_path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\image\\head_image\\tempsmall.png";
	
	 FileUtills.create_new_file(smal_head_path);
	
	 BufferedImage bufferedImage = get_head_image(new ImageIcon(head_icon), 40);
	 try {
		ImageIO.write(bufferedImage, "png", new FileOutputStream(smal_head_path));
	} catch (FileNotFoundException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	
	return Icon_tools.get_IconBytes(smal_head_path);
}
}
