package tools;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import com.sun.jna.platform.win32.OaIdl.ELEMDESC;

import Message.Group.Group_file_message;
import cc.EditDesktop;
import tcp_pack.TCP_P2P_Pointer;

public class GroupSendFile_thread extends Thread{
	
RandomAccessFile read_file = null;
Socket socket = null;
DataOutputStream dataOutputStream = null;
byte[] by = null;
int len = 0;
long progress = 0;
long total_lenth = 0;

	public GroupSendFile_thread(Group_file_message file_message) {
		String file_name = file_message.getFile_name();
		this.total_lenth = file_message.getFile_lenth();
		String string = EditDesktop.get_DesktopBackground();
		String dir = new File(string).getParentFile().getAbsolutePath();
		
		int index = file_name.lastIndexOf(".");
		File file1 = new File(dir+"\\"+file_name);
		File file2 = new File(dir+"\\"+file_name.substring(0,index)+".temp");
		
		try {
			if(file1.exists()) {read_file = new RandomAccessFile(file1,"rw");}
			else if(file2.exists()) {read_file = new RandomAccessFile(file2,"rw");}
		} catch (FileNotFoundException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}

	 socket = get_socket(file_message.getTcp_type(), file_message.getServer_port());
	 if(socket==null) {
		System.err.println("群文件发送失败！");
		 return;
	 }
	 try { 
		    by = new byte[1024*20];
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
		} catch (IOException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
}	 
	 public Socket get_socket(int tcp_type,int server_port) {
		 Socket socket = null;
		 
		 if(tcp_type==1||tcp_type==2) {
			 TCP_P2P_Pointer p2p_Pointer = new TCP_P2P_Pointer("TCP_Pointer", server_port);
			 p2p_Pointer.start();
			 socket = p2p_Pointer.get_socket(60);
		 }
		 else if(tcp_type==3) {
			 try {
				socket = new Socket(InetAddress.getByName("115.28.186.188"), server_port);
			} catch (UnknownHostException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
		 }
		 return socket;
	 }
	@Override
		public void run() {
			try {
				while(true) {
					
				if((len=read_file.read(by))!=-1) {
					dataOutputStream.write(by, 0, len);
					progress+=len;
					}
				else if(progress<total_lenth) {
					try {
						Thread.sleep(3000);
					} catch (InterruptedException e) {
						// TODO AYouTu-generated catch block
						e.printStackTrace();
					}
				}
				else {
					break;
				}
				}
			} catch (IOException e) {
				System.err.println("群文件发送失败！");
				e.printStackTrace();
				try {
					read_file.close();
					dataOutputStream.close();
					socket.close();
				} catch (IOException e1) {
					// TODO AYouTu-generated catch block
					e1.printStackTrace();
				}
				
			}
 }
}
