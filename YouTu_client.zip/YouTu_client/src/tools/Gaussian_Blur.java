package tools;

import java.awt.Color;
import java.awt.FileDialog;

//new File("C:\\ProgramData\\Users\\Administrator\\Pictures\\tht.jpg")
// new Icon_show_frame(new ImageIcon(img));

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.PixelGrabber;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

import com.oracle.webservices.internal.api.EnvelopeStyle.Style;
import com.sun.javafx.geom.AreaOp.XorOp;

import tool_Frame.Icon_show_frame;
/**
 * 
 * <p class="detail">
 * 描述：高斯模糊
 * </p>
 * @ClassName: Gaussian_Blur
 * @version V1.0  
 * @date 2016年4月20日 
 * @author <a href="mailto:1435290472@qq.com">zq</a>
 */
public class Gaussian_Blur {
 
 /**
  * 
  * <p class="detail">
  * 功能：模糊执行方法
  * </p>
  * @date 2016年4月20日
  * @author <a href="mailto:1435290472@qq.com">zq</a>
  * @param img        原图片
  * @param radius     模糊权重
  * @return     模糊后图片
  * @throws IOException
  */
 public static BufferedImage gaussian_blur(BufferedImage img,int radius) throws IOException{
     int height = img.getHeight();
     int width = img.getWidth();
        int[] values = getPixArray(img, width, height);
        values = doBlur(values, width, height, radius);
     img.setRGB(0, 0, width, height, values, 0, width);
     return img;
 }
// public static BufferedImage eclosion_corner(BufferedImage img,int radius,int clorner_width) {
//	 
//	 int height = img.getHeight();
//     int width = img.getWidth();
//     
//     clorner_width+=5;
//     
//     int[] pix = new int[clorner_width * clorner_width]; 
//     PixelGrabber pg = null; 
//     try { 
//         pg = new PixelGrabber(img,width-clorner_width,height-clorner_width,clorner_width,clorner_width, pix, 0,clorner_width); 
//         if (pg.grabPixels() != true) 
//             try { 
//                 throw new java.awt.AWTException("pg error" + pg.status()); 
//             } catch (Exception eq) { 
//                 eq.printStackTrace(); 
//             } 
//     } catch (Exception ex) { 
//         ex.printStackTrace();
//     } 
//     
//        try {
//			pix = doBlur(pix, clorner_width, clorner_width, radius);
//		} catch (IOException e) {
//			// TODO AYouTu-generated catch block
//			e.printStackTrace();
//		}
//        
//     img.setRGB(width-clorner_width,height-clorner_width,clorner_width,clorner_width, pix, 0,clorner_width);
//    
//	return img;
//	 
// }
 /**
  * 
  * <p class="detail">
  * 功能：获取图像像素矩阵
  * </p>
  * @date 2016年4月20日
  * @author <a href="mailto:1435290472@qq.com">zq</a>
  * @param im
  * @param w
  * @param h
  * @return
  */
 private static int[] get_border_PixArray(Image im,int x,int y, int w, int h) { 
     int[] pix = new int[w * h]; 
     PixelGrabber pg = null; 
     try { 
         pg = new PixelGrabber(im, x, y, w, h, pix, 0, w); 
         if (pg.grabPixels() != true) 
             try { 
                 throw new java.awt.AWTException("pg error" + pg.status()); 
             } catch (Exception eq) { 
                 eq.printStackTrace(); 
             } 
     } catch (Exception ex) { 
         ex.printStackTrace();
     } 
     return pix; 
 }
 
    private static int[] getPixArray(Image im, int w, int h) { 
        int[] pix = new int[w * h]; 
        PixelGrabber pg = null; 
        try { 
            pg = new PixelGrabber(im, 0, 0, w, h, pix, 0, w); 
            if (pg.grabPixels() != true) 
                try { 
                    throw new java.awt.AWTException("pg error" + pg.status()); 
                } catch (Exception eq) { 
                    eq.printStackTrace(); 
                } 
        } catch (Exception ex) { 
            ex.printStackTrace();
        } 
        return pix; 
    }
    
    /**
     * 
     * <p class="detail">
     * 功能：高斯模糊算法。
     * </p>
     * @date 2016年4月20日
     * @author <a href="mailto:1435290472@qq.com">zq</a>
     * @param pix
     * @param w
     * @param h
     * @param radius
     * @return
     * @throws IOException
     */
    public static int[] doBlur(int[] pix,int w,int h,int radius) throws IOException {
  int wm = w - 1;
  int hm = h - 1;
  int wh = w * h;
  int div = radius + radius + 1;
  int r[] = new int[wh];
  int g[] = new int[wh];
  int b[] = new int[wh];
  int rsum, gsum, bsum, x, y, i, p, yp, yi, yw;
  int vmin[] = new int[Math.max(w, h)];
  int divsum = (div + 1) >> 1;
  divsum *= divsum;
  int dv[] = new int[256 * divsum];
  for (i = 0; i < 256 * divsum; i++) {
   dv[i] = (i / divsum);
  }
  yw = yi = 0;
  int[][] stack = new int[div][3];
  int stackpointer;
  int stackstart;
  int[] sir;
  int rbs;
  int r1 = radius + 1;
  int routsum, goutsum, boutsum;
  int rinsum, ginsum, binsum;
  for (y = 0; y < h; y++) {
   rinsum = ginsum = binsum = routsum = goutsum = boutsum = rsum = gsum = bsum = 0;
   for (i = -radius; i <= radius; i++) {
    p = pix[yi + Math.min(wm, Math.max(i, 0))];
    sir = stack[i + radius];
    sir[0] = (p & 0xff0000) >> 16;
    sir[1] = (p & 0x00ff00) >> 8;
    sir[2] = (p & 0x0000ff);
    rbs = r1 - Math.abs(i);
    rsum += sir[0] * rbs;
    gsum += sir[1] * rbs;
    bsum += sir[2] * rbs;
    if (i > 0) {
     rinsum += sir[0];
     ginsum += sir[1];
     binsum += sir[2];
    } else {
     routsum += sir[0];
     goutsum += sir[1];
     boutsum += sir[2];
    }
   }
   stackpointer = radius;
   for (x = 0; x < w; x++) {
    r[yi] = dv[rsum];
    g[yi] = dv[gsum];
    b[yi] = dv[bsum];
    rsum -= routsum;
    gsum -= goutsum;
    bsum -= boutsum;
    stackstart = stackpointer - radius + div;
    sir = stack[stackstart % div];
    routsum -= sir[0];
    goutsum -= sir[1];
    boutsum -= sir[2];
    if (y == 0) {
     vmin[x] = Math.min(x + radius + 1, wm);
    }
    p = pix[yw + vmin[x]];
    sir[0] = (p & 0xff0000) >> 16;
    sir[1] = (p & 0x00ff00) >> 8;
    sir[2] = (p & 0x0000ff);
    rinsum += sir[0];
    ginsum += sir[1];
    binsum += sir[2];
    rsum += rinsum;
    gsum += ginsum;
    bsum += binsum;
    stackpointer = (stackpointer + 1) % div;
    sir = stack[(stackpointer) % div];
    routsum += sir[0];
    goutsum += sir[1];
    boutsum += sir[2];
    rinsum -= sir[0];
    ginsum -= sir[1];
    binsum -= sir[2];
    yi++;
   }
   yw += w;
  }
  for (x = 0; x < w; x++) {
   rinsum = ginsum = binsum = routsum = goutsum = boutsum = rsum = gsum = bsum = 0;
   yp = -radius * w;
   for (i = -radius; i <= radius; i++) {
    yi = Math.max(0, yp) + x;
    sir = stack[i + radius];
    sir[0] = r[yi];
    sir[1] = g[yi];
    sir[2] = b[yi];
    rbs = r1 - Math.abs(i);
    rsum += r[yi] * rbs;
    gsum += g[yi] * rbs;
    bsum += b[yi] * rbs;
    if (i > 0) {
     rinsum += sir[0];
     ginsum += sir[1];
     binsum += sir[2];
    } else {
     routsum += sir[0];
     goutsum += sir[1];
     boutsum += sir[2];
    }
    if (i < hm) {
     yp += w;
    }
   }
   yi = x;
   stackpointer = radius;
   for (y = 0; y < h; y++) {
    // Preserve alpha channel: ( 0xff000000 & pix[yi] )
    pix[yi] = (0xff000000 & pix[yi]) | (dv[rsum] << 16)
      | (dv[gsum] << 8) | dv[bsum];
    rsum -= routsum;
    gsum -= goutsum;
    bsum -= boutsum;
    stackstart = stackpointer - radius + div;
    sir = stack[stackstart % div];
    routsum -= sir[0];
    goutsum -= sir[1];
    boutsum -= sir[2];
    if (x == 0) {
     vmin[y] = Math.min(y + r1, hm) * w;
    }
    p = x + vmin[y];
    sir[0] = r[p];
    sir[1] = g[p];
    sir[2] = b[p];
    rinsum += sir[0];
    ginsum += sir[1];
    binsum += sir[2];
    rsum += rinsum;
    gsum += ginsum;
    bsum += binsum;
    stackpointer = (stackpointer + 1) % div;
    sir = stack[stackpointer];
    routsum += sir[0];
    goutsum += sir[1];
    boutsum += sir[2];
    rinsum -= sir[0];
    ginsum -= sir[1];
    binsum -= sir[2];
    yi += w;
   }
  }
  return pix;
 }
   
    public static BufferedImage eclosion_right_border(BufferedImage bufferedImage,int border_width) {
    	
    	int icon_width = bufferedImage.getWidth();
    	int icon_height = bufferedImage.getHeight();
    	int difference = 255/border_width;
 //   	difference*=2;
    	int start_x = icon_width-border_width;
    	int start_y = icon_height-border_width;
    	BufferedImage back_image = new BufferedImage(icon_width, icon_height, BufferedImage.TYPE_4BYTE_ABGR);
    	int x_oposity = 255;
    	int y_oposity = 255;
    	int rgb = 0;
    	Color color = null;
    	Color n_Color = null;
    	int r = 0 ;
    	int g = 0;
    	int b = 0;
    	
    	for(int x=0;x<icon_width;x++) {
    		
    		for(int y=0;y<icon_height;y++) {
    			
    			rgb = bufferedImage.getRGB(x, y);
    			color = new Color(rgb);
    			r = color.getRed();
    			g = color.getGreen();
    			b = color.getBlue();
    			
    			if(x>start_x-1) {
    		
    				n_Color = new Color(r,g,b,check_apha(x_oposity));
    				back_image.setRGB(x, y, n_Color.getRGB());
    				continue;
    			}
    			
    				back_image.setRGB(x, y,rgb);
    			
    		} // for
    		
    		if(x>start_x) {x_oposity-=difference;}
    	
    	} // for
		return back_image;
    	
    }
 public static BufferedImage eclosion_bottom_border(BufferedImage bufferedImage,int border_width) {
    	
    	int icon_width = bufferedImage.getWidth();
    	int icon_height = bufferedImage.getHeight();
    	int difference = 255/border_width;
    	int temp_difference = difference*3/4;
 //   	difference*=2;
    	int start_x = icon_width-border_width;
    	int start_y = icon_height-border_width;
    //	int strt_cor_y = start_y+border_width*2/3;
    	BufferedImage back_image = new BufferedImage(icon_width, icon_height, BufferedImage.TYPE_4BYTE_ABGR);
    	int x_oposity = 235;
    	int y_oposity = 255;
    	int temp_oposity = 0;
    	int rgb = 0;
    	Color color = null;
    	Color n_Color = null;
    	int r = 0 ;
    	int g = 0;
    	int b = 0;
    	int x=0;
    	
    	int [] corner_x_oposity = new int[border_width];
    	int medim = corner_x_oposity.length/3;
    	
    	for(int i=0;i<corner_x_oposity.length;i++) {   	
    		corner_x_oposity[i] = x_oposity;
    		x_oposity-=difference;
    		
    		}
    		
//    	for(int i=0;i<corner_x_oposity.length;i++) {   		
//    		x_oposity-=difference;
//    		if(i>medim){corner_x_oposity[i] = x_oposity;}}
//    	
//    	for(int i=0;i<medim;i++) {   		
//    	
//    		corner_x_oposity[i] = corner_x_oposity[2*i];
//    		}
    	
    	x_oposity = 255;
    	
    	for(;x<icon_width;x++) {
    		
    		y_oposity=255;
    		if(x>start_x-1) {temp_oposity = corner_x_oposity[x-start_x];}
    		
    		for(int y=0;y<icon_height-1;y++) {
    			
    			rgb = bufferedImage.getRGB(x, y);
    			color = new Color(rgb);
    			r = color.getRed();
    			g = color.getGreen();
    			b = color.getBlue();   			
    			
    			 if(y>start_y-1&&x<start_x) {
    				n_Color = new Color(r,g,b,check_apha(y_oposity));
    				back_image.setRGB(x, y, n_Color.getRGB());
    				y_oposity-=difference;
    				continue;
    			}
    			
    			 if(y>start_y&&x>start_x-1) {
     				n_Color = new Color(r,g,b,check_apha(temp_oposity));
     				back_image.setRGB(x, y, n_Color.getRGB());
     				temp_oposity-=temp_difference;
     				continue;
     			}
    				back_image.setRGB(x, y,rgb);
    			
    		} // for
    		
    	} // for
		return back_image;
    	
    }
    public static int check_apha(int argb) {
    	
    	if(argb<0) {return 0;}
    	if(argb>255) {return 255;}
    	
    	return argb;
    }
    
    float mSize = 0.5f;
   
//    public static BufferedImage get_image(BufferedImage bufferedImage,int border_width) {
//    	// 剪去东南角
    
//    	int icon_width = bufferedImage.getWidth();
//    	int icon_height = bufferedImage.getHeight();
//    	BufferedImage back = new BufferedImage(icon_width, icon_height, BufferedImage.TYPE_INT_ARGB);
//        int temp_y = 0;
//        int oposity = 255;
//        int diffence = 255/border_width;
//        
//    	for(int x=0;x<icon_width;x++) {
//    		for(int y=0;y<icon_height;y++) {
//    			 temp_y  = -x+icon_width+icon_height-border_width ; 
//    			 if(y<temp_y) {back.setRGB(x, y, bufferedImage.getRGB(x, y));}
//    		}
//    	}
//    	
//       return back;
//    }
    
    public static void main(String[] args) throws IOException {
    	
    	FileDialog fileDialog = new FileDialog(new JFrame());
    	fileDialog.setVisible(true);
    	
    	String path = fileDialog.getDirectory()+fileDialog.getFile();
    	
    	  BufferedImage img = ImageIO.read(new File(path));
    	
    	  
//    	  int border_width = 60;

 //   	  img = Gaussian_Blur.eclosion_right_border(img, border_width);
 //   	  img = Gaussian_Blur.eclosion_bottom_border(img, border_width);
    	  img = Gaussian_Blur.gaussian_blur(img, 300);
    	  
    	  new Icon_show_frame(new ImageIcon(img));
    	
}}

