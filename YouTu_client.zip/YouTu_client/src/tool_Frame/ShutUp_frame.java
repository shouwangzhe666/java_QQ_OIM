package tool_Frame;

// author: jiang quan feng
// date : 2020.01.11

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

import Frame.Only_frame;
import Group_chat.Group_show_pane;
import Message.Group.Group_chat_message;
import custom_component.My_combox;
import custom_component.Roundrec_button;
import javafx.scene.layout.HBox;
import ss.Group_Chat_Client;

public class ShutUp_frame implements ActionListener{

	int group_account=0;
	int member_account=0;
	String group_id = null;
	String group_remark = null;
	
	Only_frame only_frame = null;
	Main_pane main_pane = null;
	
	My_combox s_box = null;
	My_combox h_box = null;
	My_combox d_box = null;
	
	Roundrec_button cancle_button = null;
	Roundrec_button confirm_button = null;
	
	public ShutUp_frame(int group_account,int member_account,String group_id,String group_remark) {
	
		this.group_account = group_account;
		this.member_account = member_account;
		this.group_id = group_id;
		this.group_remark = group_remark;
		
		main_pane = new Main_pane();
		
		Init_box();
		Install_box();		
		
		Init_button();
		Install_button();
		
		Init_frame();
	}
	
	public void Init_box() {
		
		 String[] strings = new String[60];
		 for(int i=0;i<60;i++) {
			 strings[i] = ""+i;
		 }
		 s_box = new My_combox(strings);
		 
		 String[] htrings = new String[24];
		 for(int i=0;i<24;i++) {
			 htrings[i] = ""+i;
		 }
		 h_box = new My_combox(htrings);
		 
		 String[] dStrings = new String[31];
		 for(int i=0;i<31;i++) {
			 dStrings[i] = ""+i;
		 }
		 d_box = new My_combox(dStrings);
	}
	
	public void Install_box() {
		
		s_box.setBounds(25, 40, 50, 20);
		h_box.setBounds(125,40, 50, 20);
		d_box.setBounds(225,40, 50, 20);
		
		main_pane.add(s_box);
		main_pane.add(h_box);
		main_pane.add(d_box);
	}
	
	public void Init_button() {
		
		cancle_button = new Roundrec_button(75, 30, 10,new Color(18, 131, 245), "取消", 16, Color.white);
		confirm_button = new Roundrec_button(75, 30, 10,new Color(18, 131, 245), "确认", 16, Color.white);
		
		cancle_button.addActionListener(this);
		confirm_button.addActionListener(this);
	}
	
	public void Install_button() {
			
		cancle_button.setBounds(130, 120,75, 30);
		confirm_button.setBounds(210, 120,75, 30);
		
		main_pane.add(cancle_button);
		main_pane.add(confirm_button);
		
	}
	
	public void Init_frame() {
		
		only_frame = new Only_frame(main_pane,40);
		only_frame.set_Size(true,330, 220);
		only_frame.set_Title("群禁言",new Font("微软雅黑", Font.PLAIN, 20), new Color(0, 131, 253));
		only_frame.get_max_button().setVisible(false);
		only_frame.get_min_button().setVisible(false);
		
		only_frame.set_Resizable(false);
		only_frame.setVisible(true);
		only_frame.setAlwaysOnTop(true);
	}
	
	public int get_mimites() {
		
		int s = s_box.getSelectedIndex();
		int h = h_box.getSelectedIndex();
		int d = d_box.getSelectedIndex();
		
		int minites = s+h*60+d*24*60;
		
		return minites;
	}
	private class Main_pane extends JPanel{
		
		public Main_pane() {
			setLayout(null);
		}
		
		 @Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
		    Graphics2D g2 = (Graphics2D) g;
		    
		    g2.setColor(Color.white);
		    g2.setFont(new Font("宋体", Font.PLAIN, 16));
		    
		    g2.drawString("分钟", 80,55);
		    g2.drawString("小时", 180,55);
		    g2.drawString("天数", 280,55);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	
	   if(e.getSource()==cancle_button) {}
	   else {
		   int s = get_mimites();
		   if(s>0) {			   
			   
			  Group_chat_message chat_message = new Group_chat_message(4, member_account,System.currentTimeMillis(), group_id, group_remark, 0l);	
		      chat_message.setOpen_shutup(true);
		      chat_message.setShutup_minites(s);
		      Group_Chat_Client.send_message(group_account, chat_message);
		      
		   }		   		  
	   }  // else
	   
	   only_frame.dispose();
	}
}
