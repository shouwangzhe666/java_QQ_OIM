package tool_Frame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import javax.swing.BoxLayout;
import Frame.Only_frame;
import custom_component.Box_pane;
import custom_component.Roundrec_button;

public class Warn_frame implements ActionListener{

	Only_frame only_frame = null;
	Show_pane show_pane = null;
	Roundrec_button confirm =null;
	
	public Warn_frame(String title,String text) {
	   
	   Init_components(text);
	   Init_frame(title);
	   Init_listioner();
    
	}
	
	public void Init_components(String text) {
			
	    confirm =  new Roundrec_button(100, 40, 10,new Color(0, 131, 253), "确定", 18, Color.white);
	    
	    show_pane = new Show_pane(text);
		show_pane.setLayout(null);
		confirm.setBounds(170, 190, 100, 40);
		show_pane.add(confirm);

	}
	
	public void Init_frame(String title) {
		
		    only_frame = new Only_frame(show_pane,40);
			only_frame.set_Size(true,450, 300);
			only_frame.set_Title(title,new Font("微软雅黑", Font.PLAIN, 20), new Color(0, 131, 253));
			only_frame.get_max_button().setVisible(false);
			only_frame.get_min_button().setVisible(false);
			
			only_frame.set_Resizable(false);
			only_frame.setVisible(true);
			only_frame.setAlwaysOnTop(true);
	}
	
	public void Init_listioner() {
		
      only_frame.change_quite_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				confirm.doClick();
			}
		});
		
    confirm.addActionListener(this);
	}
	public void set_visiable(boolean visiable) {
		
		only_frame.setVisible(visiable);
	}
	public boolean is_visiable() {
		return only_frame.isVisible();
	}
	private class Show_pane extends Box_pane{

		String [] strings = null;
		String s = null;
		Font font = null;
		Rectangle rec = null;
		int x = 0;
		int y = 0;
		int width = 0;
		int height = 0;
		
		public Show_pane(String content) {
			super(BoxLayout.Y_AXIS);
			
			setPreferredSize(new Dimension(450, 265));
			setMinimumSize(new Dimension(450, 265));
			setMaximumSize(new Dimension(450, 265));
			
			this.strings = content.split("\n");
			font = new Font("宋体", Font.PLAIN, 20);
			FontRenderContext frc = new FontRenderContext(new AffineTransform(),true,true);
		    
			for(int i=0;i<strings.length;i++) { 
				s = strings[i];
				rec = font.getStringBounds(s, frc).getBounds();
				if(rec.getWidth()>width) {width = (int) rec.getWidth();}
			}
			
			rec = font.getStringBounds("得", frc).getBounds();
			height = (int) rec.getHeight();
		 
			height *= strings.length;
			
			x = (450-width)/2;
			y = (190-height)/2;
		
		}
		
		@Override
		protected void paintComponent(Graphics g) {
			
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
		
			g2.setFont(font);
		//	g2.setColor(Color.red);
			g2.setColor(Color.black);
		
			int string_y = y;
			
			for(int i=0;i<strings.length;i++) {
			//    System.out.println(string_y);
				s = strings[i];
				g2.drawString(s, x, string_y);
				string_y+=24;
			}
			
		}
	}
	
	
	public void set_aYouTu_click(int seconds) {
		
		confirm.set_auto_click(seconds, true);
		
	}
	
	public void alter_confirm_listioner(ActionListener actionListener) {
		   
		confirm.removeActionListener(this);
		confirm.addActionListener(actionListener);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		only_frame.dispose();
	}
	
	public static void main(String[] args) {
		
		String account = "88888888";
        String password = "88888888";
       
        String content = "恭喜您注册成功！\nYouTu账号: "+account+"\nYouTu密码："+password+"\n\n建议截屏保存好账号密码信息！";
		  new Warn_frame("提示", content);
		
	}
}
