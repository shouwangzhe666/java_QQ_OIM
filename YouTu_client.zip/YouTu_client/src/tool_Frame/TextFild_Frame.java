package tool_Frame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;

import Frame.Only_frame;
import custom_component.Box_pane;
import custom_component.My_label;
import custom_component.Roundrec_textFiled;
import custom_component.Roundrec_button;

public class TextFild_Frame extends JPanel implements ActionListener{

	Roundrec_textFiled textFiled = null;
	Roundrec_button confirm_button = null;
	Roundrec_button cancle_button = null;
	String tip_text = null;
	Only_frame only_frame = null;
	
	public TextFild_Frame(String title,String tip_text) {
	   setLayout(null);
	   this.tip_text = tip_text;
	   
	   Init_componnets();
	   Init_frame(title);
	   Init_listioner();
	
	}
	public void dispose_frame() {
		only_frame.dispose();
	}
	public void Init_componnets() {
		
		textFiled = new Roundrec_textFiled(260, 30, 1.5f, Color.gray, new Color(18,90,245),16, Color.black);
		confirm_button = new Roundrec_button(75, 30, 10,new Color(18, 131, 245), "确认", 16, Color.white);
		cancle_button = new Roundrec_button(75, 30, 10,new Color(18, 131, 245), "取消", 16, Color.white);
		
		textFiled.setBounds(50, 70,260, 30);
		cancle_button.setBounds(150, 120,75, 30);
		confirm_button.setBounds(230, 120,75, 30);
		add(textFiled);
		add(confirm_button);
		add(cancle_button);
	}
	
	public void Init_frame(String title) {
		
		    only_frame = new Only_frame(this,40);	
		    only_frame.setVisible(true);
		    only_frame.get_max_button().setVisible(false);
		    only_frame.get_min_button().setVisible(false);
		  
		    only_frame.set_Title(title, new Font("宋体", Font.PLAIN, 18),new Color(18, 131, 245));
			only_frame.set_Size(true,370, 220);
			only_frame.set_Resizable(false);
	}
	
	public void Init_listioner() {
		
		confirm_button.addActionListener(this);
		cancle_button.addActionListener(this);
		
		textFiled.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				
				only_frame.update_frame();
				if(e.getKeyCode()==KeyEvent.VK_ENTER) {confirm_button.doClick();}
			}
		});
	}
	
	public void alter_ActionListener(ActionListener actionListener) {
		
		confirm_button.addActionListener(actionListener);
	}
	
	public String get_input_text() {
		
		return textFiled.getText();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
	
		only_frame.dispose();	
	}
	
    @Override
    protected void paintComponent(Graphics g) {
    	super.paintComponent(g);
    	Graphics2D g2 = (Graphics2D) g;
    	
    	g2.setColor(Color.WHITE);
    	g2.setFont(new Font("宋体", Font.PLAIN, 16));
    	g2.drawString(tip_text, 50, 40);
    }
    
    public static void main(String[] args) {
		
    	  new TextFild_Frame("提示", "请输入姓名：");
	}
}
