package MainThread_pack;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import Frame.Chat_frame;
import Frame.Main_Frame;
import Message.Private.Private_Chat_Message;
import chat_frame_pane.Private_chat_pane;
import tools.FileUtills;
import tools.My_Object_IO;

public class Audio_thread {
	int link_account = 0;
	int p2p_type = 1;
	volatile long send_time = 0;
	volatile boolean start = true;
	ScheduledThreadPoolExecutor execYouTur = null;
    ConcurrentLinkedQueue<Object> message_queue = null;
	Socket socket = null;
	DataOutputStream dataOutputStream = null;
	DataInputStream dataInputStream = null;
	Object sync1 = new Object();
	Object sync2 = new Object();
	
	public Audio_thread() {
		
	}
	public void send_Audio_messsage(int time_lenth,long send_time,String audio_path) {
		  
		synchronized (sync1) {
			
			message_queue.add(time_lenth);
			message_queue.add(send_time);
			message_queue.add(audio_path);
		}		
	}
	public void start_thread(int link_account,int p2p_type,Socket socket) {
		this.link_account = link_account;
		this.p2p_type = p2p_type;
		this.socket = socket;
		try {
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
			dataInputStream = new DataInputStream(socket.getInputStream());
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		new Send_thread().start();
		new Recever_thread().start();
	}
	public void start_ThreadPoolExecYouTur() {
		
		message_queue = new ConcurrentLinkedQueue<>();
        execYouTur = new ScheduledThreadPoolExecutor(1);
		
		execYouTur.scheduleWithFixedDelay(new Runnable() {
			
			@Override
			public void run() {
			
				if(socket==null) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					return;
				}
			
				int time_lenth = 0;
				long send_time = 0;
				String audio_path = null;
				
			//	System.out.println(message_queue.size());
				
			synchronized (sync1) {
				Object object = message_queue.peek();
				if(object==null) {return;}
				
				 time_lenth = (int) object;
				 message_queue.remove();
				 
				 send_time = (long) message_queue.remove();				
				 audio_path = (String) message_queue.remove();
								
			}	
//			  if(send_time==Audio_thread.this.send_time) {return;}
//			  Audio_thread.this.send_time = send_time;
			  
				write_audio_message(time_lenth, send_time, audio_path);
				
			} // execYouTur run
		}, 0,1, TimeUnit.SECONDS);
	}

  private void write_heartbeat() {
		synchronized(sync2) {
		   try {
			dataOutputStream.writeInt(1);
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		   try {
			   sync2.wait(20000);
		} catch (InterruptedException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	}
}
	private void write_audio_message(int time_lenth,long send_time,String audio_path) {
		
		System.out.println("write_audio_message");
		
		File file = new File(audio_path);
		byte[] by = new byte[1024*8];
		int len = 0;
		FileInputStream fileInputStream = null;
		try {
			fileInputStream = new FileInputStream(file);
		} catch (FileNotFoundException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
		
		synchronized(sync2) {
		//	object.notify();
			 try {
				    dataOutputStream.writeInt(2);
					dataOutputStream.writeInt(time_lenth);
					dataOutputStream.writeLong(send_time);
					dataOutputStream.writeLong(file.length());
					
					while((len=fileInputStream.read(by))!=-1) {
						dataOutputStream.write(by, 0, len);
					}
					
				   // if(p2p_type==3)
				  if(p2p_type==3) {
					  start = false;
					  
					  dataOutputStream.close();
					  dataInputStream.close();
					  socket.close();
					  
					  execYouTur.shutdownNow();
					  ConcurrentHashMap<Integer,Audio_thread> all_audio_thread = Main_Frame.get_all_audio_thread();
					  all_audio_thread.remove(link_account);
				  }
				} catch (IOException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
		}
	}
	
	private class Send_thread extends Thread{
		@Override
		public void run() {
			while(start) {
				  write_heartbeat();
			}
		}
	}
	
	private class Recever_thread extends Thread{
		int type = 0;
		
		@Override
		public void run() {
			while(start) {
				try {
					type = dataInputStream.readInt();
				} catch (IOException e) {
					e.printStackTrace();
					
					start = false;				
					Main_Frame.get_all_audio_thread().remove(link_account);
					
					try {
						socket.close();
					} catch (IOException e1) {
						// TODO AYouTu-generated catch block
						e1.printStackTrace();
					}
										
					break;
				}
				
				if(type==2) {
					receve_audio_message();
				}
			}
		}
	}
	private void receve_audio_message() {
		
		System.out.println("receve_audio_message");
		
		int time_lenth = 0;
		long send_time = 0;
		long file_lenth = 0;
		long progress = 0;
		
		byte[] by = new byte[1024*4];
		int len = 0;
		String file_path = null;
		RandomAccessFile write_file = null;
		try {
			time_lenth = dataInputStream.readInt();
			send_time  = dataInputStream.readLong();
			file_lenth = dataInputStream.readLong();
			file_path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\chat_history\\private_chat\\audio\\"+link_account+"\\"+send_time+".wav";
			
			FileUtills.create_new_file(file_path);
			write_file = new RandomAccessFile(new File(file_path), "rw");
			
			while((len=dataInputStream.read(by))!=-1) {
				progress+=len;
				write_file.write(by, 0, len);
				
				if(progress==file_lenth) {break;}
			}
			
			 write_file.close();
			
			 // add audio_item into chat_frame
		     int native_count = Integer.parseInt(Main_Frame.getNative_count());
			 Private_Chat_Message chat_Message = new Private_Chat_Message(7,link_account,native_count,send_time);
			 chat_Message.setTime_lenth(time_lenth);
			 			 
			 // write the message into file
		        String path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\chat_history\\private_chat\\"+link_account+".db";
		        ObjectOutputStream objectOutputStream = My_Object_IO.get_ObjectoutputStream(path, true);
		        objectOutputStream.writeObject(chat_Message);
		        objectOutputStream.close();
		        
			 Main_Frame.getMessage_pane().put_accept_message_item(String.valueOf(link_account),send_time,"语音消息");
			 Chat_frame.update_item_content(String.valueOf(link_account),"语音消息");
			 
			 Private_chat_pane chat_pane = (Private_chat_pane) Chat_frame.get_Private_chat_jpane(link_account);
		     if(chat_pane!=null) {chat_pane.put_audio_message(chat_Message, false);}
		     
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}	
		
		try {
			 if(p2p_type==3) {
				  start = false;
				  
				  dataOutputStream.close();
				  dataInputStream.close();
				  socket.close();
				  
				  execYouTur.shutdownNow();
				  ConcurrentHashMap<Integer,Audio_thread> all_audio_thread = Main_Frame.get_all_audio_thread();
				  all_audio_thread.remove(link_account);
			  }
		} catch (Exception e) {
			e.printStackTrace();
		}
		// to add audio_item
	}
	public static void main(String[] args) {
		
	}
}
