package Main_thread;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.TimeUnit;

import Frame.Chat_frame;
import Frame.Login_frame;
import Frame.Main_Frame;
import Frame.Only_frame;

public class TelnetCheck_thread extends Thread{

	Only_frame only_frame = null;
	static volatile boolean avisiable = true;
	volatile int failed_num = 0;
	
	public TelnetCheck_thread() {
		Main_Frame.update_frame();
	
	}
	
	@Override
	public void run() {
		
		while(true) {
			
			boolean avisiable = Telnet_avisiale();
			
			if(avisiable!=TelnetCheck_thread.avisiable) {
				Login_frame.flash_frame(!avisiable);
				Main_Frame.flash_frame(!avisiable);
			    Chat_frame.flash_frame(!avisiable);
			}
			
			set_avisiable(avisiable);
			
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
		}
	}
	public static synchronized void set_avisiable(boolean avisiable) {
		      TelnetCheck_thread.avisiable = avisiable;
	}
	public static synchronized boolean isavisiable() {
		return avisiable;
	}
	
	 public static boolean Telnet_avisiale() {
		    Process p1 = null;
			try {
				p1 = java.lang.Runtime.getRuntime().exec("ping -n 1 www.aliyun.com");
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
			
			 try {
				 int returnVal = p1.waitFor();
				 return returnVal==0;
			} catch (InterruptedException e1) {
				// TODO AYouTu-generated catch block
				e1.printStackTrace();
			}
			  
		    return false;
	    }
	
	 public static void main(String[] args) {
		
		  new TelnetCheck_thread().start();
	}
}
