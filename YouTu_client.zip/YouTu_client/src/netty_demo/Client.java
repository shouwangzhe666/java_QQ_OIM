package netty_demo;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLEngine;

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.DelimiterBasedFrameDecoder;
import io.netty.handler.codec.FixedLengthFrameDecoder;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
import io.netty.handler.codec.LengthFieldPrepender;
import io.netty.handler.codec.LineBasedFrameDecoder;
import io.netty.handler.ssl.SslHandler;
import io.netty.handler.timeout.IdleStateHandler;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import tools.SslContextFactory;

public class Client extends Thread{
	EventLoopGroup work_group = null;
	Bootstrap bootstrap = null;
	ChannelFuture future = null;
	Channel channel = null;
	Timer timer = null;
	
	public Client() {
		
		 work_group = new NioEventLoopGroup();        			
		 bootstrap = new Bootstrap();
		 timer = new Timer();
	}
	
	@Override
	public void run() {
		
		 bootstrap.group(work_group).channel(NioSocketChannel.class).option(ChannelOption.TCP_NODELAY, true).handler(new ChannelInitializer<Channel>() {

			@Override
			protected void initChannel(Channel channel) throws Exception {			             
				
				SSLEngine engine = SslContextFactory.get_client_sslContext().createSSLEngine();
				engine.setUseClientMode(true);
				engine.setNeedClientAuth(false);
				channel.pipeline().addFirst(new SslHandler(engine));
				
				channel.pipeline().addLast(new PingPong_decoder());	
				channel.pipeline().addLast(new Cat_decoder());				
				
				channel.pipeline().addLast(new PingPong_encoder());	
				channel.pipeline().addLast(new Cat_encoder());
			    
				channel.pipeline().addLast(new IdleStateHandler(10, 2, 0, TimeUnit.SECONDS));
				channel.pipeline().addLast(new Client_PingPong_handler(Client.this));	
				channel.pipeline().addLast(new Client_Handle());
			}			
		});
		 
	     reconnet();
	     
	} // run
	
	public void  reconnet() {
		
		try {
			future = bootstrap.connect(InetAddress.getLocalHost(), 6666);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 future.addListener(new GenericFutureListener<Future<? super Void>>() {

			@Override
			public void operationComplete(Future<? super Void> arg0) throws Exception {
				
				if(future.isSuccess()) {
					
					channel = future.channel();
					System.out.println("客户端 连接成功！");
					
					}
				else if(!future.isSuccess()) {
							
					System.out.println("客户端连接失败，开始重连。。。");
					timer.schedule(new TimerTask() {
						
						@Override
						public void run() {
							reconnet();
						}
					}, 1000);
				}
			}
		});
	}
	public static void main(String[] args) {
		
		 new Client().start();
//		 System.out.println("Netty客户端启动");
	}
}
