package netty_demo;

import java.util.List;

import org.omg.CORBA.CTX_RESTRICT_SCOPE;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

public class PingPong_decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> list) throws Exception {
		
		int protocal_code = buf.readInt();
		
		if(protocal_code==222) {list.add(new PingPong());}
		
		else {
			buf.retain();
			ctx.fireChannelRead(buf);
		}
	}
}
