package netty_demo;

public class PingPong {

	//协议编码
	int protocal_code = 222;
	
	public PingPong() {
		// TODO Auto-generated constructor stub
	}
}
