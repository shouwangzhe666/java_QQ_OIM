package netty_demo;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleStateEvent;

public class Server_Handle extends SimpleChannelInboundHandler<Cat>{

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Cat cat) throws Exception {
		
		System.out.println("服务器收到一条消息：猫，准备返回给客户端");
		ctx.writeAndFlush(cat);
	}

	
}
