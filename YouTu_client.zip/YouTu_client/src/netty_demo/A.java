package netty_demo;

import java.util.List;

import Message.Private.Private_Chat_Message;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageCodec;
import io.netty.handler.codec.ByteToMessageDecoder;
import io.netty.handler.codec.MessageToByteEncoder;
import io.netty.handler.codec.MessageToMessageCodec;
import io.netty.handler.codec.MessageToMessageDecoder;
import io.netty.handler.codec.MessageToMessageEncoder;

public class A extends ByteToMessageCodec<Cat>{

	@Override
	protected void decode(ChannelHandlerContext arg0, ByteBuf arg1, List<Object> arg2) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void encode(ChannelHandlerContext arg0, Cat arg1, ByteBuf arg2) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	
  
}
