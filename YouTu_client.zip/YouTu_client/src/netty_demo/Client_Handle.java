package netty_demo;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleStateEvent;

public class Client_Handle extends SimpleChannelInboundHandler<Cat>{

	@Override
	public void channelActive(ChannelHandlerContext ctx) throws Exception {
//		super.channelActive(ctx);
		
		Cat cat = new Cat("我是小猫", 1);
		ctx.writeAndFlush(cat);
	}
	
	@Override
	protected void messageReceived(ChannelHandlerContext arg0, Cat cat) throws Exception {
		
		System.out.println("客户端收到一条消息: 猫");
		System.out.println(cat.getName()+","+cat.getAge()+"岁");
	}

}
