package netty_demo;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

public class PingPong_encoder extends MessageToByteEncoder<PingPong>{

	@Override
	protected void encode(ChannelHandlerContext arg0, PingPong ping, ByteBuf buf) throws Exception {
		
		buf.writeInt(222);
		
	}
}
