package netty_demo;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleStateEvent;

public class Server_PingPong_handler extends SimpleChannelInboundHandler<PingPong>{

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, PingPong pingPong) throws Exception {
		
		ctx.writeAndFlush(pingPong);
	}
	
	@Override
	public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
		if (evt instanceof IdleStateEvent) {
	        IdleStateEvent e = (IdleStateEvent) evt;
	        
	        ByteBuf buf = Unpooled.buffer(10);
	        
	        switch (e.state()) {
	            case READER_IDLE:
	            	System.out.println("服务端 读超时");

//	            	buf.writeInt(222);	            	
	                ctx.writeAndFlush(new PingPong());	     
	                break;
	                
	            case WRITER_IDLE:
//	            	 write_PingPong(ctx, buf);                   
	                break;
	                
	            case ALL_IDLE:
//	            	 write_PingPong(ctx, buf);    
	                break;
	                
	            default:
	                break;
	        }
	    }

	}
	
	public void write_PingPong(ChannelHandlerContext ctx,ByteBuf buf) {
		System.out.println("心跳超时");

    	buf.writeInt(222);	            	
        ctx.writeAndFlush(buf);	    
	}
}
