package group_info_item;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;

import javax.swing.JPanel;

import Frame.Chat_frame;
import Frame.Group_info_frame;
import group_info_pane.Item_list_pane;

public class Group_list_item extends JPanel{

	Item_list_pane list_pane = null;
	String text = null;
	Color gray_color = null;
	Font font = null;
	int x = 0;
	int y = 0;
	boolean enter = false;
	boolean selected = false;
	Cursor cursor = null;
	
	public Group_list_item(Item_list_pane list_pane,String text) {
		
		setOpaque(false);
		setPreferredSize(new Dimension(130,50));
		setMaximumSize(new Dimension(130,50));
		setMinimumSize(new Dimension(130,50));
		
		this.cursor = new Cursor(Cursor.DEFAULT_CURSOR);
		this.list_pane = list_pane;
		this.text = text;
		this.gray_color = new Color(140, 140, 140);
		font = new Font("微软雅黑", Font.PLAIN, 18);
		
		 FontRenderContext frc = new FontRenderContext(new AffineTransform(),true,true);
		 Rectangle rec = font.getStringBounds(text, frc).getBounds();
		
		int str_width= rec.width;
		int str_height = rec.height;
		x = (130-str_width)/2;
		y = (50-str_height)/2;
		
		Init_mouse_listioner();
	}
	
public void Init_mouse_listioner() {
		
		addMouseListener(new MouseAdapter() {
				
			@Override
			public void mouseEntered(MouseEvent e) {
				setCursor(cursor);
				enter = true;			    
			    repaint();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				enter = false;			    
			    repaint();
			    
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				
				if(e.getButton()==1) {
					list_pane.set_all_unselected();
					set_selected(true);
					Group_info_frame.change_pane(text);
				}
			}
		});
	}
	
	public void set_selected(boolean selected) {
		
		this.selected = selected;
		repaint();
		
	}
	
	@Override
	protected void paintComponent(Graphics g) {		
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		if(enter||selected) {
			g2.setColor(gray_color);
			g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.3f));
			g2.fillRect(0, 0,130,50);			
		}	
		
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,1f));
		g2.setColor(Color.white);
		g2.setFont(font);
		g2.drawString(text, x, y+15);	
	}
}
