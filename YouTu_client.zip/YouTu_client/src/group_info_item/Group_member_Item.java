package group_info_item;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import Frame.Group_info_frame;
import Main_frame_Item.Main_JMenuItem;
import Message.Group.Group_chat_message;
import Message.Private.Private_info;
import group_info_pane.Group_member_pane;
import ss.Group_Chat_Client;
import ss.Private_Chat_Client;
import tools.Icon_tools;

public class Group_member_Item extends JPanel implements ActionListener{

	 Group_member_pane member_pane = null;
	 boolean enter = false;
	 Image head_image = null;
	 int index = 0;
	 int member_account  = 0;
	 String group_id = null;
	 String group_remark = null;
	 long join_time = 0l;
	 long last_time = 0l;
	 
	 Font font = null;
	 Color gray_color = null;
	 String join_str = null;
	 String last_str = null;
	 
	 JPopupMenu popupMenu = null;
	 Main_JMenuItem info_item = null;
	 Main_JMenuItem administer_item = null;
	 Main_JMenuItem delete_item = null;
	 
	 public Group_member_Item(int index,ArrayList<Object> member, Group_member_pane member_pane) {
		 setBackground(Color.white);
		
		 this.index = index;
		 member_account = (int) member.get(0);
		 group_id = (String) member.get(1);
		 group_remark = (String) member.get(2);
		 join_time = (long) member.get(3);
		 last_time = (long) member.get(4);
		 this.member_pane = member_pane;
		 
		 SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		 font = new Font("宋体", Font.PLAIN, 16);
//		 gray_color = new Color(140, 140, 140);
		 this.gray_color = new Color(0, 181, 245);
			
		 head_image = Icon_tools.get_client_head_image(String.valueOf(member_account));
	     join_str = simpleDateFormat.format(join_time);
	     last_str = simpleDateFormat.format(last_time);
	     
	     setPreferredSize(new Dimension(700,45));
	     setMinimumSize(new Dimension(700,45));
	     setMaximumSize(new Dimension(700,45));
	     
	     Init_general_item();
	     if(Group_info_frame.get_group_id().equals("群主")) {
	    	 Init_owner_item();
	     }
	     
	     Init_mouse_listioner();
	}
	 
	 public void Init_general_item() {
		 
		 popupMenu = new JPopupMenu();
		 popupMenu.setBackground(Color.white);
		 
		 info_item = new Main_JMenuItem("查看资料", null);
		 info_item.addActionListener(this);
		 popupMenu.add(info_item);
	 }
	 public void Init_owner_item() {
		 if(group_id.equals("群主")) {return;}
		 
		 administer_item = new Main_JMenuItem("设为管理员", null);
		 administer_item.addActionListener(this);
		 popupMenu.add(administer_item);
		 
		 delete_item = new Main_JMenuItem("踢出群聊", null);
		 delete_item.addActionListener(this);
		 popupMenu.add(delete_item);
		 
		 update_administer_item();
	 }
	 public void update_administer_item() {
		 if(group_id.equals("管理员")) {administer_item.setText("取消管理员");}
		 else {administer_item.setText("设为管理员");}
	 }
	 public void Init_mouse_listioner() {
			
			addMouseListener(new MouseAdapter() {
					
				@Override
				public void mouseEntered(MouseEvent e) {
					
					enter = true;			    
				    repaint();
				}
				@Override
				public void mouseExited(MouseEvent e) {
					enter = false;			    
				    repaint();
				}
				@Override
				public void mousePressed(MouseEvent e) {
					if(e.getButton()==3){popupMenu.show(Group_member_Item.this,e.getX(),e.getY());}
				}
			});
		}
	 
 public String get_group_id() {
		 
		 return group_id;
 }
 public String get_group_remark() {
	 
	 return group_remark;
}
 public int get_member_account() {
	 
	 return member_account;
}
 public long get_join_time() {
	 return join_time;
 }
 public long get_last_time() {
	 return last_time;
 }
 public void set_enter(boolean enter) {
		this.enter = enter;
		repaint();
}
	@Override
	protected void paintComponent(Graphics g) {	
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		if(enter) {
			g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.3f));
			g2.setColor(gray_color);
			g2.fillRect(0, 0,720,45);			
		}	
		
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,1f));
		g2.setColor(Color.gray);
		g2.setFont(font);
		
		g2.drawImage(head_image, 5, 2, null);
		g2.drawString(group_remark, 75, 25);
		
		if(group_id.equals("管理员")||group_id.equals("群主")) {g2.setColor(Color.red);}
		g2.drawString(group_id, 230, 25);
		
		g2.setColor(Color.BLACK);
		g2.drawString(join_str, 370, 25);
		g2.drawString(last_str, 540, 25);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	
	if(e.getSource()==info_item) {
			
			   Private_info private_info = new Private_info();
			   private_info.setType(3);
			   private_info.setCount(String.valueOf(member_account));
			   Private_Chat_Client.send_message(private_info);
		} // info_item
	else if(e.getSource()==administer_item) {
             boolean administer = this.group_id.equals("管理员")?false:true;
			 
			 Group_chat_message chat_message = new Group_chat_message(5, member_account, System.currentTimeMillis(), group_id, group_remark,0l);	
			 chat_message.setSet_Administrator(administer);
		     Group_Chat_Client.send_message(Group_info_frame.get_group_account(), chat_message);	
			 
			 if(group_id.equals("管理员")) {group_id = "成员";}
			 else {group_id = "管理员";}
			 update_administer_item();
			 
			 member_pane.update_member_pane();
		}
       else if(e.getSource()==delete_item) {
        	Group_chat_message chat_message = new Group_chat_message(7, member_account, System.currentTimeMillis(), group_id, group_remark,0l);	
			Group_Chat_Client.send_message(Group_info_frame.get_group_account(), chat_message);
			
			member_pane.remove_member(index);
			member_pane.update_member_pane();
		}
	}
}
