package Frame;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import custom_component.Beauty_Slider;
import custom_component.Icon_button;
import custom_component.Roundrec_button;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import net.coobird.thumbnailator.Thumbnails;
import net.coobird.thumbnailator.geometry.Positions;

public class Edit_head_icon_frame implements ActionListener,ChangeListener{

	BufferedImage ori_buferedimage = null;
	BufferedImage min_buferedimage = null;
	BufferedImage background_buferedimage = null;
	BufferedImage head_bufferedimage = null;
	
	JPanel main_pane = null;
	Head_icon_pane icon_pane = null;
	
	int background_width = 0;
	int background_height = 0;
	int capture_x=0;
	int capture_y=0;
	   
	int origin_x = 0;
	int origin_y = 0;
	   
	Beauty_Slider slider = null;
	Icon_button left_button = null;
	Icon_button right_button = null;
	Roundrec_button image_button = null;
	Roundrec_button cancle_button = null;
	Roundrec_button confirm_button = null;
	
	Only_frame only_frame = null;
	
	public Edit_head_icon_frame(ImageIcon imageIcon) {
	      
		Init_components(imageIcon);
		Init_listioner();
		Init_frame();
	
	//	new TelnetCheck_thread(only_frame).start();
	}
	
	public void Init_components(ImageIcon imageIcon) {
		icon_pane = new Head_icon_pane();
		main_pane = new JPanel();
		main_pane.setLayout(null);
		
		change_image(imageIcon);
		
		slider = new Beauty_Slider(0, 100, 0);
		
		left_button = new Icon_button(getClass().getResource("/main_frame_image/rotate_click_left.png"),"左旋转");
		right_button = new Icon_button(getClass().getResource("/main_frame_image/rotate_click_right.png"),"右旋转");
		
		image_button = new Roundrec_button(120, 35, 15, new Color(0, 131, 245), "切换头像", 16, Color.white);
		cancle_button = new Roundrec_button(80, 35, 15, new Color(0, 131, 245), "取消", 16, Color.white);
		confirm_button = new Roundrec_button(80, 35, 15, new Color(0, 131, 245), "确认", 16, Color.white);
		
		icon_pane.setBounds(50, 30, 350, 350);
		slider.setBounds(50, 400, 300, 50);
		left_button.setBounds(360, 400, 24, 24);
		right_button.setBounds(395, 400, 24, 24);
		
		image_button.setBounds(100, 450, 120, 35);
		cancle_button.setBounds(230, 450, 80, 35);
		confirm_button.setBounds(320, 450, 80, 35);
		
		main_pane.add(icon_pane);
		main_pane.add(slider);
		main_pane.add(left_button);
		main_pane.add(right_button);
		main_pane.add(image_button);
		main_pane.add(cancle_button);
		main_pane.add(confirm_button);
	}
	
	public void Init_listioner() {
		
		    left_button.addActionListener(this);
	        right_button.addActionListener(this);
	        image_button.addActionListener(this);
	        cancle_button.addActionListener(this);
	       
	        slider.addChangeListener(this);
	}
	
	public void Init_frame() {
		
		only_frame = new Only_frame(main_pane,40);
		only_frame.set_window_buttons(true);
		only_frame.set_Size(true, 450, 550);
		only_frame.remove_window_Maxbutton(true);
		only_frame.get_min_button().setVisible(false);
		only_frame.setVisible(true);
		only_frame.set_Title("编辑头像",new Font("微软雅黑",Font.PLAIN, 16), new Color(0, 131, 245));
		only_frame.setAlwaysOnTop(true);
	}
	public void change_image(ImageIcon imageIcon) {
		
		if(imageIcon==null) {return;}
		
		int icon_width =imageIcon.getIconWidth();
		int icon_height= imageIcon.getIconHeight();
		ori_buferedimage = new BufferedImage(icon_width,icon_height, BufferedImage.TYPE_4BYTE_ABGR);
		Graphics graphics = ori_buferedimage.getGraphics();
		graphics.drawImage(imageIcon.getImage(), 0, 0, null);
		graphics.dispose();
		
		try {
			if(icon_width<icon_height) {
			 min_buferedimage = Thumbnails.of(ori_buferedimage).width(360).asBufferedImage();
			}
			else if(icon_height<icon_width){
			 min_buferedimage =	Thumbnails.of(ori_buferedimage).height(360).asBufferedImage();
			}
			else {
				min_buferedimage = Thumbnails.of(ori_buferedimage).size(360, 360).asBufferedImage();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			background_buferedimage = Thumbnails.of(min_buferedimage).scale(1.3f).asBufferedImage();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		try {
			head_bufferedimage = Thumbnails.of(background_buferedimage).scale(1).sourceRegion(Positions.CENTER, 350, 350).asBufferedImage();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		this.background_width  = background_buferedimage.getWidth();
		this.background_height = background_buferedimage.getHeight();
		this.capture_x = (background_width-350)/2;
		this.capture_y = (background_height-350)/2;
		
		icon_pane.repaint();
		
	}
	
	public void adjust_image_size(double scale) {
		
		try {
			background_buferedimage = Thumbnails.of(min_buferedimage).scale(scale).asBufferedImage();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		try {
			head_bufferedimage = Thumbnails.of(background_buferedimage).scale(1).sourceRegion(Positions.CENTER, 350, 350).asBufferedImage();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		this.background_width  = background_buferedimage.getWidth();
		this.background_height = background_buferedimage.getHeight();
		this.capture_x = (background_width-350)/2;
		this.capture_y = (background_height-350)/2;
		
		icon_pane.repaint();
	}
	
	public void turn_direction(boolean turn_left) {
		
		double degree = 90;
		if(turn_left) {degree*=-1;}
		
		try {
			min_buferedimage = Thumbnails.of(min_buferedimage).scale(1).rotate(degree).asBufferedImage();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		try {
			background_buferedimage = Thumbnails.of(background_buferedimage).scale(1).rotate(degree).asBufferedImage();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		try {
			head_bufferedimage = Thumbnails.of(background_buferedimage).scale(1).sourceRegion(Positions.CENTER, 350, 350).asBufferedImage();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		this.background_width  = background_buferedimage.getWidth();
		this.background_height = background_buferedimage.getHeight();
		this.capture_x = (background_width-350)/2;
		this.capture_y = (background_height-350)/2;
		
		icon_pane.repaint();
	}
	
	public boolean check_coordinate_avisiable(int x,int y,int x1,int y1) {
	
		boolean avisiable = true;
		
		if(x<0) {capture_x=0;avisiable = false; origin_x = x1; origin_y = y1;}
        if(y<0) {capture_y=0;avisiable = false;origin_x = x1; origin_y = y1;}
        if(x+350>background_width) {capture_x=background_width-350;avisiable = false;origin_x = x1; origin_y = y1;}
        if(y+350>background_height) {capture_y=background_height-350;avisiable = false;origin_x = x1; origin_y = y1;}
        
		return avisiable;
	}
	
	public void image_move_update(int x,int y) {

		try {
			head_bufferedimage = Thumbnails.of(background_buferedimage).scale(1).sourceRegion(x,y, 350, 350).asBufferedImage();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		icon_pane.repaint();
	}
	
	public void add_confirmButton_listionner(ActionListener actionListener) {
		
		confirm_button.addActionListener(actionListener);
	}
	
	public BufferedImage get_selected_head_image() {
		
		 Graphics g =  head_bufferedimage.getGraphics();
		 Ellipse2D.Double shape = new Ellipse2D.Double(0, 0, 350, 350);
		 g.setClip(shape);
		 g.dispose();
		 
		 return head_bufferedimage;
	}
	
	public void set_visiable(boolean visiable) {
		
		only_frame.setVisible(visiable);
	}
	
	public void dispose() {
		only_frame.dispose();
	}
	
   private class Head_icon_pane extends JPanel{
        	
	   Color color = null;
	   BasicStroke stroke = null;
	   Ellipse2D.Double shape = null;
	  
	   int relative_x = 0;
	   int relative_y = 0;
	   boolean correct  = true;
	   
	   public Head_icon_pane() {
		   
		   setOpaque(false);
		   shape = new Ellipse2D.Double(0, 0, 350, 350);
		   color = new Color(0,131, 245);
		   stroke = new BasicStroke(3f);
		   
		    addMouseListener(new MouseAdapter() {
			   @Override
			public void mousePressed(MouseEvent e) {
				
				   origin_x = e.getX();
				   origin_y = e.getY();
			}
			  @Override
				public void mouseReleased(MouseEvent e) {
					
				if(correct) { 
				 capture_x-=relative_x;
				 capture_y-=relative_y;}
				 
				}
		});
		   
		  addMouseMotionListener(new MouseMotionAdapter() {
			   @Override
			public void mouseDragged(MouseEvent e) {
			
				   relative_x = e.getX()-origin_x;
				   relative_y = e.getY()-origin_y;
				  
				   int x = capture_x-relative_x;
				   int y  = capture_y-relative_y;
				   
				  if(check_coordinate_avisiable(x, y,e.getX(),e.getY())) {
					  correct = true;
					  image_move_update(x, y);
				
				  }
				  else {  
					  correct = false;					 

				  }
			}
		});
		
		  addMouseWheelListener(new MouseWheelListener() {
			
			@Override
			public void mouseWheelMoved(MouseWheelEvent e) {
			
				if(e.getWheelRotation()==-1) {slider.setValue(slider.getValue()-5);}
				else {slider.setValue(slider.getValue()+5);}
			}
		});
	   }	   
	  
        	@Override
        	protected void paintComponent(Graphics g) {
        		super.paintComponent(g);
        		Graphics2D g2 = (Graphics2D) g;
        		g2.setClip(shape);
        		g2.drawImage(head_bufferedimage, 0, 0, null);
        		
        		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        		g2.setColor(color);
        		g2.setStroke(stroke);
        		g2.drawOval(0, 0, 350, 350);
        		
        	}
        }

@Override
public void actionPerformed(ActionEvent e) {
	
	if(e.getSource()==left_button) {turn_direction(true);}
	else if(e.getSource()==right_button) {turn_direction(false);}
	else if(e.getSource()==image_button) {
				
		FileDialog fileDialog = null;
		fileDialog = new FileDialog(only_frame);
		fileDialog.setVisible(true);
	   
		String file_name = fileDialog.getFile();
		
		if(file_name==null) {return;}
		if(file_name.endsWith("png")||file_name.endsWith("jpg")) {
			
		String file_path = fileDialog.getDirectory()+fileDialog.getFile();
		change_image(new ImageIcon(file_path));
		}
	}
	
	else if(e.getSource()==cancle_button) {only_frame.dispose();}
	
}

@Override
public void stateChanged(ChangeEvent e) {
	
	double bi = 1+(double)slider.getValue()/100;
	adjust_image_size(bi);
}

public static void main(String[] args) {
	
	new Edit_head_icon_frame(new ImageIcon("D:\\桌面\\a.png"));
         
}
}
