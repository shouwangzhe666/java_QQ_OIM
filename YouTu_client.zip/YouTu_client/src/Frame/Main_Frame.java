package Frame;

import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import Item.State_MenuItem;
import MainThread_pack.Audio_thread;
import Main_frame_Item.Main_JMenu;
import Main_frame_Item.Main_JMenuItem;
import Main_frame_friend.Main_friend_pane;
import Main_frame_group.Main_Group_pane;
import Main_frame_message.Main_message_pane;
import Main_frame_pane.Main_control_pane;
import Main_frame_pane.Main_self_pane;
import Message.Group.Group_search_message;
import Message.Private.Link_info;
import Message.Private.Private_info;
import VA_Pack_UDP.Audio_Chat;
import VA_Pack_UDP.Video_Chat;
import custom_component.Box_pane;
import custom_component.Icon_button;
import custom_component.Roundrec_textFiled;
import message_login_register.Basic_set_message;
import ss.Private_Chat_Client;
import tool_Frame.TextFild_Frame;
import tool_Frame.Warn_frame;

public class Main_Frame implements ActionListener{
    
	TrayIcon trayIcon = null;
	Box_pane main_pane = null;
    Main_self_pane self_pane = null;
	static Main_control_pane control_pane = null;
	static JPanel center_pane = null;
	JPopupMenu popupMenu = null;
	Icon_button search_button = null;
	Icon_button menu_button = null;
	Roundrec_textFiled search_fild = null;
	boolean searchfild_visiable = false;
	
	Main_JMenuItem style_item = null;
	
	Main_JMenu scure_menu = null;
	Main_JMenuItem find_pass_item = null;
	Main_JMenuItem alter_pass_item = null;
	
	Main_JMenuItem ip_item = null;
	
	Main_JMenu set_menu = null;
	Main_JMenu send_menu = null;
	Main_JMenuItem enter_item = null;
	Main_JMenuItem ctrl_item = null;
	
	Main_JMenu state_menu = null;
	State_MenuItem online_item = null;
	State_MenuItem hide_item = null;
	State_MenuItem busy_item = null;
	State_MenuItem alone_item = null;
	
	Main_JMenu group_menu = null;
	Main_JMenuItem general_item = null;
	Main_JMenuItem pay_item = null;
	Dimension dimension = null;
	MenuItem quite_item = null;

	Update_password_frame update_password_frame = null;
	Find_password_frame find_password_frame = null;
    static Private_info private_info = null;
	static Main_message_pane message_pane = null;
	static Main_friend_pane friend_pane = null;
	static Main_Group_pane group_pane = null;
    static String current_link_count = null;
	static String native_count = "10000001";
    static Only_frame only_frame = null;
    static String default_serve_ip = "192.168.31.203";
	static String state = "在线";
	static int send_type = 1;
	static String native_ip = null;
	static ConcurrentHashMap<Integer, Audio_thread> all_audio_thread = null;
	static Video_Chat video_Chat = null;
	static Audio_Chat audio_Chat = null;
	static boolean init = false;
	static {
		all_audio_thread = new ConcurrentHashMap<>();
	}
 public Main_Frame(Private_info private_info) {
	    
	 // add to test
	    init = true;
	    dimension = Toolkit.getDefaultToolkit().getScreenSize();		
	       
	    Main_Frame.private_info = private_info;
	    Main_Frame.native_count = private_info.getCount();
	    Main_Frame.native_ip = private_info.getIp();
	    Basic_set_message set_message =  Basic_set_message.get_Basic_set_message();
	    send_type = set_message.getSend_type();
	    state = set_message.getState();
	    
	    Init_self_pane(private_info);
	    Init_control_pane();
	    Init_center_pane();
	    Init_man_pane();
	    Init_search_filed();
	    Init_frame();
	    Init_TrayIcon();
	    
	}
 
 public void Init_self_pane(Private_info private_info) {
	 
	 self_pane = new Main_self_pane(private_info);
 }
 public void Init_control_pane() {
	 control_pane = new Main_control_pane(this);
 }
 public void Init_center_pane() {
	 
	    center_pane = new JPanel();
		center_pane.setOpaque(false);
		center_pane.setLayout(new BorderLayout());
		center_pane.setPreferredSize(new Dimension(280, 520));
		center_pane.setMinimumSize(new Dimension(230, 320));
		center_pane.setMaximumSize(new Dimension(595, 1000));
		
	    message_pane = new Main_message_pane(this);
		friend_pane = new Main_friend_pane(this);
		group_pane  = new Main_Group_pane(this);
		
		center_pane.add(message_pane);
	    
 }
 
 public void Init_man_pane() {
	  
	main_pane = new Box_pane(BoxLayout.Y_AXIS);
	main_pane.setPreferredSize(new Dimension(280, 680));
	main_pane.setMinimumSize(new Dimension(230, 320));
	main_pane.setMaximumSize(new Dimension(595, 1000));
	
	main_pane.add(self_pane);
	main_pane.add(Box.createVerticalStrut(20));
	main_pane.add(control_pane);
	main_pane.add(center_pane);
 }
 public void Init_search_filed() {
	 
	 search_fild = new Roundrec_textFiled(100, 25, 1.5f, Color.LIGHT_GRAY,new Color(0, 131, 245), 14, Color.black);
	 search_fild.set_watermark("回车搜索");
	 search_fild.addKeyListener(new KeyAdapter() {
		 @Override
		public void keyPressed(KeyEvent e) {
			if(e.getKeyCode()==KeyEvent.VK_ENTER) {
				click_search_button();
			}
		}
	});
 }
 public void Init_frame() {
	 	  	    
	    only_frame = new Only_frame(main_pane,130);
	    
	    only_frame.set_Bounds((int)dimension.getWidth()-300, 50,280, 700);
	    only_frame.setRetractable(true);
	    only_frame.setMin_width(280);
	    only_frame.setMin_height(530);
	    only_frame.setMax_width(600);
	    only_frame.setMax_height(1000);
	    only_frame.remove_window_Maxbutton(false);

		only_frame.set_Title("",new Font("微软雅黑",Font.PLAIN, 18), Color.white);
		only_frame.setAlwaysOnTop(true);
		only_frame.setVisible(true);
	    
		search_button = new Icon_button(getClass().getResource("/main_frame_image/search_trans.png"), "搜索账号");
		menu_button = new Icon_button(getClass().getResource("/main_frame_image/down_trans.png"), "菜单");
		search_button.addActionListener(this);
		menu_button.addActionListener(this);
		
		only_frame.add_top_component(menu_button, true);
		only_frame.add_top_component(search_button, true);
		only_frame.add_top_component(search_fild, true);
		search_fild.setVisible(false);
		 
		only_frame.change_min_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				only_frame.setVisible(false);
				init = false;
			}
		});
		 only_frame.change_quite_listioner(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
				    
//					SystemTray.getSystemTray().remove(trayIcon);
//					only_frame.setVisible(false);
					
					message_pane.save_all_message();					
					System.exit(0);
				}
			});
 }
 
 public void Init_popMenu() {
	 
	 popupMenu = new JPopupMenu();
	 popupMenu.setBackground(Color.white);
	 
	 style_item = new Main_JMenuItem("皮肤", null);
	 scure_menu = new Main_JMenu("安全");
	 ip_item = new Main_JMenuItem("官网", null);
	 state_menu = new Main_JMenu("状态");
	 
	 popupMenu.add(style_item);
	 popupMenu.add(scure_menu);
//	 popupMenu.add(ip_item);
	 popupMenu.add(state_menu);
	 
	 alter_pass_item = new Main_JMenuItem("修改密码", null);
	 find_pass_item = new Main_JMenuItem("找回密码", null);
	 scure_menu.add(alter_pass_item);
	 scure_menu.add(find_pass_item);
	 
	Init_state_item();
	Init_group_item();
	Init_set_menu();
	
	 popupMenu.add(ip_item);
 }
 
 public void Init_state_item() {
	 
	 online_item = new State_MenuItem( "在线", state.equals("在线"));
	 hide_item = new State_MenuItem( "隐身", state.equals("隐身"));
	 busy_item = new State_MenuItem( "忙碌", state.equals("忙碌"));
	 alone_item = new State_MenuItem("勿扰", state.equals("勿扰"));
	 
	 state_menu.add(online_item);
	 state_menu.add(hide_item);
	 state_menu.add(busy_item);
	 state_menu.add(alone_item);
 }
 public void Init_group_item() {
	 
	 group_menu = new Main_JMenu("建群");
	 popupMenu.add(group_menu);
	 
	 general_item = new Main_JMenuItem("普通群", null);
	 pay_item = new Main_JMenuItem("付费群", null);
	 group_menu.add(general_item);
	 group_menu.add(pay_item);
	 
 }
 public void Init_set_menu() {
	 
	 set_menu = new Main_JMenu("设置");
	 popupMenu.add(set_menu);
	 
	 send_menu = new Main_JMenu("发送");
	 set_menu.add(send_menu);
	 
	 enter_item = new Main_JMenuItem("按Enter键发送消息",null);
	 ctrl_item = new Main_JMenuItem("Ctrl+Enter键发送",null);
	 send_menu.add(enter_item);
	 send_menu.add(ctrl_item);
	 
	 enter_item.addActionListener(this);
	 ctrl_item.addActionListener(this);
 }
 public void Init_TrayIcon() {
	 
	 Image image = new ImageIcon(getClass().getResource("/tool_image/logo_tray.png")).getImage();
	 trayIcon = new TrayIcon(image);
	
	 trayIcon.setImageAutoSize(true);
	 trayIcon.addMouseListener(new MouseAdapter() {
		public void mousePressed(MouseEvent e) {
		
			only_frame.setVisible(true);
//			only_frame.setExtendedState(JFrame.NORMAL);
//			only_frame.update_frame_ui();
			init = true;
		}; 
	});
	 
	 SystemTray systemTray = SystemTray.getSystemTray();
	
	 try {
		systemTray.add(trayIcon);
	} catch (AWTException e1) {
		// TODO AYouTu-generated catch block
		e1.printStackTrace();
	}
	 
	 quite_item = new MenuItem("退出");
	 quite_item.addActionListener(this);
	 PopupMenu popupMenu = new PopupMenu();
	 popupMenu.add(quite_item);
	 trayIcon.setPopupMenu(popupMenu);
 }
 public void Init_item_listioner() {
	 
	 style_item.addActionListener(this);
	 
	 alter_pass_item.addActionListener(this);
	 find_pass_item.addActionListener(this);
	 
	 ip_item.addActionListener(this);
	 
	 general_item.addActionListener(this);
	 pay_item.addActionListener(this);
 }
 public void click_search_button() {
		
 String link_account = search_fild.getText();
 link_account = link_account.trim();
 
 if(!link_account.matches("\\d{8,9}")) {new Warn_frame("提示", "请输入8-9位有效数字账号").set_aYouTu_click(3);return;}
 else if(link_account.equals(Main_Frame.getNative_count())) {return;}
 else if(Main_Frame.getMessage_pane().get_link_info(link_account)!=null) {
//	 Main_Frame.getMessage_pane().put_send_message_item(link_account);
	 Main_Frame.getMessage_pane().put_accept_message_item(link_account, System.currentTimeMillis(), "");
	 Main_Frame.getMessage_pane().get_message_Item(link_account).set_enter(true);
	}
		
 else if(link_account.length()==8) {
	    System.out.println("搜索好友");
		Link_info link_info = new Link_info(6);
		link_info.setAccount(link_account);
		Private_Chat_Client.send_message(link_info);
		}
 else if(link_account.length()==9) {
	    System.out.println("搜索群聊");
		Group_search_message search_message = new Group_search_message(3);
		search_message.setGroup_account(link_account);
		Private_Chat_Client.send_message(search_message);
		}
 
        search_fild.setText("");
        search_button.doClick();
	}
public static void set_state(String state) {
	
	Main_Frame.state = state;
}

public static String get_state() {
	
	return Main_Frame.state;
}
public void put_private_file_message(String link_count) {
	 
	 String chat_content = "文件接收完毕";
	 message_pane.put_accept_message_item(link_count,System.currentTimeMillis(), chat_content);
	 
}
 public static void update_pane(int pane_num) {
	 
	center_pane.removeAll();
	
	if(pane_num==1) {center_pane.add(message_pane);}
	else if(pane_num==2) {center_pane.add(friend_pane);}
	else if(pane_num==3) {center_pane.add(group_pane);}
	
	 update_UI();
 }
 
 public static void update_frame() {	 
	 if(only_frame!=null) {only_frame.update_frame();}
 }

 public static void update_UI() {
	 if(only_frame!=null) {
	 	only_frame.update_frame_ui();
	 	only_frame.update_frame();
	 	}
 }
public static Only_frame get_Only_frame() {
	
	return only_frame;
}
public static String get_default_serve_ip() {
	 return default_serve_ip;
}
public static Main_control_pane get_control_pane() {
	return control_pane;
}
public static  Main_message_pane getMessage_pane() {
	return message_pane;
}

public static  Main_friend_pane getFriend_pane() {
	return friend_pane;
}

public static Main_Group_pane getGroup_pane() {
	return group_pane;
}

public static String getNative_count() {
	return native_count;
}

public static String getCurrent_link_count() {
	return Main_Frame.current_link_count;
}

public static void setCurrent_link_count(String current_link_count) {
	Main_Frame.current_link_count = current_link_count;
}

public String[] get_sorted_array(Set<String> set) {
	
		Iterator<String> it = set.iterator();
		String key = null;
		int value = 0;
				
		int[] all_int = new int[set.size()];
		
		int j = 0 ;
		while(it.hasNext()) {
			
			key = it.next();
			value = Integer.parseInt(key);
			all_int[j] = value;
			j++;
		}
		
		Arrays.sort(all_int);
		
		String[] sorted_array = new String[all_int.length];
		int e = 0;
		for(int i=0;i<sorted_array.length;i++) {
			
			e = all_int[i];
			sorted_array[i] = String.valueOf(e);
		}
		
		return sorted_array;
	}

public void set_visiable(boolean visiable) {
	
	only_frame.setVisible(visiable);
}
public static Private_info get_PrivateInfo() {
	return private_info;
}
public static void flash_frame(boolean flash) {
	 if(init) {only_frame.set_flash(flash);}
}
public static int get_send_type() {
	return send_type;
}
public static String get_NativeIp() {
	return native_ip;
}
public static ConcurrentHashMap<Integer,Audio_thread> get_all_audio_thread(){
	
	return all_audio_thread;
}
public static Video_Chat get_Video_Chat() {
	return video_Chat;
}
public static void set_Video_Chat(Video_Chat video_Chat) {
	 Main_Frame.video_Chat = video_Chat;
}
public static Audio_Chat get_Audio_Chat() {
	return audio_Chat;
}
public static void set_Audio_Chat(Audio_Chat audio_Chat) {
	Main_Frame.audio_Chat = audio_Chat;
}

@Override
public void actionPerformed(ActionEvent e) {
	
	if(e.getSource()==search_button) {
		searchfild_visiable = !searchfild_visiable;
		search_fild.setVisible(searchfild_visiable);
		only_frame.update_frame();
	}
	if(e.getSource()==menu_button) {
		 Init_popMenu();
		 Init_item_listioner();
		 popupMenu.show(menu_button, 0, 30);	
		}
	
    else if(e.getSource()==style_item) {
   
    	Appearance_frame appearance_frame = new Appearance_frame();
    	appearance_frame = null;
    	popupMenu.removeAll();
    }
	else if(e.getSource()==alter_pass_item) {
		if(update_password_frame==null) {update_password_frame = new Update_password_frame();}
		update_password_frame.set_visiable(true);
		popupMenu.removeAll();
	}
	else if(e.getSource()==find_pass_item) {
		if(find_password_frame==null) {find_password_frame = new Find_password_frame();}
		find_password_frame.set_visiable(true);
		popupMenu.removeAll();
	}
	else if(e.getSource()==ip_item) {
	//	new Warn_frame("提示", "敬请期待...").set_aYouTu_click(3);
		popupMenu.removeAll();
		try {
		Desktop.getDesktop().browse(new URL("http://www.tufeng.net.cn").toURI());
	} catch (MalformedURLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	} catch (URISyntaxException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	}
	else if(e.getSource()==general_item){
		
		String group_type = e.getSource()==general_item?"1":"2";
		
		TextFild_Frame textFild_Frame = new TextFild_Frame("建立新群", "请输入新群名称:");
		
		textFild_Frame.alter_ActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String group_name = textFild_Frame.get_input_text();
				textFild_Frame.dispose_frame();
				if(group_name.length()==0) {return;}
				
				Group_search_message search_message = new Group_search_message(1);
				search_message.setGroup_type(group_type);
				search_message.setGroup_name(group_name);
				search_message.setGroup_ower_account(Main_Frame.getNative_count());
				
				Private_Chat_Client.send_message(search_message);				
				
			}
		});
		
		popupMenu.removeAll();
	}
	else if(e.getSource()==enter_item) {
		  send_type = 1;
		  Basic_set_message set_message = Basic_set_message.get_Basic_set_message();
		  set_message.setSend_type(1);
		  Basic_set_message.write_basic_set_message(set_message);
		  popupMenu.removeAll();
	}
	else if(e.getSource()==ctrl_item) {
		  send_type = 2;
		  Basic_set_message set_message = Basic_set_message.get_Basic_set_message();
		  set_message.setSend_type(2);
		  Basic_set_message.write_basic_set_message(set_message);
		  popupMenu.removeAll();
	}
	else if(e.getSource()==quite_item) {
		message_pane.save_all_message();					
		System.exit(0);
	}
}

}
