package Frame;

import javax.swing.*;

import Main_thread.TelnetCheck_thread;
import Message.Private.Private_info;
import custom_component.Roundrec_button;
import tool_Frame.Icon_show_frame;
import tools.Icon_tools;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Look_info_frame{

	ImageIcon imageIcon = null;
	Image image = null;
	String remarks = null;
	String group = null;
	String account=null;
	String name=null;
	String sex=null;
	String birth=null;
	String blood=null;
	String home=null;
	String address=null;
	String phone=null;

	String e_mail=null;
	String signature=null;
	String state=null;
	
	Private_info private_info = null;
	Only_frame only_frame = null;
	Show_pane main_pane =null;
	Roundrec_button icon_button = null;
	Font font = null;
	
	public Look_info_frame(Private_info private_info) {
	
		Init_component();
		Init_content(private_info);
		Init_frame();
		
		only_frame.update_frame_ui();
		only_frame.update_frame();
	}
	
	public void Init_content(Private_info private_info) {
		
		this.imageIcon = private_info.getHead_icon();
		this.image = Icon_tools.get_head_image(imageIcon, 80);
		this.account = private_info.getCount();
		this.name = private_info.getName();
		this.sex = private_info.getSex();
		this.birth = private_info.getBirth();
		this.blood = private_info.getBlood();
		this.home = private_info.getHome();
		this.phone = private_info.getPhone();
		this.e_mail = private_info.getE_mail();
		this.signature = private_info.getSignature();
		this.state = private_info.getState();
	
		 font = new Font("宋体", Font.BOLD, 16);
	}
	
	public void Init_component() {
		
		main_pane = new Show_pane();
		main_pane.setLayout(null);
		
		icon_button = new Roundrec_button(120, 35, 15, new Color(0, 131, 245), "查看头像", 16, Color.white);
		icon_button.setBounds(200, 60, 120, 35);
		main_pane.add(icon_button);
		
		icon_button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				 new Icon_show_frame(imageIcon);
			}
		});
	}
	public void Init_frame() {
		
		   only_frame = new Only_frame(main_pane,40);
		   only_frame.set_Size(true, 450, 630);
		   only_frame.set_Resizable(false);
		   only_frame.remove_window_Maxbutton(false);
		   only_frame.set_Title(name+"  个人资料",new Font("微软雅黑",Font.PLAIN, 16), new Color(0, 131, 245));
		   only_frame.setVisible(true);
		   only_frame.setAlwaysOnTop(true);
		}
	
	public void set_visiable(boolean visiable) {
		
		only_frame.setVisible(visiable);
	}
	
   private class Show_pane extends JPanel{
		
		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
			
			g2.drawImage(image, 70, 20, null);
		//	g2.setColor(Color.gray);
			g2.setColor(new Color(0, 131, 245));
			g2.setFont(font);
			
			g2.drawString("头像:", 15, 70);
			g2.drawString("账号:", 15, 160);
			g2.drawString("昵称:", 15, 200); g2.drawString("性别:", 310, 200); 
			g2.drawString("出生年月:", 15, 235); g2.drawString("血型:", 310, 235); 
			g2.drawString("住址:", 15, 270);
			g2.drawString("电话:", 15, 305);
			g2.drawString("163邮箱:", 15, 340);
			g2.drawString("个性签名:", 15, 375);
			g2.drawString("个人说明:", 15, 415);
		
		//	g2.setColor(new Color(0, 131, 245));
		//	g2.setColor(Color.white);
			g2.drawString(account, 125, 160);
			g2.drawString(name, 125, 200);    g2.drawString(sex, 370, 200);
			g2.drawString(birth, 125, 235);   g2.drawString(blood, 370, 235);
			g2.drawString(home, 125, 270);
			g2.drawString(phone, 125, 305);
			g2.drawString(e_mail, 125, 340);
			g2.drawString(signature, 125, 375);
			
			String[] strings = state.split("\n");
			for(int i=0;i<strings.length;i++) {
				g2.drawString(strings[i], 125, 415+i*25);
			}
			
			
		}
	}
	
}
