package Frame;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import custom_component.Beauty_Slider;
import custom_component.Icon_button;
import custom_component.Roundrec_button;
import net.coobird.thumbnailator.Thumbnails;
import net.coobird.thumbnailator.Thumbnails.Builder;
import net.coobird.thumbnailator.geometry.Positions;

public class Edit_Icon_Frame implements ActionListener,ChangeListener{
	
	BufferedImage ori_buferedimage = null;
	BufferedImage current_buferedimage = null;
	
	JPanel main_pane = null;
	Head_icon_pane icon_pane = null;
	
	double rotate_degree = 0;
	float scale = 1;
	
	int ori_width = 0;
	int ori_height = 0;
	int capture_x=0;
	int capture_y=0;
	   
	Beauty_Slider slider = null;
	Icon_button left_button = null;
	Icon_button right_button = null;
	Roundrec_button image_button = null;
	Roundrec_button cancle_button = null;
	Roundrec_button confirm_button = null;
	
	Only_frame only_frame = null;
	
	public Edit_Icon_Frame(ImageIcon imageIcon) {
	      
		Init_components(imageIcon);
		Init_listioner();
		Init_frame();
	
	//	new TelnetCheck_thread(only_frame).start();
	}
	
	public void Init_components(ImageIcon imageIcon) {
		icon_pane = new Head_icon_pane();
		main_pane = new JPanel();
		main_pane.setLayout(null);
		
		Image image = imageIcon.getImage();
		ori_width = imageIcon.getIconWidth();
		ori_height = imageIcon.getIconHeight();
		ori_buferedimage = new BufferedImage(ori_width,ori_height, BufferedImage.TYPE_4BYTE_ABGR);
		ori_buferedimage.getGraphics().drawImage(image, 0, 0, null);
		ori_buferedimage.getGraphics().dispose();
		
		trun_direction(0);
		
		slider = new Beauty_Slider(0, 200, 100);
		
		left_button = new Icon_button(getClass().getResource("/main_frame_image/rotate_click_left.png"),"左旋转");
		right_button = new Icon_button(getClass().getResource("/main_frame_image/rotate_click_right.png"),"又旋转");
		
		image_button = new Roundrec_button(120, 35, 15, new Color(0, 131, 245), "切换头像", 16, Color.white);
		cancle_button = new Roundrec_button(80, 35, 15, new Color(0, 131, 245), "取消", 16, Color.white);
		confirm_button = new Roundrec_button(80, 35, 15, new Color(0, 131, 245), "确认", 16, Color.white);
		
		icon_pane.setBounds(50, 30, 350, 350);
		slider.setBounds(50, 400, 300, 50);
		left_button.setBounds(360, 400, 24, 24);
		right_button.setBounds(395, 400, 24, 24);
		
		image_button.setBounds(100, 450, 120, 35);
		cancle_button.setBounds(230, 450, 80, 35);
		confirm_button.setBounds(320, 450, 80, 35);
		
		main_pane.add(icon_pane);
		main_pane.add(slider);
		main_pane.add(left_button);
		main_pane.add(right_button);
		main_pane.add(image_button);
		main_pane.add(cancle_button);
		main_pane.add(confirm_button);
	}
	
	public void Init_listioner() {
		
		    left_button.addActionListener(this);
	        right_button.addActionListener(this);
	        image_button.addActionListener(this);
	        cancle_button.addActionListener(this);
	       
	        slider.addChangeListener(this);
	}
	
	public void Init_frame() {
		
		only_frame = new Only_frame(main_pane,40);
		only_frame.set_window_buttons(true);
		only_frame.set_Size(true, 450, 550);
		only_frame.remove_window_Maxbutton(true);
		only_frame.get_min_button().setVisible(false);
		only_frame.setVisible(true);
		only_frame.set_Title("编辑头像",new Font("微软雅黑",Font.PLAIN, 16), new Color(0, 131, 245));
		only_frame.setAlwaysOnTop(true);
	}
	
public void trun_direction(int trun_degree) {
		
		rotate_degree+=trun_degree;
		
		try {
			current_buferedimage = Thumbnails.of(ori_buferedimage).scale(scale).rotate(rotate_degree).sourceRegion(Positions.CENTER, 350, 350).asBufferedImage();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		icon_pane.repaint();
	}

public void sourceRegion(int capture_x,int capture_y) {
	
	try {
		current_buferedimage = Thumbnails.of(ori_buferedimage).scale(scale).rotate(rotate_degree).sourceRegion(capture_x,capture_y, 350, 350).asBufferedImage();
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	
	icon_pane.repaint();
}

public int[] get_center_coordinate() {
	
	BufferedImage tempBufferedImage = null;
	try {
		tempBufferedImage = Thumbnails.of(ori_buferedimage).scale(scale).rotate(rotate_degree).asBufferedImage();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	int temp_width = tempBufferedImage.getWidth();
	int temp_height = tempBufferedImage.getHeight();
	int center_x = (temp_width-350)/2;
	int center_y = (temp_height-350)/2;
	
	int[] center_coordinate = new int[] {temp_width,temp_height,center_x,center_y};
	
	return center_coordinate;
}

	 private class Head_icon_pane extends JPanel{
     	
		   Color color = null;
		   BasicStroke stroke = null;
		   Ellipse2D.Double shape = null;
		  
		   int press_x = 0;
		   int press_y = 0;
		   int capture_x = 0;
		   int capture_y = 0;
		   
		   boolean correct  = true;
		   
		   public Head_icon_pane() {
			   
			   setOpaque(false);
			   shape = new Ellipse2D.Double(0, 0, 350, 350);
			   color = new Color(0,131, 245);
			   stroke = new BasicStroke(3f);
			   
		  addMouseListener(new MouseAdapter() {
			 @Override
			public void mousePressed(MouseEvent e) {
				   press_x = e.getX();
				   press_y = e.getY();
			}
			 
			 @Override
			public void mouseReleased(MouseEvent e) {
				 Edit_Icon_Frame.this.capture_x = capture_x;
				 Edit_Icon_Frame.this.capture_y = capture_y;
			}
		});
				  
			  addMouseMotionListener(new MouseMotionAdapter() {
				   @Override
				public void mouseDragged(MouseEvent e) {
				
					 int  relative_x = e.getX()-press_x;
					 int  relative_y = e.getY()-press_y;
//					  int  relative_x = e.getX()-press_x>0?3:-3;
//					  int  relative_y = e.getY()-press_y>0?3:-3;
						 
					 int[] center_coordinate = get_center_coordinate();
					 int temp_width = center_coordinate[0];
					 int temp_height = center_coordinate[1];
					 int center_x = center_coordinate[2];
					 int center_y = center_coordinate[3];
					 
					  capture_x = Edit_Icon_Frame.this.capture_x-relative_x;
					  capture_y = Edit_Icon_Frame.this.capture_y-relative_y;
					 
					 if(capture_x<0||capture_y<0||capture_x+350>temp_width||capture_y+350>temp_height) {return;}
					 
					 sourceRegion(capture_x, capture_y);
					 
					
				}
			});
			
			  addMouseWheelListener(new MouseWheelListener() {
				
				@Override
				public void mouseWheelMoved(MouseWheelEvent e) {
				
					if(e.getWheelRotation()==-1) {slider.setValue(slider.getValue()-5);}
					else {slider.setValue(slider.getValue()+5);}
				}
			});
		   }	   
		  
	        	@Override
	        	protected void paintComponent(Graphics g) {
	        		super.paintComponent(g);
	        		Graphics2D g2 = (Graphics2D) g;
	        		g2.setClip(shape);
	        		g2.drawImage(current_buferedimage, 0, 0, null);
	        		
	        		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	        		g2.setColor(color);
	        		g2.setStroke(stroke);
	        		g2.drawOval(0, 0, 350, 350);
	        		
	        	}
		   }

	@Override
	public void stateChanged(ChangeEvent e) {
		
		double bi = (double)slider.getValue()/100;
		int w = (int) (ori_width*bi);
		int h = (int) (ori_height*bi);
//		System.out.println(w+","+h);
		
		if(w>350&&h>350) {
			this.scale = (float) bi;
			trun_direction(0);
//			System.out.println("trun_direction");
			 int[] center_coordinate = get_center_coordinate();
				
			 capture_x = center_coordinate[2];
			 capture_y = center_coordinate[3];
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==left_button) {trun_direction(-90);}
		else if(e.getSource()==right_button) {trun_direction(90);}
		
		 int[] center_coordinate = get_center_coordinate();
		
		 capture_x = center_coordinate[2];
		 capture_y = center_coordinate[3];
		 
	}
	
	public static void main(String[] args) {
		
		  new Edit_Icon_Frame(new ImageIcon("D:\\桌面\\c.png"));
	}
}