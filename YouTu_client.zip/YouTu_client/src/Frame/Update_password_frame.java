package Frame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JPanel;

import Main_thread.TelnetCheck_thread;
import custom_component.Roundrec_PasswordField;
import custom_component.Roundrec_button;
import message_login_register.Login_pass_message;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;

public class Update_password_frame {

	Only_frame only_frame = null;
	Show_pane main_pane = null;
	Roundrec_PasswordField old_pass_field = null;
	Roundrec_PasswordField new_pass_field = null;
	Roundrec_PasswordField confirm_pass_field = null;
	
	Roundrec_button confirm_button = null;
	
	boolean old_correct = false;
	boolean new_correct = false;
	boolean confirm_correct = false;
	
	public Update_password_frame() {
		
		Init_compnents();
		Init_listioner();
		Init_frame();
		
	}
	
	public void Init_compnents() {
		
		main_pane = new Show_pane();
		main_pane.setLayout(null);
		
		old_pass_field = new Roundrec_PasswordField(200, 25, 2f, Color.gray, Color.blue, 20, Color.black,'.');
		new_pass_field = new Roundrec_PasswordField(200, 25, 2f, Color.gray, Color.blue, 20, Color.black,'.');
		confirm_pass_field = new Roundrec_PasswordField(200, 25, 2f, Color.gray, Color.blue, 20, Color.black,'.');
		
		confirm_button = new Roundrec_button(150, 40, 30, new Color(0, 131, 251), "修改", 18, Color.white);
		
		old_pass_field.setBounds(130, 80,200, 25);
		new_pass_field.setBounds(130, 155,200, 25);
		confirm_pass_field.setBounds(130, 225,200, 25);
		
		confirm_button.setBounds(130, 350,150, 40);
		
		main_pane.add(old_pass_field);
		main_pane.add(new_pass_field);
		main_pane.add(confirm_pass_field);
		
		main_pane.add(confirm_button);
		
	}
	
	public void Init_listioner() {
		
		old_pass_field.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				only_frame.update_frame();
				check_format();
			}
		});
		new_pass_field.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				only_frame.update_frame();
				check_format();
			}
		});
		confirm_pass_field.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				only_frame.update_frame();
				check_format();
			}
		});
		
		confirm_button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(!old_correct||!new_correct||!confirm_correct) {
					new Warn_frame("提示", "信息填写错误，请重新检查！").set_aYouTu_click(5);
					return;}
				confirm_button.set_timing_unable(20);
				only_frame.setVisible(false);
				
				String old_pass = new String(old_pass_field.getPassword());
				String new_pass = new String(new_pass_field.getPassword());
				Login_pass_message pass_message = new Login_pass_message(Main_Frame.getNative_count(), old_pass, new_pass);
				pass_message.setType(3);
				Private_Chat_Client.send_message(pass_message);
				
				new Warn_frame("提示", "发送成功，请稍后。。。").set_aYouTu_click(3);
			}
		});
	}
	
	public void Init_frame() {
		
		only_frame = new Only_frame(main_pane,40);
		only_frame.set_Size(true, 400, 470);
		only_frame.set_Title("YouTu 修改密码",new Font("微软雅黑",Font.PLAIN, 18),new Color(0, 131, 245));
		only_frame.remove_window_Maxbutton(false);
		only_frame.setVisible(true);
		only_frame.setAlwaysOnTop(true);
		
        only_frame.change_quite_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				only_frame.dispose();
			}
		});
	}
	
     public void check_format() {
    	 
    	 int len1 = new String(old_pass_field.getPassword()).length();
    	 String s1  = new String(new_pass_field.getPassword());
    	 String s2 = new String(confirm_pass_field.getPassword());
    	 int len2 = s1.length();
    	 
    	 old_correct = len1>7&&len1<13?true:false;
    	 new_correct = len2>7&&len2<13?true:false;
    	 confirm_correct = s1.equals(s2)?true:false;
    	 
    	 main_pane.repaint();
     }
     
     public void set_visiable(boolean visiable) {
    	 
    	 only_frame.setVisible(visiable);
     }
     
	private class Show_pane extends JPanel{
		
		@Override
		protected void paintComponent(Graphics g) {			
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
			
			g2.setColor(Color.white);
			g2.setFont(new Font("微软雅黑", Font.PLAIN, 18));
			g2.drawString("旧密码:", 30, 100);
			g2.drawString("新密码:", 30, 170);
			g2.drawString("确认密码:", 30, 240);
			
			if(!old_correct) {
				g2.setColor(Color.RED);
				g2.drawString("密码长度必须为8-12位", 130, 130);
			}
			else if(!new_correct) {
				g2.setColor(Color.RED);
				g2.drawString("密码长度必须为8-12位", 130, 210);
			}
			else if(!confirm_correct) {
				g2.setColor(Color.RED);
				g2.drawString("密码不一致", 140, 270);
			}
		}
	}
	
}
