package Frame;

import javax.swing.*;

import Main_frame_pane.Main_self_pane;
import Main_thread.TelnetCheck_thread;
import Message.Private.Private_info;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import custom_component.*;
import message_login_register.Register_message;
import ss.Private_Chat_Client;
import tool_Frame.Icon_show_frame;
import tool_Frame.Warn_frame;
import tools.FileUtills;
import tools.Icon_tools;
public class Edit_basic_info_frame implements ActionListener{
     
	Only_frame only_frame = null;
	Edit_head_icon_frame icon_frame = null;
	Show_pane main_pane=null;
	
	Icon_button icon_button = null;
	ImageIcon head_image = null;
	
	Roundrec_textFiled nameFiled=null;
	Roundrec_textFiled birth_textFiled=null;
	My_combox birth1=null;
	My_combox birth2=null;
	My_combox birth3=null;
	My_combox sexcombox=null;
	My_combox bloodcombox=null;
	Roundrec_textFiled home_text=null;

	My_combox school_conpany_combox=null;
	Roundrec_textFiled school_conpanytext=null;
	Roundrec_textFiled phone_text=null;
	Roundrec_textFiled email_text=null;
	Roundrec_textFiled signature_text=null;
	
	Roundrec_textArear state_text=null;
	
	Roundrec_button head_button = null;
	Roundrec_button confirm_button=null;
	Roundrec_button cancle_button=null;
	
	boolean correct = true;
	boolean name_error=false;
	boolean singture_error=false;
	boolean state_error=false;
	boolean email_error = false;
	
	Private_info private_info = null;

	String account=null;
	Font font = null;
	Font font_text = null;
	Color blue = null;
	String state_num_string = null;
	String icon_path = null;
	
	ImageIcon default_image = null;
	Main_self_pane main_self_pane = null;
	
	public Edit_basic_info_frame(String email) {
		 
		this.default_image = new ImageIcon(getClass().getResource("/background_image/default_image.png"));		
		icon_path = new File(System.getProperty("java.class.path")).getParentFile().getAbsolutePath()+"\\jre\\default_image.png";
	
		  font = new Font("微软雅黑", Font.PLAIN, 16);
		  font_text = new Font("微软雅黑", Font.PLAIN, 16);
		  blue = new Color(0, 131, 245);
		  
	      Init_all_components();
	      Init_frame();
	      
	      home_text.setText("火星");
	      phone_text.setText("0101001");
	      email_text.setText(email);
	  //  email_text.setEditable(false);
	      state_text.setText("大家好：");
	      
	      Init_listioner();
	     
	}
    
	public Edit_basic_info_frame(Private_info private_info) {
		
		 this.account = private_info.getCount();
		 this.default_image = new ImageIcon(getClass().getResource("/background_image/default_image.png"));		
		 icon_path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\image\\head_image\\native.jpg";
		
		  font = new Font("微软雅黑", Font.PLAIN, 16);
		  font_text = new Font("微软雅黑", Font.PLAIN, 16);
		  blue = new Color(0, 131, 245);
		  
	      Init_all_components();
	      Init_all_contents(private_info);
	      Init_frame();
	      Init_listioner();
	    
	}
	
	public void set_visiable(boolean visiable) {
		
		only_frame.setVisible(visiable);
	}
	
	public void Init_all_components() {
	
		main_pane = new Show_pane();
		main_pane.setLayout(null);
		main_pane.setOpaque(false);
		main_pane.setPreferredSize(new Dimension(540,970));
		main_pane.setMinimumSize(new Dimension(540,970));
		main_pane.setMaximumSize(new Dimension(540,970));
	    		
		head_button = new Roundrec_button(120, 35, 15, new Color(0, 131, 245), "切换头像", 16, Color.white);
		head_button.setBounds(160, 40, 120, 35);
		
		nameFiled = new Roundrec_textFiled(165, 25, 2f, Color.gray, Color.blue, 20, Color.black);
		nameFiled.setFont(font_text);
		nameFiled.setSelectionColor(blue);
		sexcombox = new My_combox(new String[] {"男","女","其他"});
		nameFiled.setBounds(90, 105, 165, 25);
		sexcombox.setBounds(360, 105, 80, 25);		
		
		String[] bir1=new String[120];
		int i1=2019;
		for(int i=0;i<120;i++) {
			bir1[i]=""+i1+"年";
			i1--;
		}
		String[] bir2 =new String[12]; 
		int i2=1;
		for(int i=0;i<12;i++) {
			if(i2<10) {
				bir2[i]="0"+i2+"月";
				i2++;
				continue;
			}
			bir2[i]=""+i2+"月";
			i2++;
		}
		String[] bir3 =new String[31]; 
		int i3=1;
		for(int i=0;i<31;i++) {
			if(i3<10) {
				bir3[i]="0"+i3+"日";
				i3++;
				continue;
			}
			bir3[i]=""+i3+"日";
			i3++;
		}		
		
		birth1 = new My_combox(bir1); birth1.setOpaque(false);
		birth2 = new My_combox(bir2);		
		birth3 = new My_combox(bir3);			
		bloodcombox = new My_combox(new String[]{"A型","B型","AB型","O型","其他"});
	    birth1.setBounds(90, 155, 80, 25);
	    birth2.setBounds(175, 155, 60, 25);
	    birth3.setBounds(240, 155, 60, 25);
		bloodcombox.setBounds(380, 155, 60, 25);
		
		home_text = new Roundrec_textFiled(165, 25, 2f, Color.gray, Color.blue, 20, Color.black);
		phone_text = new Roundrec_textFiled(165, 25, 2f, Color.gray, Color.blue, 20, Color.black);
		email_text = new Roundrec_textFiled(165, 25, 2f, Color.gray, Color.blue, 20, Color.black);
		signature_text = new Roundrec_textFiled(165, 25, 2f, Color.gray, Color.blue, 20, Color.black);
		
		home_text.setFont(font_text);
		phone_text.setFont(font_text);
		email_text.setFont(font_text);
		signature_text.setFont(font_text);
		
		home_text.setSelectionColor(blue);
		phone_text.setSelectionColor(blue);
		email_text.setSelectionColor(blue);
		signature_text.setSelectionColor(blue);
		
		home_text.setBounds(90, 205, 165, 25);
		phone_text.setBounds(90, 250, 165, 25);
		email_text.setBounds(90, 290, 165, 25);
		signature_text.setBounds(90, 340, 165, 25);
	    
		state_text = new Roundrec_textArear(350, 150, 2f, Color.gray, Color.blue, 20, Color.black);
		state_text.setFont(font_text);
		state_text.setSelectionColor(blue);
		state_text.setLineWrap(true);
		state_text.setWrapStyleWord(true);
		state_num_string = "4/120字";
		state_text.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		state_text.setBounds(90, 385, 350, 150);
		
		cancle_button = new Roundrec_button(120,35, 30, new Color(0, 131, 251), "取消", 18, Color.white);
		confirm_button = new Roundrec_button(120,35, 30, new Color(0, 131, 251), "确认", 18, Color.white);
		cancle_button.setBounds(120, 570,120,35);
		confirm_button.setBounds(300,570,120,35);
		
		main_pane.add(head_button);
		main_pane.add(nameFiled);
		main_pane.add(sexcombox);
		main_pane.add(birth1);
		main_pane.add(birth2);
		main_pane.add(birth3);
		main_pane.add(bloodcombox);
		main_pane.add(home_text);
		main_pane.add(phone_text);
		
		main_pane.add(email_text);
		main_pane.add(signature_text);
		main_pane.add(state_text);
		main_pane.add(cancle_button);
		main_pane.add(confirm_button);
		
		if(new File(icon_path).exists()) {update_head_icon(new ImageIcon(icon_path));}
		else {update_head_icon(default_image);}
	
	}
	
	public void Init_all_contents(Private_info private_info) {
		
		nameFiled.setText(private_info.getName());
		sexcombox.setSelectedItem(new JLabel(private_info.getSex()));
		
		String[] births = private_info.getBirth().split("-");
		birth1.setSelectedItem(new JLabel(births[0]));
		birth2.setSelectedItem(new JLabel(births[1]));
		birth3.setSelectedItem(new JLabel(births[2]));
		bloodcombox.setSelectedItem(new JLabel(private_info.getBlood()));
		
		home_text.setText(private_info.getHome());
		phone_text.setText(private_info.getPhone());
		
		email_text.setText(private_info.getE_mail());
//		email_text.setEditable(false);
		signature_text.setText(private_info.getSignature());
		state_text.setText(private_info.getState());
	
	}
	
	public void update_head_icon(ImageIcon imageIcon) {
		
		if(imageIcon==null) {return;}
		
		this.head_image = imageIcon;
		if(icon_button!=null) {main_pane.remove(icon_button);}
		
		icon_button = new Icon_button(imageIcon, "点击查看头像", 68);
		icon_button.setBounds(70, 10, 68, 68);
		main_pane.add(icon_button);
		icon_button.addActionListener(this);
		
		if(only_frame!=null) {only_frame.update_frame();}
		
		icon_frame = new Edit_head_icon_frame(imageIcon);
		icon_frame.set_visiable(false);
		icon_frame.add_confirmButton_listionner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
			    BufferedImage bufferedImage = icon_frame.get_selected_head_image();
			    icon_path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\image\\head_image\\native.jpg";
			    Icon_tools.Write_image(bufferedImage, 0.5f, icon_path);
			    
			    icon_frame.dispose();
				update_head_icon(new ImageIcon(bufferedImage));
				
			}
		});
	}
	
	public void Init_listioner() {
				
		head_button.addActionListener(this);
		cancle_button.addActionListener(this);
		confirm_button.addActionListener(this);
		
		nameFiled.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				only_frame.update_frame();
				check();
			}
		});
		home_text.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				only_frame.update_frame();
			}
		});
		phone_text.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				only_frame.update_frame();
			}
		});
		email_text.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				only_frame.update_frame();
				check();
			}
		});
		signature_text.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				only_frame.update_frame();
				check();
			}
		});
		state_text.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				only_frame.update_frame();
				String s = state_text.getText();
				if(s.length()<120) {state_num_string = s.length()+"/120字";}
				else {
					s = s.substring(0, 120);
					state_text.setText(s);
					state_num_string ="120/120字";
				}
				check();
			}
		});
		
	}
	
	public void Init_frame() {
		
	   only_frame = new Only_frame(main_pane,40);
	   only_frame.set_Size(true, 480, 665);
	   only_frame.set_Resizable(false);
	   only_frame.remove_window_Maxbutton(false);
	   only_frame.set_Title("编辑个人资料",new Font("微软雅黑",Font.PLAIN, 16), new Color(0, 131, 245));
	   only_frame.get_min_button().setVisible(false);
	   only_frame.setVisible(true);
	   only_frame.setAlwaysOnTop(true);
	   
	   only_frame.change_quite_listioner(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			cancle_button.doClick();
		}
	});
	}
	
	public boolean check(){
		
		boolean correct = true;
		
		if(nameFiled.getText().length()==0) {name_error = true;correct = false;}
		else {name_error = false;}
		if(signature_text.getText().length()==0) {singture_error = true;correct = false;}
		else {singture_error = false;}
		if(state_text.getText().length()==0) {state_error = true;correct = false;}
		else {state_error = false;}
		if(!email_text.getText().matches("\\d{6,10}@qq.com")) {email_error = true;correct = false;}
		else {email_error = false;}
		
		this.correct = correct;
		  
		main_pane.repaint();
		
		return correct;
		
	}
	
	public void dispose() {
		only_frame.dispose();
	}
	
	public boolean is_corrct() {
		
		return correct;
	}
	public void add_cancle_listioner(ActionListener actionListener) {
		
		cancle_button.addActionListener(actionListener);
	}
	
   public void add_confirm_listioner(ActionListener actionListener) {
		
		confirm_button.addActionListener(actionListener);
	}
   

   public Register_message get_register_message() {
	   
	   byte[] head_icon =  Icon_tools.get_IconBytes(icon_path);
	   String sex = ((JLabel)sexcombox.getSelectedItem()).getText();
	   String b1 = ((JLabel)birth1.getSelectedItem()).getText();
	   String b2 = ((JLabel)birth2.getSelectedItem()).getText();
	   String b3 = ((JLabel)birth3.getSelectedItem()).getText();
	   String birth = b1+"-"+b2+"-"+b3;
	   String blood = ((JLabel)bloodcombox.getSelectedItem()).getText();
	   
	   return new Register_message(3, head_icon, nameFiled.getText(), sex, birth, blood, home_text.getText(), phone_text.getText(), email_text.getText(), signature_text.getText(), state_text.getText());
	   	   
   }
   
 public Private_info get_Private_info() {
	 
	   byte[] head_icon =  Icon_tools.get_IconBytes(icon_path);
	   Icon_tools.compress_head_image(head_icon);
	   
	   String name = nameFiled.getText();
	   String sex = (String) sexcombox.getSelectedItem();
	   String b1 =  (String) birth1.getSelectedItem();
	   String b2 =  (String) birth2.getSelectedItem();
	   String b3 =  (String) birth3.getSelectedItem();
	   String birth = b1+"-"+b2+"-"+b3;
	   String blood = (String) bloodcombox.getSelectedItem();
	   String home = home_text.getText();
	   String phone = phone_text.getText();
	   String email = email_text.getText();
	   String signature = signature_text.getText();
	   String state = state_text.getText();
	   
	   Private_info private_info = new Private_info(account, head_icon, name, sex, birth, blood, home, phone, email, signature, state);
	   return private_info;
	   	   
   }
 
	private class Show_pane extends JPanel{
		
		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
			
			g2.setColor(Color.white);
			g2.setFont(font);
			
			g2.drawString("头像:", 15, 50);
			g2.drawString("昵称:", 15, 120); g2.drawString("性别:", 305, 120); 
			g2.drawString("出生年月:", 15, 170); g2.drawString("血型:", 330, 170); 
			g2.drawString("住址:", 15, 215);
			g2.drawString("电话:", 15, 260);
			g2.drawString("qq邮箱:", 15, 305);
			g2.drawString("个性签名:", 15, 350);
			g2.drawString("个人说明:", 15, 400);
		
			g2.setColor(Color.BLACK);
			g2.drawString(state_num_string, 380, 550);
			
			g2.setColor(Color.red);
			if(name_error) {g2.drawString("昵称不能为空", 95, 120);}
			if(email_error) {g2.drawString("QQ邮箱格式不正确", 270, 305);}
			if(singture_error) {g2.drawString("个性签名不能为空", 100, 355);}
			if(state_error) {g2.drawString("个人说明不能为空", 110, 405);}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	
		if(e.getSource()==icon_button) {new Icon_show_frame(head_image);}
		else if(e.getSource()==head_button) {icon_frame.set_visiable(true);}
		else if(e.getSource()==cancle_button) {only_frame.dispose();}
		else if(e.getSource()==confirm_button) {			
		        check();		       
			if(!correct) {new Warn_frame("提示", "请将资料补充完整！").set_aYouTu_click(5);return;}
		
		}
	}
	 public static Private_info get_private_info() {
		   
		   byte[] by =  Icon_tools.get_IconBytes("C:\\ProgramData\\Users\\Administrator\\Pictures\\4654.jpg");
		   Private_info info = new Private_info("10000000", by, "大当家的", "男", "1998-04-05", "A型", "America", "15939403617", "15939403617@163.com", "峰哥最牛逼！", "大家好，我是峰哥，我最牛逼！");
		   
		   return info;
	   }
	 public static void main(String[] args) {
		 
		  Edit_basic_info_frame frame =  new Edit_basic_info_frame(""); 
			
			frame.add_confirm_listioner(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
						
						Register_message message = frame.get_register_message();
						byte[] by = message.getHead_icon();
						
				}
			});
	}
}