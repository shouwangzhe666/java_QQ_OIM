package Frame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JPanel;

import Message.Group.Group_file_message;
import Message.Group.Group_info_message;
import Message.Private.Apply_Message;
import Message.Private.Private_Chat_Message;
import Private_chat.File_send_pane;
import chat_frame_pane.Private_chat_pane;
import custom_component.Box_pane;
import custom_component.My_ScrollPane;
import tool_Frame.Warn_frame;
import Private_chat.*;
import Private_chat.File_accept_pane;
import Group_chat.*;
public class File_frame {

	static boolean init = false;
	static HashMap<Long, JPanel> all_pane = null;  // the left is file_code,and the right is file_pane
	static My_ScrollPane scrollPane = null;
	static Box_pane list_pane = null;              // Which may be send_pane or accept_pane
	static Only_frame only_frame = null;
	
	public File_frame() {
		
          Init_components();
          Init_frame();
          File_frame.init = true;
	}
	
	public void Init_components() {
		
        all_pane = new HashMap<>();
		
		list_pane = new Box_pane(BoxLayout.Y_AXIS);
		scrollPane = new My_ScrollPane();
		scrollPane.setViewportView(list_pane);
	}
	
	public void Init_frame() {
		
		only_frame = new Only_frame(scrollPane,40);
		only_frame.set_Size(true,420, 540);
		only_frame.get_max_button().setVisible(false);
		only_frame.setResizable(false);
		only_frame.set_Title("文件任务", new Font("宋体", Font.PLAIN, 18), Color.white);
		only_frame.setVisible(true);
		
		only_frame.change_quite_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				list_pane.removeAll();
				only_frame.get_min_button().doClick();
			}
		});
	}
    
	public static boolean is_init() {
		return init;
	}
	
	public static void set_init(boolean init) {
		File_frame.init = init;
		return;
	}
	public static void update_all_pane() {
		
		list_pane.removeAll();
		
		for(JPanel jPanel:all_pane.values()) {
			  list_pane.add(jPanel);
			  list_pane.add(Box.createVerticalStrut(10));
		}
		
		int width = only_frame.get_frame_width();
		int height = all_pane.size()*410;
		
		list_pane.setPreferredSize(new Dimension(width,height));
		list_pane.setMinimumSize(new Dimension(width,height));
		list_pane.setMaximumSize(new Dimension(width,height));
		
		only_frame.setVisible(true);
		only_frame.update_frame();
		
		if(all_pane.size()==0) {only_frame.setVisible(false);}
	}
	public static void remove_file_pane(long file_code) {
		
           all_pane.remove(file_code);
		   update_all_pane();		
	}
	
	public static  void put_Send_file_pane(Apply_Message apply_Message,String file_path) {
		
		long file_code =  apply_Message.getFile_code();
		int  link_count = apply_Message.getTo_account();
		
	  File_send_pane file_send_pane = new File_send_pane(file_code, file_path,link_count);
	  all_pane.put(file_code, file_send_pane);
	 
	  update_all_pane();		 
	}
	
	public static void start_file_transfer(Apply_Message apply_Message) {
		
		long file_code = apply_Message.getFile_code();
		long start_position = apply_Message.getFilebin_location();
		int server_port = apply_Message.getTcp_server_port();
		
		File_send_pane send_pane = (File_send_pane) all_pane.get(file_code);
		if(send_pane==null) {return;}
		
		send_pane.start_transfer(start_position,apply_Message.getP2p_type(), server_port);
		
		only_frame.setVisible(true);
		only_frame.update_frame();
	}
	public static void stop_file_transfer(Apply_Message apply_Message) {
		   long file_code = apply_Message.getFile_code();
		   
		   File_send_pane send_pane = (File_send_pane) all_pane.get(file_code);
		   send_pane.stop_file_transfer();
		   
		   remove_file_pane(file_code);
	   }
   public  static void put_Accept_file_pane(Apply_Message apply_Message) {
	   
	   if(!File_frame.is_init()) {new File_frame();}
	   
	   long file_code = apply_Message.getFile_code();
	   long start_positon = apply_Message.getFilebin_location();
	   String file_name = apply_Message.getFile_name();
	   long file_size = apply_Message.getFile_size();
	   int link_count = apply_Message.getFrom_account();
	   int server_port = apply_Message.getTcp_server_port();
	   
	   File_accept_pane accept_pane = new File_accept_pane(file_code,start_positon,file_name, file_size, link_count,apply_Message.getP2p_type(), server_port);
	   all_pane.put(file_code, accept_pane);
	   
	   update_all_pane();
	   
	   accept_pane.File_accept();
	}
   
	public static  void put_Group_Sendfile_pane(String file_path,String file_name,long send_time,int group_count) {
		
		Group_chat.File_send_pane send_pane = new Group_chat.File_send_pane(file_path, file_name, send_time, group_count);
		all_pane.put(send_time, send_pane);
		
		  update_all_pane();		
   }
   public static void start_Group_Sendfile(Group_info_message group_info_message) {
	    Group_chat.File_send_pane send_pane = (Group_chat.File_send_pane) all_pane.get(group_info_message.getSend_time());
		if(send_pane==null) {System.err.println("send_pane==null");return;}
		
		send_pane.start_transfer(group_info_message);
		
		only_frame.setVisible(true);
		only_frame.update_frame();
   }
   public  static boolean put_Group_AcceptFilePane(String file_name,long file_lenth,long send_time) {
	    if(isGroupFileloading(file_name)) {
	    	 new Warn_frame("提示", "群文件："+file_name+"已经在下载").set_aYouTu_click(3);
	    	 return false;
	    }
	   Group_chat.File_accept_pane accept_pane = new Group_chat.File_accept_pane(file_name, file_lenth, send_time);
	   all_pane.put(send_time, accept_pane);
	 
	   update_all_pane();	
	   return true;
   }
   public static boolean isGroupFileloading(String file_name) {
	    for(JPanel jPanel:all_pane.values()) {
	    	if(jPanel instanceof Group_chat.File_accept_pane) {
	    		Group_chat.File_accept_pane accept_pane = (Group_chat.File_accept_pane) jPanel;
	    		if(accept_pane.get_filename().equals(file_name)) {return true;}
	    	}
	    }
	    return false;
   }
 public static void start_Group_AcceptFilePane(Group_file_message file_message) {
	    Group_chat.File_accept_pane accept_pane =  (Group_chat.File_accept_pane) all_pane.get(file_message.getFile_code());
		if(accept_pane==null) {System.err.println(" group accept_pane ==null");return;}
		
		accept_pane.start_transfer(file_message);
		
		only_frame.setVisible(true);
		only_frame.update_frame();
   }
}
