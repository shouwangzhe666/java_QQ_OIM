package Frame;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.print.attribute.standard.RequestingUserName;

import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;

import Message.Group.Group_info_message;
import Message.Private.Link_info;
import custom_component.My_Splite_pane;
import group_info_pane.Group_file_pane;
import group_info_pane.Group_home_pane;
import group_info_pane.Group_icon_pane;
import group_info_pane.Group_member_pane;
import group_info_pane.Group_notice_pane;
import group_info_pane.Group_set_pane;
import group_info_pane.Item_list_pane;
import ss.Group_Chat_Client;
import ss.Private_Chat_Client;
import tools.Icon_tools;

public class Group_info_frame {
	
	static boolean init = false;
	static int group_account = 0;
	static String group_remark = null;
	static String group_id = null;
	static boolean file_unload = false;
	static boolean icon_unload = false;
	
	static Group_home_pane home_pane = null;
	static Group_member_pane member_pane = null;
	static Group_notice_pane notice_pane = null;
	static Group_icon_pane icon_pane = null;
	static Group_file_pane file_pane = null;
	static Group_set_pane set_pane = null;
	
	static My_Splite_pane splite_pane = null;
	Item_list_pane list_pane = null;
    static Only_frame only_frame = null;
    
    public Group_info_frame() {
		
    	Init_components();
    	Init_frame();
    	set_init(true);
    //	change_pane("主页");
	}
    
 public void Init_components() {
	 
	 list_pane = new Item_list_pane();	 
	 splite_pane = new My_Splite_pane(130);
	 
	 splite_pane.setLeftComponent(list_pane);
	// splite_pane.setRightComponent(home_pane);	 
 }
public static Group_file_pane get_file_pane() {
	return file_pane;
}
public static Group_info_message get_info_message() {
	
	Group_info_message group_info_message1 = home_pane.get_home_message();
	if(group_info_message1==null) {return null;}
	
	Group_info_message group_info_message2 = set_pane.get_set_message();
	group_info_message2.setGroup_name(group_info_message1.getGroup_name());
	group_info_message2.setGroup_head_icon(group_info_message1.getGroup_head_icon());
	group_info_message2.setGroup_introduce(group_info_message1.getGroup_introduce());
	
	return group_info_message2;
}
 public static void load_home_set_pane(Group_info_message info_message) {
     Group_info_frame.group_account = info_message.getGroup_account();
     Group_info_frame.file_unload = info_message.isFile_upload_all();
     Group_info_frame.icon_unload = info_message.isIcon_upload_all();
     
     Link_info link_info = Main_Frame.getMessage_pane().get_link_info(String.valueOf(group_account));
     Group_info_frame.group_remark = link_info.getSignature();
     Group_info_frame.group_id = link_info.getId();
     
     String group_name = info_message.getGroup_name();
     only_frame.set_Title(group_name,new Font("宋体", Font.PLAIN, 18), Color.white);
     
	 home_pane = new Group_home_pane(info_message); 
	 home_pane.callin_frame(only_frame);
	 change_pane("主页");
	 
	 set_pane = new Group_set_pane(info_message);
	 set_pane.callin_frame(only_frame);
	 
	 member_pane = null;
	 notice_pane = null;
	 icon_pane = null;
	 file_pane = null;
 }
 
 public static void load_member_pane(Group_info_message info_message) {
	 Group_info_frame.group_account = info_message.getGroup_account();
     
     only_frame.setVisible(true);
	 member_pane = new Group_member_pane(info_message);
	 member_pane.callin_frame(only_frame);
	 change_pane("成员");
 }
 public static void load_notice_pane(Group_info_message info_message) {
	 Group_info_frame.group_account = info_message.getGroup_account();
     
     only_frame.setVisible(true);
	 notice_pane = new Group_notice_pane(info_message);
	 notice_pane.callIn_frame(only_frame);
	 change_pane("通告");
 }
 public static void load_icon_pane(Group_info_message info_message) {
	 Group_info_frame.group_account = info_message.getGroup_account();
     
     only_frame.setVisible(true);
	 icon_pane = new Group_icon_pane(info_message);
	 icon_pane.callIn_frame(only_frame);
	 change_pane("相册");
 }
 public static void load_file_pane(Group_info_message info_message) {
	 Group_info_frame.group_account = info_message.getGroup_account();
     
     only_frame.setVisible(true);
	 file_pane = new Group_file_pane(info_message);
	 file_pane.callIn_frame(only_frame);
	 change_pane("文件");
 }
 public static boolean is_init() {
	 return Group_info_frame.init;
	 }
 
 public static void set_init(boolean init) {
	 Group_info_frame.init = init;
	 }
 public static int get_group_account() {
	 return Group_info_frame.group_account;
 }
 public static String get_group_remark() {
	 return Group_info_frame.group_remark;
 }
 public static String get_group_id() {
	 return Group_info_frame.group_id;
 }
 public static boolean is_file_unload() {
	 return Group_info_frame.file_unload;
 }
 public static boolean is_icon_unload() {
	 return Group_info_frame.icon_unload;
 }
 public static void set_visiable(boolean visiable) {
	 only_frame.setVisible(visiable);
 }
	public void Init_frame() {
		
		only_frame = new Only_frame(splite_pane,false,40);
		only_frame.set_Size(true,850, 550);
		only_frame.remove_window_Maxbutton(false);
		only_frame.setVisible(true);
		
		splite_pane.callin_frame(only_frame);
		
      only_frame.change_min_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				only_frame.setVisible(false);
			}
		});

		only_frame.change_quite_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				group_account = 0;
				only_frame.setVisible(false);
			}
		});
	}
	
public static void change_pane(String text) {
	
	if(text.equals("主页")) {
		if(home_pane!=null) {splite_pane.setRightComponent(home_pane);}
	}
	else if(text.equals("成员")) {
		if(member_pane!=null) {splite_pane.setRightComponent(member_pane);}
		else{
			Group_info_message group_info_message = new Group_info_message(2, group_account);
			Group_Chat_Client.send_message(Group_info_frame.get_group_account(), group_info_message);
		}
		}
	else if(text.equals("通告")) {
		if(notice_pane!=null) {splite_pane.setRightComponent(notice_pane);}
		else {
			Group_info_message group_info_message = new Group_info_message(3, group_account);
			Group_Chat_Client.send_message(Group_info_frame.get_group_account(), group_info_message);
		}
	}
	else if(text.equals("相册")) {
		if(icon_pane!=null) {splite_pane.setRightComponent(icon_pane);}
		else {
			Group_info_message group_info_message = new Group_info_message(4, group_account);
			Group_Chat_Client.send_message(Group_info_frame.get_group_account(), group_info_message);
		}
	}
	else if(text.equals("文件")) {
		if(file_pane!=null) {splite_pane.setRightComponent(file_pane);}
		else {
			Group_info_message group_info_message = new Group_info_message(5, group_account);
			Group_Chat_Client.send_message(Group_info_frame.get_group_account(), group_info_message);
		}
	}
	else if(text.equals("设置")) {
		if(set_pane!=null) {splite_pane.setRightComponent(set_pane);}
	}
	
	only_frame.update_frame();
}

public static void main(String[] args) {
	
	     new Group_info_frame();
	
}
}
