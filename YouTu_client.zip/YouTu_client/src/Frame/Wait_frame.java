package Frame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.JPanel;


public class Wait_frame {
	
	static boolean init = false;
	volatile boolean start = true;
	static Only_frame only_frame = null;
	static Show_pane show_pane = null;
	
	public Wait_frame() {
		
		Init_frame();
		init = true;
	}
	public static boolean isInit() {
		return init;
	}
	public static void setFrame_visiable(boolean visiable) {
		show_pane.second = 0;
		only_frame.setVisible(visiable);
	}
	public void Init_frame() {
		
		show_pane = new Show_pane();
		new Thread(show_pane).start();
		
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (int) ((dimension.getWidth()-600)/2);
	    only_frame = new Only_frame(show_pane,40);
	//	only_frame.set_Size(true,600, 100);
	    only_frame.set_Bounds(x, 10,600, 100);
		only_frame.set_Title("请求等待中...",new Font("微软雅黑", Font.PLAIN, 20), new Color(0, 131, 253));
		only_frame.get_max_button().setVisible(false);
		only_frame.get_min_button().setVisible(false);
		
		only_frame.set_Resizable(false);
		only_frame.setVisible(true);
		only_frame.setAlwaysOnTop(true);
		
		only_frame.change_quite_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				only_frame.setVisible(false);
			}
		});
	}
	private class Show_pane extends JPanel implements Runnable{		
		String text = "";
		Font font = null;
		int second = 0;
		
		public Show_pane() {
			setLayout(null);
			font = new Font("宋体", Font.PLAIN, 18);
			
		}
		@Override
		public void run() {
			 while(start) {
				  second++;
				  String time = time_conveter(second);
				  paint_time(time);
				  try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
			 }
		}
		public String time_conveter(int second) {
			int s = second%60;
			int m = (second%3600)/60;
			int h = second/3600;
			
			String time = h+" : "+m+" : "+s;
			return time;
		}
		public void paint_time(String time) {
			this.text = "等待时间： "+time;
			repaint();
		}
		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
			g2.setFont(font);
			g2.drawString(text, 200, 25);
		}
	}
	
	public static void main(String[] args) {
		
		 new Wait_frame();
	}
}
