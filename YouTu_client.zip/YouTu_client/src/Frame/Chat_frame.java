package Frame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.concurrent.ConcurrentHashMap;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JSplitPane;
import javax.swing.text.StyledDocument;
import Main_thread.TelnetCheck_thread;
import Message.Group.Group_chat_message;
import Message.Private.Link_info;
import Message.Private.Shake_Message;
import chat_frame_pane.Container_pane;
import chat_frame_pane.Group_chat_pane;
import chat_frame_pane.Item_list_pane;
import chat_frame_pane.Private_chat_pane;
import custom_component.My_ScrollPane;
import custom_component.My_Splite_pane;
import ss.Group_Chat_Client;
import tools.Icon_tools;

public class Chat_frame {
      
	 static ConcurrentHashMap<Integer, JSplitPane> all_chat_pane = null;
	 static Item_list_pane list_pane = null;
	 static My_ScrollPane scrollPane = null;
	 static My_Splite_pane jSplitPane = null;
	 static Container_pane container_pane = null;
	 static Only_frame only_frame = null;
	 static boolean left = false;
	 static Dimension dimension = null;
	 static StyledDocument copy_styledocment = null;
	 static byte[] icon_bytes = null;
	 static boolean init = false;
	 static {
		 all_chat_pane = new ConcurrentHashMap<>();
	 }
	 
	public Chat_frame() {
	    
		init  = true;
		Init_component();
		Init_frame();	
	    
	}

	public static void Init_component() {
		
        dimension = Toolkit.getDefaultToolkit().getScreenSize();
		
		container_pane = new Container_pane(all_chat_pane);
		list_pane = new Item_list_pane(container_pane);
		
	    scrollPane = new My_ScrollPane();
		scrollPane.setPreferredSize(new Dimension(200, 500));
		scrollPane.setMinimumSize(new Dimension(200, 400));
		scrollPane.setMaximumSize(new Dimension(200, 2000));
		scrollPane.setViewportView(list_pane);
		
		jSplitPane = new My_Splite_pane(200);
		jSplitPane.setLeftComponent(scrollPane);
		jSplitPane.setRightComponent(container_pane);
		jSplitPane.setBorder(null);
	}
	
	public static void Init_frame() {
	    
		only_frame = new Only_frame(jSplitPane,true,40);
		only_frame.set_Title("",new Font("宋体", Font.BOLD, 18),new Color(0, 131, 245));
		only_frame.add_title_button();
		
		only_frame.set_Size(true,710,555);
		only_frame.setMin_width(710);
		only_frame.setMin_height(555);
		only_frame.setVisible(false);
		jSplitPane.callin_frame(only_frame);
		
		only_frame.change_min_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				only_frame.setExtendedState(JFrame.ICONIFIED);
			}
		});
		only_frame.change_quite_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				Main_Frame.setCurrent_link_count("0");
				list_pane.remote_all_Item();
				container_pane.remove_all_chat_pane();								
				
				only_frame.setVisible(false);
				System.gc();
			}
		});
	}
	
	public static void update_item_content(String link_count,String chat_content) {
		
		list_pane.update_item_content(link_count, chat_content);
	}
	
	public static void update_state(String link_account,String state) {
		
		list_pane.update_item_state(link_account, state);
	}
	
	public static void update_item_head_icon(String link_count,byte[] icon_bytes) {
		
		list_pane.update_item_head_icon(link_count, icon_bytes);
	}
	public static void update_private_other_head_image(String link_account,byte[] icon_bytes) {
		
		container_pane.update_private_other_head_icon(link_account, icon_bytes);
	}
	
	public static void update_private_self_icon(byte[] icon_bytes) {
		
		 container_pane.update_self_icon(icon_bytes);
	}
	
public static void update_group_othericon(int group_account,int member_account,byte[] icon_bytes) {
		
		Group_chat_pane chat_pane = Chat_frame.get_Group_chat_jpane(group_account);
		if(chat_pane!=null) {chat_pane.update_group_head_icon(member_account, icon_bytes);}
	}
public static void update_group_member_remark(int group_account,int member_account,String member_remark) {
	Group_chat_pane chat_pane = Chat_frame.get_Group_chat_jpane(group_account);
	chat_pane.update_group_member_remark(member_account, member_remark);
}	
public static void update_group_selficon(byte[] icon_bytes) {
	
	ArrayList<Integer> all_account = Main_Frame.getMessage_pane().get_all_group_account();
	int nati_account = Integer.parseInt(Main_Frame.getNative_count());
	
	Group_chat_message chat_message = new Group_chat_message(9, nati_account, System.currentTimeMillis(), "id", "remark", 0l);
	chat_message.setIcon_bytes(icon_bytes);
			
	for(int i=0;i<all_account.size();i++) {
		
		int group_account = all_account.get(i);
		Group_Chat_Client.send_message(group_account, chat_message);
		
		Group_chat_pane chat_pane = Chat_frame.get_Group_chat_jpane(group_account);		
		if(chat_pane!=null) {chat_pane.update_group_head_icon(nati_account, icon_bytes);}					
		
	}
	}

 public static void put_select_Item(String link_count) {
	
        only_frame.setVisible(true);
        
		list_pane.put_chat_item(link_count, false);		
		container_pane.change_pane(link_count);
		
		Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_count);
		String remark = link_info.getRemark();
		Image head_icon = Icon_tools.get_client_head_image(link_count);
		
		update_title(link_count, remark);
		set_down_head_icon(head_icon);
		
		update_ui();
	}
 
 public static void remove_Item(String link_count) {
		
		list_pane.remove_item(link_count);		
	}
 
public static void flash_frame(boolean flash) {
	 if(init) {only_frame.set_flash(flash);}
}

public static void update_frame() {	 
	 if(only_frame!=null) {only_frame.update_frame();}
}

public static void update_title(String link_account,String link_name) {
	
	   only_frame.update_title_button(link_account, link_name);
}
public static void set_down_head_icon(Image head_icon) {
	
	only_frame.setIconImage(head_icon);
}
	
public static void set_visiable(boolean visiable) {
		init = visiable;
		only_frame.setVisible(visiable);
	}
public static void set_copy_styledocment(StyledDocument copy_styledocment) {
	
    Chat_frame.icon_bytes = null;
	Chat_frame.copy_styledocment = copy_styledocment;
}

public static StyledDocument get_copy_styledocment() {
	
return Chat_frame.copy_styledocment;		
}

public static void set_copy_iconbytes(byte[] icon_bytes) {
	
    Chat_frame.copy_styledocment = null;
	Chat_frame.icon_bytes = icon_bytes;
}

public static byte[] get_copy_iconbytes() {

	return Chat_frame.icon_bytes;
}

public static void shake_frame(boolean self,String from_count) {
	
    Shake_Message.shake_frame(only_frame);
}

public static void put_Private_chat_pane(int link_account) {
	
	container_pane.put_Private_chat_pane(link_account);
}

public static Private_chat_pane get_Private_chat_jpane(int link_count) {
	
	 Private_chat_pane chat_pane = (Private_chat_pane) all_chat_pane.get(link_count);
	 return chat_pane;
	}

public static void put_Group_chat_pane(int group_account,String ip_port,String native_id,String native_remark,String conment_time) {
	
	container_pane.put_Group_chat_pane(group_account,ip_port,native_id, native_remark,conment_time);  
}

public static Group_chat_pane get_Group_chat_jpane(int group_account) {
	
	 Group_chat_pane chat_pane =  (Group_chat_pane) all_chat_pane.get(group_account);
	 return chat_pane;
}

public static void set_frame_Opatity(float opacity) {
	only_frame.setOpacity(opacity);
}
public static void update_ui() {

	if(list_pane.get_Item_num()>0) {
//	only_frame.update_frame_ui();
	only_frame.update_frame();
	}
}
public static void main(String[] args) {
	
	Chat_frame chat_frame =  new Chat_frame();
	Chat_frame.update_title("", "适当方式的方法");
	Chat_frame.set_visiable(true);
}
}