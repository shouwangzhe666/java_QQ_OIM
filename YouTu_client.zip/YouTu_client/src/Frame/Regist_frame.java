package Frame;

import javax.swing.*;

import Main_thread.TelnetCheck_thread;
import custom_component.Roundrec_PasswordField;
import custom_component.Roundrec_button;
import custom_component.Roundrec_textFiled;
import message_login_register.Register_message;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Timer;
import java.util.TimerTask;
public class Regist_frame implements KeyListener,ActionListener{

	static Only_frame only_frame = null;
	Main_pane main_pane = null;
	Roundrec_PasswordField pass_field = null;
	Roundrec_PasswordField pass_confirm_field = null;
	static Roundrec_textFiled email_field = null;
	Roundrec_textFiled code_field = null;
	
	Roundrec_button code_button = null;
	static Roundrec_button confirm_button = null;
	
	boolean pass_error = true;
	boolean pass_confirm_error = true;
	boolean email_error = true;

	static String code = "qwer";
    int error_times = 0;
    
	public Regist_frame() {
	    
		Init_componnets();
		Init_frame();
		
	}
	
	public void Init_componnets() {
		
		pass_field = new Roundrec_PasswordField(165, 25, 2f, Color.gray, Color.blue, 25, Color.black, '.');
		pass_confirm_field = new Roundrec_PasswordField(165, 25, 2f, Color.gray, Color.blue, 20, Color.black, '.');
		email_field = new Roundrec_textFiled(165, 25, 2f, Color.gray, Color.blue, 20, Color.black);
		code_field = new Roundrec_textFiled(165, 25, 2f, Color.gray, Color.blue, 20, Color.black);
		
		code_button = new Roundrec_button(140, 30, 10, new Color(0, 131, 251), "获取验证码", 16, Color.white);
		confirm_button = new Roundrec_button(200, 50, 40, new Color(0, 131, 251), "提交", 18, Color.white);
		code_button.setEnabled(false);
		confirm_button.setEnabled(false);
		
		main_pane = new Main_pane();
		main_pane.setLayout(null);
		
		pass_field.setBounds(130, 35, 165, 25);
		pass_confirm_field.setBounds(130, 95, 165, 25);
		email_field.setBounds(130, 155,165, 25);
		code_field.setBounds(130, 215, 165, 25);
		
		code_button.setBounds(320, 215, 140, 30);
		confirm_button.setBounds(150, 280,200, 50);
		
		code_button.addActionListener(this);
		confirm_button.addActionListener(this);
		
		pass_field.addKeyListener(this);
		pass_confirm_field.addKeyListener(this);
		email_field.addKeyListener(this);		
		code_field.addKeyListener(this);
		
		main_pane.add(pass_field);
		main_pane.add(pass_confirm_field);
		main_pane.add(email_field);
		main_pane.add(code_field);
		main_pane.add(code_button);
		main_pane.add(confirm_button);
	}

	public void Init_frame() {
		
		only_frame = new Only_frame(main_pane,true,40);
		only_frame.set_Resizable(false);
		only_frame.set_Size(true, 500, 400);
		only_frame.set_window_buttons(true);
		only_frame.set_Title("YouTu注册", new Font("微软雅黑",Font.PLAIN, 20), new Color(0, 131, 253));
		only_frame.remove_window_Maxbutton(false);
		only_frame.get_min_button().setVisible(false);
		only_frame.setVisible(true);
		only_frame.setAlwaysOnTop(true);
		
		only_frame.change_quite_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				only_frame.setVisible(false);
			}
		});
	}
		
	public static void set_code(String code) {
		
		Regist_frame.code = code;
		Regist_frame.confirm_button.setEnabled(true);
		
	}
	
	public void set_visiable(boolean visiable) {
		
		only_frame.setVisible(visiable);
	}
	
    public void dispose() {
		
	    only_frame.dispose();
	}
	public boolean check_all() {
		
		boolean correct =  true;
		
		int len = new String(pass_field.getPassword()).length();
		pass_error = len<8||len>12?true:false;
		
	   String p1 = new String(pass_field.getPassword());
	   String p2 = new String(pass_confirm_field.getPassword());
		pass_confirm_error = p1.equals(p2)?false:true;
		main_pane.repaint();
		p1 = null;
	
	   String email = email_field.getText();
//	   email_error = email.matches("^[a-zA-Z]([a-zA-Z0-9_]{5,17}@163.com)$")?false:true;//163邮箱格式
	   email_error = email.matches("\\d{6,10}@qq.com")?false:true;//qq邮箱格式
	   main_pane.repaint();
	   email = null;
	   
	   correct = !pass_error&&!pass_confirm_error&&!email_error;
	   
	   main_pane.repaint();
	   
	return correct;
   }
	
	public boolean check_code() {
		
		if(code_field.getText().equals(code)) {return true;}
		
		return false;
	}
	
	private class Main_pane extends JPanel{
		Font font1 = null;
		Font font2 = null;
		public Main_pane() {
			
		  font1 = new Font("微软雅黑", Font.PLAIN, 18);
		  font2 = new Font("微软雅黑", Font.PLAIN, 16);
		}
		
		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
			
		//	g2.setColor(Color.white);
			g2.setColor(Color.black);
			g2.setFont(font1);
			
			g2.drawString("密码：", 35, 50);
			g2.drawString("确认密码：", 35, 110);
			g2.drawString("qq邮箱：", 35, 170);
			g2.drawString("验证码：", 35,230);
			
			g2.setColor(Color.red);
			g2.setFont(font2);
			if(pass_error) {g2.drawString("密码长度必须为8-12位", 310, 50);}
			else if(pass_confirm_error) {g2.drawString("两次密码不一致", 310, 110);}
			else if(email_error) {
				g2.drawString("qq邮箱格式不正确", 310, 170);
				g2.drawString("必须以英文字母开头", 310, 190);
			}
		}
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO AYouTu-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		
		
	}

	@Override
	public void keyReleased(KeyEvent e) {

		check_all();
		only_frame.update_frame();
		boolean error = pass_error||pass_confirm_error||email_error;
		if(error) {code_button.setEnabled(false);}
		else {code_button.setEnabled(true);}
		
		if(e.getSource()==code_field) {
			if(e.getKeyCode()==KeyEvent.VK_ENTER) {confirm_button.doClick();}
		}
	}
	
@Override
public void actionPerformed(ActionEvent e) {
	
	if(e.getSource()==code_button) {
	
		code_button.set_timing_unable(60);
		confirm_button.setEnabled(false);
		
		Register_message register_message = null;
		register_message = new Register_message(1, email_field.getText(), new String(pass_confirm_field.getPassword()));
		Private_Chat_Client.send_message(register_message);
		
		code_field.setText("");
		
		new Timer().schedule(new TimerTask() {
			
			@Override
			public void run() {
			pass_field.setEditable(true);
			pass_confirm_field.setEditable(true);
			email_field.setEditable(true);
			}
		}, 20000);
	}
	
	else if(e.getSource()==confirm_button){
		
		if(!check_all()) {new Warn_frame("提示", "信息填写错误，请重新检查！").set_aYouTu_click(3);return;}
		
		if(check_code()) {
			
			set_visiable(false);
			new Warn_frame("提示", "验证成功，\n请补充填写个人资料完成注册！").set_aYouTu_click(3);
			Edit_basic_info_frame frame =  new Edit_basic_info_frame(email_field.getText()); 
			
			pass_field.setText("");
			pass_confirm_field.setText("");
			email_field.setEnabled(true);
			email_field.setText("");
			code_field.setText("");
			
			frame.add_cancle_listioner(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					
					new Warn_frame("提示", "您已放弃此次注册机会！！").set_aYouTu_click(3);
				}
			});
			
			frame.add_confirm_listioner(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
									
					if(frame.is_corrct()) {					
						
						Register_message message = frame.get_register_message();
						
						Private_Chat_Client.send_message(message);
					    new Warn_frame("提示", "注册信息已提交！\n请稍后。。。").set_aYouTu_click(3);
						frame.dispose();
					    only_frame.dispose();
					}					
				}
			});
			// 开始填写详细信息
		}
		else{
			error_times++;
			new Warn_frame("提示", "验证码错误"+error_times+"次，\n请尝试刷新邮箱并重新输入！").set_aYouTu_click(5);
			
			if(error_times==4) {
			//	new Warn_frame("提示", "验证码错误次数过多，\n请重新尝试注册！").set_aYouTu_click(5);
			//	new Warn_frame("提示", "验证码错误"+error_times+"次，\n请重新输入！").set_aYouTu_click(5);
				set_code(null);
			//	only_frame.dispose();
				}
			else {
		//	new Warn_frame("提示", "验证码错误"+error_times+"次，\n请重新输入！").set_aYouTu_click(5);
			confirm_button.set_timing_unable(10);
			}
		}
	}
}
}