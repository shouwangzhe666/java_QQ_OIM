package Frame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JPanel;

import Main_thread.TelnetCheck_thread;
import custom_component.Roundrec_button;
import custom_component.Roundrec_textFiled;
import io.netty.channel.Channel;
import message_login_register.Login_pass_message;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;

public class Find_password_frame {
   
	Only_frame only_frame = null;
	Show_pane main_pane = null;
	Roundrec_textFiled account_field = null;
	Roundrec_textFiled email_field = null;
	Roundrec_button confirm_button = null;
	
	boolean account_corrct = false;
	boolean email_corrct = false;
	
	public Find_password_frame() {
		
		Init_compnents();
		Init_listioner();
		Init_frame();
		
	}
	
   public void dispose() {
		
	    only_frame.dispose();
	}
  
	public void Init_compnents() {
		
		main_pane = new Show_pane();
		main_pane.setLayout(null);
		
		account_field = new Roundrec_textFiled(190, 25, 2f, Color.gray, Color.blue, 20, Color.black);
		email_field = new Roundrec_textFiled(190, 25, 2f, Color.gray, Color.blue, 20, Color.black);
		confirm_button = new Roundrec_button(150, 40, 30, new Color(0, 131, 251), "找回", 18, Color.white);
		
		account_field.setBounds(130, 80,200, 25);
		email_field.setBounds(130, 160,200, 25);
		confirm_button.setBounds(130, 260,150, 40);
		
		main_pane.add(account_field);
		main_pane.add(email_field);
		main_pane.add(confirm_button);
		
	}
	
	public void Init_listioner() {
		
		account_field.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				only_frame.update_frame();
				check_format();
			}
		});
		
		email_field.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				only_frame.update_frame();
				check_format();
			}
		});
		
		confirm_button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(!account_corrct||!email_corrct) {
					new Warn_frame("提示", "信息填写错误，请重新检查！").set_aYouTu_click(5);
					return;}
				confirm_button.set_timing_unable(20);
				only_frame.setVisible(false);
				
				Login_pass_message pass_message = new Login_pass_message(2, account_field.getText(), email_field.getText());
				Private_Chat_Client.send_message(pass_message);
				
				new Warn_frame("提示", "发送成功，请稍后。。。").set_aYouTu_click(3);
			}
		});
	}
	
	public void Init_frame() {
		
		only_frame = new Only_frame(main_pane,40);
		only_frame.set_Size(true, 400, 400);
		only_frame.set_Title("YouTu 找回密码", new Font("微软雅黑",Font.PLAIN, 18),new Color(0, 131, 245));
		only_frame.remove_window_Maxbutton(false);
		only_frame.setVisible(true);
		only_frame.setAlwaysOnTop(true);
		
        only_frame.change_quite_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				only_frame.setVisible(false);
			}
		});
	}
	
     public void check_format() {
    	 
    	 boolean num = account_field.getText().length()==8;
    	 boolean format = account_field.getText().matches("\\d{8}");
    	 account_corrct = num&&format;
    	 
    	 String s = email_field.getText();
    //	 email_corrct = s.matches("^[a-zA-Z]([a-zA-Z0-9_]{5,17}@163.com)$");
    	 email_corrct = s.matches("\\d{6,10}@qq.com");//qq邮箱格式
    	 main_pane.repaint();
     }
     
     public void set_visiable(boolean visiable) {
    	 
    	 only_frame.setVisible(visiable);
     }
     
	private class Show_pane extends JPanel{
		
		@Override
		protected void paintComponent(Graphics g) {			
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
			
		//	g2.setColor(Color.white);
			g2.setColor(Color.black);
			g2.setFont(new Font("微软宋体", Font.PLAIN, 18));
			g2.drawString("账号:", 30, 100);
			g2.drawString("qq邮箱:", 30, 180);
			
			if(!account_corrct) {
				g2.setColor(Color.RED);
				g2.drawString("请输入8位有效数字账号", 130, 130);
			}
			else if(!email_corrct) {
				g2.setColor(Color.RED);
				g2.drawString("qq邮箱格式不正确", 130, 210);
			}
		}
	}
	
}
