package Frame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.ConcurrentHashMap;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

import MainThread_pack.Audio_thread;
import Message.Private.Apply_Message;
import Message.Private.Private_Chat_Message;
import chat_frame_pane.Private_chat_pane;
import custom_component.Roundrec_button;
import ss.Private_Chat_Client;
import tools.Audio_Tools;

public class Audio_frame {	
	
	volatile boolean start = true;
	int link_account = 0;
	long send_time = 0;
	int time_lenth = 0;
	Show_pane show_pane = null;
	Only_frame only_frame = null;
	Audio_Tools audio_Tools = null;
	
	public Audio_frame(int link_account) {
		this.link_account = link_account;
		send_time = System.currentTimeMillis();
		audio_Tools = new Audio_Tools(link_account, send_time);
		audio_Tools.start_record();
		
		show_pane = new Show_pane();
		Init_frame(show_pane);
		new Update_thread().start();
	}
	
	public void Init_frame(Show_pane show_pane) {
		
		    only_frame = new Only_frame(show_pane,40);
			only_frame.set_Size(true,370, 470);
			only_frame.set_Title("语音",new Font("微软雅黑", Font.PLAIN, 20), new Color(0, 131, 253));
			only_frame.get_max_button().setVisible(false);
			only_frame.get_min_button().setVisible(false);
			
			only_frame.set_Resizable(false);
			only_frame.setVisible(true);
			only_frame.setAlwaysOnTop(true);
			
			only_frame.change_quite_listioner(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
				     show_pane.cancle_button.doClick();
				}
			});
	}
    private class Update_thread extends Thread{
    	
    	@Override
    	public void run() {
    		while(start&&time_lenth++<60) {
    			
    			show_pane.paint_audio(time_lenth/2);
    			try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
    		}
    	}
    }
	private class Show_pane extends JPanel implements ActionListener{
		Image image = null;
		boolean show = false;
		String text = null;
		Font font = null;
		Roundrec_button cancle_button = null;
		Roundrec_button send_button = null;
		
		public Show_pane() {
			setLayout(null);
			font = new Font("宋体", Font.BOLD, 22);
			image = new ImageIcon(getClass().getResource("/tool_image/Audio_Record.png")).getImage();
			
			Init_buttons();
			Init_listioner();
		}
		public void Init_buttons() {
			
			cancle_button =  new Roundrec_button(100, 40, 10,new Color(0, 131, 253), "取消", 18, Color.white);
			send_button =  new Roundrec_button(100, 40, 10,new Color(0, 131, 253), "发送", 18, Color.white);
			send_button.set_auto_click(30, true);
			
			cancle_button.setBounds(35, 340, 100, 40);
			send_button.setBounds(210, 340, 100, 40);
			add(cancle_button);
			add(send_button);
		}
		public void Init_listioner() {
			cancle_button.addActionListener(this);
			send_button.addActionListener(this);
		}
		public void paint_audio(int second){
			 this.show = !show;
			 this.text = second+" s";
			 repaint();
		}
		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
			
			if(show) {
				g2.drawImage(image, 90, 20, null);
				g2.setColor(Color.red);
				g2.setFont(font);
				g2.drawString(text, 150, 290);
			}
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==send_button) {
				
				send_button.cancle_aYouTu_click();
				audio_Tools.save_record();
				
				ConcurrentHashMap<Integer,Audio_thread> all_audio_thread = Main_Frame.get_all_audio_thread();
				Audio_thread audio_thread = all_audio_thread.get(link_account);
				
				if(audio_thread==null) {
					 audio_thread = new Audio_thread();
					 audio_thread.start_ThreadPoolExecYouTur();
					 all_audio_thread.put(link_account, audio_thread);
					 
					// send audio_request message to server
					 Apply_Message apply_Message = get_ApplyMessage();
					 Private_Chat_Client.send_message(apply_Message);
				}
				
				// send audio file
				  audio_thread.send_Audio_messsage(time_lenth/2+1, send_time, audio_Tools.get_audio_path());
				  
				 // add audio_item into chat_frame
				     int native_count = Integer.parseInt(Main_Frame.getNative_count());
					 Private_Chat_Message chat_Message = new Private_Chat_Message(7,native_count,link_account, send_time);
					 chat_Message.setTime_lenth(time_lenth/2+1);
					 			 
					 Main_Frame.getMessage_pane().put_accept_message_item(String.valueOf(link_account),System.currentTimeMillis(),"语音消息");
					 Chat_frame.update_item_content(String.valueOf(link_account),"语音消息");
					 
					 Private_chat_pane chat_pane = (Private_chat_pane) Chat_frame.get_Private_chat_jpane(link_account);
				     chat_pane.put_audio_message(chat_Message, true);
				     
				//     Play_sound.play_message_sound();
			}
			else if(e.getSource()==cancle_button) {
				send_button.cancle_aYouTu_click();
				audio_Tools.cancle_record();
			}
			    only_frame.dispose();
		}
	}   // Show_pane
	public Apply_Message get_ApplyMessage() {
		
		String link_count = String.valueOf(link_account);
		String reply_ip = Main_Frame.getMessage_pane().get_link_info(link_count).getRemote_ip();
		String request_ip = Main_Frame.get_NativeIp();
		int p2p_type = reply_ip.endsWith("0000")||request_ip.endsWith("0000")?3:request_ip.equals(reply_ip)?2:1;
		
		int from_account  = Integer.parseInt(Main_Frame.getNative_count());
		int to_account = link_account;
		
		Apply_Message apply_Message = new Apply_Message(135, 1, from_account, to_account, p2p_type, 1, 1, 1, true, request_ip, reply_ip);
		return apply_Message;
	}
}
