package Frame;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileLock;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;
import Item.Login_Item;
import Main_thread.TelnetCheck_thread;
import Private_handle_pack.Login_Pass_handle;
import custom_component.Icon_button;
import custom_component.My_box_JmenuItem;
import custom_component.Roundrec_button;
import message_login_register.Basic_set_message;
import message_login_register.Login_Record;
import message_login_register.Login_pass_message;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;
import tools.FileUtills;
import tools.Icon_tools;

public class Login_frame implements ActionListener{

	static Only_frame only_frame = null;
	static Regist_frame regist_frame = null;
	static Find_password_frame password_frame = null;
	
	Show_pane main_pane = null;
	
	Image head_image = null;
	Image account_image = null;
	Image pass_image = null;
	
	static JTextField account_fild = null;
	static JPasswordField pass_fild = null;
	
	Icon_button set_button = null;
	Icon_button history_button = null;
	Icon_button help_button = null;
	
	Roundrec_button login_button = null;
	Roundrec_button regist_button = null;
	
	JPopupMenu popupMenu1 = null;
	My_box_JmenuItem aYouTu_item = null;
	My_box_JmenuItem remember_item = null;
	Basic_set_message set_message = null;
	
	static ArrayList<Login_Record> all_record = null;
	JPopupMenu popupMenu2 = null;
	int pop2_height = 0;
	 
	boolean account_correct = true;
	boolean pass_correct = true;
	static  boolean remember_pass = false;
	static boolean aYouTu_login = false;	
	static boolean init = false;
	static RandomAccessFile randomAccessFile = null;
	static FileLock fileLock = null;
	
	public Login_frame() {
	 
		init = true;
		Init_compents();
		Init_set_menu();
		Init_login_history();
		
		Init_listioner();
		Init_frame();
		
		if(aYouTu_login) {login_button.doClick();}
	}
	
	public void Init_compents() {
		
		account_image = new ImageIcon(getClass().getResource("/login_image/login_rabbit.png")).getImage();
		pass_image = new ImageIcon(getClass().getResource("/login_image/login_pass.png")).getImage();
		
		main_pane = new Show_pane();
		main_pane.setLayout(null);
		
		ImageIcon imageIcon = new ImageIcon(getClass().getResource("/background_image/default_image.png"));
		this.head_image =  Icon_tools.get_head_image(imageIcon, 100);
				
		account_fild = new JTextField();
		account_fild.setBorder(null);
		account_fild.setOpaque(false);
		account_fild.setFont(new Font("微软宋体",Font.PLAIN,18));
		account_fild.setBounds(200, 140, 200, 50);
		main_pane.add(account_fild);
		
		pass_fild = new JPasswordField();
		pass_fild.setBorder(null);
		pass_fild.setOpaque(false);
		pass_fild.setFont(new Font("微软宋体",Font.PLAIN,18));
		pass_fild.setBounds(200, 210, 200, 50);
		main_pane.add(pass_fild);
		
		login_button = new Roundrec_button(250, 45, 30, new Color(0, 131, 246), "登录", 18, Color.white);
		regist_button = new Roundrec_button(250, 45, 30,Color.white, "注册", 18, new Color(0, 131, 246));
		
		login_button.setBounds(160, 290, 250, 45);
		regist_button.setBounds(160, 350, 250, 45);
		
		main_pane.add(login_button);
		main_pane.add(regist_button);
		
		set_button = new Icon_button(getClass().getResource("/login_image/set_trans.png"), "登录设置");
		history_button = new Icon_button(getClass().getResource("/login_image/history_trans.png"),"登录记录");
		help_button = new Icon_button(getClass().getResource("/login_image/help_trans.png"),"找回密码");
		
		set_button.setBounds(10, 390, 25, 25);
		history_button.setBounds(50, 390, 25, 25);
		help_button.setBounds(550, 390, 25, 25);
		
		main_pane.add(set_button);
		main_pane.add(history_button);
		main_pane.add(help_button);
		
	}
	
	public void Init_set_menu() {
		
		popupMenu1 = new JPopupMenu();
		popupMenu1.setOpaque(false);
		
	    set_message = Basic_set_message.get_Basic_set_message();
	    if(set_message==null) {set_message = new Basic_set_message();}
		
	    aYouTu_login = set_message.isAuto_login();
	    remember_pass = set_message.isRemember();
	    
	    aYouTu_item = new My_box_JmenuItem(aYouTu_login, "自动登录");		
		remember_item = new My_box_JmenuItem(remember_pass, "记住密码");
		
		popupMenu1.add(aYouTu_item);
		popupMenu1.add(remember_item);
		
	}
	
	public void Init_login_history() {
		
		 popupMenu2 = new JPopupMenu();
		
		 all_record = Login_Record.get_all_Login_Record();
		 if(all_record.size()==0) {return;}
		 
		 Login_Record record = null;
		 Login_Item item = null;
		 Image head_image = null;
		 String name = null;
		 String account = null;
		 String password = null;
		 int login_num = 0;
		 		 
		 for(int i=0;i<all_record.size();i++) {
			 login_num++;
		     record = all_record.get(i);
		     
			 head_image = record.getHead_icon();
			 name = record.getName();
			 account = record.getAccount();
			 password = record.getPassword();
			 
			 item = new Login_Item(this,head_image, name,account, password);
			 popupMenu2.add(item);
			 
			 if(login_num==1) {
				
				 Init_content(head_image, account, password);}
			
		 }
            
		 pop2_height = (login_num*50+10)*-1;
	}
	
	public void Init_listioner() {
		
		account_fild.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				only_frame.update_frame();
			    account_correct = account_fild.getText().matches("\\d{8}");
			
			}
		});
		
		pass_fild.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				only_frame.update_frame();
				int len = new String(pass_fild.getPassword()).length();
				pass_correct = len>7&&len<13;
				
				if(e.getKeyCode()==KeyEvent.VK_ENTER) {login_button.doClick();}
			}
		});
		
		login_button.addActionListener(this);
		regist_button.addActionListener(this);
		
		set_button.addActionListener(this);
		history_button.addActionListener(this);
		help_button.addActionListener(this);
		
		aYouTu_item.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				    
				    aYouTu_login = aYouTu_item.isSelected();
					set_message.setAuto_login(aYouTu_item.isSelected());
					Basic_set_message.write_basic_set_message(set_message);
			}
		});
		
      remember_item.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
			     
				remember_pass = remember_item.isSelected();
				set_message.setRemember(remember_item.isSelected());
				Basic_set_message.write_basic_set_message(set_message);
				
				if(!aYouTu_login&&!remember_pass) {delete_login_pass_history();}
			}
		});
	}
	
	public void Init_frame() {
		
		only_frame = new Only_frame(main_pane,true,500);
		only_frame.set_Size(true, 600, 480);
		only_frame.set_Title("",new Font("微软雅黑",Font.PLAIN, 20),new Color(0, 131, 245));
		only_frame.remove_window_Maxbutton(false);
		only_frame.get_min_button().setVisible(false);
		only_frame.setVisible(true);
//		only_frame.setAlwaysOnTop(true);
		
		only_frame.change_quite_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
	}	
	
	public void Init_content(Image head_image, String account, String password) {
		
		this.head_image = head_image;
		if(head_image==null) {
			String icon_path = getClass().getResource("/background_image/default_image.png").toString().substring(6);
			this.head_image = Icon_tools.get_head_image(new ImageIcon(icon_path), 100);
		}
		
		account_fild.setText(account);
		
		if(remember_pass) {pass_fild.setText(password);}
		else {pass_fild.setText("");}
		
		if(aYouTu_login) {
			pass_fild.setText(password);
			account_correct = account_fild.getText().matches("\\d{8}");
			int len = new String(pass_fild.getPassword()).length();
			pass_correct = len>7&&len<13;
			login_button.doClick();
		}
		
		main_pane.repaint();
	}
	
	public void delete_login_pass_history() {
		
		Login_Record record = null;
		 for(int i=0;i<all_record.size();i++) {
			 
			record = all_record.get(i);
			record.setPassword("");
		}
		
		Login_Record.write_all_Login_Record(all_record);
	}
	
	public static void flash_frame(boolean flash) {
	
		 if(init) {only_frame.set_flash(flash);}
	}
	
	public static void login_success(String name,byte[] head_bytes) {
        init = false;
        
		String account = account_fild.getText();
		String pass = new String(pass_fild.getPassword());
		ImageIcon imageIcon = new ImageIcon(head_bytes);
		Image head_image = Icon_tools.get_head_image(imageIcon, 100);
		
		if(!aYouTu_login&&!remember_pass) {pass="";}
		
		Login_Record login_Record = new Login_Record(new ImageIcon(head_image), name, account, pass);
		if(!is_LoginRecord_exist(login_Record)) {all_record.add(login_Record);}
		
		ArrayList<Login_Record> all_temp_record = Login_Record.set_top_Login_Record(all_record,login_Record);
		Login_Record.write_all_Login_Record(all_temp_record);

		if(regist_frame!=null) {regist_frame.dispose();regist_frame=null;}
		if(password_frame!=null) {password_frame.dispose();password_frame=null;}
		only_frame.dispose();only_frame = null;	
	}
	public static void login_failed() {
		 if(fileLock!=null) {
			 try {
				fileLock.release();
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
		 }
		 if(randomAccessFile!=null) {try {
				randomAccessFile.close();
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}}
	}
	public static boolean is_LoginRecord_exist(Login_Record login_Record) {
		
		String top_account = login_Record.getAccount();
		Login_Record record = null;
		
		for(int i=0;i<all_record.size();i++) {
		      record = all_record.get(i);	
		      if(record.getAccount().equals(top_account)) {return true;}
		}
		
		return false;
	}
	
	private class Show_pane extends JPanel{
		
		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
			
		if(head_image!=null) {g2.drawImage(head_image, 250, 10, 100, 100, null);}
			
			g2.drawImage(account_image, 140, 140, null);
			g2.drawImage(pass_image, 140, 210, null);
			
			g2.setStroke(new BasicStroke(4f));
			g2.setColor(Color.gray);
			
			g2.drawLine(180, 180, 430, 180);
			g2.drawLine(180, 250, 430, 250);
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
	
		if(e.getSource()==login_button) {			 
				 
			if(!account_correct) {new Warn_frame("提示", "请输入8位有效数字账号！").set_aYouTu_click(5);return;}
			else if(!pass_correct) {new Warn_frame("提示", "密码长度必须为8-12位！").set_aYouTu_click(5);return;}
			
			 login_button.set_timing_unable(3);
			 account_fild.setEditable(false);
			 pass_fild.setEditable(false);
			 
			 new Timer().schedule(new TimerTask() {
				
				@Override
				public void run() {
					 account_fild.setEditable(true);
					 pass_fild.setEditable(true);
					
				}
			}, 3000);		 
			 
			 String file_path = "C:\\ProgramData\\YouTu\\YouTu_"+account_fild.getText()+"\\list_history\\security.db";
			 FileUtills.create_new_file(file_path);
		
			  if(TelnetCheck_thread.isavisiable()) {
					  try {
							randomAccessFile = new RandomAccessFile(new File(file_path), "rws");
							fileLock =	randomAccessFile.getChannel().tryLock();
							
						} catch (FileNotFoundException e1) {
							// TODO AYouTu-generated catch block
						//	e1.printStackTrace();
						}
					      catch (Exception e2) {
						//		e2.printStackTrace();
						}
					  if(fileLock==null) {
							new Warn_frame("提示", "你已在此设备上正在登录此账号！").set_aYouTu_click(5);							
							return;
						}
			  }
					
				// login_success  			 		
			 Login_pass_message pass_message = new Login_pass_message(1, account_fild.getText(), new String(pass_fild.getPassword()));
		     Login_Pass_handle.set_account(Integer.parseInt(account_fild.getText()));
		     
		     String file_path1 = "C:\\ProgramData\\YouTu\\YouTu_"+account_fild.getText()+"\\image\\head_image\\native.jpg";
		     String file_path2 = "C:\\ProgramData\\YouTu\\YouTu_"+account_fild.getText()+"\\image\\head_image\\"+account_fild.getText()+".png";
		     File file1 = new File(file_path1);
		     File file2 = new File(file_path2);
		     boolean exist = file1.exists()&&file1.length()>0&&file2.exists();
		     pass_message.setNativeImage_exist(exist);
		     
		     Private_Chat_Client.send_message(pass_message);		   
		}
		else if(e.getSource()==regist_button) {
			String file_path = "C:\\ProgramData\\YouTu\\login\\security.db";
			RandomAccessFile randomAccessFile = null;
			FileLock fileLock = null;
			try {
				randomAccessFile = new RandomAccessFile(new File(file_path), "rws");
				fileLock =	randomAccessFile.getChannel().tryLock();
			} catch (FileNotFoundException e1) {
				// TODO AYouTu-generated catch block
			//	e1.printStackTrace();
			}
			 catch (Exception e2) {
			//		e2.printStackTrace();
			}
			if(fileLock==null) {return;}
			
			if(regist_frame==null) {regist_frame = new Regist_frame();}
			regist_frame.set_visiable(true);
		}
		
		else if(e.getSource()==set_button) {
			popupMenu1.show(set_button, 10, -60);
		}
		else if(e.getSource()==history_button) {
			popupMenu2.show(history_button, 10,pop2_height);
		}
		else if(e.getSource()==help_button) {
			if(password_frame==null) {password_frame = new Find_password_frame();}
			password_frame.set_visiable(true);
		}
		
	}
	   
	public static void main(String[] args) {
	
		    new Login_frame();
		
		   System.out.println("Login_frame");
	}
}
