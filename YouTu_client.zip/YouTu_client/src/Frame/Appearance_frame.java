package Frame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import Main_thread.TelnetCheck_thread;
import custom_component.Back_ground_pane;
import custom_component.Beauty_Slider;
import custom_component.Color_Slider;
import custom_component.My_ScrollPane;
import custom_component.My_checkbox;
import custom_component.My_radiobutton;
import custom_component.Roundrec_button;
import message_login_register.Background_Record;
import tool_Frame.Warn_frame;
import tools.BackGround_Tools;

public class Appearance_frame implements ItemListener,ActionListener,ChangeListener{
    
	Only_frame only_frame = null;
	Show_pane main_pane = null;
	
	Beauty_Slider back_slider = null;
	Beauty_Slider white_slider = null;
	Beauty_Slider bright_slider = null;
	
	Color_Slider color_Slider = null;
	Beauty_Slider r_slider = null;
	Beauty_Slider g_slider = null;
	Beauty_Slider b_slider = null;
	
	ButtonGroup buttonGroup = null;
	My_radiobutton image_radiobutton = null;
	My_radiobutton color_radiobutton = null;
	My_checkbox total_imagebutton = null;
	
	Roundrec_button system_button = null;
	Roundrec_button local_button = null;
	Roundrec_button cancle_button = null;
	Roundrec_button confirm_button = null;
	
	boolean image = true;
	String system_Iconpath = null;
	String local_Iconpath = null;
	int r = 0;
	int g = 0;
	int b =0 ;
	int a = 255;
	int bright_value = 125;
	int white_value = 0;
	
	public Appearance_frame() {
		
		Init_components();
		Install_comopnent();
		Init_frame();
		
		Init_slider_listioner();
		Init_button_listioner();
		
	}
	
	public void Init_components() {
		
		Background_Record record = Background_Record.get_record();
				
		main_pane = new Show_pane();
		main_pane.setLayout(null);
		
		main_pane.setOpaque(false);
		main_pane.setPreferredSize(new Dimension(540,900));
		main_pane.setMinimumSize(new Dimension(540,900));
		main_pane.setMaximumSize(new Dimension(540,900));
		
	    image_radiobutton = new My_radiobutton(record.isImage());
		color_radiobutton = new My_radiobutton(!record.isImage());
		total_imagebutton = new My_checkbox(record.isTotal());
		
		buttonGroup = new ButtonGroup();
		buttonGroup.add(image_radiobutton);
		buttonGroup.add(color_radiobutton);
		
	    back_slider = new Beauty_Slider(100, 255, record.getOpatity());
	    back_slider.set_thumb_color(Color.white);
	   	    
	    white_slider = new Beauty_Slider(0, 100,record.getWhite());
	    white_slider.set_thumb_color(Color.white);
	    
	    bright_slider = new Beauty_Slider(0, 255, record.getBriter()+125);
	    bright_slider.set_thumb_color(Color.white);
	    
	    color_Slider = new Color_Slider();
	    
	    r_slider =  new Beauty_Slider(0, 255, record.getR());
	    r_slider.set_thumb_color(Color.red);
	    
	    g_slider =  new Beauty_Slider(0, 255, record.getG());
	    g_slider.set_thumb_color(Color.green);
	    
	    b_slider =  new Beauty_Slider(0, 255, record.getB());
   //   b_slider.set_thumb_color(Color.blue);
	    system_button =  new Roundrec_button(100, 30, 10,new Color(0, 131, 253), "系统背景", 16, Color.white);
	    local_button =  new Roundrec_button(100, 30, 10,new Color(0, 131, 253), "选择本地", 16, Color.white);
	    cancle_button =  new Roundrec_button(80, 30, 10,new Color(0, 131, 253), "取消", 16, Color.white);
	    confirm_button =  new Roundrec_button(80, 30, 10,new Color(0, 131, 253), "保存", 16, Color.white);
	}
	
	public void Install_comopnent() {
		
		image_radiobutton.setBounds(130, 340, 25, 25);
		color_radiobutton.setBounds(270, 340, 25, 25);
		total_imagebutton.setBounds(390,340, 25, 25);
		
		main_pane.add(image_radiobutton);
		main_pane.add(color_radiobutton);
		main_pane.add(total_imagebutton);
		
		back_slider.setBounds(130, 25, 300, 30);
		white_slider.setBounds(130, 70, 300, 30);
		bright_slider.setBounds(130,110, 300, 30);
		
		main_pane.add(back_slider);
		main_pane.add(white_slider);
		main_pane.add(bright_slider);
		
		color_Slider.setBounds(130, 160, 300, 30);
		r_slider.setBounds(130, 200, 300, 30);
		g_slider.setBounds(130, 240, 300, 30);
		b_slider.setBounds(130, 285, 300, 30);
		
		main_pane.add(color_Slider);
		main_pane.add(r_slider);
		main_pane.add(g_slider);
		main_pane.add(b_slider);
		
		system_button.setBounds(30, 400, 100, 30);
		local_button.setBounds(150, 400,100, 30);
		cancle_button.setBounds(260, 400,80, 30);
		confirm_button.setBounds(360, 400,80, 30);
		
		main_pane.add(system_button);
		main_pane.add(local_button);
		main_pane.add(cancle_button);
		main_pane.add(confirm_button);
		
	}
	
	public void Init_frame() {
		
		only_frame = new Only_frame(main_pane,40);
		only_frame.remove_window_Maxbutton(false);
		only_frame.set_Size(true, 460, 515);
	//	only_frame.set_Resizable(false);
		only_frame.set_Title("选择背景", new Font("宋体", Font.BOLD, 18),new Color(0, 131, 245));
		only_frame.setVisible(true);
		
		only_frame.change_quite_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				only_frame.dispose();
				System.gc();							
			}
		});
	}
	
	public void Init_slider_listioner() {
		
		back_slider.addChangeListener(this);
		white_slider.addChangeListener(this);
		bright_slider.addChangeListener(this);
		
		color_Slider.addChangeListener(this);		
		r_slider.addChangeListener(this);
		g_slider.addChangeListener(this);
		b_slider.addChangeListener(this);
		
	}
	public void Init_button_listioner() {
		
		image_radiobutton.addItemListener(this);
		color_radiobutton.addItemListener(this);
		total_imagebutton.addItemListener(this);
		
		system_button.addActionListener(this);
		local_button.addActionListener(this);
		cancle_button.addActionListener(this);
		confirm_button.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
	if(e.getSource()==system_button&&image_radiobutton.isSelected()) {
			FileDialog fileDialog = new FileDialog(only_frame);
		
			system_Iconpath = System.getProperty("user.dir")+"\\systemIcon\\";
			fileDialog.setDirectory(system_Iconpath);
			fileDialog.setVisible(true);
			System.out.println("system_Iconpath=="+system_Iconpath);
		
			String dir = fileDialog.getDirectory();
			String icon_name = fileDialog.getFile();
			
		    if(dir==null||icon_name==null) {return;}	
			if(!icon_name.endsWith("jpg")) {return;}
			
			system_Iconpath = dir+icon_name;
			local_Iconpath = null;
			
			bright_slider.setValue(125);
			bright_value = 125;
			
			ImageIcon background = new ImageIcon(system_Iconpath);
			
			Back_ground_pane.change_external_background(background);
			Back_ground_pane.show_all_image(total_imagebutton.isSelected());
			Main_Frame.update_frame();
			Chat_frame.update_frame();
			only_frame.update_frame();
		}
		
	else if(e.getSource()==local_button&&image_radiobutton.isSelected()) {
			
			FileDialog fileDialog = new FileDialog(only_frame);
			fileDialog.setVisible(true);
			
			String icon_name = fileDialog.getFile();
		
			if(icon_name==null) {return;}			
			if(!icon_name.endsWith("jpg")&&!icon_name.endsWith("png")) {return;}
			
			local_Iconpath = fileDialog.getDirectory()+fileDialog.getFile();
			system_Iconpath = null;
			
			bright_slider.setValue(125);
			bright_value = 125;
			
			BufferedImage bufferedImage = BackGround_Tools.get_back_ground(local_Iconpath);
			ImageIcon background = new ImageIcon(bufferedImage);
			
			Back_ground_pane.change_external_background(background);
			Back_ground_pane.show_all_image(total_imagebutton.isSelected());
			Main_Frame.update_frame();
			Chat_frame.update_frame();
			only_frame.update_frame();
		} // local_button
		
	else if(e.getSource()==cancle_button) {
			
			only_frame.dispose();
		}  // cancle_button
		
   else if(e.getSource()==confirm_button) {
			
    	  Background_Record record =  Background_Record.get_record();
    	 
    	  if(image_radiobutton.isSelected()&&system_Iconpath!=null){
     		 // 加载系统图片
   			ImageIcon background = new ImageIcon(system_Iconpath); 
     		record.setBackground(background);	
     		
     	  }
    	  else if(image_radiobutton.isSelected()&&local_Iconpath!=null){
    		 // 加载本地图片
    		BufferedImage bufferedImage = BackGround_Tools.get_back_ground(local_Iconpath);
  			ImageIcon background = new ImageIcon(bufferedImage);
    		record.setBackground(background);		  
    	  }
    	  
    	  save_generate(record);
    	  only_frame.setVisible(false);
					
		}  // confirm_button
	}
	
	public void save_generate(Background_Record record) {
		
		  record.setImage(image_radiobutton.isSelected());
   	      record.setTotal(total_imagebutton.isSelected());   		
   	   
		  record.setOpatity(back_slider.getValue());
		  record.setWhite(white_slider.getValue());
		  record.setBriter(bright_slider.getValue()-bright_value);
		  
		  record.setR(r_slider.getValue());
		  record.setG(g_slider.getValue());
		  record.setB(b_slider.getValue());
		  
		  Background_Record.write_record(record);
	
		  new Warn_frame("提示", "保存成功！").set_aYouTu_click(2);
	}
	
	@Override
	public void itemStateChanged(ItemEvent e) {
		
		if(e.getSource()==image_radiobutton) {
			
			total_imagebutton.setSelected(true);
			bright_slider.setValue(125);
			
			String Iconpath = new File(System.getProperty("java.class.path")).getParentFile().getAbsolutePath()+"\\systemIcon\\6.jpg";
			ImageIcon imageIcon = new ImageIcon(Iconpath);	
			Back_ground_pane.change_external_background(imageIcon);
			Main_Frame.update_frame();
			Chat_frame.update_frame();
			only_frame.update_frame();
		}
		
		else if(e.getSource()==color_radiobutton) {
		
			system_Iconpath = null;
			local_Iconpath = null;
			
			total_imagebutton.setSelected(true);
			bright_slider.setValue(125);			
			
			Back_ground_pane.set_background_color(back_slider.getValue(),r_slider.getValue(), g_slider.getValue(),b_slider.getValue());
			Main_Frame.update_frame();
			Chat_frame.update_frame();
			only_frame.update_frame();
		}
		
		else if(e.getSource()==total_imagebutton) {
			
			if(total_imagebutton.isSelected()) {
				back_slider.setValue(255);
				white_slider.setValue(0);
			}
			else {
				back_slider.setValue(175);
				white_slider.setValue(100);
			}
			
//			Main_Frame.set_back_Oposity(back_slider.getValue());
//			Chat_frame.set_back_Oposity(back_slider.getValue());
//			
//			Main_Frame.set_white(white_slider.getValue());
//			Chat_frame.set_white(white_slider.getValue());
			
		}  //total_imagebutton
	}
	
	@Override
	public void stateChanged(ChangeEvent e) {
		
			if(e.getSource()==back_slider) {
				Back_ground_pane.set_back_Oposity(back_slider.getValue());				
			}
			
			else if(e.getSource()==white_slider) {
				Back_ground_pane.set_white_value(white_slider.getValue());
				
			}
			
			else if(e.getSource()==bright_slider) {
				if(bright_slider.getValue()>bright_value) {Back_ground_pane.set_brightness(3);}
				else { 
					Back_ground_pane.set_brightness(-3);
				
				}
				      bright_value = bright_slider.getValue();
				}
			
			else if(e.getSource()==color_Slider) {
				
				Color color = color_Slider.get_selected_color();
				int r = color.getRed();
				int g = color.getGreen();
				int b = color.getBlue();
				r_slider.setValue(r);
				g_slider.setValue(g);
				b_slider.setValue(b);
				
			}
			
			else if(color_radiobutton.isSelected()){   // r,g,b slider
				
				Back_ground_pane.set_background_color(back_slider.getValue(),r_slider.getValue(), g_slider.getValue(),b_slider.getValue());				
			}
			Main_Frame.update_frame();
			Chat_frame.update_frame();
			only_frame.update_frame();
	}
	
	private class Show_pane extends JPanel{
		
		public Show_pane() {
			setOpaque(false);
			setPreferredSize(new Dimension(500,1100));
			setMinimumSize(new Dimension(500,1100));
			setMaximumSize(new Dimension(500,1100));
		}
		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
			
		//	g2.setColor(new Color(100,100,100));
			g2.setColor(new Color(0, 131, 245));
			g2.setFont(new Font("宋体", Font.PLAIN, 18));
			
			g2.drawString("图片背景:",40, 360);
			g2.drawString("纯色背景:",180, 360);
			g2.drawString("全景:",330, 360);
			
			g2.drawString("透明度:", 25, 45);
			g2.drawString("淡化:", 25, 90);
			g2.drawString("亮度:", 30, 130);
			g2.drawString("色带:", 30, 180);
			g2.drawString("R(红):", 30, 220);
			g2.drawString("G(绿):", 30, 260);
			g2.drawString("B(蓝):", 30, 300);
		} // paintComponent
	}
	
	public static void main(String[] args) {
		
		FileDialog fileDialog = new FileDialog(new JFrame());
		fileDialog.setDirectory("C:\\ProgramData\\Program Files (x86)\\优兔\\systemIcon");
		fileDialog.setVisible(true);
		
		String path = fileDialog.getDirectory()+fileDialog.getFile();
		System.out.println("path="+path);
	}
}
