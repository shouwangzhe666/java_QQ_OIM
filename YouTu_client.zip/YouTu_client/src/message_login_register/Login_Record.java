package message_login_register;

import java.awt.Color;
import java.awt.Image;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.ImageIcon;

import tools.My_Object_IO;

public class Login_Record implements Serializable{

	private static final long serialVersionUID = 1L;
	
	ImageIcon head_icon = null;
	String name = null;
	String account = null;
	String password = null;	
	
	public Login_Record(ImageIcon head_icon, String name, String account, String password) {
		
		this.head_icon = head_icon;
		this.name = name;
		this.account = account;
		this.password = password;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Image getHead_icon() {
		return head_icon.getImage();
	}



	public void setHead_icon(Image head_icon) {
		this.head_icon = new ImageIcon(head_icon);
	}



	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}

    public static ArrayList<Login_Record> get_all_Login_Record(){
    	
    	ArrayList<Login_Record> all_record = new ArrayList<>();
    	
    	ObjectInputStream objectInputStream = My_Object_IO.get_ObjectInputStream("C:\\ProgramData\\YouTu\\login\\login_history.db");
    	if(objectInputStream==null) {return all_record;}
    	Login_Record record = null;
    	
    	while(true) {
    		
    		try {
				record = (Login_Record) objectInputStream.readObject();
			} catch (ClassNotFoundException e) {
				break;
			} catch (IOException e) {
				break;
			}
    		
    		all_record.add(record);
    		
    	}   // while
    	
    	 try {
			objectInputStream.close();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
    	 
    	 return all_record;
    }
    
    public static ArrayList<Login_Record> set_top_Login_Record(ArrayList<Login_Record> all_record,Login_Record top_record) {
    	
    	 ArrayList<Login_Record> temp_all_record = new ArrayList<>();
    	 temp_all_record.add(top_record);
    	 String top_account = top_record.getAccount();
    	 Login_Record temp_record = null;
    	 
    	 for(int i=0;i<all_record.size();i++) {
    	         
    		 temp_record = all_record.get(i);
    		 if(temp_record.getAccount().equals(top_account)) {continue;}
    		 temp_all_record.add(temp_record);
    	 }
    	
    	return temp_all_record;
    }
    public static void write_all_Login_Record(ArrayList<Login_Record> all_record) {
    	
    	ObjectOutputStream objectOutputStream = My_Object_IO.get_ObjectoutputStream("C:\\ProgramData\\YouTu\\login\\login_history.db", false);
    	
    	 Login_Record login_Record = null;
    	 for(int i=0;i<all_record.size();i++) {
	         
    		 login_Record = all_record.get(i);
    		 try {
				objectOutputStream.writeObject(login_Record);
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
    	 }
    	 
    	try {
			objectOutputStream.close();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
    	return;
    }
}
