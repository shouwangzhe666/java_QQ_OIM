package message_login_register;

public class Register_message {

  int step = 1;
	
	String e_mail = null;
	String password = null;
	
	String verify_code = null;
	
	byte[] head_icon = null;
	String name = null;
	String sex=null;
	String birth=null;
	String blood=null;
	String home=null;
	String phone=null;
//	String e_mail=null;
	String signature=null;
	String state=null;
	
	String account = null;	
	String ip = null;
	int port = 0;
	
	
	public Register_message(int step, String e_mail, String password) {
		getEmail();
		this.step = step;
		this.e_mail = e_mail;
		this.password = password;
	}



	public Register_message(int step, String verify_code) {
		super();
		this.step = step;
		this.verify_code = verify_code;
	}

	public Register_message(int step, byte[] head_icon, String name, String sex, String birth, String blood,
			String home, String phone, String e_mail, String signature, String state) {
		super();
		this.step = step;
		this.head_icon = head_icon;
		this.name = name;
		this.sex = sex;
		this.birth = birth;
		this.blood = blood;
		this.home = home;
		this.phone = phone;
		this.e_mail = e_mail;
		this.signature = signature;
		this.state = state;
	}



	public Register_message(int step, String account, String password, String ip, int port) {
		super();
		this.step = step;
		this.account = account;
		this.password = password;
		this.ip = ip;
		this.port = port;
	}


	public int getStep() {
		return step;
	}



	public String getEmail() {
		return e_mail;
	}



	public String getPassword() {
		return password;
	}



	public String getVerify_code() {
		return verify_code;
	}



	public byte[] getHead_icon() {
		return head_icon;
	}



	public String getName() {
		return name;
	}



	public String getSex() {
		return sex;
	}



	public String getBirth() {
		return birth;
	}



	public String getBlood() {
		return blood;
	}



	public String getHome() {
		return home;
	}



	public String getPhone() {
		return phone;
	}


	public String getSignature() {
		return signature;
	}



	public String getState() {
		return state;
	}



	public String getAccount() {
		return account;
	}



	public String getIp() {
		return ip;
	}



	public int getPort() {
		return port;
	}
}
