package message_login_register;

import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import javax.swing.ImageIcon;
import Frame.Main_Frame;
import custom_component.Back_ground_pane;
import tools.My_Object_IO;

public class Background_Record implements Serializable{

	private static final long serialVersionUID = 1L;

    ImageIcon background = null;
    
    boolean image = true;
    boolean total = true;

    int opatity = 255;
    int white = 0;
    int briter = 0 ;
    		
    int r = 39;
    int g = 176;
    int b = 231;
    
    public Background_Record(boolean image) {
		this.image = image;
	}
   
	public boolean isImage() {
		return image;
	}

	public void setImage(boolean image) {
		this.image = image;
	}

	public boolean isTotal() {
		return total;
	}

	public void setTotal(boolean total) {
		this.total = total;
	}

	public int getOpatity() {
		return opatity;
	}

	public void setOpatity(int opatity) {
		this.opatity = opatity;
	}

	public int getWhite() {
		return white;
	}

	public void setWhite(int white) {
		this.white = white;
	}

	public int getBriter() {
		return briter;
	}

	public void setBriter(int briter) {
		this.briter = briter;
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		this.g = g;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public ImageIcon getBackground() {
		
		if(background==null) {
			ImageIcon imageIcon = new ImageIcon(Back_ground_pane.class.getResource("/background_image/4.jpg"));
			return imageIcon;
		}
		
		return background;
	}
    
	 public void setBackground(ImageIcon background) {
		this.background = background;
	}

	public static void write_record(Background_Record record) {
		 
		 ObjectOutputStream objectOutputStream = My_Object_IO.get_ObjectoutputStream("C:\\ProgramData\\YouTu\\set\\background.db", false);
		
		 try {
			objectOutputStream.writeObject(record);
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		 try {
			objectOutputStream.close();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		 
	 }
	 
    public static Background_Record get_record() {
    	
    	File file = new File("C:\\ProgramData\\YouTu\\set\\background.db");
    	
    	if(!file.exists()||file.length()==0) {return get_default_record();}
    		
    	ObjectInputStream objectInputStream = My_Object_IO.get_ObjectInputStream("C:\\ProgramData\\YouTu\\set\\background.db");
    	Background_Record record = null;
    	
    	if(objectInputStream==null) {return get_default_record();}
    	
    	try {
			 record = (Background_Record) objectInputStream.readObject();
		} catch (ClassNotFoundException e) {
			try {
				objectInputStream.close();
			} catch (IOException e1) {
				// TODO AYouTu-generated catch block
				e1.printStackTrace();
			}
    		return get_default_record();
		} catch (IOException e) {
			try {
				objectInputStream.close();
			} catch (IOException e1) {
				// TODO AYouTu-generated catch block
				e1.printStackTrace();
			}
    		return get_default_record();
		}
    	
    	return record;
    }
    
    public static Background_Record get_default_record() {
    	
    	Background_Record record = new Background_Record(true);
    	ImageIcon imageIcon = new ImageIcon(Back_ground_pane.class.getResource("/background_image/4.jpg"));
		record.setBackground(imageIcon);
		
		return record;
    }
}
