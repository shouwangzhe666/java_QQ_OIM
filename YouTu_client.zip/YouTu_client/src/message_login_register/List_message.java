package message_login_register;

import java.io.Serializable;
import javax.swing.ImageIcon;

public class List_message implements Serializable{

	private static final long serialVersionUID = 1L;
	
	int type =1;
	String link_count = null;
	String group_account = null;
	ImageIcon head_image = null;
	String group_name = null;
	String remark = null;
	String chat_content = null;
	long  system_time = 0l;
	int quantity = 0;
	
	public List_message(int type, String link_count,ImageIcon head_image, String group_name, String remark,
			String chat_content, long system_time, int quantity) {
		
		this.type = type;
		this.link_count = link_count;
		this.head_image = head_image;
		this.group_name = group_name;
		this.remark = remark;
		this.chat_content = chat_content;
		this.system_time = system_time;
		this.quantity = quantity;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	

	public ImageIcon getHead_image() {
		return head_image;
	}

	public void setHead_image(ImageIcon head_image) {
		this.head_image = head_image;
	}

	public String getLink_count() {
		return link_count;
	}

	public void setLink_count(String link_count) {
		this.link_count = link_count;
	}

	public String getGroup_account() {
		return group_account;
	}

	public void setGroup_account(String group_account) {
		this.group_account = group_account;
	}

	public String getGroup_name() {
		return group_name;
	}

	public void setGroup_name(String group_name) {
		this.group_name = group_name;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getChat_content() {
		return chat_content;
	}

	public void setChat_content(String chat_content) {
		this.chat_content = chat_content;
	}

	public long getSystem_time() {
		return system_time;
	}

	public void setSystem_time(long system_time) {
		this.system_time = system_time;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}	
	
}