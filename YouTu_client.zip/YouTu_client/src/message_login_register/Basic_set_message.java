package message_login_register;

// author: jiang quan feng
// date : 2020.01.11

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import com.sun.org.apache.xml.internal.resolver.helpers.PublicId;

import tools.My_Object_IO;

public class Basic_set_message implements Serializable{

	private static final long serialVersionUID = 1L;
	boolean auto_login = false;
	boolean remember = false;
	int send_type = 1;
	String state = "在线";
	
	static Basic_set_message basic_set_message = null;
	
	public Basic_set_message() {
	
	}	 
	
	public boolean isAuto_login() {
		return auto_login;
	}

	public void setAuto_login(boolean auto_login) {
		this.auto_login = auto_login;
	}


	public boolean isRemember() {
		return remember;
	}

	public void setRemember(boolean remember) {
		this.remember = remember;
	}
	
	public int getSend_type() {
		return send_type;
	}

	public void setSend_type(int send_type) {
		this.send_type = send_type;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public static Basic_set_message get_Basic_set_message() {
			
			ObjectInputStream objectInputStream = My_Object_IO.get_ObjectInputStream("C:\\ProgramData\\YouTu\\set\\basic_set.db");
	    	if(objectInputStream==null) {return new Basic_set_message();}
	    	
	    	Basic_set_message set_message = null;
	    	
	    	try {
				set_message = (Basic_set_message) objectInputStream.readObject();
			} catch (ClassNotFoundException e1) {			
				return null;
			} catch (IOException e1) {			
				return null;
			}
	    	
	    	 try {
				objectInputStream.close();
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
	    	
			return set_message;
		}
	
	public static void write_basic_set_message(Basic_set_message set_message) {
		
		ObjectOutputStream objectInputStream = My_Object_IO.get_ObjectoutputStream("C:\\ProgramData\\YouTu\\set\\basic_set.db", false);
    
    	try {
			objectInputStream.writeObject(set_message);
		} catch (IOException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
    	 try {
			objectInputStream.close();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	}	
	
}
