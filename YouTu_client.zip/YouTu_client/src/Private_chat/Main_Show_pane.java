package Private_chat;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

import Frame.Main_Frame;
import Item.Private_Chat_Item;
import Item.File_Item;
import tool_Frame.Icon_show_frame;
import tools.Icon_tools;

public class Main_Show_pane extends JPanel{
	
	 /**
     * all_dataArrayList
     * 
     * type1  图文
     * type2  图片
     * type3  撤销
     * type4  抖动
     * type5  时间
     * type6  文件
     * 
     */
	
	Color oval_color = null;
	int all_y = 0;
	int[]po_x=null;
	int[]po_y=null;
	
	HashMap<Long, Private_Chat_Item> all_chat_item = null;
	
	ArrayList<Object> row_list=null;
	HashMap<Long, ArrayList<Object>> all_dataArrayList=null;
	
	Image self_icon=null;
	Image other_icon=null;
	ImageIcon imageIcon = null;
	
	 SimpleDateFormat dateFormat = null;
	 SimpleDateFormat timeFormat = null;
	 SimpleDateFormat datetimeFormat = null;
	 Font font = null;
	 Private_show_pane private_show_pane = null;
	 
	public Main_Show_pane(Private_show_pane private_show_pane) {
		
		setOpaque(false);
		setLayout(null);
		
		oval_color = new Color(230, 230, 230);
		this.private_show_pane = private_show_pane;
		
		Init_content();
	}
	
	public void Init_content() {
		
		font = new Font("宋体", Font.PLAIN, 12);
		this.all_y = private_show_pane.all_y;
		this.po_x = private_show_pane.po_x;
		this.po_y = private_show_pane.po_y;
		
		this.all_chat_item = private_show_pane.all_chat_item;
		this.all_dataArrayList = private_show_pane.all_dataArrayList;
		
		this.self_icon = private_show_pane.self_icon;
		this.other_icon = private_show_pane.other_icon;
		
		this.dateFormat = private_show_pane.dateFormat;
		this.datetimeFormat = private_show_pane.datetimeFormat;
		this.timeFormat = private_show_pane.timeFormat;
		
	}
	
	public void update_other_head_icon(byte[] icon_bytes) {
		
		this.other_icon = new ImageIcon(icon_bytes).getImage();
		
		repaint();
	}
	
	public void update_self_icon(byte[] icon_bytes) {
		
		this.self_icon = new ImageIcon(icon_bytes).getImage();
		repaint();
	}
	
	@Override
	protected void paintComponent(Graphics g) {		
//		super.paintComponent(g);
	    Graphics2D g2 = (Graphics2D) g;
	    g2.setColor(Color.LIGHT_GRAY);
	    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	    g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
	    
	    update_all();
		
		Set<Long> set = all_dataArrayList.keySet();
		long[] all_key = get_sorted_array(set);
		
	    long key = 0;
	    int type = 1;
	    
		for(int i=0;i<all_key.length;i++) {
			
			key = all_key[i];
		
			row_list = all_dataArrayList.get(key);
		    type = (int) row_list.get(0);
          
           if(type==1||type==2||type==6||type==7) {draw_normal_bubble(g2);}
           else if(type==3||type==4) {draw_oval_bubble(g2);}
           else {draw_time_bubble(g2);}
           
		}// for
}
public void update_all() {
		
		int chat_width = private_show_pane.getWidth();
		
		setSize(chat_width, all_y);
				
		Set<Long> set = all_dataArrayList.keySet();
		long[] all_key = get_sorted_array(set);
		if(all_key.length==0) {return;}

			all_y = 0;
			long key  = 0;
			int type = 1;
			Object object = null;
					
		for(int i=0;i<all_key.length;i++) {
				
				key = all_key[i];
				row_list = all_dataArrayList.get(key);
				type = (int) row_list.get(0);
							
			   if(type==1)	{object = all_chat_item.get(key);update_chat_Item(object);}
			   else if(type==2||type==6||type==7) {object = all_chat_item.get(key);update_Icon_File_Audio_Item(object);}
			   else if(type==3||type==4) {update_oval_Item();}
			   else if(type==5) {update_time_Item();}
				
			}  //for

		  setPreferredSize(new Dimension(getWidth(),all_y));
		  setMinimumSize(new Dimension(getWidth(),all_y));
		  setMaximumSize(new Dimension(getWidth(),all_y));
		   
		}

		public void update_chat_Item(Object object) {
		 
		    Private_Chat_Item private_Chat_Item = (Private_Chat_Item) object;
		    
		    private_Chat_Item.update_Chat_Item(getWidth());
			
		    int x = 0;
			int w=private_Chat_Item.get_total_width();
			int h=private_Chat_Item.get_total_height();
			
			boolean self = (boolean) row_list.get(1);
			if(self) {x = getWidth()-w-55;}
			else {x = 55;}
			
			row_list.set(2, x);
		    row_list.set(3, all_y);
			row_list.set(4, w);
			row_list.set(5, h);
			
			private_Chat_Item.setBounds(x, all_y, w, h);
					
			all_y+=h+25;			
		}

 public void update_Icon_File_Audio_Item(Object object) {
		 
		    Private_Chat_Item private_Chat_Item = (Private_Chat_Item) object;
		    
		    private_Chat_Item.update_Chat_Item(getWidth());
			
		    int x = 0;
			int w=private_Chat_Item.get_total_width()+20;
			int h=private_Chat_Item.get_total_height()+20;
			
			if(private_Chat_Item.get_type()==7) {w -=20; h-=20;}
			
			boolean self = (boolean) row_list.get(1);
			if(self) {x = getWidth()-w-55-20;}
			else {x = 50;}
			
			row_list.set(2, x);
		    row_list.set(3, all_y);
			row_list.set(4, w);
			row_list.set(5, h);
			
			if(self) {private_Chat_Item.setBounds(x+25, all_y+10, w-20, h-20);}
			else {private_Chat_Item.setBounds(x+10, all_y+10, w-20, h-20);}
			
			all_y+=h+25;
			
		}
	
		public void  update_oval_Item() {
		 
		   row_list.set(3, all_y);
		   all_y+=30;
		}

		public void update_time_Item() {
		 
		   all_y+=30;
		   row_list.set(3, all_y-20);
		 
		}
		public void update_file_item(Object object) {
		 
		  File_Item item = (File_Item) object;
		    
		    int x = 0;
			int w = 310;
			int h = 110;
		    
			boolean self = (boolean) row_list.get(0);
			if(self) {x = getWidth()-w-55;}
			else {x = 55;}
			
			row_list.set(2, x);
		    row_list.set(3, all_y);
			row_list.set(4, w);
			row_list.set(5, h);
			
			item.setBounds(x, all_y+5, w, h);
			
			 all_y+=120;

			setPreferredSize(new Dimension(750, all_y));
			setMinimumSize(new Dimension(400, all_y));
		}
		
public void draw_normal_bubble(Graphics2D g2) {
    
   // 适用于除撤回消息以外的其他一切气泡
 
 boolean isself=(boolean) row_list.get(1);
 int y = (int) row_list.get(3);
 int rec_width=(int) row_list.get(4);
 int rec_height=(int) row_list.get(5);
 Color other_color = new Color(230,230,230);
 
if(isself) {
	po_x[0]=po_x[1]=getWidth()-60;po_x[2]=getWidth()-55;
	po_y[0]=y+5;po_y[1]=y+15;po_y[2]=y+10;
	
	g2.setColor(Color.green);
	g2.fillRoundRect(getWidth()-60-rec_width, y, rec_width, rec_height,10,10);
	g2.fillPolygon(po_x, po_y, 3);
	g2.drawImage(self_icon, getWidth()-50, y, null);
	
}

else {
	po_x[0]=45; po_x[1]=po_x[2]=50;
	po_y[0]=y+10;po_y[1]=y+5;po_y[2]=y+15;
	
//	g2.setColor(other_color);
	g2.setColor(Color.white);
	g2.fillRoundRect(50, y, rec_width, rec_height,10,10);
	g2.fillPolygon(po_x, po_y, 3);
	g2.drawImage(other_icon, 5, y, null);
	
}
}

public void draw_oval_bubble(Graphics2D g2) {
 
 String remark = null;
 int type = (int) row_list.get(0);
 boolean self = (boolean) row_list.get(1);
 
 if(type==3) {
   if(self) {remark = "你撤回了一条消息";}
   else  {remark = "对方撤回了一条消息";}
 }
 
 else {
	  if(self) {remark = "你发送一个窗口抖动";}
	  else  {remark = "对方发送一个窗口抖动";}
 }
 
 int string_len = remark.length()*14+10;
 int center_x = (getWidth()-string_len)/2;
 
//   g2.setColor(Color.white);
   g2.setColor(oval_color);
   int y = (int) row_list.get(3);
   g2.fillRoundRect(center_x, y, string_len, 20,10,10);
   
   g2.setColor(Color.BLACK);
   g2.setFont(font);
   g2.drawString(remark, center_x+11, y+14);
  
}

public void draw_time_bubble(Graphics2D g2) {
 
 String remark = null;
 boolean today = (boolean) row_list.get(1);
 long that_time = (long) row_list.get(2);
 int string_len = 0 ;
 
if(today) {
	remark = timeFormat.format(that_time);
	string_len = remark.length()*9;
}
else {
	remark = datetimeFormat.format(that_time);
	string_len = remark.length()*7;
}

 int center_x = (getWidth()-string_len)/2;
 
//   g2.setColor(Color.white);
   g2.setColor(oval_color);
   int y = (int) row_list.get(3);

   g2.fillRoundRect(center_x, y, string_len, 17,10, 10);
   
   g2.setColor(Color.BLACK);
   g2.setFont(font);
   g2.drawString(remark, center_x+10, y+13);
  
}

public void delete_screen() {
	
	 this.all_y = private_show_pane.all_y;
	 all_chat_item = private_show_pane.all_chat_item;
	 all_dataArrayList = private_show_pane.all_dataArrayList;
}

public long[] get_sorted_array(Set<Long> set) {
	
	Iterator<Long> it = set.iterator();
	long value = 0l;
			
	long[] all_int = new long[set.size()];
	
	int i = 0 ;
	while(it.hasNext()) {
		
		value = it.next();
		all_int[i] = value;
		i++;
	}
	
	Arrays.sort(all_int);
	
	return all_int;
}
} //Main_Show_pane

