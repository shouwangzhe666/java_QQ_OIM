package Private_chat;

import java.awt.*; 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.RandomAccessFile;
import java.nio.channels.FileLock;
import java.text.SimpleDateFormat;
import javax.swing.*;

import Frame.Audio_frame;
import Frame.Chat_frame;
import Frame.File_frame;
import Frame.Main_Frame;
import Frame.Wait_frame;
import Item.Face_pane_MenuItem;
import Message.Private.Apply_Message;
import Message.Private.Link_info;
import Message.Private.Private_Chat_Message;
import VA_Pack_UDP.Audio_Chat;
import VA_Pack_UDP.Video_Chat;
import chat_frame_pane.Private_chat_pane;
import custom_component.Box_pane;
import custom_component.Icon_button;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;
import tools.FileUtills;
import tools.Icon_tools;
import tools.Screen_capter;

  public class Tool_Pane extends Box_pane implements ActionListener{
	
	Icon_button face_button=null;
	Icon_button icon_button=null;
	Icon_button file_button=null;
	Icon_button shake_button=null;
	Icon_button capter_button=null;
	Icon_button audio_button=null;
	
	Icon_button vidoChat_button=null;
	Icon_button audioChat_button=null;
	Icon_button constant_button=null;
	
	String native_count = null;
	String link_count = null;
	
	String now= null;
	File file = null;
	String file_path=null;
	JPopupMenu face_pupMenu=null;
	
	Write_pane write_pane = null;
	Dimension dimension = null;
	
	SimpleDateFormat simpleDateFormat = null;
	Cursor cursor = null;
	long time = 0;
	
	 public Tool_Pane(Write_pane write_pane) {
		super(BoxLayout.X_AXIS);
		
		setOpaque(false);
		cursor = new Cursor(Cursor.DEFAULT_CURSOR);
		simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		dimension = Toolkit.getDefaultToolkit().getScreenSize();
		setPreferredSize(new Dimension(400, 35));
		setMinimumSize(new Dimension(400, 35));
		setMaximumSize(new Dimension(dimension.width,35));
		
	  this.write_pane = write_pane;
	  this.native_count = Main_Frame.getNative_count();
	  this.link_count = write_pane.get_link_count();
	  
	    face_pupMenu = new JPopupMenu();
	    face_pupMenu.setOpaque(false);
	    face_pupMenu.add(new Face_pane_MenuItem(face_pupMenu, write_pane));
		
		setBackground(new Color(250, 250, 250));
		setLayout(new FlowLayout(FlowLayout.LEFT));
		
		Init_buttons();
		Install_buttons();
		
		addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				setCursor(cursor);
			};
		});
	 }
	
	 public void Init_buttons() {
		
		    face_button = new Icon_button(getClass().getResource("/tool_image/face.png"),"表情");
			face_button.addActionListener(this);
			
			icon_button = new Icon_button(getClass().getResource("/tool_image/image.png"),"图片");
			icon_button.addActionListener(this);
			
			file_button = new Icon_button(getClass().getResource("/tool_image/file.png"),"文件");
			file_button.addActionListener(this);
			
			shake_button = new Icon_button(getClass().getResource("/tool_image/quake.png"),"抖动");
			shake_button.addActionListener(this);
			
			capter_button = new Icon_button(getClass().getResource("/tool_image/jieping.png"),"截屏");
			capter_button.addActionListener(this);
			
			audio_button = new Icon_button(getClass().getResource("/tool_image/audio.png"),"语音消息");
			audio_button.addActionListener(this);
			
			vidoChat_button = new Icon_button(getClass().getResource("/tool_image/video_chat.png"),"视频通话");
			vidoChat_button.addActionListener(this);
			
			audioChat_button = new Icon_button(getClass().getResource("/tool_image/audio_chat.png"),"语音通话");
			audioChat_button.addActionListener(this);
			
			constant_button = new Icon_button(getClass().getResource("/tool_image/constant.png"),"远程协助");
			constant_button.addActionListener(this);
		
	 }
	 public void Install_buttons() {
		 
		    super.add(face_button);
			
			super.add(Box.createHorizontalStrut(3));
			super.add(icon_button);
			
			super.add(Box.createHorizontalStrut(3));
			super.add(file_button);
			
			super.add(Box.createHorizontalStrut(3));
			super.add(shake_button);
			
			super.add(Box.createHorizontalStrut(3));
			super.add(capter_button);
			
			super.add(Box.createHorizontalStrut(3));
			super.add(audio_button);
			
			super.add(Box.createHorizontalGlue());
			
			super.add(vidoChat_button);
			
			super.add(Box.createHorizontalStrut(3));
			super.add(audioChat_button);
			
			super.add(Box.createHorizontalStrut(3));
			super.add(constant_button);
			super.add(Box.createHorizontalStrut(3));
	 }
	@Override
	public void actionPerformed(ActionEvent e) {
	     
if(e.getSource()==face_button) {face_pupMenu.show(this, 0, -170);}
	
else if(e.getSource()==icon_button) {
		
			FileDialog fileDialog = new FileDialog(new JFrame());
			fileDialog.setDirectory("C:\\ProgramData\\Users\\Administrator\\Pictures");
			fileDialog.setVisible(true);
			
			String file_dir = fileDialog.getDirectory();
			String file_name= fileDialog.getFile();
			
			if(file_dir==null) {return;}
			if(file_name==null) {return;}
			if(!file_name.endsWith("png")&&!file_name.endsWith("gif")&&!file_name.endsWith("jpg")) {
				return;}
			
			    String icon_path = file_dir+file_name;
				
			    byte[] icon_bytes = Icon_tools.get_IconBytes(icon_path);
				write_pane.Insert_icon(icon_bytes);		
		}
else if(e.getSource()==shake_button) {
			
			int from_account = Integer.parseInt(Main_Frame.getNative_count());
			int to_account = Integer.parseInt(link_count);
			
		    Private_Chat_Message chat_Message = new Private_Chat_Message(4, from_account, to_account, System.currentTimeMillis());
		    boolean online =  Main_Frame.getMessage_pane().is_online(String.valueOf(link_count));
			chat_Message.setOnline(online);
			
		    Main_Frame.getMessage_pane().put_accept_message_item(String.valueOf(to_account),chat_Message.getSend_time(),"对方发送窗口抖动");
		    
		    Chat_frame.put_select_Item(String.valueOf(to_account));
			Chat_frame.update_item_content(String.valueOf(to_account), "对方发送窗口抖动");	
			
			Chat_frame.set_visiable(true);
			Chat_frame.shake_frame(false, String.valueOf(to_account));
			    
			Private_chat_pane chat_pane = Chat_frame.get_Private_chat_jpane(to_account);
			chat_pane.shake_Item(chat_Message, true);
			
			Private_Chat_Client.send_message(chat_Message);
		}
		
else if(e.getSource()==capter_button) {
			
			new Screen_capter(write_pane).setVisible(true);		
	}

else {
			
			Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_count);
			String state = link_info.getState();
			if(state.equals("离线")||state.equals("隐身")) {
				new Warn_frame("提示", "对方不在线!").set_aYouTu_click(3);return;}
			
if(e.getSource()==file_button) {
		   
	  if(isSameComputor()) {
		  new Warn_frame("提示", "不允许在同一台计算机上收发文件！").set_aYouTu_click(6);
		  return;
	  }
			FileDialog dialog = new FileDialog(new JFrame(), "文件", FileDialog.LOAD);
			dialog.setVisible(true);
			
			String dir = dialog.getDirectory();
			if(dir==null) {return;}
			
			String file_name = dialog.getFile();
			if(file_name==null) {return;}
			
			String file_path = dir+file_name;
			file = new File(file_path);
			
			if(!File_frame.is_init()) {new File_frame();}
			
			long file_code = System.currentTimeMillis();
			
			Apply_Message apply_Message = get_ApplyMessage(131);
			apply_Message.setFile_code(file_code);
			apply_Message.setFile_name(file_name);
			apply_Message.setFile_size(new File(file_path).length());
			
            File_frame.put_Send_file_pane(apply_Message,file_path);
            
            Private_Chat_Client.send_message(apply_Message);
    		
		}//if
		
else if(e.getSource()==vidoChat_button) {
	Apply_Message apply_Message = get_ApplyMessage(132);
    
    int p2p_type = apply_Message.getP2p_type();
    if(p2p_type==2||p2p_type==3) {new Warn_frame("提示","网络繁忙中！").set_aYouTu_click(5);return;}
    
	if(!Video_Chat.Device_exist()) {new Warn_frame("提示","未检测到摄像头设备\n请检查驱动或是否正确接入！").set_aYouTu_click(10);return;}
	if(Audio_Chat.isVAOccupy()) {new Warn_frame("提示","摄像头设备被其他程序占用，无法使用！").set_aYouTu_click(6);return;}
	else {Audio_Chat.VAOccupy();}
	if(isSameComputor()) {new Warn_frame("提示", "不允许在同一台计算机上视频通话！").set_aYouTu_click(6);return;}
   
    if(!Wait_frame.isInit()) {new Wait_frame();}
    else {Wait_frame.setFrame_visiable(true);}
    
    Private_Chat_Client.send_message(apply_Message);
 }
else if(e.getSource()==audioChat_button) {
    Apply_Message apply_Message = get_ApplyMessage(132);  
    int p2p_type = apply_Message.getP2p_type();
    
    if(p2p_type==2||p2p_type==3) {new Warn_frame("提示","网络繁忙中！").set_aYouTu_click(5);return;}
    
if(!Audio_Chat.Device_exist()) {new Warn_frame("提示","未检测到麦克风设备\n请检查驱动或是否正确接入！").set_aYouTu_click(10);return;}
if(Audio_Chat.isVAOccupy()) {new Warn_frame("提示","麦克风设备被其他程序占用，无法使用！").set_aYouTu_click(6);return;}
else {Audio_Chat.VAOccupy();}
if(isSameComputor()) {new Warn_frame("提示", "不允许在同一台计算机上音频通话！").set_aYouTu_click(6);return;}
   
Private_Chat_Client.send_message(apply_Message);

    if(!Wait_frame.isInit()) {new Wait_frame();}
    else {Wait_frame.setFrame_visiable(true);}
}
else if(e.getSource()==constant_button) {
	if(isSameComputor()) {new Warn_frame("提示", "不允许在同一台计算机上远程桌面！").set_aYouTu_click(6);return;}
	if(Audio_Chat.isVAOccupy()) {new Warn_frame("提示","程序资源被占用，无法使用！").set_aYouTu_click(6);return;}
	else {Audio_Chat.VAOccupy();}
	
	Apply_Message apply_Message = get_ApplyMessage(134);
    Private_Chat_Client.send_message(apply_Message);
  
    if(!Wait_frame.isInit()) {new Wait_frame();}
    else {Wait_frame.setFrame_visiable(true);}
}
else if(e.getSource()==audio_button) {
	if(isSameComputor()) {new Warn_frame("提示", "不允许在同一台计算机上收发语音消息！").set_aYouTu_click(6);return;}
	if(System.currentTimeMillis()-time<3000) {new Warn_frame("提示","操作过于频繁！").set_aYouTu_click(3);return;}
	  
	   time  = System.currentTimeMillis();
	   new Audio_frame(Integer.parseInt(link_count));
}
		}	 
	}  // actionlistion

public boolean isSameComputor() {
	RandomAccessFile randomAccessFile = null;
	FileLock fileLock =	null;
	String file_path = "C:\\ProgramData\\YouTu\\YouTu_"+link_count+"\\list_history\\security.db";
	try {
		randomAccessFile = new RandomAccessFile(new File(file_path), "rws");
		fileLock =	randomAccessFile.getChannel().tryLock();
		
		if(fileLock!=null) {
			fileLock.release();
			randomAccessFile.close();
		}
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	catch (Exception e) {
		e.printStackTrace();
	}
	
	return fileLock==null;
}
public Apply_Message get_ApplyMessage(int Protocal_code) {
	
	String reply_ip = Main_Frame.getMessage_pane().get_link_info(link_count).getRemote_ip();
	String request_ip = Main_Frame.get_NativeIp();
	int p2p_type = reply_ip.endsWith("0000")||request_ip.endsWith("0000")?3:request_ip.equals(reply_ip)?2:1;
	
	System.out.println("reply_ip: "+reply_ip);
	System.out.println("request_ip: "+request_ip);
	System.out.println("p2p_type: "+p2p_type);
	
	int from_account  = Integer.parseInt(Main_Frame.getNative_count());
	int to_account = Integer.parseInt(link_count);
	
	Apply_Message apply_Message = new Apply_Message(Protocal_code, 1, from_account, to_account, p2p_type, 1, 1, 1, true, request_ip, reply_ip);
	return apply_Message;
}
}