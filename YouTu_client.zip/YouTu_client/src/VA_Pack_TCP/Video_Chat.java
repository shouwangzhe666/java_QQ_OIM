package VA_Pack_TCP;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import javax.media.Buffer;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.NoDataSourceException;
import javax.media.NoPlayerException;
import javax.media.Player;
import javax.media.RealizeCompleteEvent;
import javax.media.control.FrameGrabbingControl;
import javax.media.format.VideoFormat;
import javax.media.protocol.DataSource;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import com.sun.image.codec.jpeg.ImageFormatException;
import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageDecoder;
import com.sun.image.codec.jpeg.JPEGImageEncoder;

import VA_Pack_UDP.Audio_Chat;
import tcp_pack.TCP_P2P_Pointer;

import javax.media.util.BufferToImage;

public class Video_Chat extends Thread implements ControllerListener{

	Player player = null;
	FrameGrabbingControl grabbingControl = null;
	volatile Buffer buffer = null;
	BufferToImage bufferToImage = null;
	volatile Image image = null;
	BufferedImage bufferedImage = null;
	Graphics graphics = null;
	JFrame jFrame = null;
	
	Object object = null;
	boolean ready = false;
	
	volatile boolean self = true;
	Component self_pane = null;
	Show_pane other_pane = null;
	DataOutputStream dataOutputStream = null;
	DataInputStream dataInputStream = null;
	int server_port = 0;
	long time = 0l;
	
	Audio_Chat audio_Chat = null;
	
	public Video_Chat(int server_port,Audio_Chat audio_Chat) {
		this.server_port = server_port;
		this.audio_Chat = audio_Chat;
		
		time = System.currentTimeMillis();
		
		jFrame = new JFrame();
		jFrame.setBounds(400, 100, 500, 500);
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jFrame.setVisible(true);
		
		object = new Object();
		other_pane = new Show_pane();
		
	//	jFrame.add(other_pane);
	//	jFrame.update(jFrame.getGraphics());
		jFrame.getContentPane().add(other_pane);
		jFrame.getContentPane().update(jFrame.getContentPane().getGraphics());
		
		Init_comp_listioner(other_pane);
	}
	@Override
	public void run() {
		
		 Init_player();
	//	 Init_net2();
		
		    synchronized (object) {
				  while(!ready) {
					  try {
						object.wait();
					} catch (InterruptedException e) {
						// TODO AYouTu-generated catch block
						e.printStackTrace();
					}
				  }
			}
		    
		    System.out.println(System.currentTimeMillis()-time);		  
		    Init_FrameGrabber();
		    boolean scuess =  Init_net(server_port);
		    
		  if(scuess) {
		    new Sender_thread().start();
		    new Recever_thread().start();
		  }
		  else {
			  System.out.println("视频连接失败");
		  }
	}
	public boolean Init_net(int server_port) {
		
		 TCP_P2P_Pointer p2p_Pointer = new TCP_P2P_Pointer("TCP_Pointer", server_port);
		 p2p_Pointer.start();
		 Socket socket = p2p_Pointer.get_socket(60);
		 if(socket==null) {return false;}
		 
		try {
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
			dataInputStream = new DataInputStream(socket.getInputStream());
		} catch (UnknownHostException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	public void Init_net1() {
		Socket socket;
		try {
			socket = new Socket(InetAddress.getByName("192.168.31.203"),10000);
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
			dataInputStream = new DataInputStream(socket.getInputStream());
		} catch (UnknownHostException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
	}
	public void Init_net2() {
		ServerSocket serverSocket = null;
		Socket socket;
		try {
			serverSocket = new ServerSocket(10000);
			socket = serverSocket.accept();
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
			dataInputStream = new DataInputStream(socket.getInputStream());
		} catch (IOException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
	}
	 public void Init_comp_listioner(Component component) {
		   
		 JPopupMenu popupMenu = new JPopupMenu();
		   
		   JMenuItem change_item = new JMenuItem("切换图像");
		   popupMenu.add(change_item);
		   
		   component.addMouseListener(new MouseAdapter() {
			   @Override
			public void mousePressed(MouseEvent e) {
			       if(e.getButton()==3) {
			    	   popupMenu.show(component, e.getX(), e.getY());
			       }
			}
		});
		 
		   change_item.addMouseListener(new MouseAdapter() {
			   @Override
			public void mousePressed(MouseEvent e) {
				    self = !self;
				    change_pane();
			}
		});
	   }
	 public void change_pane() {
		    
		 jFrame.removeAll();
		 
		  if(self) {	jFrame.add(self_pane);}
		  else {jFrame.add(other_pane);}
		    
		  jFrame.update(jFrame.getGraphics());
	   }

	public void Init_player() {
		
		 DataSource dataSource = null;
	    	
		    while(true){
		    	try {
					 dataSource = Manager.createDataSource(new MediaLocator("vfw://0"));
				} catch (NoDataSourceException e1) {
					 continue;
				//	e1.printStackTrace();
				} catch (IOException e1) {
					continue;
				//	e1.printStackTrace();
				}
		             break;		    	
		}
	 
	    try {
			player = Manager.createPlayer(dataSource);
		} catch (NoPlayerException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		player.addControllerListener(this);
		
		player.realize();
		player.prefetch();
		player.start();
		
	}
	public void Init_FrameGrabber() {
		
		 grabbingControl = (FrameGrabbingControl)player.getControl("javax.media.control.FrameGrabbingControl");
		 
		 while(true) {
	    	 buffer = grabbingControl.grabFrame();// Convert it to an image
			 VideoFormat format = (VideoFormat)buffer.getFormat();
			 if(format!=null) {
	            bufferToImage = new BufferToImage(format);
	            bufferedImage = new BufferedImage(640,480,BufferedImage.TYPE_4BYTE_ABGR);
	            graphics = bufferedImage.getGraphics();
	            
	            break;
              }		
	    }
	}
	public byte[] encode_Image(BufferedImage bufferedImage) {
		
		 ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		 JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(byteArrayOutputStream);
		 try {
			encoder.encode(bufferedImage);
		} catch (ImageFormatException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		 return byteArrayOutputStream.toByteArray();
	}
	public BufferedImage decode_Image(byte[] by) {
		
		ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(by);
		JPEGImageDecoder decoder = JPEGCodec.createJPEGDecoder(byteArrayInputStream);
		BufferedImage bufferedImage=null;
		try {
			bufferedImage = decoder.decodeAsBufferedImage();
		} catch (ImageFormatException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		return bufferedImage;
	}
	@Override
	public void controllerUpdate(ControllerEvent arg0) {
		 if(arg0 instanceof RealizeCompleteEvent) {
				
				if((self_pane=player.getVisualComponent())!=null) {
//					jFrame.getContentPane().add(self_pane);
//					jFrame.update(jFrame.getGraphics());
//					
//					Init_comp_listioner(self_pane);
					
					 synchronized (object) {
					   ready = true;
					   object.notify();
				    }			
		 }}
	}
	private class Show_pane extends JPanel{
		Image bufferedImage = null;
		   
		   public void paint_video(Image bufferedImage) {
			    this.bufferedImage = bufferedImage;
			    repaint();
		   }
		   @Override
		protected void paintComponent(Graphics g) {
			//super.paintComponent(g);
			
			if(bufferedImage!=null) {
				g.drawImage(bufferedImage, 0, 0,getWidth(),getHeight(),null);

			}
 }}
	private class Sender_thread extends Thread{
		
		public Sender_thread() {
		}
		@Override
		public void run() {
			while(true) {
				
				 buffer = grabbingControl.grabFrame();// Convert it to an image
				 image = bufferToImage.createImage(buffer);// show the image
				 graphics.drawImage(image, 0, 0, 640,480,null);
                      
				byte[] by = encode_Image(bufferedImage);
						
				try {
					dataOutputStream.writeInt(by.length);
					dataOutputStream.write(by, 0, by.length);
				} catch (IOException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
					break;
				}			    	
			}
		}
	}
	private class Recever_thread extends Thread{
		
		public Recever_thread() {
			 
		}
		@Override
		public void run() {
			while(true) {				
			
				try {
					int len = dataInputStream.readInt();
					byte[] by = new byte[len];
					dataInputStream.readFully(by, 0, len);
					
					   image = decode_Image(by);
					   other_pane.paint_video(image);
				} catch (IOException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
					break;
				}				
			} // while
			  
		}
	}
	
	public static void main(String[] args) {
		
	//	System.out.println(System.currentTimeMillis()-time);
		 Scanner scanner = new Scanner(System.in);
			
		 System.out.println("server port1: ");
		 int server_port1 = scanner.nextInt();
		 
//		 System.out.println("server port2: ");
//		 int server_port2 = scanner.nextInt();
		 
//		 long time = System.currentTimeMillis();
//		  
//		 TCP_P2P_Pointer p2p_Pointer1 = new TCP_P2P_Pointer("TCP_Pointer", server_port1);
//		 p2p_Pointer1.start();
//		 Socket socket1 = p2p_Pointer1.get_socket(60);
//		 if(socket1!=null) {System.out.println("socket1 scuess");}
		 
//		 TCP_P2P_Pointer p2p_Pointer2 = new TCP_P2P_Pointer("TCP_Pointer", server_port2);
//		 p2p_Pointer2.start();
//		 Socket socket2 = p2p_Pointer2.get_socket(60);
//		 if(socket2!=null) {System.out.println("socket2 scuess");}
		 
		 new Video_Chat(server_port1,null).start();
//		 new Audio_Chat(socket2).start();
		
	}
}
