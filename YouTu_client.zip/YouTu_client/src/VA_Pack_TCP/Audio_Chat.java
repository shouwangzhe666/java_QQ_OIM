package VA_Pack_TCP;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.TargetDataLine;


public class Audio_Chat extends Thread{
	 int audio_port = 0;

	 Socket socket = null;
	 SourceDataLine sourceDataLine = null;
     TargetDataLine targetDataLine = null;
	 AudioFormat format = null;
	 DataLine.Info dataLineInfo  = null;
	 volatile boolean start = true;
	 DataOutputStream dataOutputStream = null;
	 DataInputStream dataInputStream = null;
	 
	public Audio_Chat(Socket socket) {
		
		  Init_net(socket);
	}
	
	@Override
	public void run() {
			  
		//      Init_net2();
			  Init_audio();
			  
			  new Sender_thread().start();
			  new Recever_thread().start();		  
		}
	  
	public void close_session() {
	 	 start = true;
	}
	public void Init_audio() {
		
		format = new AudioFormat(AudioFormat.Encoding.PCM_SIGNED,8000,16,2,4,8000,true);
		dataLineInfo = new DataLine.Info(SourceDataLine.class, format);
		
		try {
			sourceDataLine = AudioSystem.getSourceDataLine(format);
			targetDataLine = AudioSystem.getTargetDataLine(format);
			sourceDataLine.open();
			sourceDataLine.start();
			targetDataLine.open();
			targetDataLine.start();
		} catch (LineUnavailableException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
}
	
public void Init_net(Socket socket) {
	try {
		dataOutputStream = new DataOutputStream(socket.getOutputStream());
		dataInputStream = new DataInputStream(socket.getInputStream());
	} catch (UnknownHostException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
}
	public void Init_net1() {
		Socket socket;
		try {
			socket = new Socket(InetAddress.getByName("192.168.31.203"),10000);
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
			dataInputStream = new DataInputStream(socket.getInputStream());
		} catch (UnknownHostException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
	}
	public void Init_net2() {
		ServerSocket serverSocket = null;
		Socket socket;
		try {
			serverSocket = new ServerSocket(10000);
			socket = serverSocket.accept();
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
			dataInputStream = new DataInputStream(socket.getInputStream());
		} catch (IOException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
	}
	
	  private class Sender_thread extends Thread{
		
		  byte[] by = null;
		  int len = 0;
			 
		  public Sender_thread() {
			     by = new byte[1024];
		}
		  @Override
		public void run() {
			 while(start) {
				 targetDataLine.read(by, 0, 1024);
				 try {
					dataOutputStream.write(by, 0, 1024);
				} catch (IOException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
			 } // while
			 try {
				 dataOutputStream.close();
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
	 }  	// run	  
 }    // Sender_thread
	  
	  private class Recever_thread extends Thread{
		   
		     byte[] by = null;
			 int len = 0;
			 
		     public Recever_thread() {
		    	  by = new byte[1024];
			}
		     
		     @Override
		    public void run() {
		        try {
					while(start) {
						if((len=dataInputStream.read(by))!=-1) {
                           sourceDataLine.write(by, 0, len);
						  }
					}
				} catch (IOException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
		        try {
		        	dataInputStream.close();
				} catch (IOException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
		    }
	  }
	  
	  public static void main(String[] args) {
		 
//		  TCP_P2P_Pointer tcp_P2P_Pointer = new TCP_P2P_Pointer(message, server_port)
//		 new Audio_Chat(1).start();
	}
}
