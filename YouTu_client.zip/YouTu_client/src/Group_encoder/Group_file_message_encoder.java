package Group_encoder;

import java.io.UnsupportedEncodingException;

import Message.Group.Group_file_message;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

public class Group_file_message_encoder extends MessageToByteEncoder<Group_file_message>{

	@Override
	protected void encode(ChannelHandlerContext arg0, Group_file_message file_message, ByteBuf buf) throws Exception {
		 // protocal_code 214
		encode(file_message, buf);
	}

 public void encode(Group_file_message file_message, ByteBuf buf) {
	    byte[] request_ip = null;
	    byte[] reply_ip = null;
	    byte[] file_name = null;
		
		try {
			request_ip = file_message.getRequest_ip().getBytes("UTF-8");
			reply_ip = file_message.getReply_ip().getBytes("UTF-8");
			file_name = file_message.getFile_name().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		buf.writeInt(214);
		buf.writeInt(file_message.getType());
		buf.writeInt(file_message.getRequest_account());
		buf.writeInt(file_message.getReply_account());
		buf.writeLong(file_message.getFile_code());	
		buf.writeLong(file_message.getFile_lenth());
		buf.writeInt(file_message.getTcp_type());
		buf.writeInt(file_message.getServer_port());
		
		buf.writeInt(request_ip.length);
		buf.writeBytes(request_ip);
		buf.writeInt(reply_ip.length);
		buf.writeBytes(reply_ip);
		buf.writeInt(file_name.length);
		buf.writeBytes(file_name);
 }	
}
