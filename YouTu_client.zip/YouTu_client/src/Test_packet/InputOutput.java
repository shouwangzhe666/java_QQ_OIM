package Test_packet;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class InputOutput {

    private static String _fileLocation;
    private static String _fileName;
    private static String _fileDirectory;
    private static String _fileContent;
    private static byte[] _byte;

    /**
     * @return the _fileDirection
     */
    public String get_fileLocation() {
        return _fileLocation;
    }

    /**
     * @return the _fileName
     */
    public String get_fileName() {
        return _fileName;
    }

    /**
     * @return the _fileDirectory
     */
    public String get_fileDirectory() {
        return _fileDirectory;
    }

    /**
     * @return the _fileContents
     */
    public String get_fileContent() {
        return _fileContent;
    }

    /**
     * @return the _byte
     */
    public byte[] get_byte() {
        return _byte;
    }

    /**
     * @param fileDirection
     *            the _fileDirection to set
     */
    private static synchronized void set_fileLocation(String fileLocation) {
        _fileLocation = fileLocation;
    }

    /**
     *
     * @param fileName
     *            the _fileName to set
     */
    private static synchronized void set_fileName(String fileName) {
        _fileName = fileName;
    }

    /**
     *
     * @param fileLocation
     *            the _fileLocation to set
     * @param fileName
     *            the _fileName to set <br>
     * <br>
     *            fileLocation and fileName is the _fileDirectory to set.
     */
    public synchronized void set_fileDirectory(String fileLocation,
            String fileName) {
        set_fileLocation(fileLocation);
        set_fileName(fileName);
        _fileDirectory = fileLocation + fileName;
    }

    /**
     *
     * @param fileDirectory
     *            the _fileDirectory to set <br>
     * <br>
     *            _fileDirectory = _fileLocation + _fileName; <br>
     *            _fileLocation and _fileName will be set automatically in this
     *            method. <br>
     */
    public synchronized void set_fileDirectory(String fileDirectory) {
        set_fileLocation(fileDirectory.substring(0, fileDirectory
                .lastIndexOf("/") + 1));
        set_fileName(fileDirectory
                .substring(fileDirectory.lastIndexOf("/") + 1));
        _fileDirectory = fileDirectory;
    }

    /**
     * @param fileContents
     *            the _fileContents to set
     */
    public synchronized void set_fileContent(String fileContent) {
        _fileContent = fileContent;
    }

    /**
     * @param _byte
     *            the _byte to set
     */
    private synchronized void set_byte(byte[] _byte) {
        InputOutput._byte = _byte;
    }

    public InputOutput() {
        // TODO Auto-generated constructor stub
    }

    /**
     * check if the file is exist or not
     *
     * @param fileDirectory
     *            the _fileDirectory to set, and the directory of the file will
     *            be checked.
     * @return true: file is exist; <br>
     *         false: file is not exist.
     */
    public boolean checkIfFileExist(String fileDirectory) {
        set_fileDirectory(fileDirectory);
        File file = new File(get_fileDirectory());
        // System.out.println("file.exists():" + file.exists());
        return file.exists();
    }

//…………
//……省去的无关方法的代码………
//…………

    /**
     * input get_byte() to get_fileDirectory. If object file is exist, it will
     * be replaced without warning.<br>
     * <br>
     * NOTE: <br>
     * <blockquote> use the set_fileDirectory(), set_byte() and
     * checkIfFileExist(String fileDirectory) methods first <br>
     * to set a righdis.readFully(b)t file directory and file content<br>
     * before using this method; <br>
     * <blockquote>
     */
    public synchronized void DataInputFully() {
        if (get_fileLocation() != null && get_fileName() != null
                && get_fileContent() != null && get_byte() != null) {
            try {
                FileOutputStream fos = new FileOutputStream(get_fileDirectory());
                DataOutputStream dos = new DataOutputStream(fos);
                dos.write(get_byte());
                dos.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("fileLocation:" + get_fileLocation()
                    + "; or fileName:" + get_fileName() + "; or  byte[]:"
                    + get_byte() + " is null.");
        }
    }

    /**
     * input get_byte() to get_fileDirectory. If object file is exist, it will
     * be replaced without warning.<br>
     * <br>
     * NOTE: <br>
     * <blockquote> please use set_fileDirectory() to set the file directory,
     * and use checkIfFileExist(String fileDirectory) first <br>
     * before using this method. <br>
     * </blockquote>
     *
     * @param b
     *            the _byte to set
     */
    public void DataInputFully(byte[] b) {
        set_byte(b);
        DataInputFully();
    }

    /**
     * input get_byte() to get_fileDirectory. If object file is exist, it will
     * be replaced without warning.<br>
     * <br>
     * NOTE: <br>
     * <blockquote> create a file, whose directory as <code>fileDirectory</code>
     * and file content as <code>get_byte()</code>. <br>
     * Use checkIfFileExist(String fileDirectory) first <br>
     * </blockquote>
     *
     * @param fileDirectory
     *            the _fileDirectory to set<br>
     * @param b
     *            the _byte to set, contains the content of file.
     */
    public void DataInputFully(String fileDirectory, byte[] b) {
        set_fileDirectory(fileDirectory);
        set_byte(b);
        DataInputFully();
    }

    /**
     * input get_byte() to get_fileDirectory. If object file is exist, it will
     * be replaced without warning.<br>
     * <br>
     * NOTE: <br>
     * <blockquote> create file named <code>fileName</code> in
     * <code>fileLocation</code> input <code>get_byte()</code> to file named as
     * <code>fileName</code> in <code>fileLocation</code>. <br>
     * Use checkIfFileExist(String fileDirectory) first <br>
     * </blockquote>
     *
     * @param fileLocation
     *            the _fileLocation to set and will be used to set the
     *            _fileDirectory
     * @param fileName
     *            the _fileName to set and will be used to set the
     *            _fileDirectory
     * @param b
     *            the _byte to set and will be write to the file with
     *            _fileDirectory directory. _byte Contains the content of file.
     */
    public void DataInputFully(String fileLocation, String fileName, byte[] b) {
        set_fileDirectory(fileLocation, fileName);
        set_byte(b);
        DataInputFully();
    }
    
    public void DataOutputFully(String fileLocation, String fileName, byte[] b) {
        set_fileDirectory(fileLocation, fileName);
        set_byte(b);
        DataOutputFully();
    }
    
    public byte[] DataOutputFully(String fileLocation, String fileName) {
        set_fileDirectory(fileLocation, fileName);
        return DataOutputFully();
    }
    /**
     * Out put a file by using DataOutputStream class. <br>
     * <br>
     * NOTE:<br>
     * <blockquote>use the set_fileDirectory() method first<br>
     * to set a right file directory<br>
     * before using this method;<br>
     * </blockquote>
     *
     * @return null:if fileDirectory is null; <br>
     *         file content byte[];
     */
    
    public synchronized byte[] DataOutputFully() {
        if (get_fileDirectory() != null) {
            File file = new File(get_fileDirectory());
            if (file.exists()) {
                try {
                    FileInputStream fis;
                    fis = new FileInputStream(get_fileDirectory());
                    DataInputStream dis = new DataInputStream(fis);

                    byte[] b = new byte[dis.available()];
                    while (dis.available() > 0) {
                        dis.readFully(b);
                        // System.out.println("   :" + b.length);
                    }
                    set_byte(b);
                    String tmpStr = "";
                    for (int i = 0; i < b.length; i++) {
                        tmpStr += String.valueOf(b[i]);
                    }
                    set_fileContent(tmpStr);

                    // System.out.println("\n" + get_fileContent() + "\n"
                    // + get_fileLocation() + "\n" + get_fileName());
                } catch (FileNotFoundException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                return get_byte();
            } else {
                System.out.println("fileDirectory:" + get_fileDirectory()
                        + "; and the file is not exist.");
                return null;
            }
        } else {
            System.out.println("fileDirectory:" + get_fileDirectory()
                    + "; is null");
            return null;
        }
    }
    public static void main(String[] args) {
		System.out.println("1111111@qq.com".matches("\\d{6,10}@qq.com"));
	}
}