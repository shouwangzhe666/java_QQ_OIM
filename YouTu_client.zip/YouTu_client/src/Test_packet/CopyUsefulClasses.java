package Test_packet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;

//import InpYouTuutput;

/**
* @author knowyourself1010
*
*/
public class CopyUsefulClasses {
   // 文件拷贝

   private static boolean copy(String sourceFileLocation,
           String objectFileLocation, String fileName) {
       try // must try and catch,otherwise will compile error
       {
           if (sourceFileLocation.substring(sourceFileLocation.length() - 1) != "/") {
               sourceFileLocation += "/";
           }
           if ((objectFileLocation.substring(objectFileLocation.length() - 1)) != "/") {
               objectFileLocation += "/";
           }
           InputOutput inpYouTuutput = new InputOutput();
           byte[] b = inpYouTuutput
                   .DataOutputFully(sourceFileLocation, fileName);
           inpYouTuutput.DataInputFully(objectFileLocation, fileName, b);
           return true; // if success then return true

       } catch (Exception e) {
           System.out.println("Error!");
           return false; // if fail then return false
       }
   }

   // 读取路径,copy
   private static int dealClass(String needfile, String sdir, String odir)
           throws IOException {
       int sn = 0; // 成功个数
       if (odir.length() > 0 && sdir.length() > 0) {

           if ((sdir.substring(sdir.length() - 1)) != "/") {
               sdir += "/";
           }
           if (odir.substring(odir.length() - 1) != "/") {
               odir += "/";
           }
           File usedclass = new File(needfile);
           if (usedclass.canRead()) {
               String line = null;
               LineNumberReader reader = new LineNumberReader(
                       new InputStreamReader(new FileInputStream(usedclass),
                               "UTF-8"));
               while ((line = reader.readLine()) != null) {
                   line = line.trim();
                   if (line.contains(".") || line.contains("/")) {
                       // format the direction from package name to path
                       String dir = line.replace(".", "/");
                       // filter the file name.
                       String tmpdir = dir.substring(0, dir.lastIndexOf("/"));
                       String sourceFileLocation = sdir + tmpdir;
                       String objectFileLocation = odir + tmpdir;
                       String fileName = dir.substring(
                               dir.lastIndexOf("/") + 1, dir.length())
                               + ".class";
                       File fdir = new File(objectFileLocation);
                       if (!fdir.exists())
                           fdir.mkdirs();
                       boolean copy_ok = copy(sourceFileLocation,
                               objectFileLocation, fileName);
                       if (copy_ok)
                           sn++;
                       else {
                           System.out.println(line);
                       }
                   } else {
                       sn = -1;
                   }
               }
           }
       }
       return sn;
   }

   /**
    * @param args
    */
   public static void main(String[] args) {
       // TODO AYouTu-generated method stub
       try {
//           BufferedReader lineOfText = null;
//           // get need classes log file direction
//           System.out
//                   .println("要读取的class.txt文件的绝对路径  :");
//           lineOfText = new BufferedReader(new InputStreamReader(System.in));
//           String needfile = lineOfText.readLine();
//           // get source folder direction
//           System.out
//                   .println(needfile
//                           + "\n输入jre/lib/rt.jar解压後的rt文件夹所在的路径 :");
//           lineOfText = new BufferedReader(new InputStreamReader(System.in));
//           String sdir = lineOfText.readLine();
//
//           // get object folder direction
//           System.out
//                   .println(sdir
//                           + "\n再输入ort(所要存放拷贝过来的有用的.class文件的文件夹):");
//           lineOfText = new BufferedReader(new InputStreamReader(System.in));
//           String odir = lineOfText.readLine();
//           System.out.println(odir + "\n");
    	   String needfile = "D:\\桌面\\优兔\\class.txt";
    	   String sdir = "D:\\桌面\\优兔\\rt";
    	   String odir = "D:\\桌面\\优兔\\ort";
    	   
           int sn = dealClass(needfile, sdir, odir);
           System.out.print(sn);
       } catch (IOException e) {
           // TODO 自动生成 catch 块
           e.printStackTrace();
       }
   }
   
}