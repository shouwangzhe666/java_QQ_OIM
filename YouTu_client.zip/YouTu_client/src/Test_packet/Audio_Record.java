package Test_packet;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import java.io.IOException;

import javax.media.DataSink;

import javax.media.Manager;

import javax.media.MediaLocator;
import javax.media.NoDataSourceException;
import javax.media.Processor;
import javax.media.control.TrackControl;
import javax.media.format.AudioFormat;
import javax.media.format.VideoFormat;

import javax.media.protocol.DataSource;
import javax.media.protocol.FileTypeDescriptor;
import javax.media.protocol.SourceCloneable;
import javax.swing.JButton;
import javax.swing.JFrame;

import com.sun.glass.ui.Pixels.Format;

import jmapps.util.StateHelper;

public class Audio_Record extends JFrame {

	int i=0;
	boolean start=false;
	boolean stop=false;
	JButton jButton=null;
	DataSink sink = null;
	File file=null;
	DataSource ds = null;
	
	SourceCloneable clonsourse=null;
	DataSource dataSource=null;
	
	Processor p = null;

	public Audio_Record() {
		
		 setTitle("Video_accept");  
         setBounds(200, 100, 300, 300);  
      
         setDefaultCloseOperation(DISPOSE_ON_CLOSE);  
		 jButton = new JButton("开始录制");
		
		 getContentPane().add(jButton);
		
		
	
		MediaLocator audioLocator = new MediaLocator("javasound://44100");
		
	  try {
		dataSource=Manager.createDataSource(audioLocator);
	} catch (NoDataSourceException e3) {
		// TODO AYouTu-generated catch block
		e3.printStackTrace();
	} catch (IOException e3) {
		// TODO AYouTu-generated catch block
		e3.printStackTrace();
	}
	  
//	  clonsourse= (SourceCloneable) Manager.createCloneableDataSource(dataSource);
//	    dataSource=(DataSource)clonsourse.createClone();
	  
					try {

						p = Manager.createProcessor(dataSource);

					} catch (Exception e1) {

						e1.printStackTrace();

					}

					p.configure();
					
					while(p.getState()<p.Configured) {
						p.configure();
					}
					
					//VideoFormat vf = new VideoFormat(VideoFormat.);

					// AudioFormat vf = new AudioFormat(AudioFormat.IMA4);
                     
					TrackControl[] trackControls = p.getTrackControls();
					for(int i=0;i<trackControls.length;i++) {
						
						javax.media.Format[] formats=trackControls[i].getSupportedFormats();
						if(formats.length>0) {trackControls[i].setEnabled(true);trackControls[i].setFormat(formats[0]);}
						else {trackControls[i].setEnabled(false);}
					}
					
					p.setContentDescriptor(new FileTypeDescriptor(
							FileTypeDescriptor.WAVE));
				
					p.realize();
					while(p.getState()<p.Realized) {
						p.realize();
					}
				
		
		jButton.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO AYouTu-generated method stub
				super.mousePressed(e);
				
				i++;
				
				stop=false;
				
				file = new File("C:\\ProgramData\\Users\\Administrator\\Desktop\\video"+i+".wave");
				
				if(!file.exists()) {
					try {

						file.createNewFile();

					} catch (IOException e1) {

						e1.printStackTrace();

					}
					}

			
			     sink=null;
				try {

					sink = Manager.createDataSink(p.getDataOutput(), new MediaLocator(
							file.toURI().toURL()));

				} catch (Exception e1) {

					e1.printStackTrace();

				}
				
				
					p.start();
                   
					
					try {
						sink.open();
					} catch (SecurityException e1) {
						// TODO AYouTu-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO AYouTu-generated catch block
						e1.printStackTrace();
					}

					try {
						sink.start();
					} catch (IOException e1) {
						// TODO AYouTu-generated catch block
						e1.printStackTrace();
					}
                
					
					
					new Thread(
							new Runnable() {
								
								@Override
								public void run() {
								
									int a=0;
									while(true) {
										
										if(stop) {break;}
										try {
											Thread.sleep(1000);
										} catch (InterruptedException e) {
											// TODO AYouTu-generated catch block
											e.printStackTrace();
										}
										
										a++;
										
										Audio_Record.this.setTitle(a+"s");
									}
									
								}
							}
							).start();
					
			}
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO AYouTu-generated method stub
				super.mouseReleased(e);
				
				stop=true;
				Audio_Record.this.setTitle("0 s");
				
				try {
                 
				   p.stop();
                   p.close();
                  // p.deallocate();
					
                   sink.stop();
					sink.close();

				} catch (Exception e1) {

					e1.printStackTrace();

				}
			    
				p=null;
				
			   // dataSource=clonsourse.createClone();
				  try {
						dataSource=Manager.createDataSource(audioLocator);
					} catch (NoDataSourceException e3) {
						// TODO AYouTu-generated catch block
						e3.printStackTrace();
					} catch (IOException e3) {
						// TODO AYouTu-generated catch block
						e3.printStackTrace();
					}
							try {
						
								p = Manager.createProcessor(dataSource);

							} catch (Exception e1) {

								e1.printStackTrace();

							}

						
							p.configure();
							
							while(p.getState()<p.Configured) {
								p.configure();
							}
							//VideoFormat vf = new VideoFormat(VideoFormat.);

							// AudioFormat vf = new AudioFormat(AudioFormat.IMA4);

							TrackControl[] trackControls = p.getTrackControls();
							
							for(int i=0;i<trackControls.length;i++) {
								
								javax.media.Format[] formats=trackControls[i].getSupportedFormats();
								if(formats.length>0) {trackControls[i].setEnabled(true);trackControls[i].setFormat(formats[0]);}
								else {trackControls[i].setEnabled(false);}
							}
							
							p.setContentDescriptor(new FileTypeDescriptor(
									FileTypeDescriptor.WAVE));
							while(p.getState()<p.Realized) {
								p.realize();
							}
			}
		});
		
		
	}
	
}
