package Test_packet;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;

import javax.swing.filechooser.FileSystemView;

public class File_Transfer_Test extends Thread{

	File file = null;
	RandomAccessFile randomAccessFile = null;
	FileChannel fileChannel = null;
	FileLock fileLock = null;
	
	File out_file = null;
	RandomAccessFile out_AccessFile = null;
	FileChannel out_channel = null;
	byte[] by = null;
	ByteBuffer buffer = null;
	int len = 0;
	long pro = 0l;
	long file_size;
	
	public File_Transfer_Test(String in_path,String out_path,long file_size) {
	   
		  this.file_size = file_size;
		  by = new byte[1024];
		  buffer = ByteBuffer.allocate(1024);
		  
	      file = new File(in_path);
	      try {
			randomAccessFile = new RandomAccessFile(file, "rw");
		} catch (FileNotFoundException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
	      fileChannel = randomAccessFile.getChannel();
	      
	  //    long l = System.currentTimeMillis();
	      out_file = new File(out_path);
	      if(!out_file.exists()) {try {
			out_file.createNewFile();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}}
	     
	      try {
	    	  out_AccessFile = new RandomAccessFile(out_file, "rw");
		} catch (FileNotFoundException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	         out_channel = out_AccessFile.getChannel();
	}
	

	@Override
	public void run() {
		try {
			while(pro<file_size) {
				
				len=randomAccessFile.read(by);
				if(len<1) {
					try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
					continue;
				}
				pro+=len;
				out_AccessFile.write(by, 0, len);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		try {
			randomAccessFile.close();
			out_AccessFile.close();
			System.out.println("over!");
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		
		String s1 = "D:\\Users\\Administrator\\Desktop\\a.mp4";
		String s2 = "D:\\Users\\Administrator\\Desktop\\b.mp4";
		String s3 = "D:\\Users\\Administrator\\Desktop\\c.mp4";
		String s4 = "D:\\Users\\Administrator\\Desktop\\d.mp4";
		String s5 = "D:\\Users\\Administrator\\Desktop\\e.mp4";
		// 第一种：压力全部转移到s2
		// 第二种：压力平摊给s2,s3,s4,s5 (最佳)
		
		new File_Transfer_Test(s1, s2,6908858).start();
		new File_Transfer_Test(s2, s3,6908858).start();
		new File_Transfer_Test(s2, s4,6908858).start();
		new File_Transfer_Test(s2, s5,6908858).start();
		
		FileSystemView fsv = FileSystemView.getFileSystemView();
		File com=fsv.getHomeDirectory();   
		System.out.println(com.getPath()); //这便是桌面的具体路径
	}
}
