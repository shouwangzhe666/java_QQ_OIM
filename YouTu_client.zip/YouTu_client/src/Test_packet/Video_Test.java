package Test_packet;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Vector;

import javax.media.CannotRealizeException;
import javax.media.CaptureDeviceInfo;
import javax.media.Controller;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.IncompatibleSourceException;
import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.NoDataSourceException;
import javax.media.NoPlayerException;
import javax.media.Player;
import javax.media.protocol.DataSource;
import javax.swing.JFrame;
import javax.swing.JPanel;

import com.sun.org.apache.xerces.internal.util.SynchronizedSymbolTable;
import com.sun.xml.internal.ws.api.Component;

import javafx.print.Printer.MarginType;
import sun.net.www.content.image.jpeg;

public class Video_Test extends JFrame implements ControllerListener{

	DataSource dataSource=null;
	JPanel jPanel=null;
	Player player=null;
	
	public Video_Test() throws NoDataSourceException, IOException {
		
		 setTitle("Video_accept");  
         setBounds(200, 100, 1500, 800);  
      
         setDefaultCloseOperation(EXIT_ON_CLOSE);  
        
         
         MediaLocator mediaLocator = new MediaLocator("vfw://0");
         MediaLocator audioLocator = new MediaLocator("javasound://44100");
         
         DataSource vDataSource=null;
          try {
			vDataSource=Manager.createDataSource(mediaLocator);
		} catch (NoDataSourceException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
          
          if(vDataSource==null) {System.err.print("获取摄像头失败");}
          
          DataSource aDataSource=null;
          try {
        	  aDataSource=Manager.createDataSource(audioLocator);
		} catch (NoDataSourceException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
          
          if(aDataSource==null) {System.err.print("获取麦克风失败");}
          
//          DataSource[] dataSources=new DataSource[2] ;
//          dataSources[0]=vDataSource;
//          dataSources[1]=aDataSource;
//          
//          
//         try {
//			dataSource = Manager.createMergingDataSource(dataSources);
//		} catch (IncompatibleSourceException e) {
//			// TODO AYouTu-generated catch block
//			e.printStackTrace();
//		}
         
     //    dataSource=vDataSource;
         
         try {
			player=Manager.createPlayer(vDataSource);
		} catch (NoPlayerException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
         
          Player player1=null;
          try {
        	  player1=Manager.createPlayer(aDataSource);
  		} catch (NoPlayerException e) {
  			// TODO AYouTu-generated catch block
  			e.printStackTrace();
  		} catch (IOException e) {
  			// TODO AYouTu-generated catch block
  			e.printStackTrace();
  		}
          
         player.addControllerListener(this);
         player.realize();
         while(player.getState()<Controller.Realized) {
        	 player.realize();
         }
         
         player.start();
         
         player1.addControllerListener(this);
         player1.realize();
         while(player1.getState()<Controller.Realized) {
        	 player1.realize();
         }
         player1.start();
         
	}

	@Override
	public void controllerUpdate(ControllerEvent arg0) {
	
		if(arg0 instanceof javax.media.RealizeCompleteEvent) {
			
			java.awt.Component component=null;
			
			if((component=player.getVisualComponent())!=null) {
				
				add(component);
				this.setExtendedState(JFrame.MAXIMIZED_BOTH);
				this.setExtendedState(JFrame.NORMAL);
				this.setVisible(true);
			}
		}		
	}		
}
