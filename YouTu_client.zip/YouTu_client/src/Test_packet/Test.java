package Test_packet;

import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class Test {

	public static void main(String[] args) {
		
		ScheduledThreadPoolExecutor  executor = new ScheduledThreadPoolExecutor(1);
		executor.scheduleAtFixedRate(new Runnable() {
			
			@Override
			public void run() {
				
				System.out.println("2");
			}
		}, 0, 1, TimeUnit.SECONDS);
		
//		executor.schedule(new Runnable() {
//			
//			@Override
//			public void run() {
//				
//				System.out.println("1");
//			}
//		}, 1, TimeUnit.SECONDS);
	}
}
