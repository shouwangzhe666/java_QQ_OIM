package Item;

import javax.swing.ImageIcon;

public interface W_pane {
	
	public void Insert_face(ImageIcon face);
	public void Insert_icon(byte[] icon_bytes);
	
}
