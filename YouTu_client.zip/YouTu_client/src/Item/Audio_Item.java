package Item;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import Frame.Main_Frame;
import Main_frame_Item.Main_JMenuItem;
import Message.Private.Private_Chat_Message;
import Private_chat.Private_show_pane;
import ss.Private_Chat_Client;
import tools.Audio_Tools;

public class Audio_Item extends JPanel{
	
	int link_account = 0;
	long time_code = 0;
	int time_len = 0;
	int pro=0;
	String path=null;
	Image image1=new ImageIcon("tool_image/audio4.png").getImage();
	Image image2=new ImageIcon("123.png").getImage();
	boolean file_exit = true;
	boolean self  = false;
	volatile boolean shan = false;
	volatile boolean start = false;
	
	Font font = null;
	Private_show_pane show_pane = null;
	JPopupMenu popupMenu = null;
	Main_JMenuItem remove_item = null;
    Audio_Tools audio_Tools = null;
	
	public Audio_Item(Private_Chat_Message chat_message,Private_show_pane show_pane) {
        
		this.time_code = chat_message.getSend_time();
		this.show_pane = show_pane;
		this.self = Integer.parseInt(Main_Frame.getNative_count())==chat_message.getFrom_account()?true:false;
		this.link_account = self?chat_message.getTo_account():chat_message.getFrom_account();
		pro=this.time_len=chat_message.getTime_lenth();
		this.path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\chat_history\\private_chat\\audio\\"+link_account+"\\"+time_code+".wav";
		this.file_exit = new File(path).exists();

		font = new Font("宋体", Font.PLAIN, 16);
		audio_Tools = new Audio_Tools(link_account, time_code);
		
        setOpaque(false);
		setPreferredSize(new Dimension(150, 40));
		setMinimumSize(new Dimension(150, 40));
		setMaximumSize(new Dimension(150, 40));	
		
		Init_pane_listioner();
		if(self) {Init_popListioner();}
	}
	public void Init_pane_listioner() {
        this.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mousePressed(MouseEvent e) {
			
			if(!file_exit) {return;}
			
		if(e.getButton()==1) {		
			start = !start;
			
			if(start) {
				audio_Tools.start_playSound();
				new Control_thread().start();
		  	}//if			
		   else {
			   audio_Tools.stop_playSound();
			   pro = time_len;
			   shan = false;
		   }
			repaint();
			} // if(e.getButton()==1) 
		else if(e.getButton()==3) {		
			 if(popupMenu!=null) {popupMenu.show(Audio_Item.this,e.getX(),e.getY());}
		}	// if(e.getButton()==3)
			}  // mouse press			
		});		
	
	}
	public void Init_popListioner() {
		popupMenu = new JPopupMenu();
		remove_item = new Main_JMenuItem("撤销", null);

		popupMenu.add(remove_item);
		remove_item.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {			
				int from_account = Integer.parseInt(Main_Frame.getNative_count());
				
				Private_Chat_Message chat_Message = new Private_Chat_Message(3,from_account,link_account, time_code);
				Private_Chat_Client.send_message(chat_Message);
				
				try {
					show_pane.remove_Item(chat_Message, true);
				} catch (IOException e1) {
					// TODO AYouTu-generated catch block
					e1.printStackTrace();
				}
			}
		});		
	}
	@Override
	protected void paintComponent(Graphics g) {	
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		g2.setColor(Color.BLUE);
		g2.setFont(font);
		
		if(!file_exit) {g2.drawString("语音已不存在",50, 35);return;}
		
		if(!shan) {	g2.drawString("语音消息   "+pro+"s",10,15);}
	}

	private class Control_thread extends Thread{
		int temp = 0;
		
		@Override
		public void run() {
						
		     while(((temp++)/2<time_len)&&start) {

		    	 pro = temp/2;
		    	 shan = !shan;
		    	 repaint();
		    	
		    	 try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
		     } // while
		     
		      start = false;
	   }
	}	
}
