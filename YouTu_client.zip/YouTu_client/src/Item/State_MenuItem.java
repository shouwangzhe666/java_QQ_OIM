package Item;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import Frame.Main_Frame;
import Message.Private.Link_set;
import message_login_register.Basic_set_message;
import ss.Private_Chat_Client;

public class State_MenuItem extends JMenuItem implements ActionListener{

	String state = null;
	boolean selected = false;
	boolean enter = false;
	
	int x = 0;
	Font font = null;
	Color enter_color = null;
	Image image  = null;
	
	public State_MenuItem(String state,boolean selected) {		
		setOpaque(false);
		setBorderPainted(false);
		setBorder(null);
		     	
		this.state = state;
		this.selected = selected;		
		this.image = new ImageIcon(getClass().getResource("/tool_image/right.png")).getImage();
		
		font = new Font("宋体", Font.PLAIN, 14);
		enter_color = new Color(238, 238, 238);
		
		setPreferredSize(new Dimension(100, 30));
		setMinimumSize(new Dimension(100,30));
		setMaximumSize(new Dimension(100, 30));
		
	     Init_listioner();
	}
	public void Init_listioner() {
		 
    	addMouseListener(new MouseAdapter() {
    		@Override
    		public void mouseEntered(MouseEvent e) {
    			enter = true;
    			repaint();
    		}
    		@Override
    		public void mouseExited(MouseEvent e) {
    			enter = false;
    			repaint();
    		}
		});
    	
    	addActionListener(this);
    }
 
@Override
protected void paintComponent(Graphics g) {

	super.paintComponent(g);
	Graphics2D g2 = (Graphics2D) g;
	
	if(enter) {g2.setColor(enter_color);}
	else {g2.setColor(Color.white);}
	
		g2.fillRect(0, 0, 160, 30);
					
	
	if(selected) {g2.drawImage(image, 5,5, null);}
	
	g2.setFont(font);
	g2.setColor(Color.black);
	g2.drawString(state,45, 20);
	
}
@Override
public void actionPerformed(ActionEvent e) {
	
	Main_Frame.set_state(state);
	Basic_set_message set_message =  Basic_set_message.get_Basic_set_message();
	set_message.setState(state);
	Basic_set_message.write_basic_set_message(set_message);
	 
	Link_set link_set = new Link_set(8);
	link_set.setNative_count(Main_Frame.getNative_count());
	link_set.setState(state);
	link_set.setRmeote_ip(Main_Frame.get_NativeIp());
	
	Private_Chat_Client.send_message(link_set);
	
}
}
