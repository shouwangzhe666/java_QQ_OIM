package Item;

import java.awt.BasicStroke;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseMotionListener;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.File;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import tool_Frame.Warn_frame;
import tools.FileUtills;
public class File_Item extends JPanel{
     
	String file_path=null;
	
	Image image=null;
	File file=null;
	File file_dir=null;
	JLabel file_label=null;
	JLabel file_len=null;
	JLabel open_label=null;
	JLabel dir_label=null;
    Cursor cursor=null;
	
	public File_Item(String file_path) {
		setLayout(null);
		setPreferredSize(new Dimension(300, 100));
		setMinimumSize(new Dimension(300, 100));
		setMaximumSize(new Dimension(300, 100));	
		setBackground(Color.white);
		
		this.file_path=file_path;
	
		file = new File(file_path);
		file_dir = file.getParentFile();
		
		cursor = new Cursor(Cursor.DEFAULT_CURSOR);
		
		this.image= new ImageIcon("tool_image/file_over.png").getImage();
		
	int name_len=file.getName().length();
	
	if(name_len<20) {
		
		file_label = new JLabel(file.getName());
		file_label.setFont(new Font("宋体", Font.PLAIN, 16));
		file_label.setBounds(80, 5, name_len*15, 16);
	}
	
	else {
		String name_b=file.getName().substring(0, 11);
		String name_o=file.getName().substring(name_len-10);
		file_label = new JLabel(name_b+"...."+name_o);
		file_label.setBounds(80, 5, 20*15, 16);
	}
      add(file_label);
	
    
	String len = FileUtills.file_size_format(file.length());
	file_len = new JLabel("("+len+")");
	file_len.setFont(new Font("宋体", Font.PLAIN, 16));
	file_len.setBounds( 240, 5, (len.length()+2)*15, 16);
	add(file_len);
	
	open_label = new JLabel("打开");
//	open_label.setForeground(new Color(18, 131, 245));
	open_label.setFont(new Font("宋体", Font.PLAIN, 16));
	open_label.setBounds(150, 70, 35, 16);
    add(open_label);
	
	dir_label = new JLabel("打开文件夹");
//	dir_label.setForeground(new Color(18, 131, 245));
	dir_label.setFont(new Font("宋体", Font.PLAIN, 16));
	dir_label.setBounds(200, 70, 80, 16);
	add(dir_label);
	
	JLabel jl =null;
	
		
	jl = new JLabel("成功发送");
	
	
	jl.setBounds(100,40, 100, 16);
	jl.setFont(new Font("宋体", Font.PLAIN, 16));
	add(jl);		
    
	this.addMouseListener(new MouseAdapter() {
		
		@Override
		public void mouseEntered(MouseEvent e) {
			
			File_Item.this.setCursor(cursor);
		
		}
	});
	
	open_label.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseEntered(MouseEvent e) {
			open_label.setForeground(Color.red);
		}
		
		@Override
		public void mouseExited(MouseEvent e) {
			open_label.setForeground(Color.black);
		}
		
		@Override
		public void mousePressed(MouseEvent e) {
			
			if(!file.exists()) {
				new Warn_frame("提示", "文件可能被移动或删除").set_aYouTu_click(3);
				return;
			}
			
			try {
				Desktop.getDesktop().open(file);
			} catch (IOException e1) {
				// TODO AYouTu-generated catch block
				e1.printStackTrace();
			}
		}
		
	
	});
	
	dir_label.addMouseListener(new MouseAdapter() {
		
		@Override
		public void mouseEntered(MouseEvent e) {
			dir_label.setForeground(Color.red);
		}
		
		@Override
		public void mouseExited(MouseEvent e) {
			dir_label.setForeground(Color.black);
		}
		
		
		@Override
		public void mousePressed(MouseEvent e) {
		
			if(!file_dir.exists()) {
				new Warn_frame("提示", "文件夹可能被移动或删除").set_aYouTu_click(3);
				return;
			}
		
			try {
				Desktop.getDesktop().open(file.getParentFile());
			} catch (IOException e1) {
				// TODO AYouTu-generated catch block
				e1.printStackTrace();
			}
		}
		
	
	});
		}
	
	@Override
	protected void paintComponent(Graphics g) {
		
		Graphics2D g2 = (Graphics2D) g;
	//	g2.setColor(Color.WHITE);
		g2.setColor(Color.LIGHT_GRAY);
		g2.fillRect(0, 0, 300, 100);
		
	//	g2.setColor(new Color(18, 131, 245));
		g2.setStroke(new BasicStroke(2));
		g2.drawImage(image, 5, 5, null);
		
		g2.setColor(Color.black);
		g.drawLine(0, 65, 300, 65);
	}
	
	
	public String get_file_path() {

		return this.file_path;
}

	
}