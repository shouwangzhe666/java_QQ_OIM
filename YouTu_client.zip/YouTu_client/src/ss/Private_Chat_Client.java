package ss;

// author: jiang quan feng
// date : 2020.01.11

import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
import io.netty.handler.codec.LengthFieldPrepender;
import io.netty.handler.ssl.SslHandler;
import io.netty.handler.timeout.IdleStateHandler;
import io.netty.util.ReferenceCountUtil;
import io.netty.util.ReferenceCounted;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import message_login_register.Ping_Pong;
import private_decoder_pack.*;
import private_encoder_pack.*;
import sun.awt.DesktopBrowse;
import tool_Frame.Warn_frame;
import tools.FileUtills;
import tools.Icon_tools;
import tools.SslContextFactory;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLEngine;
import Frame.Login_frame;
import Frame.Main_Frame;
import Group_decoder.Group_search_decoder;
import Group_encoder.Group_search_encoder;
import Group_handle.Group_search_handle;
import Main_thread.TelnetCheck_thread;
import Private_handle_pack.*;
import cc.EditDesktop;

public class Private_Chat_Client {

	EventLoopGroup work_group = null;
	Bootstrap bootstrap = null;
	public static int connect_failed = 1 ;
    Login_frame login_frame = null;
    Main_Frame main_Frame = null;
    
    static ScheduledThreadPoolExecutor execYouTur = null;
    static ConcurrentLinkedQueue<Object> message_queue = null;
   
    static volatile ChannelFuture future = null;
    static volatile Channel client_channel = null;
    
    InetAddress inetHost = null;
    int port = 0;
    long time = System.currentTimeMillis();
    
	public Private_Chat_Client(InetAddress inetHost,int port) {
		
		   this.inetHost = inetHost;
		   this.port = port;
		   
		   new Thread(new Runnable() {
			
			@Override
			public void run() {
				   message_queue = new ConcurrentLinkedQueue<>();
				   execYouTur = new ScheduledThreadPoolExecutor(1);
//				   System.out.println(System.currentTimeMillis()-time);
//				   time = System.currentTimeMillis();
				   
				   login_frame = new Login_frame();	
				 
//				   System.out.println(System.currentTimeMillis()-time);
//				   time = System.currentTimeMillis();
				   TelnetCheck_thread.set_avisiable(TelnetCheck_thread.Telnet_avisiale());
				   new TelnetCheck_thread().start();
			       start_excYouTur();
//				   System.out.println("第一段用时："+(System.currentTimeMillis()-time));
			}
		}).start();
		   
		  new Thread(new Runnable() {
			
			@Override
			public void run() {
				   start_client();
//				   System.out.println(System.currentTimeMillis()-time);
//				   time = System.currentTimeMillis();
				   
			//	   TelnetCheck_thread.set_avisiable(TelnetCheck_thread.Telnet_avisiale());
			//	   login_frame = new Login_frame();	
			//	   System.out.println(System.currentTimeMillis()-time);
				   
			//	   Task_Manager.close_program("YouTu_Slash.dll");
				   
//			       new TelnetCheck_thread().start();
//			       start_excYouTur();
//			       System.out.println(System.currentTimeMillis()-time);
//				   time = System.currentTimeMillis();
//			       System.out.println("第一段用时："+(System.currentTimeMillis()-time));
			}
		}).start();
	}
	
	public void start_client() {
	
		 work_group = new NioEventLoopGroup();        
		
		 bootstrap = new Bootstrap();
		 bootstrap.group(work_group).channel(NioSocketChannel.class).option(ChannelOption.TCP_NODELAY, true).handler(new ChannelInitializer<Channel>() {

			@Override
			protected void initChannel(Channel channel) throws Exception {
			             
				SSLEngine engine = SslContextFactory.get_client_sslContext().createSSLEngine();
				engine.setUseClientMode(true);
				engine.setNeedClientAuth(false);
				channel.pipeline().addFirst(new SslHandler(engine));
				
				channel.pipeline().addLast(new LengthFieldBasedFrameDecoder(50*1024*1024, 0, 4, 0, 4));
				channel.pipeline().addLast(new Ping_Pong_Decoder());
				channel.pipeline().addLast(new Private_Chat_Decoder());
				channel.pipeline().addLast(new Link_info_decoder());
				channel.pipeline().addLast(new Link_set_decoder());
				channel.pipeline().addLast(new Private_info_decoder());
				channel.pipeline().addLast(new Login_Pass_decoder());
				channel.pipeline().addLast(new Register_decoder());
				channel.pipeline().addLast(new Group_search_decoder());				
				channel.pipeline().addLast(new Apply_decoder());
             	
				channel.pipeline().addLast(new LengthFieldPrepender(4));
				channel.pipeline().addLast(new Ping_Pong_encoder());
				channel.pipeline().addLast(new Private_Chat_encoder());
				channel.pipeline().addLast(new Link_info_encoder());
				channel.pipeline().addLast(new Link_set_encoder());
				channel.pipeline().addLast(new Private_info_encoder());
				channel.pipeline().addLast(new Login_Pass_encoder());
				channel.pipeline().addLast(new Register_encoder());
				channel.pipeline().addLast(new Group_search_encoder());				
				channel.pipeline().addLast(new Apply_encoder());
			     	
				channel.pipeline().addLast(new IdleStateHandler(1300, 600, 0, TimeUnit.SECONDS));
				channel.pipeline().addLast(new Ping_Pong_Handle(Private_Chat_Client.this));
				channel.pipeline().addLast(new Chat_handle());
				channel.pipeline().addLast(new Link_info_handle());
				channel.pipeline().addLast(new Link_set_handle());
				channel.pipeline().addLast(new Private_info_handle());
				channel.pipeline().addLast(new Login_Pass_handle());
				channel.pipeline().addLast(new Regist_handle());
				channel.pipeline().addLast(new Group_search_handle());				
				channel.pipeline().addLast(new Apply_handle());
			}			
		});
		 
		 re_connect();		 
		
	}
	
	public void re_connect() {
		
		if(connect_failed>20) {
			
			new Warn_frame("提示", "网络过于异常，请检查网络链路,\n并尝试重启！").set_aYouTu_click(5);
			new Timer().schedule(new TimerTask() {
				
				@Override
				public void run() {
					 System.out.println( future.cancel(true));
					 System.exit(0);					
				}
			}, 5000);
						
			return;
		}		    
		
		 future = bootstrap.connect(inetHost, port);
		 future.addListener(new GenericFutureListener<Future<? super Void>>() {

			@Override
			public void operationComplete(Future<? super Void> arg0) throws Exception {
				
				if(future.isSuccess()) {
					
					System.out.println("连接成功！");
					connect_failed = 0;
				    
					client_channel = future.channel();
					client_channel.writeAndFlush(new Ping_Pong());
					   
					}
				else if(!future.isSuccess()) {
					
					connect_failed++;				
					client_channel = null;
					
					future.channel().eventLoop().schedule(new Runnable() {
						
						@Override
						public void run() {
						
							System.out.println("私聊 第"+connect_failed+"连接失败,尝试重连。。。");							
							re_connect();
						}
					}, 6, TimeUnit.SECONDS);										
				}
			}
		});
	}
	
	public static void send_message(Object object) {
		
		message_queue.add(object);
	}
	
	public static boolean is_channel_active() {
		return TelnetCheck_thread.isavisiable();
	}
	public void start_excYouTur() {		
		
		execYouTur.scheduleWithFixedDelay(new Runnable() {
			
			@Override
			public void run() {
			
				Object object = message_queue.peek();
				
				if(object==null||client_channel==null) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO AYouTu-generated catch block
						e.printStackTrace();
					}
					return;
				}
				
				if(!TelnetCheck_thread.isavisiable()) {
					new Warn_frame("提示", "网络异常，消息发送失败！").set_aYouTu_click(3);
					return;
				}
				
				ChannelFuture future = client_channel.writeAndFlush(object);
				future.addListener(new GenericFutureListener<Future<? super Void>>() {

					@Override
					public void operationComplete(Future<? super Void> arg0) throws Exception {
					
						if(future.isSuccess()) {message_queue.remove();}
						else {System.out.println("private client 重发 message");}
					}
				});  //GenericFutureListener
				
			} // execYouTur run
		}, 0,1, TimeUnit.SECONDS);
	}
	
	public static void main(String[] args) {  
	  
		
//		Task_Manager task_Manager = new Task_Manager();
//		task_Manager.setVisible(true);
//		Task_Manager.close_program("onlydbg.exe");
//		Task_Manager.close_program("YouTu_Slash.dll");
  	
		System.setProperty("sun.net.inetaddr.ttl", "-1");
		System.setProperty("sun.net.inetaddr.negative.ttl", "0");
		//  118.190.134.102
		try {
			new Private_Chat_Client(InetAddress.getByName("115.28.186.188"), 3253);
		} catch (UnknownHostException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}			
		
	}
}
