package ss;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;

import com.sun.org.apache.xerces.internal.util.EntityResolver2Wrapper;

public class Test {
	
	public static void process_Image() {
		File file = new File("E:\\背景图-psd");
		File[] files = file.listFiles();
		
		for(int i=0;i<files.length;i++) {
			String file_name = files[i].getName();
			int last_index = file_name.lastIndexOf(".");
			String lastString = file_name.substring(last_index);
			String pathname = "E:\\背景图-psd\\"+i+lastString;
			files[i].renameTo(new File(pathname));
		}
	}
	public static void create_dir(File from_file) {
		String to_path = "D:\\桌面\\workspace\\"+from_file.getName();
		File to_file = new File(to_path);
		
		if(!to_file.exists()) {
			to_file.mkdir();
		}
	}
	public static void wipeOff_blank(File from_file) {
		
		String file_name = from_file.getName();
		if(file_name.endsWith("jpg")||file_name.endsWith("png")||file_name.endsWith("wav")) {return;}
		if(file_name.endsWith("jks")||file_name.endsWith("xml")) {return;}
		
//		String to_path = "D:\\桌面\\workspace\\"+from_file.getName();
		String to_path = "D:\\桌面\\process.txt";
		File to_file = new File(to_path);		
		BufferedReader bufferedReader = null;
		PrintWriter printWriter = null;
		String line = null;
		if(!to_file.exists()) {try {
			to_file.createNewFile();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}}
	
	try {
		 bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(from_file),"GB2312"));
		 printWriter = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(to_file,true),"GB2312")));
	} catch (FileNotFoundException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	catch (Exception e) {
		e.printStackTrace();
	}
	try {
		while((line=bufferedReader.readLine())!=null) {
			 if(line.trim().length()==0) {continue;}
			 printWriter.println(line);
		}
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	
	  printWriter.close();
	  try {
		bufferedReader.close();
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	System.out.println("file_name=="+file_name);
 }
 
  public static void process_allFile(File file) {
	 
	  File[] files = file.listFiles();
	  
	  for(int i=0;i<files.length;i++) {
		  if(files[i].isDirectory()) {
		//	  create_dir(files[i]);
			  process_allFile(files[i]);
		  }
		  else {wipeOff_blank(files[i]);}
	  }
	  
	  System.out.println("over");
  }
  public static void devided_txt() {
	  
	BufferedReader bufferedReader = null;
	
	try {
		 bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("D:\\桌面\\client.txt"),"GB2312"));
	} catch (FileNotFoundException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	catch (Exception e) {
		e.printStackTrace();
	}
	for(int i=0;i<31055;i++) {
		try {
			bufferedReader.readLine();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	}
	for(int i=31;i<61;i++) {
		write_txt(i, bufferedReader);
	}
  }
  public static void write_txt(int index,BufferedReader bufferedReader) {
	  String path = "D:\\桌面\\sourse\\"+index+".txt";
	  PrintWriter printWriter = null;
	  File file = null;
	  file = new File(path);

	  if(!file.exists()) {
		  try {
			file.createNewFile();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	  }
	  try {
		  printWriter = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file,false),"GB2312")));
		} catch (FileNotFoundException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
			  
	   for(int i=0;i<50;i++) {
		   try {
			String line = bufferedReader.readLine();
			printWriter.println(line);
			printWriter.flush();
			System.out.println("line="+line);
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}	  
	 }
  }
	public static void main(String[] args) {
		
//		process_allFile(new File("E:\\workspace\\YouTu_client\\src"));  // client
//		process_allFile(new File("E:\\workspace\\YouTu_Serve\\src"));  // server
//		devided_txt();
//		System.out.println("over!");
		File file = new File("E:\\");
	    File[] files = file.listFiles();
	    for(int i=0;i<files.length;i++) {
	    	System.out.println(files[i].getName());
	    }
	}
}
