package chat_frame_pane;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.color.ColorSpace;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.awt.image.ColorConvertOp;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import Frame.Chat_frame;
import Frame.Main_Frame;
import Main_frame_Item.Main_JMenuItem;
import Message.Private.Link_info;
import tools.Icon_tools;

public class Chat_frame_Item extends JPanel implements ActionListener{
    
	String link_count = null;
	Image head_image = null;
	BufferedImage grayImage = null;
	boolean online = true;
	String state = null;
	
	String remark = null;
	String content = null;
	String time = null;
	String inform_type = null;
	int quantity  = 0 ;
	
	boolean private_link = true;
	boolean group_owner = false;	
	boolean enter = false;
	boolean selected = false;
	
	Item_list_pane list_pane = null;
	Font remark_font = null;
	Font content_font = null;
    Color gray_color = null;
    Color conten_color = null;
    
    SimpleDateFormat simpleDateFormat = null;
    Cursor cursor = null;
    
    JPopupMenu popupMenu = null;
    Main_JMenuItem delete_item = null;
    
	public Chat_frame_Item(Item_list_pane list_pane,String remark,String link_count) {
		
		setOpaque(false);
		
		setPreferredSize(new Dimension(200, 60));
		setMinimumSize(new Dimension(200, 60));
		setMaximumSize(new Dimension(200, 60));
		
		Init_content(list_pane, remark, link_count);
		Init_popmenu();
		Init_mouse_listioner();
		
	}
	
	public void Init_content(Item_list_pane list_pane,String remark,String link_count) {
		
		this.remark = remark;
		this.link_count = link_count;
		cursor = new Cursor(Cursor.DEFAULT_CURSOR);
		simpleDateFormat = new SimpleDateFormat("HH:mm");
		remark_font = new Font("宋体", Font.PLAIN, 15);
		content_font = new Font("宋体", Font.PLAIN, 13);
		gray_color = new Color(140, 140, 140);
		conten_color = new Color(70, 70, 70);
		
		Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_count);
		this.state = link_info.getState();
		this.online = is_online(state);
		Chat_frame.update_title(link_count, remark+"      "+state);
		
//		this.group_owner = group_owner;
//		this.inform_type = inform_type;
		this.list_pane = list_pane;
		this.head_image = Icon_tools.get_client_head_image(link_count);	
		this.grayImage = getGrayImage();
		
	}
	
	public void Init_popmenu() {
		
		popupMenu = new JPopupMenu();
		popupMenu.setBackground(Color.white);
		
		delete_item = new Main_JMenuItem("移除会话", null);
		popupMenu.add(delete_item);
		
		delete_item.addActionListener(this);
	}
	
	public void Init_mouse_listioner() {
		
		addMouseListener(new MouseAdapter() {
				
			@Override
			public void mouseEntered(MouseEvent e) {
				
				enter = true;			    
			    repaint();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				
				enter = false;			    
			    repaint();
			    
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				
				if(e.getButton()==1) {
			
				list_pane.set_selected_item(link_count);
				quantity = 0;
				repaint();
				
				Chat_frame.update_ui();
				Chat_frame.update_title(link_count, remark);
				Chat_frame.set_down_head_icon(head_image);
				
				}
				else if(e.getButton()==3){popupMenu.show(Chat_frame_Item.this,e.getX(),e.getY());}
			}
		});
	}
	
	public void set_selected(boolean selected) {
		
		this.selected = selected;
		repaint();
		
	}
	public void update_content(String content) {
		
		this.content = content;
		this.time = simpleDateFormat.format(new Date());
		
		if(Main_Frame.getCurrent_link_count().equals(link_count)) {quantity = 0;}
		else {quantity++;}
		
		repaint();
	}
	
	public  BufferedImage getGrayImage(){
		
		BufferedImage originalImage = null;
		try {
			originalImage = ImageIO.read(new FileInputStream("C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\image\\head_image\\"+link_count+".png"));
		} catch (FileNotFoundException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		int rgb = 0 ;
		Color color = null;
		int green = 0,red = 0,blue = 0;
		int imageWidth = originalImage.getWidth();
		int imageHight = originalImage.getHeight();
		BufferedImage routeImage = new BufferedImage(imageWidth,imageHight,BufferedImage.TYPE_4BYTE_ABGR);
		for(int i = originalImage.getMinX();i < imageWidth;i++){
			for(int j = originalImage.getMinY();j < imageHight;j++){
				//获取该点像素，用Object类型标识
				
				rgb = originalImage.getRGB(i, j);
				color = new Color(rgb);
				
				red = color.getRed();
				green = color.getGreen();
				blue = color.getBlue();
				red = (red*3+green*6+blue*1)/10;
				green = red;
				blue = green;
							
				rgb = (red*256 +green)*256 +blue;
				if(rgb>8388608){
					rgb = rgb - 256*256*256;
				}
				
				if(red<2&&green<2&&blue<2) {color = new Color(0, 0, 0,0);}
				else {color = new Color(red, green, blue);}
				//将rgb值写回图片
				routeImage.setRGB(i, j, color.getRGB());
			}
		}
		
		Graphics2D g2 = (Graphics2D) routeImage.getGraphics();
		g2.setColor(Color.LIGHT_GRAY);
		g2.setStroke(new BasicStroke(2f));
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2.drawOval(-1,-1, imageWidth+1, imageHight+1);
		
		return routeImage;
	}
	
	public boolean is_online(String state) {

		if(state.equals("离线")||state.equals("隐身")) {return false;}
		return true;
	}
	
	public void update_state(String state) {
		
		if(state.equals("隐身")) {this.state = "离线";}
		else {this.state = state;}
		
		if(this.state.equals("离线")) {this.online = false;}
		else {this.online = true;}
		
		Chat_frame.update_title(link_count, remark+"      "+this.state);
		repaint();
		
	}
	
	public void update_head_image(byte[] icon_bytes) {
		
		 this.head_image = new ImageIcon(icon_bytes).getImage();
		 this.grayImage = getGrayImage();
		 repaint();
	}
	
	@Override
	protected void paintComponent(Graphics g) {		
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		if(enter||selected) {
			g2.setColor(gray_color);
			g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.3f));
			g2.fillRect(0, 0, 250, 60);
			
		}
		
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
		

		if(online) {g2.drawImage(head_image, 10, 10, null);}
		else {g2.drawImage(grayImage, 10, 10, null);}
			
		
		g2.setColor(Color.black);
		g2.setFont(remark_font);
		g2.drawString(remark, 55, 25);
		
		g2.setColor(conten_color);
		g2.setFont(content_font);
		
		if(content!=null) {g2.drawString(content, 60, 45);}
		if(time!=null) {g2.drawString(time, 150, 20);}
		
		if(quantity>0) {
			
			g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			g2.setColor(new Color(247, 76, 49));
			g2.fillOval(165, 30, 16, 16);
			
			g2.setColor(Color.white);
			g2.setFont(new Font("宋体", Font.BOLD, 14));
			
			if(quantity<10) {g2.drawString(""+quantity, getWidth()-31, 41);}
			else {g2.drawString("..", getWidth()-34, 40);}
			  
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==delete_item) {list_pane.remove_item(link_count);}
	}
}
