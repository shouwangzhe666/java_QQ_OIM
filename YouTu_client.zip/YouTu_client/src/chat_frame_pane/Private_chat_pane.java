package chat_frame_pane;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.io.IOException;
import javax.swing.BoxLayout;
import javax.swing.JSplitPane;
import Frame.Chat_frame;
import Frame.Main_Frame;
import Message.Private.Link_info;
import Message.Private.Private_Chat_Message;
import Private_chat.Private_Tip_pane;
import Private_chat.Private_show_pane;
import Private_chat.Send_pane;
import Private_chat.Tool_Pane;
import Private_chat.Write_pane;
import custom_component.Box_pane;
import custom_component.My_ScrollPane;

public class Private_chat_pane extends JSplitPane {
   
	String link_count = null;
	Dimension dimension = null;
	Private_top_pane top_pane = null;
	Private_down_pane down_pane = null;
	
	My_ScrollPane scrollPane = null;
	Private_show_pane show_pane = null;
	Private_Tip_pane tip_pane = null;
	
	Tool_Pane tool_Pane = null;
	Write_pane write_pane = null;
	Send_pane send_pane = null;

	
 public Private_chat_pane(String link_count) {
	   
	    this.link_count = link_count;
	    dimension = Toolkit.getDefaultToolkit().getScreenSize();
		setOrientation(JSplitPane.VERTICAL_SPLIT);
		setContinuousLayout(true);
		setBorder(null);
	
		setOpaque(false);
		setBorder(null);
		setDividerSize(1);
		setDividerLocation(400);
		
		setPreferredSize(new Dimension(500, 550));
		setMinimumSize(new Dimension(500, 550));
		setMaximumSize(dimension);
	
		down_pane = new Private_down_pane(link_count);
		top_pane = new Private_top_pane();
		
		setLeftComponent(top_pane);
		setRightComponent(down_pane);
	
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
				show_pane.lock_location(0);
			}
		}).start();
	}
 
private class Private_top_pane extends Box_pane{

	 Private_top_pane() {
		super(BoxLayout.Y_AXIS);
	    setOpaque(false);
	    
		setPreferredSize(new Dimension(500, 385));
		setMinimumSize(new Dimension(500, 385));
		setMaximumSize(dimension);

		 show_pane = new Private_show_pane(Integer.parseInt(link_count), write_pane);	 
		 Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_count);
		 tip_pane = new Private_Tip_pane(link_info.getRemark(),show_pane);
		 
		add(show_pane);
		add(tip_pane);
		
	}
	 
 }

private class Private_down_pane extends Box_pane{
			
		 Private_down_pane(String link_count) {
			super(BoxLayout.Y_AXIS);		
			setOpaque(false);
			
			Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			setPreferredSize(new Dimension(500, 125));
			setMinimumSize(new Dimension(500, 125));
			setMaximumSize(dimension);			
			
			 write_pane = new Write_pane(link_count,Private_chat_pane.this);
			 tool_Pane = new Tool_Pane(write_pane);
			 send_pane = new Send_pane(write_pane);
			 
			add(tool_Pane);
			add(write_pane);
			add(send_pane);
			
		}
}

public void update_other_head_icon(byte[] icon_bytes) {
	
	 show_pane.update_other_head_icon(icon_bytes);
}

public void update_self_icon(byte[] icon_bytes) {
	
	show_pane.update_self_icon(icon_bytes);
}

public void load_chat_content() {
	 
	 show_pane.load_all_chat_content();
 }

public void put_chat_Message(Private_Chat_Message chat_Message,boolean save) {
		try {
			show_pane.put_chat_Message(chat_Message, save);
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
			
   boolean self = chat_Message.getFrom_account()==Long.parseLong(Main_Frame.getNative_count());
   
  if(show_pane.get_difference_height()==0) {return;}
   
 if(!self&&show_pane.get_difference_value()>50) {		
	 String content = chat_Message.get_popu_message();
	 tip_pane.load_message(content);  }
 
	}

public void put_file_message(Private_Chat_Message chat_Message,boolean save) {
	
	try {
		show_pane.put_file_message(chat_Message, save);
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	
	if(show_pane.get_all_y()-show_pane.getVerticalScrollBar().getValue()>50) {		
		 String content = "文件：file_name";
		 tip_pane.load_message(content);  }

}
public void put_audio_message(Private_Chat_Message chat_Message,boolean save) {
	
	try {
		show_pane.put_audio_message(chat_Message, save);
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	
	if(show_pane.get_all_y()-show_pane.getVerticalScrollBar().getValue()>50) {		
		 String content = "语音消息";
		 tip_pane.load_message(content);  }

}
public void remove_chat_item(Private_Chat_Message chat_Message,boolean save) {
	
	try {
		show_pane.remove_Item(chat_Message, save);
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	
	if(show_pane.get_difference_height()==0) {return;}
	
	if(show_pane.get_all_y()-show_pane.getVerticalScrollBar().getValue()>50) {		
		 String content = "撤销一条消息";
		 tip_pane.load_message(content);  }

}
public void shake_Item(Private_Chat_Message chat_Message,boolean save) {
	 
	  show_pane.shake_Item(chat_Message, save);
	 
}

//@Override
//protected void paintComponent(Graphics g) {	
//	super.paintComponent(g);
//	
//	setDividerLocation(getHeight()-115);
//
//}
}
