package chat_frame_pane;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import javax.swing.BoxLayout;
import Frame.Chat_frame;
import Frame.Main_Frame;
import Message.Private.Link_info;
import custom_component.Box_pane;

public class Item_list_pane extends Box_pane{
      
	Dimension dimension = null;
	ConcurrentHashMap<String, Chat_frame_Item> all_item = null;
	int item_num = 0;
	int width = 200;
	int height = 0;
	
	Container_pane container_pane = null;
	Chat_frame_Item chat_frame_Item = null;
	
	public Item_list_pane(Container_pane container_pane) {
		super(BoxLayout.Y_AXIS);
		
		setOpaque(false);
	    //setBackground(Color.orange);
		this.container_pane = container_pane;
		all_item = new ConcurrentHashMap<>();
		dimension = Toolkit.getDefaultToolkit().getScreenSize();
		setPreferredSize(new Dimension(200, 100));
		setMinimumSize(new Dimension(200, 100));
		setMaximumSize(new Dimension(200, 2000));
	}
         
	public void set_selected_item(String link_count) {
		
		if(chat_frame_Item!=null) {chat_frame_Item.set_selected(false);}
		
		Main_Frame.setCurrent_link_count(link_count);
	 
		 chat_frame_Item = all_item.get(link_count);
		 chat_frame_Item.set_selected(true);
		
		container_pane.change_pane(link_count);
	}
	
	public void put_chat_item(String link_count,boolean group_owner) {
		
		if(all_item.get(link_count)!=null) {set_selected_item(link_count);return;}
		
		Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_count);
		String remark = link_info.getRemark();
		Chat_frame_Item item = new Chat_frame_Item(this, remark, link_count);
		
		all_item.put(link_count, item);
		add(item);
		
		item_num++;
		height = item_num*60;
		
		setPreferredSize(new Dimension(width, height));
		setMinimumSize(new Dimension(width, height));
		setMaximumSize(new Dimension(width, height));
		
		set_selected_item(link_count);
	}
	
	public void update_item_content(String link_count,String content) {
		
		Chat_frame_Item chat_Item = all_item.get(link_count);
		if(chat_Item==null) {return;}
		
		chat_Item.update_content(content);
		
	}
	
public void update_item_state(String link_count,String state) {
		
		Chat_frame_Item chat_Item = all_item.get(link_count);
		if(chat_Item==null) {return;}
		
		chat_Item.update_state(state);		
	}

public void update_item_head_icon(String link_count,byte[] icon_bytes) {
	
	Chat_frame_Item chat_Item = all_item.get(link_count);
	if(chat_Item==null) {return;}
	
	chat_Item.update_head_image(icon_bytes);
}

  public void remote_all_Item() {
	 
	  String key = null;
	  Chat_frame_Item value = null;
	  Iterator<String> iterator = all_item.keySet().iterator();
	  
	  while(iterator.hasNext()) {
		   key = iterator.next();
		   value = all_item.get(key);
		   remove(value);
		   iterator.remove();
	  }
	   
	    item_num=0;
		
		height = item_num*200;
		
		setPreferredSize(new Dimension(width, height));
		setMinimumSize(new Dimension(width, height));
		setMaximumSize(new Dimension(width, height));
  }
  public void remove_item(String link_count) {
	
		Chat_frame_Item item = all_item.get(link_count);
		if(item==null) {return;}
		
		remove(item);
		all_item.remove(link_count);
		container_pane.remove_chat_pane(link_count);
		
		item_num--;
		
		height = item_num*200;
		
		setPreferredSize(new Dimension(width, height));
		setMinimumSize(new Dimension(width, height));
		setMaximumSize(new Dimension(width, height));
		
		Chat_frame.update_ui();
		
		if(item_num==0) {
			Chat_frame.set_visiable(false);
			Main_Frame.setCurrent_link_count("0");
			return;
		}
		
		Iterator<String> it = all_item.keySet().iterator();
		while(it.hasNext()) {
			link_count = it.next();
		}
		
		if(link_count!=null) {
		
		Main_Frame.setCurrent_link_count(link_count);
		
		container_pane.change_pane(link_count);
		}	
	}
  
  public int get_Item_num() {
	  
	  return item_num;
  }
}
