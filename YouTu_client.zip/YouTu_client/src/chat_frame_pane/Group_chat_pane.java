package chat_frame_pane;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.io.IOException;
import javax.swing.BoxLayout;
import javax.swing.JSplitPane;

import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;

import Frame.Chat_frame;
import Frame.Main_Frame;
import Group_chat.Group_show_pane;
import Group_chat.Send_pane;
import Group_chat.Tip_Bottom_pane;
import Group_chat.Tip_Top_pane;
import Group_chat.Tool_Pane;
import Group_chat.Write_pane;
import Message.Group.Group_chat_message;
import Message.Private.Link_info;
import Message.Private.Private_Chat_Message;
import custom_component.Box_pane;
import custom_component.My_ScrollPane;

public class Group_chat_pane extends JSplitPane {
	
	int group_account = 0;
	String ip_port = null;
	String native_id = null;
	String native_remark = null;
	String conment_time = null;
	
	Dimension dimension = null;
	Private_top_pane top_pane = null;
	Private_down_pane down_pane = null;
	
	My_ScrollPane scrollPane = null;
	Group_show_pane show_pane = null;
	Tip_Top_pane tip_Top_pane = null;
	Tip_Bottom_pane tip_Bottom_pane = null;
	
	Tool_Pane tool_Pane = null;
	Write_pane write_pane = null;
	Send_pane send_pane = null;
	
 public Group_chat_pane(int group_account,String ip_port,String native_id,String native_remark,String conment_time) {
	   
	    this.group_account = group_account;
	    this.ip_port = ip_port;
	    this.native_id = native_id;
	    this.native_remark = native_remark;
	    this.conment_time = conment_time;
	    
	    dimension = Toolkit.getDefaultToolkit().getScreenSize();
		setOrientation(JSplitPane.VERTICAL_SPLIT);
		setContinuousLayout(true);
		setBorder(null);
	
		setOpaque(false);
		setBorder(null);
		setDividerSize(1);
		setDividerLocation(400);
		
		setPreferredSize(new Dimension(500, 550));
		setMinimumSize(new Dimension(500, 550));
		setMaximumSize(dimension);
	
		down_pane = new Private_down_pane();
		top_pane = new Private_top_pane();
		
		setLeftComponent(top_pane);
		setRightComponent(down_pane);	
		
     new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
				show_pane.lock_location(0);
			}
		}).start();
	}
 
private class Private_top_pane extends Box_pane{

	 Private_top_pane() {
		super(BoxLayout.Y_AXIS);
	    setOpaque(false);
	    
		setPreferredSize(new Dimension(500, 385));
		setMinimumSize(new Dimension(500, 385));
		setMaximumSize(dimension);

		 show_pane = new Group_show_pane(group_account,ip_port,native_id, write_pane);
		 tip_Top_pane = new Tip_Top_pane(show_pane);
		 tip_Bottom_pane = new Tip_Bottom_pane(show_pane);
		 
		add(tip_Top_pane);
		add(show_pane);
		add(tip_Bottom_pane);
		
	}	 
 }

private class Private_down_pane extends Box_pane{
			
		 Private_down_pane() {
			super(BoxLayout.Y_AXIS);		
			setOpaque(false);
			
			Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			setPreferredSize(new Dimension(500,125));
			setMinimumSize(new Dimension(500, 125));
			setMaximumSize(dimension);			
			
			 write_pane = new Write_pane(group_account, native_id, native_remark,Group_chat_pane.this);
			 write_pane.update_shutup(conment_time);
			 tool_Pane = new Tool_Pane(write_pane);
			 send_pane = new Send_pane(write_pane);
			 
			add(tool_Pane);
			add(write_pane);
			add(send_pane);
			
	}
}

public void update_group_head_icon(int member_account,byte[] icon_bytes) {
	
	 show_pane.update_group_head_icon(member_account, icon_bytes);
}
public void update_group_member_remark(int member_account,String member_remark) {
	
	 show_pane.update_group_member_remark(member_account, member_remark);
}
public void load_chat_content() {
	 
	 show_pane.load_all_chat_content();
 }

public void put_chat_Message(Group_chat_message chat_Message,boolean save) {
		try {
			show_pane.put_chat_Message(chat_Message, save);
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
			
   boolean self = chat_Message.getMember_account()==Integer.parseInt(Main_Frame.getNative_count());
   boolean reply = chat_Message.isReply();
   long send_time = chat_Message.getSend_time();
   String text = chat_Message.get_popu_message();
   
  if(show_pane.get_difference_height()==0) {return;}
   
 if(reply) {tip_Top_pane.add_top_tip(send_time,text);}
 
 if(!self&&show_pane.get_difference_value()>50) {		
	 String content = chat_Message.get_popu_message();
	 tip_Bottom_pane.load_message(content);  }
 
       Chat_frame.update_ui();
	}

public void update_shutup(Group_chat_message chat_message,boolean save) {
                    	
	 show_pane.update_shutup(chat_message, save);
	
	 if(chat_message.getMember_account()==Integer.parseInt(Main_Frame.getNative_count())) {
		 write_pane.update_shutup(chat_message);
	 } 
}

public void set_all_shutup(boolean all_shutup) {		
	 write_pane.set_all_shutup(all_shutup);
}
public void update_administer(Group_chat_message chat_message,boolean save) {
	
	String group_id = chat_message.isSet_Administrator()?"管理员":"成员";
	chat_message.setGroup_id(group_id);
	
	update_id(chat_message, save);
	
}

public void update_id(Group_chat_message chat_message,boolean save) {
	
	show_pane.update_id(chat_message, save);
	
	if(Integer.parseInt(Main_Frame.getNative_count())==chat_message.getMember_account()) {
		write_pane.update_native_id(chat_message.getGroup_id());}
	
}

public void update_native_remark(Group_chat_message chat_message,boolean save) {
	
	  write_pane.update_native_remark(chat_message.getGroup_remark());
}
public void remove_member(Group_chat_message chat_message,boolean save) {
	
	show_pane.remove_member(chat_message, save);
}

public void remove_chat_item(Group_chat_message chat_Message,boolean save) {
	
	try {
		show_pane.remove_Item(chat_Message, save);
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	
	if(show_pane.get_difference_height()==0) {return;}
	
	if(show_pane.get_all_y()-show_pane.getVerticalScrollBar().getValue()>50) {		
		 String content = chat_Message.get_popu_message();
		 tip_Bottom_pane.load_message(content);  }

		   Chat_frame.update_ui();
}

//@Override
//protected void paintComponent(Graphics g) {	
//	super.paintComponent(g);
//	
//	setDividerLocation(getHeight()-115);
//
//}
}
