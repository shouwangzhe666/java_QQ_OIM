package chat_frame_pane;

// author: jiang quan feng
// date : 2020.01.11

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JSplitPane;

import Frame.Main_Frame;
import Message.Private.Link_info;
import Private_chat.Private_show_pane;
import tool_Frame.Warn_frame;

public class Container_pane extends JPanel{
    
	Dimension dimension = null;
	ConcurrentHashMap<Integer, JSplitPane> all_chat_pane = null;
	JSplitPane current_pane = null;
	Chat_frame_Item chat_frame_Item = null;
	
	public Container_pane(ConcurrentHashMap<Integer, JSplitPane> all_chat_pane) {
	    
	    //setBackground(Color.orange);
        setOpaque(false);
		setLayout(new BorderLayout());
		this.all_chat_pane = all_chat_pane;
		
		dimension = Toolkit.getDefaultToolkit().getScreenSize();
		setPreferredSize(new Dimension(800, 600));
		setMinimumSize(new Dimension(440, 450));
		setMaximumSize(dimension);
	}
	
	public void update_private_other_head_icon(String link_count,byte[] icon_bytes) {
		
		 Private_chat_pane private_chat_pane = (Private_chat_pane) all_chat_pane.get(Integer.parseInt(link_count));
		 if(private_chat_pane==null) {return;}
		 private_chat_pane.update_other_head_icon(icon_bytes);
	}
	
public void update_self_icon(byte[] icon_bytes) {
		
	Private_chat_pane private_chat_pane = null;
	
	for(JSplitPane chat_pane:all_chat_pane.values()) {
        if(chat_pane instanceof Private_chat_pane) {
			
			private_chat_pane = (Private_chat_pane) chat_pane;
			private_chat_pane.update_self_icon(icon_bytes);
		}      
	}    // for
}
	public void change_pane(String link_count) {
		
		if(all_chat_pane.get(Integer.parseInt(link_count))==null) {
			if(link_count.length()==8) {
				put_Private_chat_pane(Integer.parseInt(link_count));
			}
			else {
				Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_count);
				put_Group_chat_pane(Integer.parseInt(link_count), link_info.getRemote_ip(), link_info.getId(), link_info.getSignature(), link_info.getState());
				
			}
		}
	
		current_pane = all_chat_pane.get(Integer.parseInt(link_count));
		
		removeAll();	
		add(current_pane);
		
	}	
public void remove_chat_pane(String link_count) {
	
	all_chat_pane.remove(Integer.parseInt(link_count));
}
public void remove_all_chat_pane() {
	
	  removeAll();
	 
	  Iterator<Integer> iterator = all_chat_pane.keySet().iterator();
	  while(iterator.hasNext()) {
		  Integer key  = iterator.next();
		  iterator.remove();
	  }
}
public void put_Private_chat_pane(int link_account) {
	
	Private_chat_pane chat_pane = new Private_chat_pane(String.valueOf(link_account));
	all_chat_pane.put(link_account, chat_pane);
  
}

public  Private_chat_pane get_Private_chat_jpane(int link_count) {
	
	 Private_chat_pane chat_pane = (Private_chat_pane) all_chat_pane.get(link_count);		
	 return chat_pane;
	}

public void put_Group_chat_pane(int group_account,String ip_port,String native_id,String native_remark,String conment_time) {
	
	Group_chat_pane chat_pane = new Group_chat_pane(group_account,ip_port,native_id, native_remark,conment_time);
	all_chat_pane.put(group_account, chat_pane); 
}

public  Group_chat_pane get_Group_chat_jpane(int group_account) {
	
	 Group_chat_pane chat_pane = (Group_chat_pane) all_chat_pane.get(group_account);		
	 return chat_pane;
}

}
