package tcp_pack;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;
public class TCP_Transfer_Pointer{

public TCP_Transfer_Pointer(){
}

public void connect_And_transfer(int server_port) {
	
	TCP_P2P_Pointer p2p_Pointer1 = new TCP_P2P_Pointer("TCP_Transfer_Pointer_Sender",server_port);
	p2p_Pointer1.start();
	
	TCP_P2P_Pointer p2p_Pointer2 = new TCP_P2P_Pointer("TCP_Transfer_Pointer_Recever",server_port);
	p2p_Pointer2.start();
	
	Socket socket1 = p2p_Pointer1.get_socket(60);
	Socket socket2 = p2p_Pointer2.get_socket(60);
	
	if(socket1==null||socket2==null) {
		System.err.println("tcp transfer error!");
		return;
	}
	
	try {
		new Transfer_thread(socket1.getInputStream(), socket2.getOutputStream()).start();
		new Transfer_thread(socket2.getInputStream(), socket1.getOutputStream()).start();
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
}

private static class Transfer_thread extends Thread{
	byte[] by = null;
	int len = 0;
	InputStream inputStream = null;
	OutputStream outputStream = null;
	
	public Transfer_thread(InputStream inputStream,OutputStream outputStream) {
		    this.inputStream = inputStream;
		    this.outputStream = outputStream;
		    by = new byte[1024*8];
	}
	@Override
	public void run() {
	       try {
			while((len=inputStream.read(by))!=-1) {
				     outputStream.write(by, 0,len);
			   }
		} catch (IOException e) {
			e.printStackTrace();
		}
	       try {
				inputStream.close();
				outputStream.close();
			} catch (IOException e1) {
				// TODO AYouTu-generated catch block
				e1.printStackTrace();
			}
	}
}
public static void main(String[] args) {
	 Scanner scanner = new Scanner(System.in);
		
	 System.out.println("server port: ");
	 int server_port = scanner.nextInt();
	 
	 TCP_Transfer_Pointer transfer_Pointer = new TCP_Transfer_Pointer();
	 transfer_Pointer.connect_And_transfer(server_port);
	
}
}
