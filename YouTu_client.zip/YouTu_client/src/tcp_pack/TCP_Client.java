package tcp_pack;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;

public class TCP_Client extends Thread{

	Socket socket = null;
	int local_port = 0;
	int server_TcpPort1 = 0;
	int server_TcpPort2 = 0;
	
	public TCP_Client(int server_TcpPort1, int server_TcpPort2) {
		// 默认优先IP4
		 System.setProperty("java.net.preferIPv4Stack", "true");
				
		this.server_TcpPort1 = server_TcpPort1;
		this.server_TcpPort2 = server_TcpPort2;
		
	}
	
	@Override
	public void run() {
		
		     int local_port = get_port();	   
		     
		    
		      try {
		    	    socket = new Socket();
					socket.bind(new InetSocketAddress(InetAddress.getLocalHost(),local_port));
					socket.connect(new InetSocketAddress("115.28.186.188",server_TcpPort1),1500);
					if(!socket.isClosed()) {socket.close();}
					
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					socket = new Socket();
					socket.bind(new InetSocketAddress(InetAddress.getLocalHost(),local_port));
					socket.connect(new InetSocketAddress("115.28.186.188",server_TcpPort2),1500);
					if(!socket.isClosed()) {socket.close();}
					
				} catch (IOException e1) {
					e1.printStackTrace();
				}
	    	
	}
	 public int get_port() {
		  int port = 0;
		  try {
			DatagramSocket datagramSocket = new DatagramSocket();
			port = datagramSocket.getLocalPort();
			datagramSocket.close();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  return port;
	  }
	 
	public static void main(String[] args) {
		
		 new TCP_Client(1,2).start();
		 
		 System.out.println("org.libjpegturbo.turbojpeg...");
	}
}
