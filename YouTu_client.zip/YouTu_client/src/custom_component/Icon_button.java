package custom_component;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPopupMenu;
import Main_frame_Item.Tip_Text_JMenuItem;
import tools.Icon_tools;

public class Icon_button extends JButton{

	int type = 1;
	boolean enter  = false;
	ImageIcon imageIcon = null;
	int width = 0;
	int height = 0;
	int tip_x=0;
	int tip_y = 10;
	JPopupMenu popupMenu=null;
	String tip_text = null;
	ActionListener actionlistener = null;
	
	public Icon_button(URL icon_path,String tip_text) {
		
		type = 1;
		setBorderPainted(false);
		setBorder(null);
		setContentAreaFilled(false);					
		
		popupMenu = new JPopupMenu();
		popupMenu.setBorder(null);
		popupMenu.setBorderPainted(false);
		this.tip_text=tip_text;
		
		if(tip_text!=null) {
		popupMenu.add(new Tip_Text_JMenuItem(tip_text));

		}
		
		if(icon_path!=null) {
			imageIcon = new ImageIcon(icon_path);
			setIcon(imageIcon);
			width = imageIcon.getIconWidth();
			height = imageIcon.getIconHeight();
		}		
		
		setPreferredSize(new Dimension(width, height));
		setMaximumSize(new Dimension(width, height));
		setMinimumSize(new Dimension(width, height));
		
		
		addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseEntered(MouseEvent e) {
				enter = true;
				repaint();
				
				if(tip_text!=null) {				
					try {
						popupMenu.show(Icon_button.this,e.getX()+tip_x,e.getY()+tip_y);
					} catch (Exception e2) {
						return;
					}
				
			}
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				enter = false;
				repaint();
				
				if(tip_text!=null) {					
				popupMenu.setVisible(false);}
			}
		});
	}
	
	public Icon_button(ImageIcon imageIcon ,String tip_text,int icon_width) {
	
		type = 2;
		ImageIcon icon1 = null;
		ImageIcon icon2 = null;
		
		BufferedImage b1 = Icon_tools.get_head_image(imageIcon, icon_width);
		BufferedImage b2 = Icon_tools.get_head_image(imageIcon, icon_width);
		icon1 = new ImageIcon(b1);
		icon2 = new ImageIcon(b2);
		
		setIcon(icon1);
		setRolloverIcon(icon2);
		
		popupMenu = new JPopupMenu();
		popupMenu.setBorder(null);
		popupMenu.setBorderPainted(false);
		this.tip_text=tip_text;
		
		if(tip_text!=null) {
		popupMenu.add(new Tip_Text_JMenuItem(tip_text));}
		
		setPreferredSize(new Dimension(icon_width, icon_width));
		setMinimumSize(new Dimension(icon_width, icon_width));
		setMaximumSize(new Dimension(icon_width, icon_width));
		
		setBorderPainted(false);
		setBorder(null);
		setContentAreaFilled(false);

		addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseEntered(MouseEvent e) {
				if(tip_text!=null) {
					System.out.println(e.getY()+tip_y);
					popupMenu.show(Icon_button.this,e.getX()+tip_x,e.getY()+tip_y);
				}
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				if(tip_text!=null) {
				popupMenu.setVisible(false);}
			}
		});
	}
public void set_tip_x(int tip_x) {
	this.tip_x=tip_x;
}
public void set_tip_y(int tip_y) {
	this.tip_y=tip_y;
}
	@Override
	public void addActionListener(ActionListener l) {
	
		super.addActionListener(l);
		this.actionListener=l;
	}
	
	@Override
	public void setEnabled(boolean enable) {
		
		if(enable&&!isEnabled()) {this.addActionListener(this.actionListener);}
		if(!enable&&isEnabled()) {this.removeActionListener(this.actionListener);}
		
	}
	
	@Override
	protected void paintComponent(Graphics g) {

		
		if(type==1&&enter) {
			Graphics2D g2 = (Graphics2D) g;
			g2.setColor(new Color(200,200,200));
			g2.fillRect(0,0,width, height);
		}
		
        super.paintComponent(g);
	}

	 public static void main(String[] args) {
		  
		 Icon_button face_button = new Icon_button(Icon_button.class.getResource("/tool_image/face.png"),"表情");						
		 Icon_button icon_button = new Icon_button(Icon_button.class.getResource("/tool_image/image.png"),"图片");
		 Icon_button file_button = new Icon_button(Icon_button.class.getResource("/tool_image/file.png"),"文件");
	     
		  JFrame jFrame = new JFrame();
		  jFrame.getContentPane().setLayout(new FlowLayout());
		  jFrame.getContentPane().add(face_button);
		  jFrame.getContentPane().add(icon_button);
		  jFrame.getContentPane().add(file_button);
		  jFrame.setBounds(500, 200, 500, 500);
		  jFrame.setVisible(true);
		
	}
}
