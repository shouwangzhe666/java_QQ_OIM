package custom_component;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

public class Test {
	
public static void main(String[] args) {
		
	ByteBuf buf = Unpooled.buffer(100, 1024);
	buf.writeInt(100);
	int a = buf.readInt();
	buf.setInt(0, 90);
	
	System.out.println(a);
}
}
