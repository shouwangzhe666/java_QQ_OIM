package custom_component;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

public class Box_pane extends JPanel{

	public Box_pane(int boxlaout) {
		setOpaque(false);
		BoxLayout boxLayout = new BoxLayout(this, boxlaout);
		setLayout(boxLayout);
	}
	}
