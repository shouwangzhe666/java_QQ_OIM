package custom_component;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButton;
import javax.swing.plaf.ButtonUI;
import javax.swing.plaf.basic.BasicCheckBoxUI;

import com.sun.corba.se.pept.transport.ReaderThread;

import Frame.Only_frame;

public class My_radiobutton extends JRadioButton{
 
	ImageIcon imageIcon1=null;
	ImageIcon imageIcon2=null;
	Image image  = null;
	boolean enter = false;
	boolean selected = false;
	boolean first  = false;
	Color enter_color = null;
	String text = null;
	
	public My_radiobutton(boolean selected) {
		 setOpaque(false);
		 
		imageIcon1 = new ImageIcon(getClass().getResource("/login_image/radio_unselected.png"));
		imageIcon2 = new ImageIcon(getClass().getResource("/login_image/radio_selected.png"));
		
	     setBorderPainted(false);
	     setBorder(null);
	    
		 setIcon(imageIcon1);
		 setSelectedIcon(imageIcon2);
		 
		 setDisabledIcon(imageIcon1);
		 setDisabledSelectedIcon(imageIcon2);
		 
		 setSelected(selected);
        
	}

	public static void main(String[] args) {
		
		My_radiobutton radiobutton = new My_radiobutton(true);
		JPanel main_pane  = new JPanel();
		main_pane.add(radiobutton);
		
		  JFrame jFrame = new JFrame();
		  jFrame.getContentPane().setLayout(new FlowLayout());
		  jFrame.getContentPane().add(new JRadioButton());
		  jFrame.getContentPane().add(radiobutton);
		  jFrame.setBounds(500, 200, 500, 500);
		  jFrame.setVisible(true);
	}
}
