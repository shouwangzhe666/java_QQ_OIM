package custom_component;

// author: jiang quan feng
// date : 2020.01.11

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JSplitPane;

import Frame.Chat_frame;
import Frame.Only_frame;

public class My_Splite_pane extends JSplitPane{

	Only_frame only_frame = null;
	Component left_comp = null;
	Right_pane right_pane = null;
	Cursor cursor = null;
	int max_width = 0;
	     
    public My_Splite_pane(int max_width) {
    	setBorder(null);
    	setOpaque(false);
    	setDividerSize(1);
    	setDividerLocation(max_width);
    	
    	this.max_width = max_width;
    	cursor = new Cursor(Cursor.DEFAULT_CURSOR);
    	right_pane = new Right_pane();
    
    	super.setRightComponent(right_pane);
    }
 
    @Override
    public void setLeftComponent(Component comp) {
    	super.setLeftComponent(comp);
    	this.left_comp = comp;
    }
    @Override
    public void setRightComponent(Component comp) {

        if(right_pane==null) {right_pane = new Right_pane();}
        
        right_pane.removeAll();
    	right_pane.add(Box.createHorizontalStrut(16));
    	right_pane.add(comp);
    	
    	update(getGraphics());
    }
    public void callin_frame(Only_frame only_frame) {
    	this.only_frame = only_frame;
    }
   
    private class Right_pane extends Box_pane{
 
   	 boolean enter = false;
   	 boolean left = false;
   	 Image left_image = null;
   	 Image right_image = null;
   	
   	public Right_pane() {
   	 super(BoxLayout.X_AXIS);
   		
   		 setOpaque(false);
   		
   		 Init_content();
   		 Init_MouseListener();
   		 Init_MouseMotionListener();
   	}
   	
   	public void Init_content() {
   		
   	     left_image = new ImageIcon(getClass().getResource("/tool_image/chat_left.png")).getImage();
		 right_image = new ImageIcon(getClass().getResource("/tool_image/chat_right.png")).getImage();
	

   	}
   	
   	public void Init_MouseListener() {
   		
   		addMouseListener(new MouseAdapter() {
   		
  			 @Override
  				public void mousePressed(MouseEvent e) {
  					
  					left = !left;
  					set_left(left);	
  				   
  				    enter = false;
  				    repaint();
  				   
  				}
  		});
   	}
   	
   	public void Init_MouseMotionListener() {
   		
   	 addMouseMotionListener(new MouseMotionAdapter() {
			 @Override
			public void mouseMoved(MouseEvent e) {
				
				 int x = e.getX();
				 setCursor(cursor);
				 enter = true;
				 
				 if(x<5||x>12) {
					 enter = false;				
				 }
				 
				 repaint();
			}
		});
   	}
   		
    public void set_left(boolean left) {
   
    	if(left) {
    		left_comp.setVisible(false);
    		setDividerLocation(0);}
    	else {
    		left_comp.setVisible(true);
    		setDividerLocation(max_width);}
    	
    	if(left) {only_frame.set_Size(false,only_frame.get_frame_width()-max_width, only_frame.get_frame_height());}
		else {only_frame.set_Size(false,only_frame.get_frame_width()+max_width, only_frame.get_frame_height());}
   	 }
   	 
    @Override
   	protected void paintComponent(Graphics g) {
   	
   		super.paintComponent(g);
   		Graphics2D g2 = (Graphics2D) g;
   		
   		  g2.setComposite(AlphaComposite
   			    .getInstance(AlphaComposite.SRC_OVER, 1f));
   				  
   		if(enter&&left) {
   			g2.drawImage(right_image, 0,(getHeight()-90)/2, null);
   		}
   		
   		if(enter&&!left) {
   			g2.drawImage(left_image, 0, (getHeight()-90)/2, null);
   		}		     
   
  	    }}
}
