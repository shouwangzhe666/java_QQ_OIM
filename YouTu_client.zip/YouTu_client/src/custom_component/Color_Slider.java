package custom_component;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.metal.MetalSliderUI;

import jdk.internal.org.objectweb.asm.tree.analysis.Value;

public class Color_Slider extends JSlider{
	
	Color thumb_color = null;
	Color track_color = null;
	
	public Color_Slider() {
	   super(0, 300, 0);
	   setOpaque(false);
	   
		track_color = Color.lightGray;
		thumb_color = new Color(0, 131,245);
		
	   setUI(new Beauty_UI());
	   
	   addChangeListener(new ChangeListener() {
		
		@Override
		public void stateChanged(ChangeEvent e) {
			
			int value = getValue();
			int seg = value/50;
			value-=seg*50;
			value*=5.1;

			updat_thumb_color(seg, value);
		}
	});
	}
	
	public Color get_selected_color() {
		
		return thumb_color;
	}
	public void updat_thumb_color(int seg,int value) {
		
		if(seg==0) {thumb_color = new Color(255,value, 0);} //seg 0
		else if(seg==1) {thumb_color = new Color(255-value,255, 0);}
		
		if(seg==2) {thumb_color = new Color(0,255, value);} //seg 0
		else if(seg==3) {thumb_color = new Color(0,255-value, 255);}
		
		if(seg==4) {thumb_color = new Color(value,0, 255);} //seg 0
		else if(seg==5) {thumb_color = new Color(255,0, 255-value);}
	}
	
	public void set_thumb_color(Color thumb_color) {
		this.thumb_color = thumb_color;
		 setUI(new Beauty_UI());
	}
	public void set_track_color(Color track_color) {
		this.track_color = track_color;
	}
	
	private class  Beauty_UI extends MetalSliderUI{
		
		@Override
    	public void paintThumb(Graphics g) {
            //绘制指示物
    		Graphics2D g2d = (Graphics2D) g;
    		g2d.setColor(thumb_color);
    		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    		g2d.fillOval(thumbRect.x, thumbRect.y, thumbRect.width,
                    thumbRect.height);//修改为圆形
            //也可以帖图(利用鼠标事件转换image即可体现不同状态)
            //g2d.drawImage(image, thumbRect.x, thumbRect.y, thumbRect.width,thumbRect.height,null);

    
    	}
    	public void paintTrack(Graphics g) {
            //绘制刻度的轨迹
    		int cy,cw;
    		Rectangle trackBounds = trackRect;
    		if (slider.getOrientation() == JSlider.HORIZONTAL) {
    			Graphics2D g2 = (Graphics2D) g;
    			g2.setPaint(track_color);//将背景设为黑色
    			cy = (trackBounds.height/2) - 2;
    			cw = trackBounds.width;
    			
    			g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
    					RenderingHints.VALUE_ANTIALIAS_ON);
    			g2.translate(trackBounds.x, trackBounds.y + cy);
    			g2.fillRect(0, -cy + 5, cw, cy);
    			
    			int trackLeft = 0;
    			int trackRight = 0;
    			trackRight = trackRect.width - 1;

    			int middleOfThumb = 0;
    			int fillLeft = 0;
    			int fillRight = 0;
    			//换算坐标
    			middleOfThumb = thumbRect.x + (thumbRect.width / 2);
    			middleOfThumb -= trackRect.x;
    			
    			if (!drawInverted()) {
    				fillLeft = !slider.isEnabled() ? trackLeft : trackLeft + 1;
    				fillRight = middleOfThumb;
    				} else {
    				fillLeft = middleOfThumb;
    				fillRight = !slider.isEnabled() ? trackRight - 1
    				: trackRight - 2;
    				}
    			//设定渐变,在这里从红色变为红色,则没有渐变,滑块划过的地方自动变成红色
//    			g2.setPaint(new GradientPaint(0, 0,thumb_color, cw, 0,
//    					thumb_color, true));
//    			g2.fillRect(0, -cy + 5, fillRight - fillLeft, cy);
    					
    			g2.setPaint(new GradientPaint(0, 0,Color.red,100, 0,
    					Color.green, true));
    			g2.fillRect(0,0,100, cy);
    			
    			g2.setPaint(new GradientPaint(100, 0,Color.green, 200, 0,
    					Color.blue, true));
    			g2.fillRect(100,0,100, cy);
    			
    			g2.setPaint(new GradientPaint(200, 0,Color.blue, 300, 0,
    					Color.RED, true));
    			g2.fillRect(200,0,100, cy);
    			
    			g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
    			RenderingHints.VALUE_ANTIALIAS_OFF);
    			g2.translate(-trackBounds.x, -(trackBounds.y + cy));   					
    		}
    		else {
				super.paintTrack(g);
				}
    	}

	}
	
	public static void main(String[] args) {
		 
		 for(int i=0;i<300;i++) {
			 System.out.println(i/50);
		 }
	}
}
