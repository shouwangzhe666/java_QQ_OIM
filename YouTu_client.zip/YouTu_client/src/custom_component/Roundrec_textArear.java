package custom_component;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;

import javax.swing.JFrame;
import javax.swing.JTextArea;

import com.sun.xml.internal.stream.Entity;

import sun.swing.SwingUtilities2;

public class Roundrec_textArear extends JTextArea{

	boolean changeable = true;
	boolean focus=false;
	boolean focusalbe=true;
	int width=0;
	int height=0;
	float strok_width=0;
	Color default_color=null;
	Color focus_color = Color.lightGray;
	
	boolean watermark = false;
	String water_String = null;
	 Font font = null;
	 FontRenderContext frc = null;
	  
	public  Roundrec_textArear(int width,int height,float strok_width,Color default_border_color,Color focus_border_color,int font_size,Color font_color) {
		putClientProperty(SwingUtilities2.AA_TEXT_PROPERTY_KEY,null);
		setOpaque(false);
		setMargin(new Insets(5, 5, 5, 5));
		setLineWrap(true);
		
		this.width=width;
		this.height=height;
		this.strok_width=strok_width;
		this.default_color = default_border_color;
		if(focus_border_color!=null) {this.focus_color = focus_border_color;}
		
		font = new Font("宋体", Font.PLAIN, font_size);
		frc = new FontRenderContext(new AffineTransform(),true,true);
		 
		setFont(font);		
		setForeground(font_color);
		setSelectedTextColor(Color.white);
		setSelectionColor(new Color(51,153,255));
		
		 setPreferredSize(new Dimension(width,height));
		 setMaximumSize(new Dimension(width,height));
		 setMinimumSize(new Dimension(width,height));
		
		 Init_mouseListioner();
	}
	public void set_watermark(String watermark) {
		
		this.watermark = true;
		this.water_String = watermark;
		
	}

	public void Init_mouseListioner() {
		 this.addMouseListener(new MouseAdapter() {
	    	  
	    	  @Override
	    	public void mouseEntered(MouseEvent e) {
	    		
	    		  focus=true;
	  			  repaint();
	    	}
	    	  
	    	  @Override
	    	public void mouseExited(MouseEvent e) {
	    		  
	    		  focus=false;
	  			repaint();
	    	}
	    	  @Override
	    	public void mousePressed(MouseEvent e) {
	    	   System.out.println(getLineCount());
	    	}
		});
	}
	@Override
	public void setSize(int width, int height) {
		super.setSize(width, height);
		this.width = width;
		this.height = height;
		
		setPreferredSize(new Dimension(width,height));
		setMinimumSize(new Dimension(width,height));
		setMaximumSize(new Dimension(width,height));
	}
	public void set_focusable(boolean focusalbe) {
		this.focusalbe=focusalbe;
	}
	
	public void set_changeable(boolean changeable) {
		this.changeable = changeable;
	}
	
	@Override
	protected void paintBorder(Graphics g) {
		 super.repaint();
		 Graphics2D g2 = (Graphics2D) g;
		
		if(focusalbe) {
			
			if(changeable) {
				if(focus) {g2.setColor(focus_color);}
				else{g2.setColor(default_color);}
			}     //if changeable
			else{
				if(!focus) {g2.setComposite(AlphaComposite
	    			    .getInstance(AlphaComposite.SRC_OVER, 0.6f));}
				g2.setColor(default_color);
			} //if !changeable
		} //if focusalble
		 
		else {
			g2.setColor(default_color);
		} // !focusalble
		
		  g2.setStroke(new BasicStroke(strok_width));
		  		 
		  g2.drawRoundRect(1,1, width-2, height-2, 5, 5);
		  
		  if(watermark&&getText().trim().length()==0) {
			  g2.drawString(water_String, 10,20);
		  }
	}
	
	@Override
	public int getLineCount() {
		
		String[] all_text = getText().split("\n");

		String text = null;
		int width = 0;
		int rows = 0;
		int line_count = 0;
		
		for(int i=0;i<all_text.length;i++) {
			text = all_text[i];
			width = (int) font.getStringBounds(text, frc).getBounds().getWidth();
			rows = width/this.width+1;
			line_count+=rows;
		
		}

		return line_count;
 }
	
 public static void main(String[] args) {
	 
	  Roundrec_textArear textArear = new Roundrec_textArear(350, 150, 2f, Color.gray, Color.blue, 20, Color.black);
	  
	  JFrame jFrame = new JFrame();
	  jFrame.getContentPane().setLayout(new FlowLayout());
	  jFrame.getContentPane().add(textArear);
	  jFrame.setBounds(500, 500, 500, 500);
	  jFrame.setVisible(true);
}
}
