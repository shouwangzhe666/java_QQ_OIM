package custom_component;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import sun.swing.SwingUtilities2;

public class Roundrec_textFiled extends JTextField{
     
	boolean focusalbe=true;
	boolean changeable = true;
	boolean focus=false;
	
	int width=0;
	int height=0;
	float strok_width=0;
	Color default_color=null;
	Color focus_color = Color.lightGray;
	boolean watermark = false;
	String water_String = null;
	
	public  Roundrec_textFiled(int width,int height,float strok_width,Color default_border_color,Color focus_border_color,int font_size,Color font_color) {
		putClientProperty(SwingUtilities2.AA_TEXT_PROPERTY_KEY,null);
		setOpaque(false);
		setMargin(new Insets(0, 5, 0, 5));
		
		this.width=width;
		this.height=height;
		this.strok_width=strok_width;
		this.default_color = default_border_color;
		if(focus_border_color!=null) {this.focus_color = focus_border_color;}
		
		setFont(new Font("宋体", Font.PLAIN, font_size));
		setForeground(font_color);
		setSelectedTextColor(Color.white);
		setSelectionColor(new Color(51,153,255));
		
		 setPreferredSize(new Dimension(width,height));
		 setMaximumSize(new Dimension(width,height));
		 setMinimumSize(new Dimension(width,height));
	
		 Init_mouseListioner();
	}
public void set_watermark(String watermark) {
		
		this.watermark = true;
		this.water_String = watermark;
		
	}
public void Init_mouseListioner() {
	 this.addMouseListener(new MouseAdapter() {
   	  
   	  @Override
   	public void mouseEntered(MouseEvent e) {
   		
   		      focus=true;
 			  repaint();
   	}
   	  
   	  @Override
   	public void mouseExited(MouseEvent e) {
   		  
   		    focus=false;
 			repaint();
   	}
	});
}
	public void set_focusable(boolean focusalbe) {
		this.focusalbe=focusalbe;
	}
	
	public void set_changeable(boolean changeable) {
		this.changeable = changeable;
	}

	
	@Override
	protected void paintBorder(Graphics g) {
	//      super.paintBorder(g);
	      
		 Graphics2D g2 = (Graphics2D) g;
		      
		if(focusalbe) {
			
			if(changeable) {
				if(focus) {g2.setColor(focus_color);}
				else{g2.setColor(default_color);}
			}     //if changeable
			else{
				if(!focus) {g2.setComposite(AlphaComposite
	    			    .getInstance(AlphaComposite.SRC_OVER, 0.6f));}
				g2.setColor(default_color);
			} //if !changeable
		} //if focusalble
		 
		else {
			g2.setColor(default_color);
		} // !focusalble
		
		  g2.setStroke(new BasicStroke(strok_width));
		  		 
		  g2.drawRoundRect(1,1, width-2, height-2, 5, 5);
		 
		  if(watermark&&getText().length()==0) {
			  g2.drawString(water_String, 10,20);
		  }
	}
	
	public static void main(String[] args) {
		
		JTextField textField1 = new JTextField("这是一个JTextField文本框");
		Roundrec_textFiled textFiled2 = new Roundrec_textFiled(165, 25, 2f, Color.gray, new Color(0, 181, 245), 18, Color.black);
		textFiled2.set_watermark("请输入内容：");
		textFiled2.set_focusable(true);
		textFiled2.set_changeable(false);
		
		  JFrame jFrame = new JFrame();
		  jFrame.getContentPane().setLayout(new FlowLayout());
		  jFrame.getContentPane().add(textField1);
		  jFrame.getContentPane().add(textFiled2);
		  jFrame.setBounds(500, 200, 500, 500);
		  jFrame.setVisible(true);
	}
}
