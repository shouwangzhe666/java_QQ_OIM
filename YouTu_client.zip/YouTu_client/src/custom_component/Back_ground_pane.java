package custom_component;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException; 
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import message_login_register.Background_Record;
import net.coobird.thumbnailator.Thumbnails;
import net.coobird.thumbnailator.geometry.Positions;
import tools.Icon_tools;

public class Back_ground_pane extends JPanel{
    
	static BufferedImage root_bufferedImage = null;
	static BufferedImage ori_bufferedImage = null;
	static BufferedImage bufferedImage = null;
	
	 static int load_x = 0;
	 static int load_y = 0;
	
	static int back_Oposity = 255;
	static boolean show_back_image = true;
	static boolean flash = false;
	static boolean show_all_image = false;
	static float white_value = 0;
	static int show_image_height = 40;
	static Color back_color = null;
	static  JLabel loeading_com = null;
	
	public Back_ground_pane(int show_image_height) {
		
	    setOpaque(false);
        back_color = Color.white;
        Back_ground_pane.show_image_height = show_image_height;
        
		loeading_com = new JLabel(new ImageIcon(getClass().getResource("/main_frame_image/loading.gif")));		
		update_loadcom_location();
		this.add(loeading_com);          
		loeading_com.setVisible(false);
		
	 if(root_bufferedImage==null) {	
	    Background_Record record = Background_Record.get_record();	
	    show_all_image = record.isTotal();
	    
	    if(record.isImage()) {	    	
	    	 ImageIcon background = record.getBackground();	    
	 	     change_external_background(background);	  
	 	
	    }
	    
	    else {
	    
	    	int r = record.getR();
	    	int g = record.getG();
	    	int b = record.getB();
	    	set_background_color(255, r, g, b);	  
	    }
	    
	    int opatity = record.getOpatity();
	    int white = record.getWhite();
	    int bright = record.getBriter();
	    	   
	    set_brightness(bright);
	    set_back_Oposity(opatity);
	    set_white_value(white);    
	 }  // if(root_bufferedImage==null) {	
	    	    
	}

	public static void show_all_image(boolean show_all_image) {
		
		Back_ground_pane.show_all_image = show_all_image;
	}
	
	public static void set_white_value (int white_value) {
         // max value is 100
		   Back_ground_pane.white_value = (float)white_value/100;
	//	  repaint();
	}
	
	public static void set_background_color(int a,int r,int g,int b) {
		
		Back_ground_pane.show_back_image = false;
		Back_ground_pane.back_color = new Color(r, g, b, a);
	//	repaint();
	
	}
	
	public static void set_back_Oposity(int back_Oposity) {
		
		Back_ground_pane.back_Oposity = back_Oposity;
		
		if(show_back_image) {set_image_Oposity(back_Oposity);}
		else {
			int r = check_ARGB(back_color.getRed());
			int g = check_ARGB(back_color.getGreen());
			int b = check_ARGB(back_color.getBlue());
			Back_ground_pane.back_color = new Color(r, g, b, back_Oposity);
		}
	//	repaint();
	}
	public static void set_brightness(int adjust_brightness) {
		
		if(show_back_image) {
			set_brightness(ori_bufferedImage, adjust_brightness);
		}
		else {
			
			int r = check_ARGB(back_color.getRed()+adjust_brightness);
			int g = check_ARGB(back_color.getGreen()+adjust_brightness);
			int b = check_ARGB(back_color.getBlue()+adjust_brightness);
			
			Back_ground_pane.back_color = new Color(r, g, b, back_Oposity);
		}
	}
	
	public static int check_ARGB(int argb) {
		
		if(argb<0) {return 0;}
		if(argb>255) {return 255;}
		
		return argb;
	}
	
	public static void set_image_Oposity(int back_Oposity ) {
		
		 BufferedImage back= null;
			
	     try {
	         //创建一个包含透明度的图片,半透明效果必须要存储为png合适才行，存储为jpg，底色为黑色
	     	back = new BufferedImage(root_bufferedImage.getWidth(), root_bufferedImage.getHeight(), BufferedImage.TYPE_INT_ARGB);
	     	
	         int width = root_bufferedImage.getWidth();  
	         int height = root_bufferedImage.getHeight();  
	         int rgb = 0 ;
	         Color color1 = null;
	         Color color2 = null;
             
	         for (int x = 0; x < width; x++) { 
	             for (int y = 0; y < height; y++) { 
	            	 
	                  rgb = root_bufferedImage.getRGB(x,y);
	                  color1 = new java.awt.Color(rgb);
	                  
	                int a = back_Oposity;
	                int r = color1.getRed();
	                int g = color1.getGreen();
	                int b = color1.getBlue();
	        		
	                if(y<show_image_height) {a = check_ARGB(2*back_Oposity);}
	                
	                color2 = new Color(r, g, b, a);
	                back.setRGB(x,y,color2.getRGB());
	             }
	         }
	       
	     } catch (Exception e) {
	         e.printStackTrace();
	       
	     }
	     Back_ground_pane.ori_bufferedImage = back;
	}
	
	public static void set_brightness(BufferedImage root_bufferedImage,int adjust_brightness) {
		
		  BufferedImage back= null;
			
		     try {
		         //创建一个包含透明度的图片,半透明效果必须要存储为png合适才行，存储为jpg，底色为黑色
		     	back = new BufferedImage(root_bufferedImage.getWidth(), root_bufferedImage.getHeight(), BufferedImage.TYPE_INT_ARGB);
		         int width = root_bufferedImage.getWidth();  
		         int height = root_bufferedImage.getHeight();  
		         for (int j = 0; j < height; j++) { 
		             for (int i = 0; i < width; i++) { 
		                 int rgb = root_bufferedImage.getRGB(i, j);
		                java.awt.Color color = new java.awt.Color(rgb);
		                int a = color.getAlpha();
		                int r = check_ARGB(color.getRed()+adjust_brightness);
		                int g = check_ARGB(color.getGreen()+adjust_brightness);
		                int b = check_ARGB(color.getBlue()+adjust_brightness);
		        		
		                java.awt.Color newcolor = new Color(r, g, b, a);
		                 back.setRGB(i,j,newcolor.getRGB());
		             }
		         }
		       
		     } catch (Exception e) {
		         e.printStackTrace();
		       
		     }
		     Back_ground_pane.ori_bufferedImage = back;
	}
	
	public void set_flash(boolean flash) {
		
		Back_ground_pane.flash = flash;
		
	if(flash) {	
		     
		      loeading_com.setVisible(true);
		      update_loadcom_location();
		}
	else {
		
		 loeading_com.setVisible(false);
		}	
	 //     repaint();
	}
	
	public static void change_external_background(ImageIcon background) {
//		System.out.println("background.getIconWidth()="+background.getIconWidth());
//		System.out.println("background.getIconHeight()="+background.getIconHeight());
//		
		Back_ground_pane.show_back_image = true;
		Back_ground_pane.root_bufferedImage = new BufferedImage(background.getIconWidth(), background.getIconHeight(), BufferedImage.TYPE_4BYTE_ABGR);
		
		Graphics2D g2 = (Graphics2D) root_bufferedImage.getGraphics();
		g2.drawImage(background.getImage(),0,0,null);
		
		Back_ground_pane.ori_bufferedImage = Icon_tools.copy_buffedImage(root_bufferedImage);
		
	//	repaint();
	}
	
	public void capture_background() {
		
		int width = getWidth();
		int height = getHeight();
				
			try {
				bufferedImage = Thumbnails.of(ori_bufferedImage).scale(1f).sourceRegion(Positions.TOP_LEFT, width, height).asBufferedImage();
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}			
	}
	
  public void update_loadcom_location() {
	  
	    load_x = (getWidth()-125)/2;
		load_y = (getHeight()-125)/2-60;
		loeading_com.setBounds(load_x,load_y, 124, 124);
  }
	@Override
	protected void paintComponent(Graphics g) {		
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
			
		if(show_all_image) {Back_ground_pane.show_image_height=getHeight();}
		
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,white_value));
		g2.setColor(Color.white);
		
	    if(show_all_image) {g2.fillRect(0, 0, getWidth(), getHeight());}	    
	    else {g2.fillRect(0,Back_ground_pane.show_image_height, getWidth(), getHeight()-Back_ground_pane.show_image_height);}	    
	    
	    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,1f));
	    
		if(show_back_image) {
	      capture_background();
		  g2.drawImage(bufferedImage, 0, 0,null);					
		}
		else {
		
			int r = back_color.getRed();
			int gg = back_color.getGreen();
			int b = back_color.getBlue();
			int a = back_color.getAlpha();
			    a = check_ARGB(2*a);
			    
			g2.setColor(new Color(r, gg, b, a));
			g2.fillRect(0, 0, getWidth(), show_image_height);
			
			g2.setColor(back_color);
			g2.fillRect(0,show_image_height, getWidth(), getHeight()-show_image_height);
		}
		if(flash) { update_loadcom_location();}
		
	} // paintComponent
	
	public static void main(String[] args) {
		
		Background_Record record = Background_Record.get_record();	  	    
		ImageIcon background = record.getBackground();
		System.out.println(background==null);
	}	
}
