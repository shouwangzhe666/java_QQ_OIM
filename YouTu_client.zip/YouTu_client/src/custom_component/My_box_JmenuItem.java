package custom_component;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;

import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;

import Frame.Login_frame;

public class My_box_JmenuItem extends JCheckBoxMenuItem{

	Image unselect_image = null;
	Image select_image = null;
			
	boolean enter = false;
	
	Color back_color = null;
	Color enter_color = null;
	Font font = null;
	String text = null;
	FontRenderContext frc = null;
	int width = 0 ;
	int height = 0;
	
	public My_box_JmenuItem(boolean select,String text) {
	        super(text, select);
	        setOpaque(false);
	        
	        unselect_image = new ImageIcon(getClass().getResource("/login_image/box_gray.png")).getImage();
	        select_image = new ImageIcon(getClass().getResource("/login_image/box_green.png")).getImage();
	        
	        back_color = new Color(0, 180, 245);
	        enter_color = new Color(0, 131, 245);
	        font = new Font("宋体", Font.PLAIN,16);
	        this.text = text;
	        
	        frc = new FontRenderContext(new AffineTransform(),true,true);
	   	    Rectangle rec = font.getStringBounds(text, frc).getBounds();
	   	    width = (int) (rec.getWidth()+40);
	   	    height = (int) (rec.getHeight()+10);
	   	    
	        setPreferredSize(new Dimension(width,height));
	        setMinimumSize(new Dimension(width,height));
	        setMaximumSize(new Dimension(width,height));
	        
	        addMouseListener(new MouseAdapter() {
				
				@Override
				public void mouseEntered(MouseEvent e) {
					enter = true;
					repaint();
				}
				
				@Override
				public void mouseExited(MouseEvent e) {
					enter = false;
					repaint();
				}
				
				@Override
				public void mousePressed(MouseEvent e) {
					
					enter = false;
				}
			});
	}
	
	@Override
	protected void paintComponent(Graphics g) {
	//	super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;				
		
		if(enter) {	g2.setColor(back_color);}
		else {g2.setColor(Color.white);}
		
		g2.fillRect(0, 0,width, height);
		
		if(isSelected()) {g2.drawImage(select_image, 3, 3, null);}
		else {g2.drawImage(unselect_image, 3, 3, null);}
		
		g2.setFont(font);
		
		if(enter) {g2.setColor(Color.white);}
		else{g2.setColor(Color.BLACK);}
		
		g2.drawString(text, 30, 20);
	}
}
