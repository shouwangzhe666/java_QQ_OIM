package custom_component;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

public class My_ListCellRenderer  implements ListCellRenderer<Object>{
	Color blue = null;
	Color white = null;
	
	 public My_ListCellRenderer() {
		
		 blue = new Color(35,134,235);
		 white = Color.white;
	}
	
	@Override
	public Component getListCellRendererComponent(JList<? extends Object> list, Object value, int index,
			boolean isSelected, boolean cellHasFocus) {
		
		String string = (String) value;
		JLabel jl = new JLabel(string);
		jl.setOpaque(true);
		jl.setFont(new Font("微软雅黑", Font.PLAIN, 16));
		
		jl.setHorizontalAlignment(JLabel.CENTER);
		
		if(isSelected) {

			jl.setBackground(blue);
			jl.setForeground(white);
		   
		}
		else {

			jl.setForeground(blue);
			jl.setBackground(white);
		}
					
		return jl;
	}
}
