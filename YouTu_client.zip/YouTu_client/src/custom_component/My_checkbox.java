package custom_component;

import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class My_checkbox extends JCheckBox{

	ImageIcon imageIcon1=null;
	ImageIcon imageIcon2=null;
	
	public My_checkbox(boolean select) {
	
		imageIcon1 = new ImageIcon(getClass().getResource("/login_image/box_gray.png"));
		imageIcon2 = new ImageIcon(getClass().getResource("/login_image/box_green.png"));

		
		setContentAreaFilled(false);
		setBorderPainted(false);
		setBorder(null);
		
		setIcon(imageIcon1);
		setSelectedIcon(imageIcon2);
		
		setDisabledIcon(imageIcon1);
		setDisabledSelectedIcon(imageIcon2);
		
		setSelected(select);
	}
	
public static void main(String[] args) {
		
		  JFrame jFrame = new JFrame();
		  jFrame.getContentPane().setLayout(new FlowLayout());
		  jFrame.getContentPane().add(new JCheckBox());
		  jFrame.getContentPane().add(new My_checkbox(true));
		  jFrame.setBounds(500, 200, 500, 500);
		  jFrame.setVisible(true);
	}
}
