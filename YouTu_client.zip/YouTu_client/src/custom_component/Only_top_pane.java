package custom_component;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;

import javax.swing.*;
public class Only_top_pane extends JPanel{

	ArrayList<Component> left_componnet = null;
	ArrayList<Component> right_componnet = null;
	
	Image window_icon = null;
	String title = null;
	Color title_color = null;
	Font font = null;
	FontRenderContext frc = null;
	int title_x = 0;
	Title_button title_button = null;
	String link_account=null;
	String link_name=null;
	int frame_width = 0;
	
	public Only_top_pane() {
	    
		BoxLayout boxLayout = new BoxLayout(this, BoxLayout.X_AXIS);
		setLayout(boxLayout);
		
		left_componnet = new ArrayList<>();
		right_componnet = new ArrayList<>();
		
		window_icon = new ImageIcon(getClass().getResource("/main_frame_image/logo_main_frame.png")).getImage();
		title = "窗口";
		title_color = Color.black;
		font = new Font("微软雅黑", Font.PLAIN, 18);
		frc = new FontRenderContext(new AffineTransform(),true,true);
	}
	
	public void set_window_Icon(ImageIcon window_icon) {
		this.window_icon = window_icon.getImage();
		repaint();
	}
	
	public void set_window_title(String title,Font title_font,Color title_color) {
		
		 this.title = title;
		 this.font = title_font;
		 this.title_color = title_color;
		 repaint();
	}
	public void delete_allComponnets() {
		removeAll();
		left_componnet = new ArrayList<>();
		right_componnet = new ArrayList<>();
	}
	public void update_title_posion() {
		
		Rectangle rec = font.getStringBounds(title, frc).getBounds();
			
		int	str_width= rec.width;
	
		title_x = (getWidth()-str_width)/2;
	}
	public void add_title_button() {
		  this.title_button = new Title_button();
	}
	public void update_title_button(int frame_width) {
          this.frame_width = frame_width;
		  update_title_button(link_account, link_name);
	}
	public void update_title_button(String link_account,String link_name) {
	     if(this.title_button==null||link_account==null) {return;}
		
	     this.link_account = link_account;
	     this.link_name = link_name;
	     
		   title_button.update(link_account, link_name);
		   int title_width = title_button.get_buttonWidth();
		   int left_gap = (frame_width-250-title_width)/2+105;
		 
		   if(title_button!=null) {
			   left_componnet = new ArrayList<>();
			   left_componnet.add(Box.createHorizontalStrut(left_gap));
			   left_componnet.add(title_button);
			   update_all_componnets();
		   }
	}
	public void add_left_component(Component jComponent) {
		left_componnet.add(jComponent);
		update_all_componnets();
		repaint();
	}
	
	public void add_right_component(Component jComponent) {
		right_componnet.add(jComponent);
		update_all_componnets();
		repaint();
	}
	
	public void update_all_componnets() {
		
		removeAll();
		add(Box.createHorizontalStrut(35));
		
		Component jComponent = null;
		for(int i=0;i<left_componnet.size();i++) {
			jComponent = left_componnet.get(i);
			add(Box.createHorizontalStrut(5));
			add(jComponent);
		}
		
		add(Box.createHorizontalGlue());
		
		for(int i=right_componnet.size()-1;i>-1;i--) {
			jComponent = right_componnet.get(i);
			add(Box.createHorizontalStrut(5));
			add(jComponent);
		}
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		g2.drawImage(window_icon, 5, 5, null);
		
		update_title_posion();
		
		g2.setColor(title_color);
		g2.setFont(font);
		g2.drawString(title, title_x, 20);
	}
	
	public static void main(String[] args) {
		
		 Icon_button face_button = new Icon_button(Icon_button.class.getResource("/tool_image/face.png"),"表情");						
		 Icon_button icon_button = new Icon_button(Icon_button.class.getResource("/tool_image/image.png"),"图片");
		 Icon_button file_button = new Icon_button(Icon_button.class.getResource("/tool_image/file.png"),"文件");
	     
		 Icon_button min_button = new Icon_button(Only_top_pane.class.getResource("/window_top_image/window_min_dark_normal.png"),"最小化");		
		 Icon_button max_button = new Icon_button(Only_top_pane.class.getResource("/window_top_image/window_max_dark_normal.png"),"最大化");	
		 Icon_button quite_button = new Icon_button(Only_top_pane.class.getResource("/window_top_image/window_close_dark_normal.png"), "关闭");
			
		 Only_top_pane top_pane = new Only_top_pane();
		 top_pane.setPreferredSize(new Dimension(500,30));
		 top_pane.add_left_component(face_button);
		 top_pane.add_left_component(icon_button);
		 top_pane.add_left_component(file_button);
		 top_pane.add_right_component(quite_button);
		 top_pane.add_right_component(max_button);
		 top_pane.add_right_component(min_button);
		 
		  JFrame jFrame = new JFrame();
		  jFrame.getContentPane().setLayout(new FlowLayout());
		  jFrame.getContentPane().add(top_pane);
		  jFrame.setBounds(500, 200, 600, 500);
		  jFrame.setVisible(true);
	}
}
