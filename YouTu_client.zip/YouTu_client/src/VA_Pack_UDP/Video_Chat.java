package VA_Pack_UDP;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;

import javax.media.CannotRealizeException;
import javax.media.Codec;
import javax.media.Control;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.Format;
import javax.media.Manager;  
import javax.media.MediaLocator;
import javax.media.NoDataSourceException;
import javax.media.NoPlayerException;
import javax.media.NoProcessorException;
import javax.media.Owned;
import javax.media.Player;
import javax.media.Processor;
import javax.media.RealizeCompleteEvent;
import javax.media.control.QualityControl;
import javax.media.control.TrackControl;
import javax.media.format.AudioFormat;
import javax.media.format.UnsupportedFormatException;
import javax.media.format.VideoFormat;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.DataSource;
import javax.media.protocol.PushSourceStream;
import javax.media.protocol.SourceCloneable;
import javax.media.rtp.GlobalReceptionStats;
import javax.media.rtp.InvalidSessionAddressException;
import javax.media.rtp.Participant;
import javax.media.rtp.RTPManager;
import javax.media.rtp.ReceiveStream;
import javax.media.rtp.ReceiveStreamListener;
import javax.media.rtp.RemoteListener;
import javax.media.rtp.SendStream;
import javax.media.rtp.SessionAddress;
import javax.media.rtp.SessionListener;
import javax.media.rtp.SessionManager;
import javax.media.rtp.event.ByeEvent;
import javax.media.rtp.event.InactiveReceiveStreamEvent;
import javax.media.rtp.event.NewParticipantEvent;
import javax.media.rtp.event.NewReceiveStreamEvent;
import javax.media.rtp.event.RTPEvent;
import javax.media.rtp.event.ReceiveStreamEvent;
import javax.media.rtp.event.RemoteCollisionEvent;
import javax.media.rtp.event.RemoteEvent;
import javax.media.rtp.event.RemotePayloadChangeEvent;
import javax.media.rtp.event.SessionEvent;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.text.AbstractDocument.BranchElement;

import Frame.Main_Frame;
import Message.Private.Apply_Message;
import jmapps.rtp.SessionControlDialog;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;
import udp_pack.UDP_P4P_Client;

public class Video_Chat implements Runnable{  
	 SessionAddress localaddr1 = null;
	 SessionAddress remoteaddr1 = null;
	 SessionAddress localaddr2 = null;
	 SessionAddress remoteaddr2 = null;
	 RTPManager videoRTPManager = null;
	 RTPManager audioRTPManager = null;
	 SendStream video_SendStream = null;
	 SendStream audio_SendStream = null;
	 
	 Format videoFormat = null;
	 Format audioFormat = null;
	 Processor video_processor = null;
	 Processor audio_processor = null;
	 Clone_tool clone_tool = null;
    
	 DataSource ori_videodatasourse = null;
     DataSource video_datasourse = null;
     DataSource audio_datasourse = null;
    
     InetAddress local_address = null;
     InetAddress remote_address = null;
     int[] ports = null;
    
     int sourse_num = 0;
     int bye_num = 0;
    
     JPopupMenu popupMenu = null;
     JMenuItem change_item = null;
     JMenuItem flush_item = null;
 
     boolean isTransfer = false;
     volatile boolean self = true;
     Component self_comp = null;
     Component other_comp = null;
     Object sync = new Object();
     boolean ready = false; 
     long time = 0l;
     int server_port = 0;
     int link_count = 0;
     JFrame jFrame = null;
    
    public Video_Chat(int server_port,int link_account) {
    	
    	 this.server_port = server_port;
    	 this.link_count = link_account;
    	 time = System.currentTimeMillis();
    	 
    	 jFrame = new JFrame();
    	 jFrame.setTitle("视频通话正在连接中...");  
    	 jFrame.setBounds(500, 100,850, 600);  
    	 jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);  
        
    	 jFrame.addWindowListener(new WindowAdapter() {
        	@Override
        	public void windowClosing(WindowEvent e) {
        		Apply_Message apply_Message = get_flushApplyMessage();
        		apply_Message.setType(5);
        		Private_Chat_Client.send_message(apply_Message);
        		
        		close_video_chat();
        	}
		});
    	 
    }
    
    @Override
	public void run() {
    //	 time = System.currentTimeMillis();
   	     Create_Processor();
//   	  System.out.println(System.currentTimeMillis()-time);
  // 	  time = System.currentTimeMillis();
   	  
         Configure__Processor();
 //        System.out.println(System.currentTimeMillis()-time);
  // 	  time = System.currentTimeMillis();
   	  
         start_processor();
 //        System.out.println(System.currentTimeMillis()-time);
   //	    time = System.currentTimeMillis();
   	  
 //  	  Init_comp_listioner(self_comp);
  // 	  System.out.println(System.currentTimeMillis()-time);
//	  time = System.currentTimeMillis();
	  
	  UDP_P4P_Client udp_P4P_Client =  new UDP_P4P_Client(server_port,true);
		
		int[] ports = udp_P4P_Client.get_ports(60);
		String remote_ip = udp_P4P_Client.get_remoteIP();
		
		if(remote_ip==null) {
			new Warn_frame("提示", "视频通话连接异常").set_aYouTu_click(5);
			video_processor.close();
			audio_processor.close();
			return;
		}
		
		   isTransfer = true;
  	 
	        try {
				this.local_address = InetAddress.getLocalHost();
				this.remote_address = InetAddress.getByName(remote_ip);
				this.ports = ports;
			} catch (UnknownHostException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}  
	        
        Init_RTPManeger();
        
 //     System.out.println(System.currentTimeMillis()-time);
//	    time = System.currentTimeMillis();
    
 //     System.out.println("正在连接中。。。。");
}
    
    public void Create_Processor() {
    
    	DataSource dataSource = null;
    	
    while(true){
    	try {
    		ori_videodatasourse = Manager.createDataSource(new MediaLocator("vfw://0"));
		} catch (NoDataSourceException e1) {
			 continue;
		//	e1.printStackTrace();
		} catch (IOException e1) {
			continue;
		//	e1.printStackTrace();
		}
             break;
    	}
    
    	clone_tool = new Clone_tool();
    	dataSource = Manager.createCloneableDataSource(ori_videodatasourse);
    	clone_tool.getVisualComponent(dataSource,true);
    	self_comp = clone_tool.getVisualComponent(((SourceCloneable)dataSource).createClone(),false);
    	Init_comp_listioner(self_comp);
    	
//    	 System.out.println(System.currentTimeMillis()-time);
//    	 time = System.currentTimeMillis();
    	 
             try {
				video_processor = Manager.createProcessor(((SourceCloneable)dataSource).createClone());
				audio_processor = Manager.createProcessor(new MediaLocator("javasound://44100"));
			} catch (NoProcessorException e) {
				e.printStackTrace();
				System.err.print("获取摄像头失败，请检查摄像头是否正确连接。");
			} catch (IOException e) {
				e.printStackTrace();
				System.err.print("获取摄像头失败，请检查摄像头是否正确连接。");
			}           
 
             change_pane(true);
             jFrame.setVisible(true);
    }
    public void Configure__Processor() {
    	
    	waitForState(video_processor, javax.media.Processor.Configured);  
        waitForState(audio_processor, javax.media.Processor.Configured);  
        
        Configure_VideoProcessor();
        Configure_Audio_Processor();
        
        waitForState(video_processor, javax.media.Processor.Realized);  
        waitForState(audio_processor, javax.media.Processor.Realized); 
        
        setJPEGQuality(0.5f);
        
        video_datasourse = video_processor.getDataOutput();
        audio_datasourse = audio_processor.getDataOutput();
    }
    /** 初始化启动摄像头 */  
    public void start_processor() {
 	   
 	   video_processor.prefetch();
 	   video_processor.start();
 	   audio_processor.prefetch();
 	   audio_processor.start();
    }
   
    public void Init_RTPManeger() {  
    	   
	      localaddr1 = new SessionAddress(local_address,ports[0], local_address, ports[1]);
		  remoteaddr1 = new SessionAddress(remote_address,ports[4], remote_address,ports[5]);
		  localaddr2 = new SessionAddress(local_address,ports[2], local_address, ports[3]);
		  remoteaddr2 = new SessionAddress(remote_address,ports[6], remote_address,ports[7]);
		  
		  flush_video_chat();
 }   
   
    public void close_video_chat() {
    	
    	if(video_SendStream!=null) {video_SendStream.close();video_SendStream=null;}
    	if(audio_SendStream!=null) {audio_SendStream.close();audio_SendStream=null;}
    	if(videoRTPManager!=null)  {videoRTPManager.dispose();videoRTPManager=null;}
    	if(audioRTPManager!=null)  {audioRTPManager.dispose();audioRTPManager=null;}
    	 
    	 video_processor.close();
    	 audio_processor.close();
    	 clone_tool.close_sourse();
    	 
    	 jFrame.dispose();
    	 Main_Frame.set_Video_Chat(null);
    	 Audio_Chat.ReleaseVAOccupy();
    }
   public void flush_video_chat() {    	
	   
	   sourse_num = 0;
	   
    	if(video_SendStream!=null) {video_SendStream.close();}   	
    	if(videoRTPManager!=null) { videoRTPManager.dispose();}
    	if(audio_SendStream!=null) {audio_SendStream.close();}   	
    	if(audioRTPManager!=null) { audioRTPManager.dispose();}
    	
		 videoRTPManager = RTPManager.newInstance();			
		 videoRTPManager.addFormat(videoFormat, 73);	   
		 audioRTPManager = RTPManager.newInstance();			
		 audioRTPManager.addFormat(audioFormat, 73);

			try {
				videoRTPManager.initialize(localaddr1);
				videoRTPManager.addTarget(remoteaddr1);
				audioRTPManager.initialize(localaddr2);
				audioRTPManager.addTarget(remoteaddr2);
			} catch (InvalidSessionAddressException | IOException e1) {
				// TODO AYouTu-generated catch block
				e1.printStackTrace();
			}									
				
			 videoRTPManager.addReceiveStreamListener(get_ReceiveStreamListener());		 
			 audioRTPManager.addReceiveStreamListener(get_ReceiveStreamListener());
			 
		 try {
			video_SendStream = videoRTPManager.createSendStream(video_datasourse,0);			
			video_SendStream.start();		
			audio_SendStream = audioRTPManager.createSendStream(audio_datasourse,0);			
			audio_SendStream.start();		
		} catch (UnsupportedFormatException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
    }
 
   public void Init_comp_listioner(Component component) {
	   
	   popupMenu = new JPopupMenu();
	   
	   flush_item = new JMenuItem("刷新通话");
	   popupMenu.add(flush_item);
	   change_item = new JMenuItem("切换图像");
	   popupMenu.add(change_item);
	   
	   component.addMouseListener(new MouseAdapter() {
		   @Override
		public void mousePressed(MouseEvent e) {
		       if(e.getButton()==3) {
		    	   popupMenu.show(component, e.getX(), e.getY());
		       }
		}
	});
	   	   
	   flush_item.addMouseListener(new MouseAdapter() {
		   @Override
		public void mousePressed(MouseEvent e) {			  			   
			   Apply_Message apply_Message = get_flushApplyMessage();
			   Private_Chat_Client.send_message(apply_Message);
			   
			   flush_video_chat();
		}
	});
	   change_item.addMouseListener(new MouseAdapter() {
		   @Override
		public void mousePressed(MouseEvent e) {
			    self = !self;
			    change_pane(self);
		}
	});
   }
   public void change_pane(boolean self) {
	    
	    Dimension dimension =  jFrame.getSize();
	    if(self) {
	    	 jFrame.getContentPane().removeAll();
	    	 jFrame.getContentPane().add(self_comp);
	    	 jFrame.setSize((int)dimension.getWidth()+5,(int)dimension.getHeight()+5);	
	    }
	    else if(other_comp!=null){
	    	 jFrame.getContentPane().removeAll();
	    	 jFrame.getContentPane().add(other_comp);
	    	 jFrame.setSize((int)dimension.getWidth()-5,(int)dimension.getHeight()-5);	
	    }
	   
   }
   public boolean Configure_VideoProcessor() {
	   TrackControl[] tracks = video_processor.getTrackControls();  
      
       if (tracks == null || tracks.length ==0) {return false;}
       
       ContentDescriptor cd = new ContentDescriptor(ContentDescriptor.RAW_RTP);  
       video_processor.setContentDescriptor(cd);  
       
       Format ori_Format = null;
       videoFormat = null;
       Format supportedFormats[] = null;        
       boolean atLeastOneTrack = false;  
       
	   for (int i = 0; i < tracks.length; i++) {  
           if (tracks[i].isEnabled()) { 
        	   
        	   ori_Format = tracks[i].getFormat();
               supportedFormats = tracks[i].getSupportedFormats();  
            
               if (supportedFormats.length > 0) {  
                     
            	   videoFormat = checkForVideoSizes(ori_Format, supportedFormats);
                   tracks[i].setFormat(videoFormat);                                
                   atLeastOneTrack = true;  
               } //if
       } // if
      } // for
	   return atLeastOneTrack;
   }
   public boolean Configure_Audio_Processor() {
	   TrackControl[] tracks = audio_processor.getTrackControls();  
      
       if (tracks == null || tracks.length ==0) {return false;}
       
       ContentDescriptor cd = new ContentDescriptor(ContentDescriptor.RAW_RTP);  
       audio_processor.setContentDescriptor(cd);  
       
       Format ori_Format = null;
       audioFormat = null;
       Format supportedFormats[] = null;        
       boolean atLeastOneTrack = false;  

	   for (int i = 0; i < tracks.length; i++) {  
           if (tracks[i].isEnabled()) { 
        	   
        	   ori_Format = (AudioFormat) tracks[i].getFormat();
               supportedFormats = tracks[i].getSupportedFormats();  
            
               if (supportedFormats.length > 0) {  
                    
            	    audioFormat = checkFor_AudioFormat(ori_Format, supportedFormats);
         //    	    System.out.println(chosen_Format.getEncoding());
                    tracks[i].setFormat(audioFormat);                                
                    atLeastOneTrack = true;  

               } //if
       } // if
      } // for
	   return atLeastOneTrack;
   }
   public Format checkForVideoSizes(Format original, Format[] supported) {
       
	   Format format = checkFor_jpegFormat(original, supported);
	   if(format!=null) {return format;}
	   else {
		   format = checkFor_h263Format(original, supported);
		   if(format!=null) {return format;}
		   else {return original;}
	   }
   }
   
 public Format checkFor_jpegFormat(Format original, Format[] supported) {
	   
	   Dimension size = ((VideoFormat)original).getSize();//获取视频图像的尺寸
	   Format jpegFormat = new Format(VideoFormat.JPEG_RTP);
	   
	    for(int i=0;i<supported.length;i++) {
	    	if(supported[i].matches(jpegFormat)) {
	    		int width = (size.width % 8 == 0 ? size.width :(int)(size.width / 8) * 8);
	    		int height = (size.height % 8 == 0 ? size.height :(int)(size.height / 8) * 8);
	    		return (new VideoFormat(null,new Dimension(width, height),Format.NOT_SPECIFIED,null,Format.NOT_SPECIFIED)).intersects(supported[i]);
	    	}
	    }
	    return null;
   }
 public Format checkFor_h263Format(Format original, Format[] supported) {
	   
	   Dimension size = ((VideoFormat)original).getSize();//获取视频图像的尺寸
	   Format h263Format = new Format(VideoFormat.H263_RTP);
	   int width = 0;
	   int height = 0;
	   
	    for(int i=0;i<supported.length;i++) {
	    	if(supported[i].matches(h263Format)) {
	    		 if (size.width < 128) {
	    	            width = 128;
	    	            height = 96;
	    	            } else if (size.width < 176) {
	    	            width = 176;
	    	            height = 144;
	    	            } else {
	    	            width = 352;
	    	            height = 288;
	    	            }
	    		return (new VideoFormat(null,new Dimension(width, height),Format.NOT_SPECIFIED,null,Format.NOT_SPECIFIED)).intersects(supported[i]);
	    	}
	    }
	    return null;
 }
 public Format checkFor_AudioFormat(Format original,Format[] supported) {
	 Format format = null;
	 
	 if((format=checkFor_gsmFormat(original, supported))!=null) {return format;}
	  if((format=checkFor_g723FormatFormat(original, supported))!=null) {return format;}
	 else if((format=checkFor_dviFormatFormat(original, supported))!=null) {return format;}
	 else {return original;}
 }
public Format checkFor_gsmFormat(Format original,Format[] supported) {
	   Format gsmFormat = new Format(AudioFormat.GSM_RTP);
	   AudioFormat audioFormat = null;
	   
	    for(int i=0;i<supported.length;i++) {
	    	if(supported[i].matches(gsmFormat)) {
	    		audioFormat = (AudioFormat) supported[i];
//	    		System.out.println(audioFormat.getSampleRate());
//	    		System.out.println(audioFormat.getSampleSizeInBits());
//	    		System.out.println(audioFormat.getChannels());
//	    		return new AudioFormat(AudioFormat.GSM_RTP).intersects(supported[i]);
	    		return new AudioFormat(AudioFormat.GSM_RTP,8000,16, 1);
	    	}
	    }
	    return null;
 }
public Format checkFor_g723FormatFormat(Format original,Format[] supported) {
	 Format g723Format = new Format(AudioFormat.G723_RTP);
	   
	    for(int i=0;i<supported.length;i++) {
	    	if(supported[i].matches(g723Format)) {
	    		
	    		return new AudioFormat(AudioFormat.G723_RTP,8000,16, 1);
	    	}
	    }
	    return null;
}
public Format checkFor_dviFormatFormat(Format original,Format[] supported) {
	 Format dviFormat = new Format(AudioFormat.DVI_RTP);
	   
	    for(int i=0;i<supported.length;i++) {
	    	if(supported[i].matches(dviFormat)) {
	    		
	    		return new AudioFormat(AudioFormat.DVI_RTP,8000,16, 1);
	    	}
	    }
	    return null;
}

    private Integer stateLock = new Integer(0);  
    private boolean failed = false;  
  
    Integer getStateLock() {  
        return stateLock;  
    }  
    
    private synchronized boolean waitForState(javax.media.Processor p, int state) {  
        // p.addControllerListener(new StateListener());  
       boolean  sucsess = false;  
         if (state == javax.media.Processor.Configured) {  
             p.configure();  
             
             while(p.getState()<javax.media.Processor.Configured) {
             	p.configure();
             }
         } else if (state == javax.media.Processor.Realized) {  
         	p.realize();  
             while(p.getState()<javax.media.Processor.Realized) {
             	p.realize();
             }
         }                 
             return true;  
     }  
    
    boolean setJPEGQuality(float quality) {  
    	  
        Control cs[] = video_processor.getControls();  
        QualityControl qc = null;  
        VideoFormat jpegFmt = new VideoFormat(VideoFormat.JPEG_RTP);  
        
        for (int i = 0; i < cs.length; i++) {  
  
            if (cs[i] instanceof QualityControl && cs[i] instanceof Owned) {  
                Object owner = ((Owned) cs[i]).getOwner();  
                if (owner instanceof Codec) {  
                    Format fmts[] = ((Codec) owner)  
                            .getSupportedOutputFormats(null);  
                    for (int j = 0; j < fmts.length; j++) {  
                        if (fmts[j].matches(jpegFmt)) {  
                            qc = (QualityControl) cs[i];  
                            qc.setQuality(quality);  
                            System.err.println("- Setting quality to " +quality 
                                    + " on " + qc);  
                            break; 
                        }  
                    }  
                }  
                if (qc != null)  
                    return false;  
            }  
        }
        
		return true;  
    }
  public Apply_Message get_flushApplyMessage() {
    	
    	String reply_ip = Main_Frame.getMessage_pane().get_link_info(String.valueOf(link_count)).getRemote_ip();
    	String request_ip = Main_Frame.get_NativeIp();
    	int p2p_type = request_ip.equals(reply_ip)?2:1;
    	
    	int from_account  = Integer.parseInt(Main_Frame.getNative_count());
    	int to_account = Integer.parseInt(String.valueOf(link_count));
    	
    	Apply_Message apply_Message = new Apply_Message(132, 4, from_account, to_account, p2p_type, 1, 1, 1, true, request_ip, reply_ip);
    	return apply_Message;
    }
  
  public ReceiveStreamListener get_ReceiveStreamListener() {
	  ReceiveStreamListener receiveStreamListener = new ReceiveStreamListener() {
		
		@Override
		public void update(ReceiveStreamEvent arg0) {
			if(arg0 instanceof NewReceiveStreamEvent) {
				
				System.out.println("play_sourse");
					 
				ReceiveStream re = arg0.getReceiveStream();	
				DataSource dataSource = re.getDataSource();
				
				play_sourse(dataSource);
				sourse_num++;
				
				if(sourse_num==1) {new Check_thread().start();}
		}		 
		}
	};
	return receiveStreamListener;
  }
   
public void play_sourse(DataSource dataSource) {
    	
    	Player player = null;
    	try {
			player = Manager.createPlayer(dataSource);
		} catch (NoPlayerException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
      player.addControllerListener(new ControllerListener() {
		
		@Override
		public void controllerUpdate(ControllerEvent arg0) {
			if(arg0 instanceof RealizeCompleteEvent) {
				 
				 Player player = (Player) arg0.getSourceController();
				 Component component = null;
				 
				 if((component=player.getVisualComponent())!=null) {
				
					    other_comp = component;
					    
					    self = false;
					    change_pane(self);
					    
					    Init_comp_listioner(other_comp);
					   		        	
				 }
			 }		
		}
	});
	  player.realize();
      player.prefetch();
      player.start();
           
	}
private class Check_thread extends Thread{
	@Override
	public void run() {
		 try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		 
		if(sourse_num==1) {
		   Apply_Message apply_Message = get_flushApplyMessage();
		   Private_Chat_Client.send_message(apply_Message);
		   
		   flush_video_chat();
		}
	}
}
public static boolean Device_exist() {
	DataSource dataSource = null;
	int times = 0;
	boolean scuess = false;
	
    while(true){
    	try {
    		 times++;
    		 if(times>10) {break;}
			 dataSource = Manager.createDataSource(new MediaLocator("vfw://0"));
			 scuess = true;
		} catch (NoDataSourceException e1) {
			 continue;
		//	e1.printStackTrace();
		} catch (IOException e1) {
			continue;
		//	e1.printStackTrace();
		}
             break;
    	}
    
    if(scuess) {dataSource.disconnect();}
    
    return scuess;
}
}  