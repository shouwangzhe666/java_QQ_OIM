package VA_Pack_UDP;

import java.util.Scanner;
import javax.media.protocol.DataSource;

import VA_Pack_UDP.Clone_tool;
import udp_pack.UDP_P4P_Client;

public class Audio_Transfer_Server extends Thread{

	int server_port1 = 0;
	int server_port2 = 0;
	
	int[] ports1 = null;
	int[] ports2 = null;
	
	Audio_Transfer  va_Transfer1 = null;
	Audio_Transfer  va_Transfer2 = null;
	
	public Audio_Transfer_Server(int server_port1,int server_port2) {

		this.server_port1 = server_port1;
		this.server_port2 = server_port2;	
	}
	
	@Override
	public void run() {
		
		UDP_P4P_Client client1 =  new UDP_P4P_Client(server_port1,true);
		UDP_P4P_Client client2 =  new UDP_P4P_Client(server_port2,true);
		ports1 = client1.get_ports(60);
		ports2 = client2.get_ports(60);
		String remote_ip1 = client1.get_remoteIP();
		String remote_ip2 = client2.get_remoteIP();
		
		if(remote_ip1==null||remote_ip2==null) {
			System.err.println("connect assist failed !");
			return;
		}
		
		va_Transfer1 = new Audio_Transfer(remote_ip1, ports1);
		va_Transfer2 = new Audio_Transfer(remote_ip2, ports2);
		va_Transfer1.import_VA_Transfer(va_Transfer2);
		va_Transfer2.import_VA_Transfer(va_Transfer1);
		
		va_Transfer1.start();
		va_Transfer2.start();
	}
	
	public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);
		  
		    System.out.println("server port1: ");
		    int p1 = scanner.nextInt();
		    System.out.println("server port2: ");
		    int p2 = scanner.nextInt();
		   
		    new Audio_Transfer_Server(p1, p2).start();
		 
	}
}
