package VA_Pack_UDP;

import java.awt.*;
import java.io.File;
import java.io.IOException;

import javax.media.*;
import javax.media.control.TrackControl;
import javax.media.format.*;
import javax.media.protocol.*;
import javax.swing.JFrame;

/**
 * Sample program to clone a data source using the cloneable DataSource and
 * playback the result.
 */
public class Clone_tool implements ControllerListener {

 DataSource cloable_datasourse = null;
 Player ori_p; // 播放器
 Player p; // 播放器
 Object waitSync = new Object(); // 同步对象
 boolean stateTransitionOK = true; // 状态标识符
 boolean cloable = true;
 
public Clone_tool() {
	// TODO AYouTu-generated constructor stub
}

public void close_sourse() {
	ori_p.close();
}
 public Component getVisualComponent(DataSource ds,boolean isCloseableDatasourse) {

	  if(!cloable) {return null;}
	  
//  System.out.println("create player for: " + ds.getContentType());
  try {
   p = Manager.createPlayer(ds);
  } catch (Exception e) {
   System.err.println("Failed to create a player from the given DataSource: "+ e);
   return null;
  }
  
  if(isCloseableDatasourse) {ori_p = p;}
  
  p.addControllerListener(this);  //添加监听器为播放器

  // Realize the player.
  p.prefetch();    //使播放器达到 prefetched状态
  if (!waitForState(Player.Prefetched)) {
   System.err.println("Failed to realize the player.");
   return null;
  }

  // Display the visual & control component if there's one.

  // Start the player.

  try {
	return p.getVisualComponent();
} finally {
	p.start();    //播放媒体
}
}
 
 /** 
  * 当状态转换时阻塞播放器，直到播放器达到参数中给定的状态。如果转换失败则返回false
  * 
  */
 boolean waitForState(int state) {
  synchronized (waitSync) {
   try {
    while (p.getState() < state && stateTransitionOK)
     waitSync.wait();
   } catch (Exception e) {
   }
  }
  return stateTransitionOK;
 }

 /**
  * 监听器
  */
 @Override
 public void controllerUpdate(ControllerEvent evt) {

  if (evt instanceof ConfigureCompleteEvent
    || evt instanceof RealizeCompleteEvent
    || evt instanceof PrefetchCompleteEvent) {
   synchronized (waitSync) {
    stateTransitionOK = true;
    waitSync.notifyAll();
   }
  } else if (evt instanceof ResourceUnavailableEvent) {
   synchronized (waitSync) {
    stateTransitionOK = false;
    waitSync.notifyAll();
   }
  } else if (evt instanceof EndOfMediaEvent) {
   p.close();
   // System.exit(0);
  } else if (evt instanceof SizeChangeEvent) {
  }
 }

 public static void main(String[] args) {
	
}
}