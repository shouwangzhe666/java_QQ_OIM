package Group_decoder;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import Message.Group.Group_info_message;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

public class Group_info_decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> list) throws Exception {
	
		buf.readerIndex(0);
		if(buf.readableBytes()==0) {return;}
		
		int protocol_code = buf.readInt();
		
		if(protocol_code==213) {
			
			Group_info_message group_info = generate_decode(buf);
			int type = group_info.getType();
			
			if(type<10) {}
			else if(type<20) {group_info = decode_info(group_info, buf);}
			else if(type<30) {group_info = decode_members(group_info, buf);}
			
			else if(type==31) {group_info = decode_notice1(group_info, buf);}
			else if(type==32) {group_info = decode_notice2(group_info, buf);}
			else if(type==33) {group_info = decode_notice3(group_info, buf);}
			else if(type==34) {group_info = decode_notice4(group_info, buf);}
			
			else if(type==41) {group_info = decode_icon1(group_info, buf);}
			else if(type==42) {group_info = decode_icon2(group_info, buf);}
			else if(type==44) {group_info = decode_icon4(group_info, buf);}
			
			else if(type==52) {group_info = decode_file2(group_info, buf);}
			else if(type==53) {group_info = decode_file3(group_info, buf);}
			else if(type==54) {group_info = decode_file4(group_info, buf);}
			
			else if(type==55) {group_info = decode_file5(group_info, buf);}
			else if(type==56) {group_info = decode_file6(group_info, buf);}
			else if(type==57||type==58) {group_info = decode_file7_8(group_info, buf);}
				
			list.add(group_info);
		}
	
		else {
			buf.retain();
			ctx.fireChannelRead(buf);
		}
	}

  public Group_info_message generate_decode(ByteBuf buf) {
		
		int type = buf.readInt();
		int group_account = buf.readInt();
		
		Group_info_message group_info_message = new Group_info_message(type, group_account);
		
		return group_info_message;
	}
	
 public Group_info_message decode_info(Group_info_message group_info,ByteBuf buf) {
	    byte[] question = null;
		byte[] answer = null;
		
		byte[] group_name = new byte[buf.readInt()];
		buf.readBytes(group_name);
		
		byte[] head_bytes = new byte[buf.readInt()];
		buf.readBytes(head_bytes);	
		
		byte[] group_introduce = new byte[buf.readInt()];
		buf.readBytes(group_introduce);
		
		try {
			group_info.setGroup_name(new String(group_name,"UTF-8"));
			group_info.setGroup_head_icon(head_bytes);			
			group_info.setGroup_introduce(new String(group_introduce,"UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		group_info.setGroup_type(buf.readInt());
		group_info.setPay_days(buf.readInt());
		group_info.setPay_money(buf.readInt());
		
		question = new byte[buf.readInt()];
		buf.readBytes(question);
		answer = new byte[buf.readInt()];
		buf.readBytes(answer);
		
		try {
			group_info.setQuestion(new String(question,"UTF-8"));
			group_info.setAnswer(new String(answer,"UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		group_info.setTemporary_chat(buf.readBoolean());
		group_info.setStop_all_chat(buf.readBoolean());
		group_info.setFile_upload_all(buf.readBoolean());
		group_info.setFile_load_all(buf.readBoolean());
		group_info.setIcon_upload_all(buf.readBoolean());		
		
		return group_info;
	}
 public Group_info_message decode_members(Group_info_message group_info,ByteBuf buf) {
	 
	     int size = buf.readInt();
	     ArrayList<ArrayList<Object>> all_members = new ArrayList<>();
	     ArrayList<Object> member = null;
	     
	     int member_account = 0;
	     byte[] member_id = null;
	     byte[] group_remark = null;
	     long join_time = 0l;
	     long last_time = 0l;
	        
	     for(int i=0;i<size;i++) {
	    	 
	    	 member_account = buf.readInt();
	    	 member_id = new byte[buf.readInt()];
	    	 buf.readBytes(member_id);
	    	 group_remark = new byte[buf.readInt()];
	    	 buf.readBytes(group_remark);
	    	 join_time = buf.readLong();
	    	 last_time = buf.readLong();
	    	 
	    	 try {
	    		member = new ArrayList<>();
	    		
		    	member.add(member_account);
				member.add(new String(member_id,"UTF-8"));
				member.add(new String(group_remark,"UTF-8"));
				member.add(join_time);
				member.add(last_time);
				
				all_members.add(member);
			} catch (UnsupportedEncodingException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
	     }
	     
	     group_info.setAll_members(all_members);
	     
	  return group_info;  
 }
 
 public Group_info_message decode_notice1(Group_info_message group_info,ByteBuf buf) {
	 byte[] content = null;
	 byte[] sender = null;
	 long send_time = 0l;
	 
	 content = new byte[buf.readInt()];
	 buf.readBytes(content);
	 sender = new byte[buf.readInt()];
	 buf.readBytes(sender);
     send_time = buf.readLong();
	 
	 try {
		group_info.setContent(new String(content,"UTF-8"));
		group_info.setSender(new String(sender,"UTF-8"));
		group_info.setSend_time(send_time);
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	 	 
	 return group_info;
 }
 public Group_info_message decode_notice2(Group_info_message group_info,ByteBuf buf) {
	 
	 group_info.setSend_time(buf.readLong());
	 return group_info;
 }
 public Group_info_message decode_notice3(Group_info_message group_info,ByteBuf buf) {
	 
	 group_info = decode_notice1(group_info, buf);
	 return group_info;
 }
 public Group_info_message decode_notice4(Group_info_message group_info,ByteBuf buf) {
	 
     int size = buf.readInt();
     ArrayList<ArrayList<Object>> all_notices = new ArrayList<>();
     ArrayList<Object> notice = null;
     
     byte[] content = null;
     byte[] sender = null;
     long send_time = 0l;
        
     for(int i=0;i<size;i++) {
    	 
    	 content = new byte[buf.readInt()];
    	 buf.readBytes(content);
    	 sender = new byte[buf.readInt()];
    	 buf.readBytes(sender);
    	 send_time = buf.readLong();
    	 
    	 try {
    		 notice = new ArrayList<>();
    		
    		notice.add(new String(content,"UTF-8"));
    		notice.add(new String(sender,"UTF-8"));
			notice.add(send_time);
			
			all_notices.add(notice);
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
     }
     
     group_info.setAll_notices(all_notices);
     
  return group_info;  
}
 public Group_info_message decode_icon1(Group_info_message group_info,ByteBuf buf) {
	 byte[] sender = null;
	 byte[] group_icon = null;
	 long send_time = 0l;
	 
	 group_icon = new byte[buf.readInt()];
	 buf.readBytes(group_icon);
	 
	 sender = new byte[buf.readInt()];
	 buf.readBytes(sender);
	 
	 send_time = buf.readLong();
	 
	 try {
		group_info.setGroup_icon(group_icon);
		group_info.setSender(new String(sender,"UTF-8"));
		group_info.setSend_time(send_time);
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	 
	 return group_info;
 }
 public Group_info_message decode_icon2(Group_info_message group_info,ByteBuf buf) {
	 group_info.setSend_time(buf.readLong());
	 return group_info;
 }
 public Group_info_message decode_icon4(Group_info_message group_info,ByteBuf buf) {
	 
     int size = buf.readInt();
     ArrayList<ArrayList<Object>> all_icon = new ArrayList<>();
     ArrayList<Object> icon = null;
     
     byte[] icon_bytes = null;
     byte[] sender = null;
     long send_time = 0l;
        
     for(int i=0;i<size;i++) {
    	 
    	 icon_bytes = new byte[buf.readInt()];
    	 buf.readBytes(icon_bytes);
    	 sender = new byte[buf.readInt()];
    	 buf.readBytes(sender);
    	 send_time = buf.readLong();
    	 
    	 try {
    		icon = new ArrayList<>();
    		
    		icon.add(icon_bytes);
    		icon.add(new String(sender,"UTF-8"));
    		icon.add(send_time);
			
			all_icon.add(icon);
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
     }
     
     group_info.setAll_icons(all_icon);
     
  return group_info;  
}
 
 public Group_info_message decode_file2(Group_info_message group_info,ByteBuf buf) {
	 group_info.setSend_time(buf.readLong());
	 return group_info;
 }
 public Group_info_message decode_file3(Group_info_message group_info,ByteBuf buf) {
	 byte[] file_name = null;
	 long send_time = 0l;
	 
	 file_name = new byte[buf.readInt()];
	 buf.readBytes(file_name);
	 send_time = buf.readLong();
	 
	 try {
		group_info.setFile_name(new String(file_name,"UTF-8"));
		group_info.setSend_time(send_time);
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	 
	 return group_info;
 }
public Group_info_message decode_file4(Group_info_message group_info,ByteBuf buf) {
	 
     int size = buf.readInt();
     ArrayList<ArrayList<Object>> all_file = new ArrayList<>();
     ArrayList<Object> file = null;
     
     byte[] name = null;
     long file_size = 0l;
     byte[] sender = null;
     long send_time = 0l;
     
     for(int i=0;i<size;i++) {
    	 
    	 name = new byte[buf.readInt()];
    	 buf.readBytes(name);
    	 file_size = buf.readLong();
    	 sender = new byte[buf.readInt()];
    	 buf.readBytes(sender);
    	 send_time = buf.readLong();
    	 
    	 try {
    		 file = new ArrayList<>();
    		
    		 file.add(new String(name,"UTF-8"));
    		 file.add(file_size);
    		 file.add(new String(sender,"UTF-8"));
    		 file.add(send_time);
			
			all_file.add(file);
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
     }
     
     group_info.setAll_files(all_file);
     
  return group_info;  
}
public Group_info_message decode_file5(Group_info_message group_info,ByteBuf buf) {
	 byte[] file_name = null;
	 long file_size = 0l;
	 byte[] sender = null;
	 long send_time = 0l;
		
	 file_name = new byte[buf.readInt()];
	 buf.readBytes(file_name);
	 file_size = buf.readLong();
	 sender = new byte[buf.readInt()];
	 buf.readBytes(sender);
	 send_time = buf.readLong();
	 
	 try {
		group_info.setFile_name(new String(file_name,"UTF-8"));
		group_info.setFile_size(file_size);
		group_info.setSender(new String(sender,"UTF-8"));
	    group_info.setSend_time(send_time);
	  
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	 
	 return group_info;
}
public Group_info_message decode_file6(Group_info_message group_info,ByteBuf buf) {
	
	byte[] file_name = null;
	long start_position = 0l;
	long send_time = 0l;
	
	 file_name = new byte[buf.readInt()];
	 buf.readBytes(file_name);
	 start_position = buf.readLong();
	 send_time = buf.readLong();
	 
	 try {
		group_info.setFile_name(new String(file_name,"UTF-8"));
		group_info.setStart_position(start_position);
		group_info.setSend_time(send_time);
	} catch (UnsupportedEncodingException e) {
		e.printStackTrace();
	}
	return group_info;
}
public Group_info_message decode_file7_8(Group_info_message group_info,ByteBuf buf) {
	
	byte[] ip_port = null;
	long send_time = 0l;
	
	 ip_port = new byte[buf.readInt()];
	 buf.readBytes(ip_port);
	 send_time = buf.readLong();
	 try {
		group_info.setIp_port(new String(ip_port,"UTF-8"));
		group_info.setSend_time(send_time);
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	 
	return group_info;
}
}
