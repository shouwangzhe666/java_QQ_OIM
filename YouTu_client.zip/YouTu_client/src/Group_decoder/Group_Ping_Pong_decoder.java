package Group_decoder;

import java.util.List;

import Message.Group.Group_Ping_Pong;
import Message.Group.Group_chat_message;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

public class Group_Ping_Pong_decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> list) throws Exception {
		buf.readerIndex(0);
		if(buf.readableBytes()==0) {return;}
		
		int protocol_code = buf.readInt();
		
		if(protocol_code==210) {
			
			int member_account = buf.readInt();
			list.add(new Group_Ping_Pong(member_account));
		}
		else {
			buf.retain();
			ctx.fireChannelRead(buf);
		}
		
	}

}
