package Group_decoder;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.SealedObject;

import Message.Group.Group_chat_message;
import Message.Group.Group_search_message;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

public class Group_search_decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> list) throws Exception {
		buf.readerIndex(0);
		if(buf.readableBytes()==0) {return;}
		
		int protocol_code = buf.readInt();
		
		if(protocol_code==212) {
			
			int type = buf.readInt();
			
			if(type==1) {decode_type1(buf, list);}
			else if(type==2) {decode_type2(buf, list);}
			else if(type==3) {decode_type3(buf, list);}
			else if(type==4) {decode_type4(buf, list);}
			else if(type==5) {decode_type5(buf, list);}
			else if(type==6) {decode_type6(buf, list);}
		}
		else {
			buf.retain();
			ctx.fireChannelRead(buf);
		}
		
	}

   public void decode_type1(ByteBuf buf, List<Object> list) {
	   
	    byte[] group_type = null;
		byte[] group_name = null;
		byte[] group_ower_account = null;
		
		group_type = new byte[buf.readInt()];
		buf.readBytes(group_type);
		group_name = new byte[buf.readInt()];
		buf.readBytes(group_name);
		group_ower_account = new byte[buf.readInt()];
		buf.readBytes(group_ower_account);
		
		Group_search_message search_message = new Group_search_message(1);
		try {
			search_message.setGroup_type(new String(group_type,"UTF-8"));
			search_message.setGroup_name(new String(group_name,"UTF-8"));
			search_message.setGroup_ower_account(new String(group_ower_account,"UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		list.add(search_message);
   } // decode_type1
   
   public void decode_type2(ByteBuf buf, List<Object> list) {
	   
	    boolean scuess = false;
		byte[] group_account = null;
		
		scuess = buf.readBoolean();
		group_account = new byte[buf.readInt()];
		buf.readBytes(group_account);
		
		Group_search_message search_message = new Group_search_message(2);
		try {
		      search_message.setScuess(scuess);
		      search_message.setGroup_account(new String(group_account,"UTF-8"));
			
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		list.add(search_message);
   } // decode_type2
   
   public void decode_type3(ByteBuf buf, List<Object> list) {
	   
	    byte[] group_account = null;
	   
	    group_account = new byte[buf.readInt()];
		buf.readBytes(group_account);
		
		Group_search_message search_message = new Group_search_message(3);
		try {
		      search_message.setGroup_account(new String(group_account,"UTF-8"));
			
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		list.add(search_message);
	   
   }  // decode_type3
   
   public void decode_type4(ByteBuf buf, List<Object> list) {
	   
	     byte[] group_type = null;
		 int pay_money = 0;
		 byte[] question = null;
		 byte[] answer = null;
		 
		 byte[] group_icon = null;
		 byte[] group_account = null;
		 byte[] group_name = null;
		 
		    group_type = new byte[buf.readInt()];
			buf.readBytes(group_type);
			
			pay_money = buf.readInt();
			question = new byte[buf.readInt()];
			buf.readBytes(question);
			answer = new byte[buf.readInt()];
			buf.readBytes(answer);
			
			group_icon = new byte[buf.readInt()];
			buf.readBytes(group_icon);
			group_account = new byte[buf.readInt()];
			buf.readBytes(group_account);
			group_name = new byte[buf.readInt()];
			buf.readBytes(group_name);
			
			Group_search_message search_message = new Group_search_message(4);
			try {
			      search_message.setGroup_type(new String(group_type,"UTF-8"));
			      search_message.setPay_money(pay_money);
			      search_message.setQuestion(new String(question,"UTF-8"));
			      search_message.setAnswer(new String(answer,"UTF-8"));
			      
			      search_message.setGroup_icon(group_icon);
			      search_message.setGroup_account(new String(group_account,"UTF-8"));
			      search_message.setGroup_name(new String(group_name,"UTF-8"));
				
			} catch (UnsupportedEncodingException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
			list.add(search_message);
   }  // decode_type4
   
   public void decode_type5(ByteBuf buf, List<Object> list) {
	   
	    byte[] group_type = null;
	    byte[] group_account = null;
		byte[] native_icon = null;
		byte[] native_name = null;
		byte[] native_account = null;
		byte[] verify_message = null;
		
		group_type = new byte[buf.readInt()];
		buf.readBytes(group_type);
		group_account = new byte[buf.readInt()];
		buf.readBytes(group_account);
		native_icon = new byte[buf.readInt()];
		buf.readBytes(native_icon);
		native_name = new byte[buf.readInt()];
		buf.readBytes(native_name);
		native_account = new byte[buf.readInt()];
		buf.readBytes(native_account);
		verify_message = new byte[buf.readInt()];
		buf.readBytes(verify_message);
		
		Group_search_message search_message = new Group_search_message(5);
		try {
		      search_message.setGroup_type(new String(group_type,"UTF-8"));
		      search_message.setGroup_account(new String(group_account,"UTF-8"));
		      search_message.setNative_icon(native_icon);
		      search_message.setNative_name(new String(native_name,"UTF-8"));
		      search_message.setNative_account(new String(native_account,"UTF-8"));
		      search_message.setVerify_message(new String(verify_message,"UTF-8"));
			
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		list.add(search_message);
  }  // decode_type5
  
  public void decode_type6(ByteBuf buf, List<Object> list) {
	   
	    boolean accept = false;
		byte[] group_account = null;
		byte[] native_account = null;
		
		accept = buf.readBoolean();
		group_account = new byte[buf.readInt()];
		buf.readBytes(group_account);
		native_account = new byte[buf.readInt()];
		buf.readBytes(native_account);
		
		Group_search_message search_message = new Group_search_message(6);
		try {
		      search_message.setAccept(accept);
		      search_message.setGroup_account(new String(group_account,"UTF-8"));
			  search_message.setNative_account(new String(native_account,"UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		list.add(search_message);
  }  // decode_type6
   
   public void decode_type7(ByteBuf buf, List<Object> list) {
	   
		byte[] group_account = null;
		byte[] native_account = null;
		
		group_account = new byte[buf.readInt()];
		buf.readBytes(group_account);
		native_account = new byte[buf.readInt()];
		buf.readBytes(native_account);
		
		Group_search_message search_message = new Group_search_message(7);
		try {
		      search_message.setGroup_account(new String(group_account,"UTF-8"));
			  search_message.setNative_account(new String(native_account,"UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		list.add(search_message);
  }  // decode_type6
}
