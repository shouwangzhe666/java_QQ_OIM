package Group_decoder;

import java.io.UnsupportedEncodingException;
import java.util.List;
import Message.Group.Group_chat_message;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

public class Group_chat_decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> list) throws Exception {
		buf.readerIndex(0);
		if(buf.readableBytes()==0) {return;}
		
		int protocol_code = buf.readInt();
		
		if(protocol_code==211) {
			
			   Group_chat_message chat_Message  = general_decoder(buf);
			   int type = chat_Message.getType();
				
			  if(type==1) {chat_Message = decode_type1(chat_Message, buf);}
			  else if(type==2) {chat_Message = decode_type2(chat_Message, buf);}
			  else if(type==3) {chat_Message = decode_type3(chat_Message, buf);}
			  else if(type==4) {chat_Message = decode_type4(chat_Message, buf);}
			  else if(type==5) {chat_Message = decode_type5(chat_Message, buf);}
			  else if(type==6) {chat_Message = decode_type6(chat_Message, buf);}
			  //else if type==7 general_encode done already;
			  else if(type==8||type==9) {chat_Message = decode_type8_9(chat_Message, buf);}
			  else if(type==10||type==11) {chat_Message = decode_type10_11(chat_Message, buf);}
			  else if(type==12) {chat_Message = decode_type12(chat_Message, buf);}
			  
			  list.add(chat_Message);
		}
		else {
			buf.retain();
			ctx.fireChannelRead(buf);
		}
		
	}

	public Group_chat_message decode_type1(Group_chat_message chat_Message,ByteBuf buf) {
		
		 byte[] bytes = new byte[buf.readInt()];
	     buf.readBytes(bytes);
	     chat_Message.setBytes(bytes,true);
		 
		return chat_Message;
		
	}	
	public Group_chat_message decode_type2(Group_chat_message chat_Message,ByteBuf buf) {
		
		byte[] bytes = new byte[buf.readInt()];
		buf.readBytes(bytes);
		chat_Message.setBytes(bytes,false);
		 
		return chat_Message;
		
	}
public Group_chat_message decode_type3(Group_chat_message chat_Message,ByteBuf buf) {
		
		boolean self = buf.readBoolean();
		chat_Message.setSelf(self);
		 
		return chat_Message;		
	}

public Group_chat_message decode_type4(Group_chat_message chat_Message,ByteBuf buf) {
	
	boolean isOpen_shutup = buf.readBoolean();
	int Shutup_minites = buf.readInt();
	
	chat_Message.setOpen_shutup(isOpen_shutup);
	chat_Message.setShutup_minites(Shutup_minites);
	 
	return chat_Message;		
}
public Group_chat_message decode_type5(Group_chat_message chat_Message,ByteBuf buf) {
	
	boolean Set_Administrator = buf.readBoolean();
	chat_Message.setSet_Administrator(Set_Administrator);
	 
	return chat_Message;		
}
public Group_chat_message decode_type6(Group_chat_message chat_Message,ByteBuf buf) {
	
	byte[] group_id = null;
	
	group_id = new byte[buf.readInt()];
	buf.readBytes(group_id);
	try {
		chat_Message.setGroup_id(new String(group_id,"UTF-8"));
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	 
	return chat_Message;		
}

public Group_chat_message decode_type8_9(Group_chat_message chat_Message,ByteBuf buf) {
	
	byte[] group_remark = null;
	
	group_remark = new byte[buf.readInt()];
	buf.readBytes(group_remark);
	try {
		chat_Message.setGroup_remark(new String(group_remark,"UTF-8"));
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	 
	return chat_Message;		
}

public Group_chat_message decode_type10_11(Group_chat_message chat_Message,ByteBuf buf) {
	
	byte[] icon_bytes = null;
	
	icon_bytes = new byte[buf.readInt()];
	buf.readBytes(icon_bytes);
	
	chat_Message.setIcon_bytes(icon_bytes);
	
	return chat_Message;
}

public Group_chat_message decode_type12(Group_chat_message chat_Message,ByteBuf buf) {
	
	boolean all_shutup = buf.readBoolean();
	boolean temp_chat =  buf.readBoolean();
	
	chat_Message.setAll_shutup(all_shutup);
	chat_Message.setTemp_chat(temp_chat);
	
	return chat_Message;
}
	public Group_chat_message general_decoder(ByteBuf buf) {
		
		int type = 0;
		int member_account =0;
		byte[] group_id = null;
		byte[] group_remark = null;
		long send_time = 0l;
		boolean is_Aite = false;
		boolean isReply = false;
		long time_code = 0l;
		
		type = buf.readInt();
		member_account = buf.readInt();
		
		group_id = new byte[buf.readInt()];
		buf.readBytes(group_id);
		
		group_remark = new byte[buf.readInt()];
		buf.readBytes(group_remark);
		
		send_time = buf.readLong();
		time_code = buf.readLong();
		is_Aite = buf.readBoolean();
		isReply = buf.readBoolean();		
				
		Group_chat_message chat_message = null;
		try {
			chat_message = new Group_chat_message(type, member_account, send_time, new String(group_id,"UTF-8"), new String(group_remark,"UTF-8"), time_code);
			chat_message.setReply(isReply);
			chat_message.setAite(is_Aite);
		} catch (UnsupportedEncodingException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
		
		return chat_message;
		
	}
}
