package Main_frame_message;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.color.ColorSpace;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.awt.image.ColorConvertOp;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;

import Frame.Chat_frame;
import Frame.Group_info_frame;
import Frame.Main_Frame;
import Main_frame_Item.Main_JMenuItem;
import Message.Group.Group_info_message;
import Message.Group.Group_search_message;
import Message.Private.Link_info;
import Message.Private.Link_set;
import Message.Private.Private_info;
import custom_component.Roundrec_button;
import message_login_register.List_message;
import ss.Group_Chat_Client;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;
import tools.Icon_tools;

public class Main_message_Item extends JPanel implements ActionListener{

	Color focus_color = null;
	
	int type = 1;
	String link_count = null;
	String group_account = null;
	
	String state = null;
	boolean online = true;
	Image image  = null;
	BufferedImage grayImage = null;
	
	String name = null;
	String group_name = null;
	String chat_content = null;
	long system_time = 0l;
	String chat_time = null;
	boolean enter = false;
	int quantity = 0;
	
	JPopupMenu popupMenu = null;
	Main_JMenuItem send_item = null;
	Main_JMenuItem info_item = null;
	Main_JMenuItem mark_item = null;
	Main_JMenuItem mark_all_item = null;
	Main_JMenuItem drop_item = null;
	Main_JMenuItem drop_all_item = null;
	Main_JMenuItem blacklist_item = null;
	Main_JMenuItem delete_item = null;
	
	Roundrec_button accept_button = null;
	Roundrec_button quite_button = null;
	
	boolean private_linkman = true;
	Main_Frame main_Frame = null;
	Main_message_pane main_message_pane = null;
	Cursor cursor = null;
	SimpleDateFormat date_Format = null;
    SimpleDateFormat time_Format = null;
    
public Main_message_Item(Main_Frame main_Frame,List_message list_message) {
	
		setLayout(null);
		setOpaque(false);
		setPreferredSize(new Dimension(275, 60));
		setMinimumSize(new Dimension(265, 60));
		setMaximumSize(new Dimension(590, 60));
		
		cursor = new Cursor(Cursor.DEFAULT_CURSOR);
		focus_color = new Color(160, 160, 160);
    
        Init_content(main_Frame, list_message);
        
        if(type==1||type==2) {      	
        	Init_MenuItem_component();
        	Init_MenuItem_listioner();
        }
        else {
        	Init_few_MenuItem();
        	Init_few_ItemListioner();
        	Init_button_component();
        	Init_button_listioner();
        }
    	 
    	Init_pane_listioner();
    	
	}// constructor

public void Init_content(Main_Frame main_Frame,List_message list_message) {
	
	  this.main_Frame = main_Frame;
	  this.type = list_message.getType();
	  this.link_count = list_message.getLink_count();
	  this.group_account = list_message.getGroup_account();
	  this.state = "在线";
	  this.private_linkman=link_count.length()==8?true:false;
	 
	  this.image = list_message.getHead_image().getImage();
	  
	  this.grayImage = getGrayImage();
	  
      this.name = list_message.getRemark();
      this.quantity = list_message.getQuantity();  
      this.group_name = list_message.getGroup_name();
      this.chat_content = list_message.getChat_content();
    		  
      this.system_time = list_message.getSystem_time();
	  date_Format = new SimpleDateFormat("MM-dd");
      time_Format = new SimpleDateFormat("HH:mm");
       
      String date1 = date_Format.format(system_time);
      String date2 = date_Format.format(new Date());
      
      if(date1.equals(date2)) {this.chat_time = time_Format.format(system_time);}
      else {this.chat_time = date1;}
}

public void Init_MenuItem_component() {
	
     popupMenu = new JPopupMenu();
     popupMenu.setBackground(Color.white);
     
     send_item = new Main_JMenuItem("发送消息",null);
     info_item = new Main_JMenuItem("查看资料",null);
     mark_item = new Main_JMenuItem("标为已读", null);
     mark_all_item = new Main_JMenuItem("全部已读", null);
     drop_item = new Main_JMenuItem("会话移除",null);
     drop_all_item = new Main_JMenuItem("全部移除",null);
     
     blacklist_item = new Main_JMenuItem("加入黑名单", null);
     if(type==1) { delete_item = new Main_JMenuItem("删除好友", null);}
     else if(type==2) { delete_item = new Main_JMenuItem("退出群聊", null);}
     
     popupMenu.add(send_item);
     popupMenu.add(info_item);
 //    popupMenu.add(mark_item);
     popupMenu.add(mark_all_item);
     popupMenu.add(drop_item);
     popupMenu.add(drop_all_item);
     popupMenu.add(blacklist_item);
     popupMenu.add(delete_item);
}

public void Init_few_MenuItem() {
	
	 popupMenu = new JPopupMenu();
     popupMenu.setBackground(Color.white);
     
     info_item = new Main_JMenuItem("查看资料",null);
     mark_item = new Main_JMenuItem("标为已读", null);
     mark_all_item = new Main_JMenuItem("全部已读", null);
     drop_item = new Main_JMenuItem("会话移除",null);
     drop_all_item = new Main_JMenuItem("全部移除",null);
     
     blacklist_item = new Main_JMenuItem("加入黑名单", null);     
     delete_item = new Main_JMenuItem("删除", null);
   
     popupMenu.add(info_item);
     popupMenu.add(mark_item);
     popupMenu.add(mark_all_item);
     popupMenu.add(drop_item);
     popupMenu.add(drop_all_item);
	 popupMenu.add(blacklist_item);
	 popupMenu.add(delete_item);
}

public void Init_few_ItemListioner() {
	
	info_item.addActionListener(this);
	mark_item.addActionListener(this);
	mark_all_item.addActionListener(this);
	drop_item.addActionListener(this);
	drop_all_item.addActionListener(this);
	blacklist_item.addActionListener(this);
	delete_item.addActionListener(this);
}
public void Init_button_component() {
	
	accept_button = new Roundrec_button(45, 25, 5, new Color(0, 131, 245), "同意", 14, Color.white);
	quite_button = new Roundrec_button(45, 25, 5, new Color(0, 131, 245), "拒绝", 14, Color.white);
	
	update_button_location();
	
	add(accept_button);
	add(quite_button);
}
public void update_button_location() {
	
	if(type==1||type==2) {return;}
	
	accept_button.setBounds(getWidth()-100, 10, 45, 25);
	quite_button.setBounds(getWidth()-150, 10, 45, 25);
}
public void Init_MenuItem_listioner() {
		
	send_item.addActionListener(this);
	info_item.addActionListener(this);
	mark_item.addActionListener(this);
	mark_all_item.addActionListener(this);
	drop_item.addActionListener(this);
	drop_all_item.addActionListener(this);
	blacklist_item.addActionListener(this);
	delete_item.addActionListener(this);
}
public void Init_button_listioner() {
	
	accept_button.addActionListener(this);
	quite_button.addActionListener(this);
}

public void mark_readed() {
	this.quantity = 0 ;
	repaint();
}
public void Init_pane_listioner() {
	
	addMouseListener(new MouseAdapter() {
		@Override
		public void mousePressed(MouseEvent e) {
			
			if(e.getButton()==1&&e.getClickCount()==2) {
				
				open_chat_frame();
				
			} // if button==1
			else if(e.getButton()==3) {
				
				popupMenu.show(Main_message_Item.this, e.getX(),e.getY());
			
			}
		}
		@Override
		public void mouseEntered(MouseEvent e) {
			enter = true;
			repaint();
		}
		public void mouseExited(MouseEvent e) {
			enter = false;
			repaint();
		}; 
	});
}

public void open_chat_frame() {
	
	 quantity = 0;repaint();
	 Main_Frame.setCurrent_link_count(link_count);
	 Chat_frame.put_select_Item(link_count);
	 
	if(private_linkman) {Chat_frame.update_state(link_count, state); }
}
public  BufferedImage getGrayImage(){
	
	BufferedImage originalImage = new BufferedImage(40,40, BufferedImage.TYPE_4BYTE_ABGR);
	Graphics2D g2 = (Graphics2D) originalImage.getGraphics();
	g2.drawImage(image, 0, 0, null);
	g2.dispose();
	
	int rgb = 0 ;
	Color color = null;
	int green = 0,red = 0,blue = 0;
	int imageWidth = originalImage.getWidth();
	int imageHight = originalImage.getHeight();
	BufferedImage routeImage = new BufferedImage(imageWidth,imageHight,BufferedImage.TYPE_4BYTE_ABGR);
	for(int i = originalImage.getMinX();i < imageWidth;i++){
		for(int j = originalImage.getMinY();j < imageHight;j++){
			//获取该点像素，用Object类型标识
			
			rgb = originalImage.getRGB(i, j);
			color = new Color(rgb);
			
			red = color.getRed();
			green = color.getGreen();
			blue = color.getBlue();
			red = (red*3+green*6+blue*1)/10;
			green = red;
			blue = green;
						
			rgb = (red*256 +green)*256 +blue;
			if(rgb>8388608){
				rgb = rgb - 256*256*256;
			}
			
			if(red<2&&green<2&&blue<2) {color = new Color(0, 0, 0,0);}
			else {color = new Color(red, green, blue);}
			//将rgb值写回图片
			routeImage.setRGB(i, j, color.getRGB());
		}
	}
	
	Graphics2D g22 = (Graphics2D) routeImage.getGraphics();
	g22.setColor(Color.LIGHT_GRAY);
	g22.setStroke(new BasicStroke(2f));
	g22.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	g22.drawOval(-1,-1, imageWidth+1, imageHight+1);
	
	return routeImage;
}

public boolean is_online(String state) {

	if(state.equals("离线")||state.equals("隐身")) {return false;}
	return true;
}

public void update_state(String state) {
	
	if(state.equals("隐身")) {this.state = "离线";}
	else {this.state = state;}
	
	if(this.state.equals("离线")) {this.online = false;}
	else {this.online = true;}
	
	repaint();	
}

public void update_head_image(byte[] icon_bytes) {
	
	 this.image = new ImageIcon(icon_bytes).getImage();
	 this.grayImage = getGrayImage();
	 repaint();
}
public void set_enter(boolean enter) {
	 this.enter = enter;
}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D  g2 = (Graphics2D) g;
		
		if(enter){
			g2.setColor(focus_color);
			g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
			g2.fillRect(0, 0, 600, 60);
		}
		
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
		
		if(image!=null) {
			   if(online) {g2.drawImage(image, 10, 10, null);}
			   else {g2.drawImage(grayImage, 10, 10, null);}
			}
		
		if(name!=null) {
		g2.setColor(Color.RED);
		g2.setFont(new Font("宋体", Font.PLAIN, 15));
		g2.drawString(name, 55, 25);}
		
		if(chat_content!=null) {
		g2.setColor(Color.black);
		g2.setFont(new Font("宋体", Font.PLAIN, 13));
		g2.drawString(chat_content,60, 45);}
		
		g2.drawString(chat_time,getWidth()-50, 20);
	
		if(quantity>0) {
			g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			g2.setColor(new Color(247, 76, 49));
			g2.fillOval(getWidth()-39, 25, 16, 16);
			g2.setColor(Color.white);
			g2.setFont(new Font("宋体", Font.BOLD, 14));
			
			if(quantity<10) {g2.drawString(""+quantity, getWidth()-35, 37);}
			else {g2.drawString("..", getWidth()-37, 34);}
			g2.dispose();
		}
		
		update_button_location();
	}
    
	public void update_remark(String remark) {
		this.name = remark;
		repaint();
	}
	
	public void update_chat_content(long send_time,String chat_content) {
	    
		  this.system_time = send_time;
		  date_Format = new SimpleDateFormat("MM-dd");
	      time_Format = new SimpleDateFormat("HH:mm");
	       
	      String date1 = date_Format.format(system_time);
	      String date2 = date_Format.format(new Date());
	      
	      if(date1.equals(date2)) {this.chat_time = time_Format.format(system_time);}
	      else {this.chat_time = date1;}
	      
		this.chat_content = chat_content;
		String current_count = Main_Frame.getCurrent_link_count();
		if(link_count.equals(current_count)) {quantity=0;}
		else {quantity++;}
		repaint();
	}
	
	public String get_link_count() {
		
		return this.link_count;
	}
	
    public List_message get_list_message() {
    	
    	if(type==3||type==4) {return null;}
    	List_message list_message = new List_message(type, link_count,new ImageIcon(image), group_name, name, chat_content, system_time, quantity);
    	
    	return list_message;
    }
    
  public boolean is_private() {
	 return this.private_linkman;
 }
	
	@Override
	public void actionPerformed(ActionEvent e) {
				
		 if(e.getSource()==send_item) {
			 open_chat_frame();
		} // if send_item
		else if(e.getSource()==info_item) {
			
			  if(private_linkman) {
				  
				  Private_info info = new Private_info();
				  info.setType(3);
				  info.setCount(link_count);
				  Private_Chat_Client.send_message(info);
			  }
			  else {				  
				  int current_account = Integer.parseInt(link_count);
				  
				  if(!Group_info_frame.is_init()) {new Group_info_frame();}
				  
				  Group_info_frame.set_visiable(true);
				  
				  if(Group_info_frame.get_group_account()!=current_account) {
					  Group_info_message group_info_message = new Group_info_message(1, current_account);
				      Group_Chat_Client.send_message(current_account, group_info_message);
				  }
			  } // if group
		} // if info_item
		 
		else if(e.getSource()==mark_item) {
			quantity = 0; repaint();
		}
		else if(e.getSource()==mark_all_item) {
			Main_Frame.getMessage_pane().mark_all_item_readed();
		}
		else if(e.getSource()==drop_item) {
		
			Main_Frame.getMessage_pane().remove_message_item(link_count);
		}// if drop_item
		else if(e.getSource()==drop_all_item) {
			
			Main_Frame.getMessage_pane().remove_all_message_item();
		}// if 
		 
		else if(e.getSource()==blacklist_item) {
			
			 delete_item.doClick();
			 
			 Link_set link_set = new Link_set(9);
			 link_set.setNative_count(Main_Frame.getNative_count());
			 link_set.setLink_account(link_count);
			 Private_Chat_Client.send_message(link_set);
			 
			 new Warn_frame("提示","加入黑名单后，将自动屏蔽对方添加请求\n只有主动添加对方，才会移出黑名单").set_aYouTu_click(10);
		}
		else if(e.getSource()==delete_item) {
			
			if(type==1) {
			    Main_Frame.getFriend_pane().remove_link_Item(link_count);
			    
				Link_set link_set = new Link_set(5);
				link_set.setNative_count(Main_Frame.getNative_count());
				link_set.setLink_account(link_count);
				Private_Chat_Client.send_message(link_set);
			} // if private
			else if(type==2) {
				 Main_Frame.getGroup_pane().remove_link_Item(link_count);
				 
				 Group_search_message search_message = new Group_search_message(7);
				 search_message.setGroup_account(link_count);
				 search_message.setNative_account(Main_Frame.getNative_count());
				 
				 Private_Chat_Client.send_message(search_message);
			}
			
			 Main_Frame.getMessage_pane().remove_message_item(link_count);
			 Main_Frame.getMessage_pane().remove_link_man(link_count);
			 Chat_frame.remove_Item(link_count);
		} // if delete_item
		
		 
	else if(type==3) {
		
		Link_info link_info = new Link_info(9);
		link_info.setAccount(Main_Frame.getNative_count());
		link_info.setLink_count(link_count);
		
		String icon_path =  "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\image\\head_image\\"+Main_Frame.getNative_count()+".png";
		byte[] head_icon_bytes = Icon_tools.get_IconBytes(icon_path);
		if(head_icon_bytes==null) {new Warn_frame("提示", "无法找到本人头像图片").set_aYouTu_click(5);return;}
		
		link_info.setHead_icon_bytes(head_icon_bytes);
		link_info.setName(Main_Frame.get_PrivateInfo().getName());
		link_info.setSystem_time(System.currentTimeMillis());
		
		if(e.getSource()==accept_button) {link_info.setAccept(true);}
		else if(e.getSource()==quite_button) {link_info.setAccept(false);}
		
		Private_Chat_Client.send_message(link_info);
		
		Main_Frame.getMessage_pane().remove_message_item(link_count+"00");
		new Warn_frame("提示", "发送成功！").set_aYouTu_click(3);
		
		}  // type==3
		 
	else if(type==4) {
		
		 Group_search_message search_message = new Group_search_message(6);
		 search_message.setGroup_account(group_account);
		 search_message.setNative_account(link_count);
		 
		 if(e.getSource()==accept_button) {search_message.setAccept(true);}
		 else if(e.getSource()==quite_button) {search_message.setAccept(false);}
		 
		 Private_Chat_Client.send_message(search_message);
		 Main_Frame.getMessage_pane().remove_message_item(link_count+"000");
		 new Warn_frame("提示", "发送成功！").set_aYouTu_click(3);
	}   // type==4
	}
}
