package Main_frame_Item;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;

import javax.swing.ImageIcon;
import javax.swing.JMenu;
import javax.swing.JPopupMenu;

public class Main_JMenu extends JMenu{

	boolean enter = false;
	String text = null;
	java.awt.Image image = null;
	Font font = null;
	FontRenderContext frc = null;
	
	public Main_JMenu(String text) {
		
		setBorder(null);
		setBorderPainted(false);
		setContentAreaFilled(false);
		
		font = new Font("宋体", Font.PLAIN, 15);
		frc = new FontRenderContext(new AffineTransform(),true,true);
		Rectangle rec = font.getStringBounds(text, frc).getBounds();
		
		int str_width= rec.width+40;
//		int str_height= rec.height;
		
		setPreferredSize(new Dimension(str_width, 30));
		setMinimumSize(new Dimension(str_width, 30));
		setMaximumSize(new Dimension(str_width, 30));
		
		this.text = text;
		image = new ImageIcon("tool_image/group_right.png").getImage();
		
		addMouseListener(new MouseAdapter() {
			
			  @Override
			    public void mouseEntered(MouseEvent e) {
			    	
			    	enter = true;
			    	repaint();
			    }
			    
			    @Override
			    public void mouseExited(MouseEvent e) {
			    	
			    	enter = false;
			    	repaint();
			    }
		});
}

	@Override
	protected void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		if(!enter) {
		g2.setColor(Color.white);}
		else {
			g2.setColor(new Color(238, 238, 238));
		}
		g2.fillRect(0, 0, 160, 30);
	
		g2.drawImage(image, 120, 5, null);
		g2.setColor(Color.black);
		g2.setFont(font);
		g2.drawString(text, 20, 20);
	}
}
