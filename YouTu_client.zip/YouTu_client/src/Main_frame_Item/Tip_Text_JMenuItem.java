package Main_frame_Item;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.*;

import Item.Face_pane_MenuItem;
import Private_chat.Face_pane;
import chat_frame_pane.Private_chat_pane;
import custom_component.My_label;
import sun.swing.SwingUtilities2;
public class Tip_Text_JMenuItem extends JMenuItem{

	private static final long serialVersionUID = 1L;

	JPopupMenu popupMenu=null;
	int width  = 0;
	int height = 0;
	
	public Tip_Text_JMenuItem(String text) {		
		this(text,text.length()*16, 20);
		
	}
  public Tip_Text_JMenuItem(String text,int width,int height) {
		super(text);
		
		setBorder(null);
		setBorderPainted(false);
		setContentAreaFilled(false);
		
		setBackground(Color.white);
		setForeground(Color.black);
		putClientProperty(SwingUtilities2.AA_TEXT_PROPERTY_KEY,null);
		setFont(new Font("宋体", Font.PLAIN, 14));
		
	 if(width!=0) {
		  setPreferredSize(new Dimension(width, height));
		  setMaximumSize(new Dimension(width, height));
		  setMinimumSize(new Dimension(width, height));
		}
	}
}
