package jna;

import java.io.DataOutputStream;
import java.io.IOException;

public class GlobleKeyListioner {

	DataOutputStream dataOutputStream = null;
	
	public GlobleKeyListioner(DataOutputStream dataOutputStream) {
		this.dataOutputStream = dataOutputStream;
	}
	public void actionEvent(int keyType,int keyCode) {
//		String s = keyType==5?"press":"release";
//		System.out.println(KeyEvent.getKeyText(keyCode)+","+s);
		 try {
			 dataOutputStream.writeByte(keyType);
			 dataOutputStream.writeShort(keyCode);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
