package jna;

import java.awt.event.KeyEvent;

public abstract class KeycodeUtills {
    public static final int ACTION_MOUSEMOVE = 1;// 512;
    public static final int ACTION_LBUTTONDOWN = 2;// 513;
    public static final int ACTION_LBUTTONUP = 3;//514;
    public static final int ACTION_RBUTTONDOWN = 4;//516;
    public static final int ACTION_RBUTTONUP = 5;//517;
    public static final int ACTION_MBUTTONDOWN = 6;//519;
    public static final int ACTION_MBUTTONUP = 7;//520;
    public static final int ACTION_WHEEL = 8;//522;

    public abstract void keyboardHook(int vkCode,int scanCode,int flags,int time,long timeInterval);
    
    public static byte isKeyPressed(int intValue) {
    	// value=5 if is isPressed;or value=6
    	 byte KeyType = (byte) (intValue==256?5:6);
    	 return KeyType;
    }
    public static int translate_Keycode(int vkCode) {
        if (vkCode == 27) {//Esc 27 VK_ESCAPE 27
            return KeyEvent.VK_ESCAPE;
        } else if (vkCode >= 112 && vkCode <= 123) { //F1-F12
            return vkCode;
        } else if (vkCode >= 48 && vkCode <= 57) { //0-9
            return vkCode;
        } else if (vkCode >= 65 && vkCode <= 90) { //A-Z
            return vkCode;
        } else if (vkCode == 144) {//NumLock 144 VK_NUM_LOCK 144
            return KeyEvent.VK_NUM_LOCK;
        } else if (vkCode >= 96 && vkCode <= 110) { //数字小键盘
            return vkCode;
        } else if (vkCode == 13) {//数字小键盘Enter 13 VK_ENTER 10
            return KeyEvent.VK_ENTER;
        } else if (vkCode == 45) {//Insert 45 VK_INSERT 155
            return KeyEvent.VK_INSERT;
        } else if (vkCode == 46) {//Delete 46 VK_DELETE 127
            return KeyEvent.VK_DELETE;
        } else if (vkCode == 33) {//PageUp 33 VK_PAGE_UP 33
            return KeyEvent.VK_PAGE_UP;
        } else if (vkCode == 34) {//PageDown 34 VK_PAGE_DOWN 34
            return KeyEvent.VK_PAGE_DOWN;
        } else if (vkCode == 35) {//End 35 VK_END 35
            return KeyEvent.VK_END;
        } else if (vkCode == 36) {//Home 36 VK_HOME 36
            return KeyEvent.VK_HOME;
        } else if (vkCode >= 37 && vkCode <= 40) { //方向键
            return vkCode;
        } else if (vkCode == 9) {//Tab 9 VK_TAB 9
            return KeyEvent.VK_TAB;
        } else if (vkCode == 20) {//Caps Lock 20 VK_CAPS_LOCK 20
            return KeyEvent.VK_CAPS_LOCK;
        } else if (vkCode == 160) {//Shift(Left) 160 VK_SHIFT 16
            return KeyEvent.VK_SHIFT;
        } else if (vkCode == 161) {//Shift(Right) 161 VK_SHIFT 16
            return KeyEvent.VK_SHIFT;
        } else if (vkCode == 162) {//Ctrl(Left) 162 VK_CONTROL 17
            return KeyEvent.VK_CONTROL;
        } else if (vkCode == 163) {//Ctrl(Right) 163 VK_CONTROL 17
            return KeyEvent.VK_CONTROL;
        } else if (vkCode == 91) {//Win(Left) 91 VK_WINDOWS 524
            return KeyEvent.VK_WINDOWS;
        } else if (vkCode == 92) {//Win(Right) 92 VK_WINDOWS 524
            return KeyEvent.VK_WINDOWS;
        } else if (vkCode == 164) {//Alt(Left) 164 VK_ALT 18
            return KeyEvent.VK_ALT;
        } else if (vkCode == 165) {//Alt(Right) 165 VK_ALT 18
            return KeyEvent.VK_ALT;
        } else if (vkCode == 189) {//- 189 VK_MINUS 45
            return KeyEvent.VK_MINUS;
        } else if (vkCode == 187) {//= 187 VK_EQUALS 61
            return KeyEvent.VK_EQUALS;
        } else if (vkCode == 8) {//Backspace 8 VK_BACK_SPACE 8
            return KeyEvent.VK_BACK_SPACE;
        } else if (vkCode == 219) {//[ 219 VK_OPEN_BRACKET 91
            return KeyEvent.VK_OPEN_BRACKET;
        } else if (vkCode == 221) {//] 221 VK_CLOSE_BRACKET 93
            return KeyEvent.VK_CLOSE_BRACKET;
        } else if (vkCode == 220) {//\ 220 VK_BACK_SLASH 92
            return KeyEvent.VK_BACK_SLASH;
        } else if (vkCode == 186) {//; 186 VK_SEMICOLON 59
            return KeyEvent.VK_SEMICOLON;
        } else if (vkCode == 222) {//‘ 222 VK_QUOTE 222
            return KeyEvent.VK_QUOTE;
        } else if (vkCode == 188) {//, 188 VK_COMMA 44
            return KeyEvent.VK_COMMA;
        } else if (vkCode == 190) {//. 190 VK_PERIOD 46
            return KeyEvent.VK_PERIOD;
        } else if (vkCode == 191) {/// 191 VK_SLASH 47
            return KeyEvent.VK_SLASH;
        } else if (vkCode == 13) {//Enter 13 VK_ENTER 10
            return KeyEvent.VK_ENTER;
        }
        return vkCode;
    }


}