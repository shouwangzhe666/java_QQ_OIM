package jna;

import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef.HWND;
import com.sun.jna.platform.win32.WinDef.RECT;
//import com.sun.jna.platform.win32.WinUser.POINT;
import com.sun.jna.platform.win32.WinUser.WINDOWINFO;
import com.sun.jna.platform.win32.WinUser.WNDENUMPROC;
import com.sun.jna.Native;
import com.sun.jna.win32.StdCallLibrary;
import com.sun.org.apache.xerces.internal.util.SynchronizedSymbolTable;

public class JNA_Main {
    // Equivalent JNA mappings
//    public interface User extends StdCallLibrary {
//    	User user = (User) Native.loadLibrary("user32", User.class);
//
//        interface WNDENUMPROC extends StdCallCallback {
//            boolean callback(Pointer hWnd, Pointer arg);
//        }
//       
//          HWND GetDesktopWindow();
//          HWND WindowFromPoint(POINT p);
//          
//          boolean IsIconic(HWND hWnd); // 是否最小化
//          boolean IsZoomed(HWND hWnd); // 是否最小化
//          boolean GetCursorPos(POINT p);
//         
//    }
//
//    public static void main(String[] args) {
//    	
//        final User user = User.user;
//        
//        char[] chars = new char[1024];
//     //   HWND h = user.GetDesktopWindow();
//        HWND h = User32.INSTANCE.GetForegroundWindow();
//
//        User32.INSTANCE.GetWindowText(h,chars, 1024);
//        String s = Native.toString(chars);
//        System.out.println("ForegroundWindow: "+s);
//        
//        int count = 0;
//        User32.INSTANCE.EnumWindows(new WNDENUMPROC() {
//			
//			@Override
//			public boolean callback(HWND arg0, Pointer arg1) {
//				
//			char[] chars = new char[1024];
//		User32.INSTANCE.GetWindowText(arg0,chars,1024);
//		String wText = Native.toString(chars);
//		
//		boolean visiable =  User32.INSTANCE.IsWindowVisible(arg0);
//		
//		if(visiable&&wText.length()>0) {
//		//	boolean show = User32.INSTANCE.ShowWindow(arg0,4);
////			System.out.println(wText+" IsIconic? "+user.IsIconic(arg0));
//			System.out.println(wText);
//			RECT rec = new RECT();
//			int width = rec.right-rec.left;
//			int height = rec.bottom - rec.top;
//			
//			User32.INSTANCE.GetWindowRect(arg0,rec);
//		//	System.out.println(rec.left+","+rec.top+","+width+","+height);
//			 System.out.println(rec);
//			 User32.INSTANCE.ShowWindow(arg0, 9 ); 
//		}
//				return true;
//			}
//		}, null);
//       
//    }
}