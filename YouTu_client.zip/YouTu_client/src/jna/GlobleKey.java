package jna;

import com.sun.jna.platform.win32.Kernel32;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef;
import com.sun.jna.platform.win32.WinUser;

public class GlobleKey{
   
    public User32 lib;
    private WinDef.HMODULE hMod;
    private WinUser.HHOOK keyboardhhk;
    private long timeStamp;
    
    GlobleKeyListioner keyListioner = null;
    WinUser.LowLevelKeyboardProc keyboardHook = null;
    Object object = new Object();
    
    public GlobleKey(GlobleKeyListioner keyListioner) {
        this.keyListioner = keyListioner;
        lib = User32.INSTANCE;
        hMod = Kernel32.INSTANCE.GetModuleHandle(null);   
        
        Init();
     }
    
    public void Init() {
    	
    	     keyboardHook = new WinUser.LowLevelKeyboardProc() {
             public WinDef.LRESULT callback(int nCode, WinDef.WPARAM wParam, WinUser.KBDLLHOOKSTRUCT info) {
                 long timeInterval = 0;
                 long l = System.currentTimeMillis();
                 if (timeStamp != 0) {
                     timeInterval = l - timeStamp;
                 } else {
                     timeInterval = 0;
                 }
                 timeStamp = l;
                 
                 keyListioner.actionEvent(KeycodeUtills.isKeyPressed(wParam.intValue()),KeycodeUtills.translate_Keycode(info.vkCode));
                return lib.CallNextHookEx(keyboardhhk, nCode, wParam, new WinDef.LPARAM());
             }
         };
    }
    public void startListion() {
          
       new Thread(new Runnable() {
		
		@Override
		public void run() {
			    keyboardhhk = lib.SetWindowsHookEx(User32.WH_KEYBOARD_LL, keyboardHook, hMod, 0); 

		        int result;
		        WinUser.MSG msg = new WinUser.MSG();
		        result = lib.GetMessage(msg, null, 0, 0);
		}
	}).start();
       
    }

    public void stopListion() {

        lib.UnhookWindowsHookEx(keyboardhhk);
    }

    public static void main(String[] args) {
    
//		GlobleKeyListioner keyListioner = new GlobleKeyListioner(null);
//		ConstantQuite_KeyListioner globleKey = new ConstantQuite_KeyListioner(keyListioner);
//		globleKey.start();
//		try {
//			Thread.sleep(30000);
//		} catch (InterruptedException e) {
//			// TODO AYouTu-generated catch block
//			e.printStackTrace();
//		}
//		globleKey.stop();
	}
}