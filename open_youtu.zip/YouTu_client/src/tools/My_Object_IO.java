package tools;

import java.io.*;

import com.sun.org.apache.xml.internal.resolver.helpers.PublicId;

import sun.swing.FilePane;

public class My_Object_IO{

	int type = 1;

	public static ObjectInputStream get_ObjectInputStream(String file_path) {
		
		File file = null;
		file  = new File(file_path);
		
		FileUtills.create_new_file(file_path);
		
		if(file.length()==0) {return null;}
			
		
		FileInputStream fileInputStream = null;
		try {
			fileInputStream = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
				
		ObjectInputStream objectInputStream  = null;
		try {
			objectInputStream = new ObjectInputStream(fileInputStream);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		return objectInputStream;
	}
	
    public static ObjectOutputStream get_ObjectoutputStream(String file_path,boolean append) {
    	
    	FileUtills.create_new_file(file_path);
		
       return My_object_outputstream.create_My_object_outputstream(file_path, append);
		
    }
	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
	
	private static class NostreamHeader_objectInputStream extends ObjectInputStream{

		public NostreamHeader_objectInputStream(InputStream in) throws IOException {
			super(in);
			// TODO AYouTu-generated constructor stub
		}
		
		@Override
		protected void readStreamHeader() throws IOException, StreamCorruptedException {
		
			return;
		}
	}
	
}
