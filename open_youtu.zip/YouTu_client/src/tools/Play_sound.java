package tools;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.NoPlayerException;
import javax.media.Player;

public class Play_sound {

	static Timer timer = null;
	static String path = null;
	static {
		timer = new Timer();
	    path = "file:"+System.getProperty("user.dir")+"\\sound_file\\";
	}
	
	public static void play_message_sound() {
		
		MediaLocator mediaLocator = null;
		Player player = null;
		
		mediaLocator = new MediaLocator(path+"message.wav");
	
		try {
			player = Manager.createPlayer(mediaLocator);
		} catch (NoPlayerException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		player.start();
		
		timer.schedule(new Task(player),1000);	   
	}
	
public static void play_shake_sound() {
		
		MediaLocator mediaLocator = null;
		Player player = null;
		
		mediaLocator = new MediaLocator(path+"shake.wav");
		try {
			player = Manager.createPlayer(mediaLocator);
		} catch (NoPlayerException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		player.start();
		
		timer.schedule(new Task(player),1000);
	   
	}

	private static class Task extends TimerTask{
		Player player = null;
		
		public Task(Player player) {
			this.player = player;
		}		
	
		@Override
		public void run() {
		
			player.close();
		}		
	}	
}
