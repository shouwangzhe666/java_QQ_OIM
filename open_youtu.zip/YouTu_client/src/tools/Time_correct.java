package tools;

import java.io.IOException;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.apache.commons.net.ntp.NTPUDPClient;
import org.apache.commons.net.ntp.TimeInfo;
import org.apache.commons.net.ntp.TimeStamp;


public class Time_correct {

	public  String[] get_Intenet_DateTime() {
	    	
   	  String[] datetime = new String[2];
   	  
   	 try {
   		   NTPUDPClient timeClient = new NTPUDPClient();
   		   String timeServerUrl = "time.windows.com";
   		   InetAddress timeServerAddress = InetAddress.getByName(timeServerUrl);
   		   TimeInfo timeInfo=null;
			try {
				timeInfo = timeClient.getTime(timeServerAddress);
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
   		   TimeStamp timeStamp = timeInfo.getMessage().getTransmitTimeStamp();
   		   java.util.Date date = (java.util.Date) timeStamp.getDate();
   		  
   		   DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
   		   datetime[0] = new SimpleDateFormat("yyyy-MM-dd").format(date);
   		   datetime[1] = new SimpleDateFormat("HH:mm:ss").format(date);
   		   
   		   
   		   Date date2 = new Date(date.getTime());
   		   
   		  } catch (UnknownHostException e) {
   		   e.printStackTrace();
   		  }
   	 
   	 return datetime;
   }
   
   public  void updat_SystemTime(){
   	
   	String[] datetime = get_Intenet_DateTime();
   	String date = datetime[0];
   	String time = datetime[1];
   	
       try {
           String osName = System.getProperty("os.name");
           // Window 系统
           if (osName.matches("^(?i)Windows.*$")) {
               String cmd;
               // 格式：yyyy-MM-dd
               cmd = " cmd /c date " + date;
               Runtime.getRuntime().exec(cmd);
               // 格式 HH:mm:ss
               cmd = " cmd /c time " + time;
               Runtime.getRuntime().exec(cmd);
               System.out.println("windows 时间已校准");
           } 
       } catch (IOException e) {
           e.getMessage();
       }
   }
 public static void main(String[] args) {
	
	new Time_correct().updat_SystemTime();
}
   
}
