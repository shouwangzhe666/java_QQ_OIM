package tools;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import javax.imageio.ImageIO;
import javax.swing.*;
import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;

import Item.W_pane;
import Private_chat.Write_pane;
import custom_component.Icon_button;
import custom_component.My_ScrollPane;
import javafx.scene.image.Image;
import tools.Screen_capter.Capter_Frame.Tool_JFrame;

public class Screen_capter extends JFrame{

	private static final long serialVersionUID = 1L;
	static int	frame_x=0;
	static int	frame_y=0;
	static int  frame_width=0;
	static int  frame_height=0;
	
	 int kind=0;
	
	 int re = 0;
	
	 Robot ro =null;
  
	int head_or_x=0;
	int head_or_y=0;

	int[]marsk_x=null;
	int[]marsk_y=null;
	Color[]marsk_color=null;
	int color_shu=20;
	My_pane paint_pane =null;
	Tool_JFrame tool_frame=null;
	  
	int type=1;
	int shu=0;
	boolean clicked=false;
	static int start_x=0;
	static int start_y=0;
	static int end_x=0;
	static int end_y=0;
	static int[]po_x=null;
	static int[]po_y=null;
	static int ov_width=0;
	static int ov_height=0;
	
	static LinkedList<BufferedImage> all_imaBufferedImages=null;
	static BufferedImage backgroundBufferedImage=null;
	static BufferedImage temp_image=null;
	static BufferedImage bacBufferedImage_ori=null;
	static BufferedImage bacBufferedImage_gray=null;
	Capter_Frame basic_Frame=null;
	
	static boolean pressed=false;
	boolean alive=false;
	static Dimension dimension =null;
	int screen_width = 0;
	int screen_height = 0;
	show show=null;
	int ori_x=0;
	int ori_y=0;
	int width=0;
	int height=0;
    static int i=0;
    
    W_pane write_pane = null;
    
	public Screen_capter( W_pane write_pane) {
	
		this.write_pane = write_pane;
	     
		 setType(JFrame.Type.UTILITY);
		 setUndecorated(true);
		 
		 dimension =Toolkit.getDefaultToolkit().getScreenSize();
		 screen_width  = (int) dimension.getWidth();
		 screen_height = (int) dimension.getHeight();
		setBounds(0, 0,(int) dimension.getWidth(), (int)dimension.getHeight());
	
		try {
			ro = new Robot();
		} catch (AWTException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
	   bacBufferedImage_ori=backgroundBufferedImage= ro.createScreenCapture(new Rectangle(dimension));
		  RescaleOp r = new RescaleOp(0.6f, 0, null);// 创建RescaleOp对象，来更改图片每个颜色的颜色偏差，颜色偏移量为0.5f(暗色)
		  bacBufferedImage_gray = r.filter(bacBufferedImage_ori, null);// 将屏幕图片的每个像素进行颜色调整，付给临时的图片对象
		//bacBufferedImage_gray=r.filter(bacBufferedImage_ori, null);
		
		 marsk_x=new int[2];
		 marsk_y=new int[2];
		 marsk_color=new Color[2];
		  
		    show = new show();
			getContentPane().add(show);
			
			basic_Frame = new Capter_Frame(frame_x, frame_y, 2, 2);
		
	  this.addMouseListener(new MouseAdapter() {
		  @Override
		public void mouseReleased(MouseEvent e) {
			// TODO AYouTu-generated method stub
			super.mouseReleased(e);
			 
			int x = frame_x+frame_width-350;
			int y = frame_y+frame_height+10;
			if(x>screen_width-350) {x=screen_width-360;}
			if(y>screen_height-40) {y=screen_height-80;}
			
			  tool_frame.setBounds(x,y, 350, 34);
			
			  basic_Frame.setVisible(true);
				
				tool_frame.setVisible(true);
			
		       start_x=end_x=e.getX();
				start_y=end_y=e.getY();
				ov_width=ov_height=0;
			
					
				   temp_image =ro.createScreenCapture(new Rectangle(frame_x,frame_y,frame_width,frame_height));
				   all_imaBufferedImages.add(temp_image);
			      shu++;
		}
	});
	
		this.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
			
				super.mouseDragged(e);

				       i++;
                       if(i==1) {
					
					show.repaint();
					
					frame_x=e.getX();
					frame_y=e.getY();
					
					basic_Frame.setVisible(true);
				
				}
				if(i>1) {
				   
					
					frame_width=e.getX()-frame_x;
					frame_height=e.getY()-frame_y;
					
					 show.repaint();
					 
				basic_Frame.setBounds(frame_x, frame_y, frame_width, frame_height);					
				paint_pane.repaint();

					   
				}
				
			}
		});
		
		
	}

	private static class show extends JPanel{		
		
		@Override
		public void paint(Graphics g) {
			// TODO AYouTu-generated method stub
			super.paint(g);
			Graphics2D g2 = (Graphics2D) g;
			if(i==0) {
				g2.setColor(Color.red);
				g2.setStroke(new BasicStroke(20));
				g2.drawImage(bacBufferedImage_ori, 0, 0, null);
				g2.drawRect(0, 0, (int)dimension.getWidth(), (int)dimension.getHeight());
			}
			
			else if(i>0) {
				g2.drawImage(bacBufferedImage_gray, 0, 0, null);
			}
		}
		
	}
	
 class Capter_Frame extends JFrame {
	
	
	public Capter_Frame(int x,int y,int width,int height) {
	
		setUndecorated(true);
	    setBounds(frame_x, frame_y, frame_width, frame_height);
		
		frame_x=x;
		frame_y=y;
		frame_width=width;
		frame_height=height;
		
		Container container =getContentPane();
	
             
		try {
			ro = new Robot();
		} catch (AWTException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
		
	    all_imaBufferedImages = new LinkedList<>();
	    
	   backgroundBufferedImage=bacBufferedImage_ori;
	   temp_image=backgroundBufferedImage.getSubimage(frame_x, frame_y, frame_width, frame_height);
	   all_imaBufferedImages.add(temp_image);
		
		  
			paint_pane = new My_pane();
		
		   container.add(paint_pane);
		
		   tool_frame = new Tool_JFrame();
		     x = frame_x+frame_width-350;
			 y = frame_y+frame_height+10;
			if(x>screen_width-350) {x=screen_width-360;}
			if(y>screen_height-40) {y=screen_height-80;}
			
			  tool_frame.setBounds(x,y, 350, 34);
		 
		   paint_pane.addMouseListener(new MouseAdapter() {
			
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO AYouTu-generated method stub
				super.mousePressed(e);
				
				
				if(kind==0) {
					tool_frame.setVisible(false);
					head_or_x=e.getX();
					head_or_y=e.getY();
				}
				
				 if(kind==1) {start_x=e.getX();start_y=e.getY();}
				else if(kind ==2) {po_x[0]=po_x[1]=po_x[2]=e.getX();po_y[0]=po_y[1]=po_y[2]=e.getY();}
				else if(kind==3) {start_x=e.getX();start_y=e.getY();}
				else if(kind==4) {start_x=e.getX();start_y=e.getY();}
			}
			
			@Override
			public void mouseReleased(MouseEvent e) {
				super.mouseReleased(e);
				
				if(kind==0) {tool_frame.setVisible(true);}
				
				start_x=end_x=e.getX();
				start_y=end_y=e.getY();
				ov_width=ov_height=0;
			
					if(clicked) {
						shu++;
				   temp_image =ro.createScreenCapture(new Rectangle(frame_x,frame_y,frame_width,frame_height));
				   all_imaBufferedImages.add(temp_image);
					}
			}
		});
		
		   paint_pane.addMouseMotionListener(new MouseMotionAdapter() {
			

			@Override
			public void mouseMoved(MouseEvent e) {
				// TODO AYouTu-generated method stub
				super.mouseMoved(e);
				if(kind==0) {

				 if(e.getX()>frame_width-5&&e.getY()>frame_height-5) {
					Cursor cursor=new Cursor(Cursor.SE_RESIZE_CURSOR);
					Capter_Frame.this.setCursor(cursor);
					type=3;
				}
				
				else if(e.getX()>frame_width-5) {
					
					Cursor cursor=new Cursor(Cursor.E_RESIZE_CURSOR);
					Capter_Frame.this.setCursor(cursor);
					type=2;
				}
				
				else if(e.getY()>frame_height-5) {
					Cursor cursor=new Cursor(Cursor.S_RESIZE_CURSOR);
					Capter_Frame.this.setCursor(cursor);
					type=4;
				}
				 
				else {
					head_or_x=e.getX();
					head_or_y=e.getY();
					Cursor cursor=new Cursor(Cursor.HAND_CURSOR);
					Capter_Frame.this.setCursor(cursor);
					type=1;
					}
				}
			}
			
			@Override
			public void mouseDragged(MouseEvent e) {
				// TODO AYouTu-generated method stub
				super.mouseDragged(e);
				if(kind ==1) {end_x=e.getX();end_y=e.getY();paint_pane.repaint();}
				else if(kind==2) {po_x[0]=po_x[1];po_x[1]=po_x[2];po_x[2]=e.getX();
				po_y[0]=po_y[1];po_y[1]=po_y[2];po_y[2]=e.getY();
				paint_pane.repaint();
				temp_image=ro.createScreenCapture(new Rectangle(frame_x, frame_y, frame_width, frame_height));
				}
				else if(kind==3) {ov_width=e.getX()-start_x;ov_height=e.getY()-start_y;paint_pane.repaint();}
				else if(kind==4) {ov_width=e.getX()-start_x;ov_height=e.getY()-start_y;paint_pane.repaint();}
				else if(kind==6) {
					
					             if(color_shu==10) {
					            	 color_shu=0;
					            	
					            	start_x=e.getX();
					            	start_y=e.getY();
					           
					             paint_pane.repaint();
					             temp_image=ro.createScreenCapture(new Rectangle(frame_x, frame_y, frame_width, frame_height));
					             
					             }
					             color_shu++;
					
				}
				else if(kind==0) {
					
					int x = frame_x+frame_width-350;
					int y = frame_y+frame_height+10;
					if(x>screen_width-350) {x=screen_width-360;}
					if(y>screen_height-40) {y=screen_height-80;}
					
					  tool_frame.setBounds(x,y, 350, 34);
					  
					 paint_pane.repaint();
					if(type==1) {
						frame_x=e.getXOnScreen()-head_or_x;
						frame_y=e.getYOnScreen()-head_or_y;
						Capter_Frame.this.setLocation(frame_x, frame_y);
						
						
					}
				
					else if(type==2) {
						frame_width=e.getXOnScreen()-frame_x;
						Capter_Frame.this.setSize(frame_width, frame_height);
						
						
					}
					
					else if(type==3) {
						
						frame_width=e.getXOnScreen()-frame_x;
						frame_height=e.getYOnScreen()-frame_y;
						Capter_Frame.this.setSize(frame_width, frame_height);
					
						
					}
					
					else if(type==4) {
						frame_height=e.getYOnScreen()-frame_y;
						Capter_Frame.this.setSize(frame_width, frame_height);
						
						
					}
				}
			}
		});
	}

	class Tool_JFrame extends JFrame implements ActionListener{
		
		Icon_button straight_button = null;
		Icon_button curve_button=null;
		Icon_button rec_button=null;
		Icon_button ovel_button=null;
		Icon_button marsk_button=null;
		Icon_button delete_button=null;
		Icon_button save_button=null;
		Icon_button Insert_button=null;
		Icon_button exit_button=null;
		
		public Tool_JFrame() {

			setType(JFrame.Type.UTILITY);
			setUndecorated(true);
			
			setBackground(new Color(0, 0, 0,0));
			setPreferredSize(new Dimension(350,34));
			setMaximumSize(new Dimension(350,34));
			setLayout(new FlowLayout(FlowLayout.LEFT, 15, 2));
			
			 straight_button = new Icon_button(getClass().getResource("/tool_image/line.png"),"直线");			 
			 curve_button =  new Icon_button(getClass().getResource("/tool_image/pen.png"),"画笔");			 
			 rec_button =  new Icon_button(getClass().getResource("/tool_image/rec.png"),"矩形");			 
			 ovel_button = new Icon_button(getClass().getResource("/tool_image/oval.png"),"椭圆");			 				 
			 marsk_button =  new Icon_button(getClass().getResource("/tool_image/mosco.png"),"马赛克");			 
			 delete_button =  new Icon_button(getClass().getResource("/tool_image/remove.png"),"撤销");			 
			 save_button =  new Icon_button(getClass().getResource("/tool_image/save.png"),"保存");			 
			 Insert_button =  new Icon_button(getClass().getResource("/tool_image/confirm.png"),"插入");			 
			 exit_button =  new Icon_button(getClass().getResource("/tool_image/cancle.png"),"退出");
			
			 
			 straight_button.addActionListener(this);
			 curve_button.addActionListener(this);
			 rec_button.addActionListener(this);
			 ovel_button.addActionListener(this);
			 marsk_button.addActionListener(this);
			 delete_button.addActionListener(this);
			 save_button.addActionListener(this);
			 Insert_button.addActionListener(this);
			 exit_button.addActionListener(this);
			
			 Container container =getContentPane();
			 container.setBackground(Color.white);
			 container.setLayout(new FlowLayout());
			 
			 container.add(straight_button);
			 container.add(curve_button);
			 container.add(rec_button);
			 container.add(ovel_button);
			 container.add(marsk_button);
			 container.add(delete_button);
			 container.add(save_button);
			
			 container.add(exit_button);
			 container.add(Insert_button);
			 
		}

@Override
public void actionPerformed(ActionEvent e) {

	Cursor cursor = new Cursor(Cursor.HAND_CURSOR);
if(e.getSource()==straight_button) {if(!clicked) {clicked=true;} kind=1;Capter_Frame.this.setCursor(cursor);}
	else if(e.getSource()==curve_button) {if(!clicked) {clicked=true;}kind=2;Capter_Frame.this.setCursor(cursor);}
	else if(e.getSource()==rec_button) {if(!clicked) {clicked=true;}kind=3;Capter_Frame.this.setCursor(cursor);}
	else if(e.getSource()==ovel_button) {if(!clicked) {clicked=true;}kind=4;Capter_Frame.this.setCursor(cursor);}
	else if(e.getSource()==delete_button) {kind=5;if(shu>0&&!all_imaBufferedImages.isEmpty()) {shu--;all_imaBufferedImages.removeLast();paint_pane.repaint();}Capter_Frame.this.setCursor(cursor);}
	else if(e.getSource()==marsk_button) {if(!clicked) {clicked=true;}kind=6;Capter_Frame.this.setCursor(cursor);}
	else if(e.getSource()==Insert_button) {
		
		if(!clicked) {clicked=true;}
		kind=7;
		Capter_Frame.this.setCursor(cursor);
		
			String name=new SimpleDateFormat("yyyyMMddHHmmss").format(new java.util.Date());
			String icon_path = "C:\\ProgramData\\YouTu_"+name+".jpg";
			
			FileUtills.create_new_file(icon_path);
			
			FileOutputStream fileOutputStream = null;
			try {
				fileOutputStream = new FileOutputStream(icon_path);
			} catch (FileNotFoundException e2) {
				// TODO AYouTu-generated catch block
				e2.printStackTrace();
			}
			try {
				ImageIO.write(all_imaBufferedImages.getLast(), "jpg", fileOutputStream);
			
			} catch (IOException e1) {
				// TODO AYouTu-generated catch block
				e1.printStackTrace();
			}
			
			byte[] icon_bytes = Icon_tools.get_IconBytes(icon_path);
			write_pane.Insert_icon(icon_bytes);
			
			try {
				fileOutputStream.close();
			} catch (IOException e1) {
				// TODO AYouTu-generated catch block
				e1.printStackTrace();
			}

		exit_button.doClick();
	
	}
	else if(e.getSource()==save_button) {
		
		String name=new SimpleDateFormat("yyyyMMddHHmmss").format(new java.util.Date());
		
		FileDialog fileDialog = new FileDialog(this, "保存图片");
		fileDialog.setAlwaysOnTop(true);
		fileDialog.setVisible(true);
		
		
		String dir =fileDialog.getDirectory();
		File f = new File(dir, name+"_"+name+".png");
		if(!f.exists()) {try {
			f.createNewFile();
		} catch (IOException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}}
			try {
				ImageIO.write(all_imaBufferedImages.getLast(), "png", f);
			
			} catch (IOException e1) {
				// TODO AYouTu-generated catch block
				e1.printStackTrace();
			}
			
			if(dir!=null) {
				
				JOptionPane.showMessageDialog(null, "图片已保存");
				exit_button.doClick();
				
				}
			
		    
	}
	if(e.getSource()==exit_button) {
	     
		Screen_capter.this.i=0;
		Capter_Frame.this.dispose();
		this.dispose();
		Screen_capter.this.dispose();}
}


	}

}

    class My_pane extends JPanel{
		
    	 public My_pane() {
		
    		po_x=new int[3];
    		po_y=new int[3];
		}
	
		@Override
		public void paint(Graphics g) {
			
			Graphics2D g2 =(Graphics2D) g;
			g2.setColor(Color.red);
			g2.setStroke(new BasicStroke(5));
			
			 if(kind==1) {super.repaint();	if(!all_imaBufferedImages.isEmpty()) {g2.drawImage(all_imaBufferedImages.getLast(), 0, 0, null);}  g2.drawLine(start_x, start_y, end_x, end_y);}
			else if(kind==2) {
				super.repaint();
				g2.drawImage(temp_image, 0, 0, null);
				g2.drawPolyline(po_x, po_y, 3);
				}
			else if(kind==3) {super.repaint();	if(!all_imaBufferedImages.isEmpty()) {g2.drawImage(all_imaBufferedImages.getLast(), 0, 0, null);} g2.drawRect(start_x, start_y, ov_width, ov_height);}
			else if(kind==4) {super.repaint();	if(!all_imaBufferedImages.isEmpty()) {g2.drawImage(all_imaBufferedImages.getLast(), 0, 0, null);} g2.drawOval(start_x, start_y, ov_width, ov_height);}
			else if(kind==5) {if(!all_imaBufferedImages.isEmpty()) {super.repaint();g2.drawImage(all_imaBufferedImages.getLast(), 0, 0, null);}}
			else if(kind==6) {   super.repaint();
			                   
			                     g2.drawImage(temp_image, 0, 0, null);
			                     
			                     g2.setColor(new Color(temp_image.getRGB(start_x-5, start_y-5)));		                   
			                     g2.fillRect(start_x-10, start_y-10, 10, 10);
			                     
			                     g2.setColor(new Color(temp_image.getRGB(start_x+5, start_y-5)));		                   
			                     g2.fillRect(start_x+10, start_y-10, 10, 10);
			                     
			                     g2.setColor(new Color(temp_image.getRGB(start_x-5, start_y+5)));
			                     g2.fillRect(start_x-10, start_y+10, 10, 10);
			                     
			                     g2.setColor(new Color(temp_image.getRGB(start_x+5, start_y+5)));		                   
			                     g2.fillRect(start_x+10, start_y+10, 10, 10);
			                     
			                   
			                  }	 
			else if(kind==0) {
				g2.setColor(Color.blue);
				g2.setStroke(new BasicStroke(3));
				temp_image=backgroundBufferedImage.getSubimage(frame_x, frame_y, frame_width, frame_height);
				g2.drawImage(temp_image, 0, 0, null);
				g2.drawRect(0, 0, frame_width, frame_height);
			}
			
		}
		
	}// paint_pane

    
}
