package Frame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

import VA_Pack_UDP.Audio_Chat;
import custom_component.Roundrec_button;

public class Audio_chat_frame{

	Only_frame only_frame = null;
	Show_pane show_pane = null;
	volatile boolean start = true;
	Audio_Chat audio_Chat = null;
	
	public Audio_chat_frame(Audio_Chat audio_Chat) {
	   
		this.audio_Chat = audio_Chat;
		show_pane = new Show_pane();
		new Thread(show_pane).start();
		
		Init_frame();
	}
	public void setFrame_visiable(boolean visiable) {
		if(visiable) {show_pane.second = 0;}
		only_frame.setVisible(visiable);
	}
	public void dispose_frame() {
		 start = false;
		 only_frame.dispose();
	}
	public void Init_frame() {
		
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (int) ((dimension.getWidth()-600)/2);
	    only_frame = new Only_frame(show_pane,40);
	//	only_frame.set_Size(true,600, 100);
	    only_frame.set_Bounds(x, 10,600, 100);
		only_frame.set_Title("语音通话中",new Font("微软雅黑", Font.PLAIN, 20), new Color(0, 131, 253));
		only_frame.get_max_button().setVisible(false);
		only_frame.get_min_button().setVisible(false);
		
		only_frame.set_Resizable(false);
		only_frame.setAlwaysOnTop(true);
		
		only_frame.change_quite_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				show_pane.quite_button.doClick();				
			}
		});
}

	private class Show_pane extends JPanel implements Runnable,ActionListener{		
		String time = "";
		Font font = null;
		int second = 0;
		Roundrec_button quite_button  = null;
		Roundrec_button flush_button  = null;
		
		public Show_pane() {
			setLayout(null);
			font = new Font("宋体", Font.PLAIN, 18);
			quite_button =  new Roundrec_button(100, 40, 10,Color.red, "挂断", 18, Color.white);
			flush_button =  new Roundrec_button(100, 40, 10,new Color(0, 131, 245), "刷新", 18, Color.white);
			quite_button.addActionListener(this);
			flush_button.addActionListener(this);
			
			quite_button.setBounds(320, 0,100, 40);
			add(quite_button);
			flush_button.setBounds(450, 0,100, 40);
			add(flush_button);
		}
		@Override
		public void run() {
			 while(start) {
				  second++;
				  String time = time_conveter(second);
				  paint_time(time);
				  try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
			 }
		}
		public String time_conveter(int second) {
			int s = second%60;
			int m = (second%3600)/60;
			int h = second/3600;
			
			String time = h+" : "+m+" : "+s;
			return time;
		}
		public void paint_time(String time) {
			this.time = time;
			repaint();
		}
		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			Graphics2D g2 = (Graphics2D) g;
			g2.setFont(font);
			g2.drawString("通话时长： "+time, 100, 25);
		}
		@Override
		public void actionPerformed(ActionEvent e) {			
		//	 System.out.println("挂断");
			
			if(e.getSource()==flush_button) {
				audio_Chat.write_message(4);
				audio_Chat.flush_audio();
			}
			else if(e.getSource()==quite_button) {
				 audio_Chat.write_message(5);
				 audio_Chat.close_audio_chat();	 
				 start = false;
				 only_frame.dispose();
			}
		}
	}
	
	public static void main(String[] args) {
		
	}
}
