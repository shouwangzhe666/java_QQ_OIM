package Frame;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JPanel;

import com.sun.org.glassfish.gmbal.ManagedAttribute;

import Main_frame_pane.Search_show_pane;
import Main_thread.TelnetCheck_thread;
import Message.Group.Group_search_message;
import Message.Private.Link_info;
import custom_component.Focus_button;
import custom_component.Roundrec_button;
import custom_component.Roundrec_textFiled;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;

public class Search_frame extends JPanel {
    // 38165238
	Only_frame only_frame = null;
	Search_show_pane show_pane = null;
	
	public Search_frame() {
		setLayout(null);
		
		Init_frame();
	
	}
	
	public void Init_frame() {
		
		only_frame = new Only_frame(this,40);
		only_frame.set_Size(true, 460, 250);
		only_frame.set_Resizable(false);
		only_frame.setVisible(true);
		only_frame.remove_window_Maxbutton(false);
		only_frame.set_Title("添加", new Font("微软雅黑", Font.PLAIN, 18), Color.white);
		
		only_frame.change_quite_listioner(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				only_frame.dispose();				
			}
		});
	}
	
	public void dispose_frame() {
		only_frame.dispose();
	}
	
public void put_friend_show_pane(Link_info link_info) {
		
		if(show_pane!=null) {remove(show_pane);}
		
		show_pane = new Search_show_pane(1,this,link_info.getHead_icon_bytes(), link_info.getAccount(), link_info.getName());
		show_pane.setBounds(100, 50, 250, 100);
		add(show_pane);
		only_frame.update_frame_ui();
		only_frame.update_frame();
	}
public void put_group_show_pane(Group_search_message search_message) {
		
		if(show_pane!=null) {remove(show_pane);}
		
		show_pane = new Search_show_pane(this, search_message);
		show_pane.setBounds(100, 50, 250, 100);
		add(show_pane);
		only_frame.update_frame_ui();
		only_frame.update_frame();
	}
}
