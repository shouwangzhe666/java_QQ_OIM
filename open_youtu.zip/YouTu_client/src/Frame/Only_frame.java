package Frame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JWindow;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.SplitPaneUI;

import custom_component.Back_ground_pane;
import custom_component.Icon_button;
import custom_component.Only_top_pane;
import custom_component.Title_button;

public class Only_frame extends JFrame implements ActionListener{

	Back_ground_pane back_pane = null;
	Only_top_pane top_pane=null;	
	JComponent main_pane=null;
	
	Icon_button min_button = null;
	Icon_button normal_button = null;
	Icon_button max_button = null;
	Icon_button quite_button = null;
	
	int start_x=0;
	int start_y=0;
	int type=1;
	int frame_width=600;
	int frame_height=400;
	int normal_width=600;
	int normal_height=400;
	int main_height = 350;
	int top_height = 50;
	
	boolean resizable=true;
	boolean retractable = false;
	
	int show_image_height = 40;
	int min_width = 0;
	int min_height = 0;
	int max_width = 0;
	int max_height = 0;
	Dimension dimension = null;
	Container container = null;
	
	JPanel outer_pane = null;
	JPanel inner_pane = null;
	
	public Only_frame(JComponent main_pane,int show_image_height) {
	    this(main_pane, false,show_image_height);
	}
	
	public  Only_frame(JComponent main_pane,boolean task_icon_visiable,int show_image_height) {
		
		setVisible(false);
		this.show_image_height = show_image_height;
		if(!task_icon_visiable) {setType(JFrame.Type.UTILITY);}
		
		this.setUndecorated(true);
		
		this.setBackground(new Color(0,0,0,0));
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.main_pane=main_pane;
	
		dimension = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		this.max_width = (int) dimension.getWidth();
		this.max_height = (int) dimension.getHeight();			
		container  = getContentPane();					
	
		Init_top_componnets();
		Init_down_components();
		Init_top_pane_listioner();
		Init_down_listioner();

	}
	
	@Override
	public void dispose() {
		removeAll();
		super.dispose();
		System.gc();
	}
	
public void Init_top_componnets() {
		
		top_pane = new Only_top_pane();
		set_jcomponent_size(top_pane,frame_width, 40);  
		
		set_window_buttons(false);
		
		Image image = new ImageIcon(getClass().getResource("/tool_image/logo_login.png")).getImage();
		setIconImage(image);
		
		top_pane.setOpaque(false);
	}

public void Init_down_components() {
	
	back_pane = new Back_ground_pane(this.show_image_height);
	back_pane.setLayout(new BorderLayout());
	container.add(back_pane);
	
	outer_pane = get_box_pane(new JPanel(), BoxLayout.X_AXIS);
	inner_pane = get_box_pane(new JPanel(), BoxLayout.Y_AXIS);
	
	set_jcomponent_size(outer_pane, frame_width, frame_height-top_height);
	set_jcomponent_size(inner_pane, frame_width-5, frame_height-top_height);
	set_jcomponent_size(main_pane,  frame_width-5, frame_height-top_height-5);
	
	back_pane.add(top_pane,BorderLayout.NORTH);
	back_pane.add(outer_pane,BorderLayout.SOUTH);

	outer_pane.add(inner_pane);
	outer_pane.add(javax.swing.Box.createHorizontalStrut(5));
	
	inner_pane.add(main_pane);
	inner_pane.add(javax.swing.Box.createVerticalStrut(5));
	
		outer_pane.setOpaque(false);
		inner_pane.setOpaque(false);
		main_pane.setOpaque(false);
}

public void Init_top_pane_listioner() {
		
    top_pane.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mousePressed(MouseEvent e) {
								
				start_x= e.getX();
				start_y=e.getY();
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
			
				
				top_pane.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}
		});
		
		top_pane.addMouseMotionListener(new MouseMotionAdapter() {
			
			@Override
			public void mouseDragged(MouseEvent e) {
				
				
				int x=e.getXOnScreen()-start_x;
				int y=e.getYOnScreen()-start_y;
				
				Only_frame.this.setLocation(x, y);
				//Only_frame.this.setBounds(x, y, frame_height, frame_height);
			}
		});
	}
	
public void Init_down_listioner() {
	
     outer_pane.addMouseMotionListener(new MouseMotionListener() {
			
			@Override
			public void mouseMoved(MouseEvent e) {
				
				if(!resizable) {return;}
				
				int x=e.getX();
				int y=e.getY();
				
				
				if(x>frame_width-5&&y>main_height) {
					
					type=2;
					outer_pane.setCursor( new Cursor(Cursor.SE_RESIZE_CURSOR));
					
				}
				
				else if(x>frame_width-5) {
					
					type=1;
					
					outer_pane.setCursor(new Cursor(Cursor.E_RESIZE_CURSOR));
				}
				
				else if(y>main_height) {
					
					type=3;
					outer_pane.setCursor(new Cursor(Cursor.S_RESIZE_CURSOR));
				}
				
				else {
					type=0;
					outer_pane.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
				}
			}
			
			@Override
			public void mouseDragged(MouseEvent e) {
				
				if(!resizable) {return;}
				
				int x=e.getX();
				int y=e.getY();
				
				if(type==1) {
					
					if(retractable) {
						
						if(x<min_width) {return;}
						else if(x>max_width) {return;}
					}
					
					frame_width=x;
					set_Size(false,frame_width, frame_height);
				}
				
				else if(type==2) {
					
					if(retractable) {
						
						if(x<min_width) {return;}
						else if(x>max_width) {return;}
						else if(y<min_height) {return;}
						else if(y>max_height) {return;}
						
					}
					
				    frame_width=x;
					main_height = y-5;
					frame_height=y+top_height;
					set_Size(false,frame_width, frame_height);
				}
				
               else if(type==3) {
            	 
					if(retractable) {
            	    if(y<min_height) {return;}
					else if(y>max_height) {return;}
				         }
				
					main_height = y-5;
					frame_height=y+top_height;
					
					set_Size(false,frame_width, frame_height);
				
				}
			}
		});
	}

	public void change_min_listioner(ActionListener actionListener) {
		
		min_button.remove(this);
		min_button.addActionListener(actionListener);
	}
	public void change_quite_listioner(ActionListener actionListener) {
		
		quite_button.removeActionListener(this);
		quite_button.addActionListener(actionListener);
		
	}	
    	
public void set_Resizable(boolean resizable) {
	
		this.resizable=resizable;
	}
	
	public int get_frame_width() {
		
		return this.frame_width;
	}
	
	public int get_frame_height() {
		
		return this.frame_height;
	}
public void set_icon(ImageIcon icon) {
		
		top_pane.set_window_Icon(icon);
	}	
public void set_Title(String title,Font title_font,Color title_color) {
	  
	top_pane.set_window_title(title, title_font, title_color);
}
	
public void set_Bounds(int x, int y, int width, int height) {
	
	super.setBounds(x, y, width, height);
	this.frame_width=width;
	this.frame_height=height;
	this.main_height = frame_height-top_height-5;
	set_Size(false,width, height);
	
}

 public void set_top_background_color(Color color) {
	   top_pane.setOpaque(true);
	   top_pane.setBackground(color);
   }
   
 public void remove_window_Maxbutton(boolean white) {
	 
	 top_pane.delete_allComponnets();
	 Init_window_buttons(white);
	 
	    min_button.addActionListener(this);
		quite_button.addActionListener(this);
		
		top_pane.add_right_component(quite_button);
		top_pane.add_right_component(min_button);	
 }
 public void set_window_buttons(boolean white) {
	   
	    top_pane.delete_allComponnets();
	    Init_window_buttons(white);
	   
	    min_button.addActionListener(this);
		normal_button.addActionListener(this);
		max_button.addActionListener(this);
		quite_button.addActionListener(this);
		
		top_pane.add_right_component(quite_button);
		top_pane.add_right_component(normal_button);
		top_pane.add_right_component(max_button);
		top_pane.add_right_component(min_button);	
   }
   public void Init_window_buttons(boolean white) {
	   
	   if(white) {
	    min_button = new Icon_button(getClass().getResource("/window_top_image/window_min_light_normal.png"),"最小化");		
		max_button = new Icon_button(getClass().getResource("/window_top_image/window_max_light_normal.png"),"最大化");	
		normal_button = new Icon_button(getClass().getResource("/window_top_image/window_restore_light_normal.png"), "正常化");
		normal_button.setVisible(false);	
		quite_button = new Icon_button(getClass().getResource("/window_top_image/window_close_light_normal.png"), "关闭");
	   }
	   else {
		    min_button = new Icon_button(getClass().getResource("/window_top_image/window_min_dark_normal.png"),"最小化");		
			max_button = new Icon_button(getClass().getResource("/window_top_image/window_max_dark_normal.png"),"最大化");	
			normal_button = new Icon_button(getClass().getResource("/window_top_image/window_restore_dark_normal.png"),"正常化");
			normal_button.setVisible(false);	
			quite_button = new Icon_button(getClass().getResource("/window_top_image/window_close_dark_normal.png"),"关闭");
	   }
			
   }
   
   public void set_Size(boolean center,int width, int height) {
	
	   top_pane.update_title_button(width);
	   
	super.setSize(width, height);
	this.frame_width=width;
	this.frame_height=height;
	this.main_height = frame_height-top_height-5;
	
	set_jcomponent_size(top_pane, frame_width, top_height);
	set_jcomponent_size(outer_pane, frame_width, frame_height-top_height);
	set_jcomponent_size(inner_pane,frame_width-5, frame_height-top_height);
	set_jcomponent_size(main_pane, frame_width-5, frame_height-top_height-5);
	
	if(center) {setLocationRelativeTo(null);}
}

  public void update_frame_ui() {
	  
	  container.remove(back_pane);	  
	  container.add(back_pane);
	  
	  container.invalidate();
	  container.repaint();
	  container.setVisible(true);
	  
  }
  
  public void update_frame() {
	  
	  frame_width++;
	  frame_height++;
	  
	  set_Size(false,frame_width, frame_height);
	  
	  frame_width--;
	  frame_height--;
	  set_Size(false,frame_width, frame_height);
	  
	  setExtendedState(JFrame.NORMAL);
	  
	  repaint();
  }
  
  public void setRetractable(boolean retractable) {
	this.retractable = retractable;
}

public void setMin_width(int min_width) {
	this.retractable = true;
	this.min_width = min_width;
}

public void setMin_height(int min_height) {
	this.retractable = true;
	this.min_height = min_height-this.top_height;
}

public void setMax_width(int max_width) {
	this.retractable = true;
	this.max_width = max_width;
}

public void setMax_height(int max_height) {
	this.retractable = true;
	this.max_height = max_height-this.top_height;

}

public void set_top_prefer_size(int width, int height) {
	   
	   this.top_height = height;
	   set_Size(true, this.frame_width, this.frame_height);
   }
   
public JPanel get_box_pane(JPanel jPanel,int axis) {
	
	BoxLayout boxLayout = new BoxLayout(jPanel, axis);
	jPanel.setLayout(boxLayout);
	
	return jPanel;
}
public void set_jcomponent_size(JComponent jComponent,int width,int height) {
	
	jComponent.setPreferredSize(new Dimension(width,height));
	jComponent.setMinimumSize(new Dimension(width,height));
	jComponent.setMaximumSize(new Dimension(width,height));
}

public void set_flash(boolean flash) {
	back_pane.set_flash(flash);
}

public Icon_button get_min_button() {
	return this.min_button;
}
public Icon_button get_normal_button() {
	return this.normal_button;
}
public Icon_button get_max_button() {
	return this.max_button;
}
public Icon_button get_quite_button() {
	return this.quite_button;
}
public int get_main_width() {
	return frame_width-5;
}

public int get_main_height() {
	return frame_height-top_height-5;
}

public void add_top_component(Component Component,boolean right) {
	 if(right) {top_pane.add_right_component(Component);}
	 else {top_pane.add_left_component(Component);}
}
public void add_title_button() {
	   top_pane.add_title_button();
}
public void update_title_button(String link_account,String link_name) {
	   top_pane.update_title_button(link_account, link_name);
}

@Override
public void actionPerformed(ActionEvent e) {
	
	if(e.getSource()==min_button) {
	//	  this.setExtendedState(JFrame.ICONIFIED);
		  setVisible(false);
	}
	
	else if(e.getSource()==normal_button) {
		
		normal_button.setVisible(false);
		max_button.setVisible(true);
		    
			frame_width=normal_width;
			frame_height=normal_height;
			
			//Only_frame.this.setExtendedState(JFrame.NORMAL);
		  
			set_Size(true,frame_width, frame_height);
			
	}
	else if(e.getSource()==max_button) {
		
		normal_button.setVisible(true);
		max_button.setVisible(false);
		
		//Only_frame.this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        normal_width=frame_width;
        normal_height=frame_height;
	    
      Dimension size= java.awt.Toolkit.getDefaultToolkit().getScreenSize();
      frame_width=size.width;
      frame_height=size.height;
      
      set_Size(true,frame_width, frame_height);
     	  
	}
	
	else if(e.getSource()==quite_button) {
		
         this.dispose();
	}
}
public static void main(String[] args) {
	
//	 JFrame jFrame = new JFrame();
//	 jFrame.setBounds(150, 50, 500, 500);
//	 jFrame.setVisible(true);
	
	 Only_frame only_frame =  new Only_frame(new JPanel(), true, 40);
	 only_frame.set_Bounds(700, 50, 500, 500);
	 only_frame.setVisible(true);
	 only_frame.setMin_width(200);
	 only_frame.setMin_height(200);
	 
}
}
