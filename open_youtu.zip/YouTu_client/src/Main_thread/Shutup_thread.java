package Main_thread;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JTextPane;
import org.apache.commons.net.ntp.NTPUDPClient;
import org.apache.commons.net.ntp.TimeInfo;
import org.apache.commons.net.ntp.TimeStamp;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.IntData;

import Frame.Only_frame;
import Message.Group.Group_chat_message;

public class Shutup_thread extends Thread{

	JTextPane jTextPane = null;
	long conment_time = 0l;
	volatile long left_time = 8l;
	volatile boolean stop = false;
	
	public Shutup_thread(JTextPane jTextPane,Group_chat_message chat_message) {
		
		long send_time = chat_message.getSend_time();
		long shutup_minites = chat_message.getShutup_minites();
		shutup_minites*=60000;
		
		this.jTextPane = jTextPane;
		this.conment_time = send_time+shutup_minites;
		
		jTextPane.setText("");
		jTextPane.setEditable(false);
		
	}
public Shutup_thread(JTextPane jTextPane,long conment_time) {
		
		this.jTextPane = jTextPane;		
		this.conment_time = conment_time;
		
		jTextPane.setText("");
		jTextPane.setEditable(false);
	}
	
	public void stop_shutup() {
		this.stop = true;
	
	}
	
	@Override
	public void run() {
		
		while(!stop&&left_time>0) {
			
		left_time = conment_time-get_Intenet_DateTime();
		String tip = "你已被禁言，"+transfer_time(left_time)+" 后解除禁言";
		jTextPane.setText(tip);
		jTextPane.setEditable(false);
		try {
			Thread.sleep(30000);
		} catch (InterruptedException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}		
		} //while
		
		jTextPane.setText("");
		jTextPane.setEditable(true);
	
	}
	
	public String transfer_time(long time) {
		
		time/=1000;
		
		int d = (int) (time/(86400));
		int h = (int) (time%86400/3600);
		int m = (int) (time%86400%3600/60);
		
		String l_time = "";
		if(d>0) {l_time+=d+"天";}
		if(h>0) {l_time+=h+"小时";}
		if(m>0) {l_time+=m+"分钟";}
		if(l_time.length()==0) {l_time = "1分钟";}
		
		return l_time;
		
	}
	public  long get_Intenet_DateTime() {
    	   
		       TimeInfo timeInfo=null;
	   		   NTPUDPClient timeClient = new NTPUDPClient();
	   		   String timeServerUrl = "time.windows.com";
	   		   InetAddress timeServerAddress = null;
			try {
				timeServerAddress = InetAddress.getByName(timeServerUrl);
			} catch (UnknownHostException e1) {
				// TODO AYouTu-generated catch block
				e1.printStackTrace();
			}
			try {
				timeInfo = timeClient.getTime(timeServerAddress);
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
	   		   TimeStamp timeStamp = timeInfo.getMessage().getTransmitTimeStamp();
	   		   java.util.Date date = (java.util.Date) timeStamp.getDate();
	   		   
	   		   return date.getTime();
	   	 }
}
