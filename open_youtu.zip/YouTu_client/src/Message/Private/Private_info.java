package Message.Private;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.ImageIcon;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import tools.Icon_tools;
import tools.My_Object_IO;

public class Private_info implements Serializable{

	private static final long serialVersionUID = 1L;
	
	int type = 1;
	
	boolean scuess = false;
	String result = null;
	ImageIcon head_icon=null;
	String remarks = null;
	String group = null;
	
	String count=null;

	byte[] icon_bytes = null;
	String name=null;
	String sex=null;
	String birth=null;
	String blood=null;
	String home=null;
	String phone=null;
	String e_mail=null;
	String signature=null;
	String state=null;
	String ip = "";
	
	public Private_info() {
		
	}
	
	public Private_info(String count,byte[] icon_bytes, String name, String sex,
			String birth, String blood, String home, String phone, String e_mail, String signature,
			String state) {
	
		this.count = count;
		this.icon_bytes = icon_bytes;
		this.name = name;
		this.sex = sex;
		this.birth = birth;
		this.blood = blood;
		this.home = home;
		this.phone = phone;
		this.e_mail = e_mail;
		this.signature = signature;
		this.state = state;
		
	}

	public int getType() {
		return type;
	}


	public void setType(int type) {
		this.type = type;
	}
	
	
    public boolean isScuess() {
		return scuess;
	}

	public void setScuess(boolean scuess) {
		this.scuess = scuess;
	}

	
	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	private ImageIcon get_head_icon() {
    	
    	String icon_path = "E:\\oim\\all_head_image\\icon_"+count+".jpg";
    	
    	if(new File("E:\\oim\\all_head_image\\icon_"+count+".jpg").exists()) {
    	      
    		return new ImageIcon(icon_path);
    	}
    	
    	else {
    		return new ImageIcon(getClass().getResource("/background_image/default_image.png"));
    	}
    	
    }
    
	public ImageIcon getHead_icon() {
		
		if(head_icon==null) {head_icon = new ImageIcon(getIcon_bytes());}
		
		return head_icon;
	}


	public void setHead_icon(ImageIcon head_icon) {
		this.head_icon = head_icon;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public String getGroup() {
		return group;
	}


	public void setGroup(String group) {
		this.group = group;
	}


	public String getCount() {
		return count;
	}


	public void setCount(String count) {
		this.count = count;
	}


	public byte[] getIcon_bytes() {
		return icon_bytes;
	}


	public void set_icon_bytes(byte[] icon_bytes) {
		this.icon_bytes = icon_bytes;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getSex() {
		return sex;
	}


	public void setSex(String sex) {
		this.sex = sex;
	}


	public String getBirth() {
		return birth;
	}


	public void setBirth(String birth) {
		this.birth = birth;
	}


	public String getBlood() {
		return blood;
	}


	public void setBlood(String blood) {
		this.blood = blood;
	}


	public String getHome() {
		return home;
	}


	public void setHome(String home) {
		this.home = home;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getE_mail() {
		return e_mail;
	}


	public void setE_mail(String e_mail) {
		this.e_mail = e_mail;
	}


	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}
  
}