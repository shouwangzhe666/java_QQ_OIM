package tool_Frame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

import Frame.Only_frame;
import Main_frame_pane.Icon_show_pane;

public class Icon_show_frame implements ActionListener{

	Image image = null;
	int start_x=0;
	int start_y=0;
	int x=0;
	int y=0;
	int icon_width = 0;
	int icon_height = 0;
	
	Icon_show_pane show_pane = null;
	Only_frame only_frame = null;
	 
	public Icon_show_frame(ImageIcon imageIcon) {
		
		    show_pane = new Icon_show_pane(imageIcon);
	
		    Init_frame();
	        Init_listioner();	 	
		    
	}
	
	public void Init_frame() {
		
		    only_frame = new Only_frame(show_pane,40);	 
		    only_frame.set_window_buttons(true);	 
		    only_frame.set_Size(true,370,390);
		    only_frame.get_max_button().doClick();
		    only_frame.set_top_prefer_size(700, 30);
		    only_frame.set_Title("图片查看", new Font("微软雅黑", Font.PLAIN, 18), Color.white);		  		   
		    only_frame.setVisible(true);
	}
	
	public void Init_listioner() {
		
		only_frame.get_normal_button().addActionListener(this);
		only_frame.get_max_button().addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		new Timer().schedule(new TimerTask() {
			
			@Override
			public void run() {
			
				show_pane.re_paint();
			}
		}, 100);
	}
	

	public static void main(String[] args) {
		
		 new Icon_show_frame(new ImageIcon("C:\\ProgramData\\Users\\Administrator\\Pictures\\4654.jpg"));
	}

}
