package Private_chat;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JScrollBar;
import Frame.Main_Frame;
import Item.Private_Chat_Item;
import Item.File_Item;
import Message.Private.Private_Chat_Message;
import custom_component.My_ScrollPane;
import tool_Frame.Warn_frame;
import tools.Icon_tools;
import tools.My_Object_IO;

public class Private_show_pane extends My_ScrollPane {
    
	Dimension dimension = null;
	int type = 0;
	int all_y = 0;
	int[]po_x=null;
	int[]po_y=null;
	
	HashMap<Long, Private_Chat_Item> all_chat_item = null;
	
	ArrayList<Object> row_list=null;
	HashMap<Long, ArrayList<Object>> all_dataArrayList=null;
	
	Image self_icon=null;
	Image other_icon=null;
	ImageIcon imageIcon = null;
	
	 int link_count = 0;
	 int h = 0;
	 long send_time = 0l;
	 String file_path = null;
   	 
	 Font font = null;
	 Write_pane write_pane = null;	 
	 Cursor cursor = null;
	 Main_Show_pane main_Show_pane = null;
	 
	 SimpleDateFormat dateFormat = null;
	 SimpleDateFormat timeFormat = null;
	 SimpleDateFormat datetimeFormat = null;
	 // rowlist type = 1 face_text
	 //         type = 2 Icon_item
	 //         type = 3 remove_item
	 //         type = 4 shake_item
	 //         type = 5 
	 
	public Private_show_pane(int link_count, Write_pane write_pane) {
		
		dimension = Toolkit.getDefaultToolkit().getScreenSize();
		
		setPreferredSize(new Dimension(500,345));
		setMinimumSize(new Dimension(500, 345));
		setMaximumSize(dimension);
	
		
		Init_content(link_count, write_pane);
		
		main_Show_pane = new Main_Show_pane(this);
		setViewportView(main_Show_pane);
		
		load_all_chat_content();

	}
		
	public void Init_content(int link_count, Write_pane write_pane) {
		
		this.link_count = link_count;
		this.write_pane = write_pane;
		font = new Font("宋体", Font.PLAIN, 12);
		cursor = new Cursor(Cursor.DEFAULT_CURSOR);
		
		byte[] self_by = Icon_tools.get_IconBytes(Integer.parseInt(Main_Frame.getNative_count()));
		byte[] other_by = Icon_tools.get_IconBytes(link_count);
		
		this.self_icon = new ImageIcon(self_by).getImage();	
		this.other_icon = new ImageIcon(other_by).getImage();
		
		file_path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\chat_history\\private_chat\\"+link_count+".db";
		
		po_x=new int[3];
		po_y=new int[3];
		
		dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		timeFormat = new SimpleDateFormat("HH:mm:ss");
		datetimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		all_chat_item = new HashMap<>();
		all_dataArrayList = new HashMap<>();
				
	}		
 
	public void update_other_head_icon(byte[] icon_bytes) {
		
		 main_Show_pane.update_other_head_icon(icon_bytes);
	}
	
public void update_self_icon(byte[] icon_bytes) {
		
		main_Show_pane.update_self_icon(icon_bytes);
	}

 public void put_chat_Message(Private_Chat_Message chat_message,boolean save) throws IOException {

		boolean self = false;
		int from_count = chat_message.getFrom_account();
			    
		if(String.valueOf(from_count).equals(Main_Frame.getNative_count())) {self = true;}
		
		Private_Chat_Item private_Chat_Item = new Private_Chat_Item(chat_message, write_pane,this);
//		String content = chat_Item.get_popu_message();
		long send_time = chat_message.getSend_time();
		
		if(send_time-this.send_time>120000) {      // draw time_Item
			
			all_y+=30;
			boolean today = dateFormat.format(new Date()).equals(dateFormat.format(send_time));
			
			row_list = new ArrayList<Object>();
			row_list.add(5);
			row_list.add(today);
			row_list.add(send_time);
			row_list.add(all_y-20);
			
			all_dataArrayList.put(send_time-100, row_list);
			
		}
		
		this.send_time = send_time;
		
	    write_chat_message(chat_message, save);
	   
		all_chat_item.put(send_time, private_Chat_Item);
		
		int w=private_Chat_Item.get_total_width();
		h=private_Chat_Item.get_total_height();
		
		int x = 0;
		if(self) {x = getWidth()-55-w;}
		else {x= 55;}
	    
		row_list = new ArrayList<Object>();
		row_list.add(chat_message.getType());
		row_list.add(self);
		row_list.add(x);
		row_list.add(all_y);
		row_list.add(w);
		row_list.add(h);
		
		all_dataArrayList.put(send_time, row_list);
		
		private_Chat_Item.setBounds(x, all_y, w, h);	
		main_Show_pane.add(private_Chat_Item);
		
		all_y+=h+15;
	
		try {
			update(getGraphics());
		   
		} catch (Exception e) {
			
		}
			if(save&&get_difference_value()<50) {
			 int maxHeight = getVerticalScrollBar().getMaximum();  
	         getViewport().setViewPosition(new Point(0, maxHeight));  
	      
		   }
	
       if(save) {check_history_size(); }  // check_history_size
	}
 
 public void put_file_message(Private_Chat_Message chat_Message,boolean save) throws IOException {
	    
	    boolean self = false;
	    int from_count = chat_Message.getFrom_account();
	    if(from_count==(Integer.parseInt(Main_Frame.getNative_count()))) {self = true;}
	    
	    long send_time = chat_Message.getSend_time();	    
		Private_Chat_Item private_Chat_Item = new Private_Chat_Item(chat_Message, write_pane, this);
		all_chat_item.put(send_time, private_Chat_Item);
		
		write_chat_message(chat_Message, save);
		
		    int x = 0;
			int w=private_Chat_Item.get_total_width()+20;
			int h=private_Chat_Item.get_total_height()+20;
			
			if(self) {x = getWidth()-w-55-20;}
			else {x = 50;}
			
			row_list = new ArrayList<Object>();
			row_list.add(6);
			row_list.add(self);
			row_list.add(x);
			row_list.add(all_y);
			row_list.add(w);
			row_list.add(h);
			
			all_dataArrayList.put(send_time, row_list);
			
			if(self) {private_Chat_Item.setBounds(x+25, all_y+10, w-20, h-20);}
			else {private_Chat_Item.setBounds(x+10, all_y+10, w-20, h-20);}
			main_Show_pane.add(private_Chat_Item);
			
			all_y+=h+20;
		
		update(getGraphics());
			     
				if(save&&get_difference_value()<50) {
				 int maxHeight = getVerticalScrollBar().getMaximum();  
		         getViewport().setViewPosition(new Point(0, maxHeight));  
		      
			   }	
	}
 public void put_audio_message(Private_Chat_Message chat_Message,boolean save) throws IOException {
	    
	    boolean self = false;
	    int from_count = chat_Message.getFrom_account();
	    if(from_count==(Integer.parseInt(Main_Frame.getNative_count()))) {self = true;}
	    
	    long send_time = chat_Message.getSend_time();	    
		Private_Chat_Item private_Chat_Item = new Private_Chat_Item(chat_Message, write_pane, this);
		all_chat_item.put(send_time, private_Chat_Item);
		
		write_chat_message(chat_Message, save);
		
		    int x = 0;
			int w=private_Chat_Item.get_total_width();
			int h=private_Chat_Item.get_total_height();
			
			if(self) {x = getWidth()-w-55-20;}
			else {x = 50;}
			
			row_list = new ArrayList<Object>();
			row_list.add(7);
			row_list.add(self);
			row_list.add(x);
			row_list.add(all_y);
			row_list.add(w);
			row_list.add(h);
			
			all_dataArrayList.put(send_time, row_list);
			
			if(self) {private_Chat_Item.setBounds(x+25, all_y+10, w-20, h-20);}
			else {private_Chat_Item.setBounds(x+10, all_y+10, w-20, h-20);}
			main_Show_pane.add(private_Chat_Item);
			
			all_y+=h+20;
		
		update(getGraphics());
			     
				if(save&&get_difference_value()<50) {
				 int maxHeight = getVerticalScrollBar().getMaximum();  
		         getViewport().setViewPosition(new Point(0, maxHeight));  
		      
			   }	
	}
 public void remove_Item(Private_Chat_Message chat_Message,boolean save) throws IOException {
		
		long time_code = chat_Message.getTime_code();
		
		Private_Chat_Item item =  all_chat_item.get(time_code);
		if(item==null) {return;}
		
		main_Show_pane.remove(item);		
		all_chat_item.remove(time_code);
		
		write_chat_message(chat_Message, save);
		
		row_list = all_dataArrayList.get(time_code);
		row_list.set(0, 3);
		
		update(getGraphics());
	}
 
 public void shake_Item(Private_Chat_Message chat_Message,boolean save) {
	 
	    this.send_time = chat_Message.getSend_time();
	    
	    boolean self = false;
		int from_count = chat_Message.getFrom_account();
			    
		if(String.valueOf(from_count).equals(Main_Frame.getNative_count())) {self = true;}
		
		write_chat_message(chat_Message, save);
		
	    row_list = new ArrayList<Object>();
		row_list.add(4);
		row_list.add(self);
		row_list.add(0);
		row_list.add(all_y);
		
		all_dataArrayList.put(send_time, row_list);
		all_y+=30;
		
		update(getGraphics());
			     
				if(save&&get_difference_value()<50) {
				 int maxHeight = getVerticalScrollBar().getMaximum();  
		         getViewport().setViewPosition(new Point(0, maxHeight));  
		   
				}
 }
 
	
	public void delete_screen() {
	    
	    try {
			new FileOutputStream(new File(file_path), false).close();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		};
		
		main_Show_pane.removeAll();
		
	    all_chat_item = new HashMap<>();
	    all_dataArrayList = new HashMap<>();	    
	    all_y = 0;
	    
	    main_Show_pane.delete_screen();
	    
	    main_Show_pane.repaint();
		
		main_Show_pane.setPreferredSize(new Dimension(getWidth(), 0));
		main_Show_pane.setMinimumSize(new Dimension(getWidth(), 0));
		main_Show_pane.setMaximumSize(new Dimension(getWidth(),0));
		
		new Warn_frame("提示", "清屏后相关聊天记录将会同步删除").set_aYouTu_click(3);
	}	
	
	public void write_chat_message(Private_Chat_Message chat_Message,boolean save) {
		
		if(!save) {return;}
		
		ObjectOutputStream objectOutputStream  = My_Object_IO.get_ObjectoutputStream(file_path, true);
		try {
			objectOutputStream.writeObject(chat_Message);
			objectOutputStream.flush();
			objectOutputStream.close();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}		
	}
	
	public int get_all_y() {
		return all_y;
	//	return main_Show_pane.getHeight();
	}
	
	public void check_history_size() {
		
		 int max_size = 50;
		 
		if(all_chat_item.size()>max_size) {
			long[] all_code = get_sorted_array(all_dataArrayList.keySet());
			long code = 0l;
			Private_Chat_Item chat_Item = null;
			
			for(int i=0;i<all_code.length-max_size;i++) {
				code = all_code[i];
				chat_Item = all_chat_item.get(code);
				
				if(chat_Item==null) {continue;}
				
				main_Show_pane.remove(chat_Item);
				all_chat_item.remove(code);
				all_dataArrayList.remove(code);
			}
			
			main_Show_pane.repaint();
		} // if size>10
	}
	public long[] get_sorted_array(Set<Long> set) {
		
		Iterator<Long> it = set.iterator();
		long value = 0l;
				
		long[] all_int = new long[set.size()];
		
		int i = 0 ;
		while(it.hasNext()) {
			
			value = it.next();
			all_int[i] = value;
			i++;
		}
		
		Arrays.sort(all_int);
		
		return all_int;
	}
	
	public void load_all_chat_content() {

        File f = new File(this.file_path);
		
		if(!f.exists()||f.length()<5) {return;}
		     
		     int type = 0;
			 ObjectInputStream objectInputStream = My_Object_IO.get_ObjectInputStream(file_path);
			 Private_Chat_Message chat_Message = null;
			 ArrayList<Private_Chat_Message> all_message = new ArrayList<>();
			 int max_size = 50;
			 
       while(true) {
				 
				 try {
					chat_Message = (Private_Chat_Message) objectInputStream.readObject();
					all_message.add(chat_Message);
				} catch (ClassNotFoundException e) {
					break;
				} catch (IOException e) {
					break;
				}
       }
       
       if(all_message.size()>max_size) {
    	   ArrayList<Private_Chat_Message> all = new ArrayList<>();
    	   ObjectOutputStream objectOutputStream = My_Object_IO.get_ObjectoutputStream(file_path, false);
    	 
    	    for(int i=all_message.size()-max_size;i<all_message.size();i++) {
    	    	
    	    	chat_Message = all_message.get(i);
    	    	all.add(chat_Message);
    	    	try {
					objectOutputStream.writeObject(chat_Message);
				} catch (IOException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
    	    }
    	    all_message = all;
    	    all = null;
    	    try {
				objectOutputStream.close();
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
       }
			
            for(int i=0;i<all_message.size();i++) {
				
            	 chat_Message = all_message.get(i);
				 type = chat_Message.getType();
				 
				 try {
					 if(type==1||type==2) {put_chat_Message(chat_Message, false);}
					 else if(type==3) {remove_Item(chat_Message, false);}
					 else if(type==4) {shake_Item(chat_Message, false);}
					 else if(type==6) {put_file_message(chat_Message, false);}
					 else if(type==7) {put_audio_message(chat_Message, false);}
				} catch (Exception e) {
					e.printStackTrace();
				
				}
				
				} // for			
            
				all_message = null;
	}

public void lock_location(long time_code) {
		
		ArrayList<Object> row_list =  all_dataArrayList.get(time_code);
		
		if(row_list==null) { 
		    int maxHeight = getVerticalScrollBar().getMaximum();  
            getViewport().setViewPosition(new Point(0, maxHeight));
//          System.out.println("maxHeight: "+maxHeight);
		
        }
		else {
		  int y = (int) row_list.get(3);
		  getVerticalScrollBar().setValue(y);
		}
	}
public int get_difference_value() {
	
	  JScrollBar scrollBar = getVerticalScrollBar();
      int difference_value = main_Show_pane.getHeight()-scrollBar.getValue()-getHeight()-h;
      
      return difference_value;
}

	public ImageIcon get_headicon() {
		
		return this.imageIcon;
	}

public int get_difference_height() {
	
	return main_Show_pane.getHeight()-getHeight();
}
}