package Private_chat;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.filechooser.FileSystemView;

import Frame.Chat_frame;
import Frame.File_frame;
import Frame.Main_Frame;
import Message.Private.Private_Chat_Message;
import chat_frame_pane.Private_chat_pane;
import custom_component.Roundrec_button;
import tcp_pack.TCP_P2P_Pointer;
import tool_Frame.Warn_frame;
import tools.FileUtills;
import tools.My_Object_IO;
import tools.Play_sound;

public class File_accept_pane extends JPanel implements ActionListener{
    
	int link_account = 0;
    String ip = null;
    int p2p_type = 1;
    int server_port = 0;
    
    Socket socket =null;
	DataInputStream dataInputStream = null;
	DataOutputStream dataOutputStream = null;
	File file=null;
	RandomAccessFile write_file = null;
	
	String file_path = null;
	long file_code = 0l;
	String file_name=null;
	String file_progress_format = "0";
	String file_size = null;
	String speed = "0kb";
	String time_left = "0s";
	
	double file_progress=0;
	double size=0;
	int progress_x=0;
	int time = 30;
	long start_position = 0;
	long f_size  = 0l;
	volatile boolean accept = false;
	volatile boolean quite=false;
	boolean reply = false;
	boolean over = false;
	Image image = null;
	Font font = null;
	Color blue_color = null;
	
	volatile boolean transfer = false;
	Roundrec_button quite_button = null;
	
	public File_accept_pane(long file_code,long start_positon,String file_name, long size,int link_account,int p2p_type, int server_port) {
		 setLayout(null);
		 
		 setBackground(Color.LIGHT_GRAY);
	     setPreferredSize(new Dimension(400,100));
	     setMinimumSize(new Dimension(400,100));
		 setMaximumSize(new Dimension(400,100));
		 
		Init_content(file_code, file_name, size, link_account,p2p_type,server_port);
		Init_buttons();
		
		file = new File(file_path);
		this.file_progress = this.start_position = start_positon;
		
		new Timer_thread().start();
	}

	 public void Init_content(long file_code,String file_name, long size,int link_account,int p2p_type, int server_port) {
		 
		    this.file_code = file_code;
			this.file_name = file_name;
			this.size = size;
			this.link_account = link_account;
			this.p2p_type = p2p_type;
			this.server_port = server_port;
			this.f_size = size;
			file_size = FileUtills.file_size_format((long)size);
			
			 image = new ImageIcon("tool_image/file_transfer.png").getImage();
			 font = new Font("宋体", Font.PLAIN, 12);
			 blue_color = new Color(18, 181, 245);
			 
			 file_path = FileSystemView.getFileSystemView() .getHomeDirectory().getAbsolutePath()+"\\"+file_name;
			 System.out.println("file_name: "+file_name);	 
			 
			 if(new File(file_path).exists()) {start_position = new File(file_path).length();}
			 else {
				 int index = file_name.lastIndexOf(".");
				 file_path = FileSystemView.getFileSystemView() .getHomeDirectory().getAbsolutePath()+"\\"+file_name.substring(0,index)+".temp";
				 if(new File(file_path).exists()) {start_position = new File(file_path).length();}
               }
	 }
	 
	 public void Init_buttons() {
		 
		    quite_button = new  Roundrec_button(70, 25, 5, new Color(0, 180, 245), "取消", 14, Color.white);		
		    quite_button.setBounds(250,75,70, 25);
			super.add(quite_button);
			quite_button.addActionListener(this);
		 
	 }
	
  public void file_cancle() {
			
     File_frame.remove_file_pane(file_code);
		 
		 if(socket!=null&&!socket.isClosed()) {
			 try {
				socket.close();
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
		 }
	 }
 
	public void File_accept() {
		
		transfer = true;
		reply = true;
		this.accept = true;
		
		file_accept_configure();
		
		new File_accept_thread().start();
		new Transfer_speed_thead().start();
		
	}
	
	public void file_accept_configure() {
		 
	     FileUtills.create_new_file(file_path);
	     file = new File(file_path);
	     System.out.println("file_path: "+file_path);
		 try {
			write_file = new RandomAccessFile(file, "rw");
		} catch (FileNotFoundException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
		 try {
			write_file.seek(file.length());
		} catch (IOException e1) {
			// TODO AYouTu-generated catch block
			e1.printStackTrace();
		}
		 
		 if(p2p_type==1||p2p_type==2) {
			  TCP_P2P_Pointer p2p_Pointer = new TCP_P2P_Pointer("TCP_Pointer", server_port);
			  p2p_Pointer.start();
			  socket = p2p_Pointer.get_socket(60);
			}
			else if(p2p_type==3) {
				try {
					socket = new Socket(InetAddress.getByName("115.28.186.188"), server_port);
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		  
		  if(socket==null) {
			  File_termination_manager();
			  new Warn_frame("提示", "文件接收失败！");
			  return;
		  }
		  
			 try {
					dataInputStream = new DataInputStream(socket.getInputStream());
				} catch (IOException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
			  
	}
	
	 public void File_termination_manager() {
				 
		 quite = true;
		 String  file_path = FileSystemView.getFileSystemView() .getHomeDirectory().getAbsolutePath()+"\\"+file_name;
		 
		 System.out.println("file_accept_pane file_progress="+file_progress);
		 System.out.println("file_accept_pane size="+size);
		 
		 if(file_progress==size||file_progress>size) { over = true;}
				
		 try {
				write_file.close();
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
			
			if(over) {
							
			 file.renameTo(new File(file_path));	
				 
			 Private_Chat_Message chat_Message = new Private_Chat_Message(6,link_account, Integer.parseInt(Main_Frame.getNative_count()), file_code);
			 chat_Message.setFile_path(file_path);
			 			 
			 Main_Frame.getMessage_pane().put_accept_message_item(String.valueOf(link_account),System.currentTimeMillis(),"文件："+file_name+" 发送成功");
			 Chat_frame.update_item_content(String.valueOf(link_account), "文件："+file_name+" 接收成功");
			 
			    String path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\chat_history\\private_chat\\"+link_account+".db";
		        ObjectOutputStream objectOutputStream = My_Object_IO.get_ObjectoutputStream(path, true);
		        try {
					objectOutputStream.writeObject(chat_Message);
					objectOutputStream.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		       		        
			 Private_chat_pane chat_pane = (Private_chat_pane) Chat_frame.get_Private_chat_jpane(link_account);
		     if(chat_pane!=null) {chat_pane.put_file_message(chat_Message, false);}
		     
		     Play_sound.play_message_sound();
		     
			}
			
			 file_cancle();
//		System.out.println("file accept: "+file_progress);
	 }
	 
	@Override
	protected void paintComponent(Graphics g) {
	
		super.paintComponent(g);

		Graphics2D g2 =(Graphics2D) g;
		
		g2.setColor(new Color(230, 230, 230));
		g2.fillRect(0, 60, 400, 10);

		g2.drawImage(image, 5, 5, null);
		
		g2.setColor(blue_color);
		g2.fillRect(0, 60, progress_x, 10);
		
		g2.setColor(Color.BLACK);
		g2.setFont(font);
		
		g2.drawString("文件："+file_name, 30, 15);
		g2.drawString("大小："+file_progress_format+"/"+file_size,250, 15);
		
		if(accept) {
			
			g2.drawString("速度："+speed+"/s",250, 40);
			g2.drawString("预估剩余："+time_left, 30, 40);
		}
		
		else {
		
			g2.drawString("等待时间剩余： "+time+"s", 250, 40);
		}
	}
	
	private class File_accept_thread extends Thread{
		
		@Override
		public void run() {
			
			 byte[] by = new byte[1024*20];
			int len=0;
			
			try {
				while((len=dataInputStream.read(by))!=-1) {
					
					write_file.write(by, 0, len);					
					file_progress+=len;
//					System.out.println("len: "+len);				
				}
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}  //while true
			
			File_termination_manager();  //文件终止处理
			
		} // run
	}
	
	 private class Transfer_speed_thead extends Thread{
		 
		  // 文件传输速度测试线程
		 
		 @Override
		public void run() {

			    double bin=0l;
				long total=0l;
				long time = 0l;
				
					while(true) {
						
						if(file_progress>f_size) {file_progress = f_size;}
						
						file_progress_format = FileUtills.file_size_format((long) file_progress);
						double par = file_progress/size;
						progress_x=(int) (400*par);
						
						bin=file_progress;
						
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							// TODO AYouTu-generated catch block
							e.printStackTrace();
						}
						
						total=(long) (file_progress-bin);
						if(total==0) {continue;}
						
						speed = FileUtills.file_size_format(total);
						
						time=(long) ((size-file_progress)/total);
		
						time_left = time_format(time);
						
						repaint();
						
						if(quite||over) {break;}
						
					}  // while true

		} // run
	 }
	 
	 private class Timer_thread extends Thread{
         			
			@Override
			public void run() {
				
				while(time>0) {
					
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO AYouTu-generated catch block
						e.printStackTrace();
					}
					
					if(over) {break;}
					repaint();
					time--;
				}
				
				if(!reply) {
					
					file_cancle();
				}
			}
		}
	 
	 public String time_format(long time) {
			
			if(time<60) {return time+"s";}
			
			else if(time<3600) {
				long m = time/60;
				long s = time%60;
				return m+"分"+s+"秒";
	        }
			else {
				long h = time/3600;
				long m = (time%3600)/60;
				return h+"小时"+m+"分";
			}
		}
	 
	@Override
	public void actionPerformed(ActionEvent e) {
		 if(e.getSource()==quite_button) {
			if(transfer) { try {
				dataInputStream.close();
			} catch (IOException e1) {
				// TODO AYouTu-generated catch block
				e1.printStackTrace();
			}}
		
		} // if refuse_quite_button
	}
    
	public static void main(String[] args) {
		
		File file = null;
		String file_path = "C:\\ProgramData\\Users\\Administrator\\Desktop\\峰哥视频.temp";
		RandomAccessFile write_file = null;
		file = new File(file_path);
		
		 try {
				write_file = new RandomAccessFile(file, "rw");
			} catch (FileNotFoundException e1) {
				// TODO AYouTu-generated catch block
				e1.printStackTrace();
			}
		
		 try {
				write_file.close();
			} catch (IOException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
		
		    String path = "C:\\ProgramData\\Users\\Administrator\\Desktop\\峰哥视频.mp4";
			boolean scuess =  file.renameTo(new File(path));
			System.out.println("重命名是否成功？ "+scuess);
	}
}
