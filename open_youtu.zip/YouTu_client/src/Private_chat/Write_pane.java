package Private_chat;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.RandomAccessFile;
import java.nio.channels.FileLock;
import java.text.SimpleDateFormat;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;
import javax.swing.TransferHandler;
import javax.swing.text.BadLocationException;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import Frame.Chat_frame;
import Frame.File_frame;
import Frame.Main_Frame;
import Item.W_pane;
import Main_frame_Item.Main_JMenuItem;
import Message.Private.Apply_Message;
import Message.Private.Link_info;
import Message.Private.Private_Chat_Message;
import chat_frame_pane.Private_chat_pane;
import custom_component.My_ScrollPane;
import custom_component.My_text_pane;
import ss.Private_Chat_Client;
import sun.swing.SwingUtilities2;
import tool_Frame.Warn_frame;
import tools.Icon_tools;

public class Write_pane extends My_ScrollPane implements ActionListener,W_pane{

	My_text_pane textPane = null;
	Dimension dimension = null;
	
	JPopupMenu popupMenu = null;
    Main_JMenuItem past_item = null;
    Main_JMenuItem delete_item = null;
    
    SimpleDateFormat simpleDateFormat = null;
    long time_code = 0l;
    String native_count = null;
    String link_count = null;
    String reply_total_message = null;
    int reply_lenth = 0;
    boolean reply = false;
    Private_chat_pane show_pane = null;
    Robot robot = null;
    StyledDocument native_styledocment = null;
    String remark = null;
    
	public Write_pane(String link_count,Private_chat_pane show_pane) {
		
		setOpaque(false);
		getViewport().setOpaque(false);
		
		setPreferredSize(new Dimension(400,35));
		setMinimumSize(new Dimension(400,35));
		setMaximumSize(dimension);
	
		Init_text_pane();
		Init_textPane_keylistioner();
		Init_textPane_mouselistioner();
		Init_textPane_TransferHandler();
		
        Init_content(link_count, show_pane);
        
		Init_popmenu();
		
	}
	
    public void Init_content(String link_count,Private_chat_pane show_pane) {
    	try {
			robot = new Robot();
		} catch (AWTException e2) {
			
			e2.printStackTrace();
		}
		this.show_pane = show_pane;
		Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_count);
		this.remark = link_info.getRemark();
		link_info = null;
		this.link_count = link_count;
		simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		dimension = Toolkit.getDefaultToolkit().getScreenSize();
		native_styledocment = textPane.getStyledDocument();
		link_info=null;
    }
    
    public void Init_text_pane() {
    	
    	textPane = new My_text_pane();
		textPane.setBorder(null);
		textPane.setOpaque(false);
		textPane.putClientProperty(SwingUtilities2.AA_TEXT_PROPERTY_KEY,null);
		textPane.setFont(new Font("宋体", Font.PLAIN, 14));
		
		setViewportView(textPane);
    }
    
   public void Init_textPane_keylistioner() {
    	
         textPane.addKeyListener(new KeyAdapter() {
			
			@Override
			public void keyReleased(KeyEvent e) {
				
				Chat_frame.update_ui();
				
		 if(e.isControlDown()&&e.getKeyCode()==KeyEvent.VK_ENTER) {
			 if(Main_Frame.get_send_type()==1) {
					try {
						textPane.getStyledDocument().insertString(textPane.getStyledDocument().getLength(), " \n", null);
					} catch (BadLocationException e1) {
						
						e1.printStackTrace();
					}
			 }
			 else {
				 Send_message();	
			 }
				} // if control && enter
			 
		 else if(e.getKeyCode()==KeyEvent.VK_ENTER) {
		//    robot.keyPress(KeyEvent.VK_BACK_SPACE);
			if(Main_Frame.get_send_type()==1) {
			    Send_message();	
			 }
			
			     }  // if enter
		  
		 else if(e.getKeyCode()==KeyEvent.VK_BACK_SPACE&&reply) {
			   if(native_styledocment.getLength()<reply_lenth) {
				   
				   reply = false;
				   textPane.setText("");
				   textPane.setCaretPosition(0);
			   } 
			
		 }  // if back_space
				
			}  //keyReleased
			
		});
    }
    
    public void Init_textPane_mouselistioner() {
    	
      textPane.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mousePressed(MouseEvent e) {
				
				if(e.getButton()==3) {
				//	popupMenu.show(textPane, getX(), e.getY());
					popupMenu.show(null,e.getXOnScreen(), e.getYOnScreen());
				}
				
				else {popupMenu.setVisible(false);}
				
			}
		});
    }
    public void Init_textPane_TransferHandler() {
    	
    	textPane.setTransferHandler(new TransferHandler() {
    		/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
    		public boolean importData(JComponent arg0, Transferable t) {
    			  try {
                      Object o = t.getTransferData(DataFlavor.javaFileListFlavor);
                      
                      String filepath = o.toString();
                  
                      if (filepath.startsWith("[")) {
                          filepath = filepath.substring(1);
                      }
                      if (filepath.endsWith("]")) {
                          filepath = filepath.substring(0, filepath.length() - 1);
                      }
                   
                      File file = null;
                      file = new File(filepath);
                      
                      if(!file.isFile()) {return true;}
                      
                      // if icon
                      if(filepath.endsWith("png")||filepath.endsWith("jpg")) {
                    	  byte[] icon_bytes = Icon_tools.get_IconBytes(filepath);
                    	  Insert_icon(icon_bytes);
                      }                     
                      // if file
                      else{
                    	  
                    	  if(isSameComputor()) {
                    		  new Warn_frame("提示", "不允许在同一台计算机上收发文件！").set_aYouTu_click(6);
                    		  return true;
                    	  }
                        long file_code = System.currentTimeMillis();
                        
                        if(!File_frame.is_init()) {new File_frame();}
            			
                        String reply_ip = Main_Frame.getMessage_pane().get_link_info(link_count).getRemote_ip();
                    	String request_ip = Main_Frame.get_NativeIp();
                    	int p2p_type = reply_ip.endsWith("0000")||request_ip.endsWith("0000")?3:request_ip.equals(reply_ip)?2:1;
                    	
                    	int from_account  = Integer.parseInt(Main_Frame.getNative_count());
                    	int to_account = Integer.parseInt(link_count);
                    	
                    	Apply_Message apply_Message = new Apply_Message(131, 1, from_account, to_account, p2p_type, 1, 1, 1, true, request_ip, reply_ip);
            			apply_Message.setFile_code(file_code);
            			apply_Message.setFile_name(file.getName());
            			apply_Message.setFile_size(file.length());
            			
                        File_frame.put_Send_file_pane(apply_Message,file.getAbsolutePath());
                        
                        Private_Chat_Client.send_message(apply_Message);
                      }
                      return true;
                  }
                  catch (Exception e) {
                  	
                  }
				return true;
    		}
			 @Override
	            public boolean canImport(JComponent comp, DataFlavor[] flavors) {
	                for (int i = 0; i < flavors.length; i++) {
	                    if (DataFlavor.javaFileListFlavor.equals(flavors[i])) {
	                        return true;
	                    }
	                }
	                return false;
	            }
    	});
    }
	public void Init_popmenu() {
		
		popupMenu = new JPopupMenu();
		past_item = new Main_JMenuItem("黏贴", null);
		delete_item = new Main_JMenuItem("清空", null);
		
		popupMenu.add(past_item);	
		popupMenu.add(delete_item);
		
		past_item.addActionListener(this);
		delete_item.addActionListener(this);
	}
	
  public boolean wrap_line() {
	  
	  String type  = textPane.getStyledDocument().getCharacterElement(0).getName();
	  
		if(textPane.getStyledDocument().getLength()>300) {
			new Warn_frame("提示", "最多输入300字").set_aYouTu_click(3);
			return false;
		}
		
		if(textPane.getText().trim().length()==0&&!type.equals("icon")) {
			textPane.setText("");
			textPane.setCaretPosition(0);
			return false;
		}
		
	   textPane.setSelectionStart(textPane.getCaretPosition()-1);
	   textPane.setSelectionEnd(textPane.getCaretPosition());
	   textPane.replaceSelection("");

	    return true;
	}

	public void Send_message() {
		
		boolean send = wrap_line();
		if(!send) {return;}
		
		String popu_message = null; 
		
		long send_time  = System.currentTimeMillis();
		
		Private_Chat_Message chat_Message = new Private_Chat_Message(1,Integer.parseInt(Main_Frame.getNative_count()),Integer.parseInt(link_count),send_time);
		chat_Message.setDocument(textPane.getStyledDocument());
		
		boolean online = Main_Frame.getMessage_pane().is_online(link_count);
		chat_Message.setOnline(online);
		
		if(reply) {
			reply = false;
			chat_Message.setReply(true);
			chat_Message.setTime_code(time_code);
			}
		
		popu_message  = chat_Message.get_popu_message();
		Main_Frame.getMessage_pane().put_accept_message_item(link_count,send_time, popu_message);
		Chat_frame.update_item_content(link_count, popu_message);
		 
		show_pane.put_chat_Message(chat_Message, true);		
		
		Private_Chat_Client.send_message(chat_Message);
		chat_Message = null;
	    
		textPane.update_pane();
		textPane.setText("");
		textPane.setCaretPosition(0);
	}
	
	public void delete_content() {
	
		this.reply = false;
		textPane.update_pane();
		textPane.setText("");
		textPane.setCaretPosition(0);
	}
	
	@Override
	public void Insert_face(ImageIcon face) {
		
	//	textPane.setCaretPosition(textPane.getCaretPosition());
		textPane.insertIcon(face);
	
		try {
			textPane.getStyledDocument().insertString(textPane.getCaretPosition(), " ", null);
		} catch (BadLocationException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void Insert_icon(byte[] icon_bytes) {
	
		long send_time = System.currentTimeMillis();
		Private_Chat_Message chat_Message = new Private_Chat_Message(2,Integer.parseInt(Main_Frame.getNative_count()),Integer.parseInt(link_count),send_time);
		chat_Message.set_Icon(icon_bytes);
		
		boolean online = Main_Frame.getMessage_pane().is_online(link_count);
		chat_Message.setOnline(online);
		
		String popu_message  = chat_Message.get_popu_message();
		Main_Frame.getMessage_pane().put_accept_message_item(link_count,send_time,popu_message);
		Chat_frame.update_item_content(link_count, popu_message);
		
		if(reply) {
			reply = false;
			chat_Message.setReply(true);
			chat_Message.setTime_code(time_code);
			}
	
		show_pane.put_chat_Message(chat_Message, true);
		
		Private_Chat_Client.send_message(chat_Message);
		chat_Message = null;
	    
		textPane.update_pane();
		textPane.setText("");
		textPane.setCaretPosition(0);
	}

	public String get_link_count() {
		
		return this.link_count;		
	}
	
	public void reply_message(long time_code,String reply_message) {
		
		StyledDocument native_styledocment  = textPane.getStyledDocument();
		this.time_code  = time_code;
		this.reply = true;
		
		String that_time = new SimpleDateFormat("HH:mm:ss").format(time_code);
		
		String top_message = "“"+remark+"”   "+that_time+"   点击查看原文\n";
	    reply_message+="\n———————————————\n";
	    
		this.reply_total_message = top_message+reply_message;
		this.reply_lenth = reply_total_message.length();
		
		try {
			native_styledocment.insertString(0,reply_total_message, null);
		} catch (BadLocationException e) {
			
			e.printStackTrace();
		}

		textPane.setCaretPosition(native_styledocment.getLength());
		
	}
	
	public void paste() {
		
		StyledDocument styledDocument = Chat_frame.get_copy_styledocment();
		byte[] icon_bytes = Chat_frame.get_copy_iconbytes();
		
		if(styledDocument!=null) {
			paste_face_text(styledDocument);
		}		
		else if(icon_bytes!=null){
		
			Insert_icon(icon_bytes);
		}
	}

	public void paste_face_text(StyledDocument document) {
		
		String type = null;
		String temp_text="";
		
		for(int i=0;i<document.getLength();i++) {
  		 
  		  type= document.getCharacterElement(i).getName();
  		 
  		if(type.equals("content")){
 			 
 			 try {
 				temp_text =document.getText(i, 1);
				} catch (BadLocationException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
 			    
 			   int offset = textPane.getCaretPosition();
 			   try {
				textPane.getStyledDocument().insertString(offset, temp_text,null);
			} catch (BadLocationException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
 		 } // if text
  		
  		else if(type.equals("icon")) {
  			   			
  		//  add icon_name into the buf
  			
  			 Icon icon =StyleConstants.getIcon(document.getCharacterElement(i).getAttributes());
   			 ImageIcon imageIcon =(ImageIcon) icon;
   		      textPane.insertIcon(imageIcon);
		}
		} // for
		
		 robot.keyPress(KeyEvent.VK_BACK_SPACE);
	}
	
	public boolean isSameComputor() {
		RandomAccessFile randomAccessFile = null;
		FileLock fileLock =	null;
		String file_path = "C:\\ProgramData\\YouTu\\YouTu_"+link_count+"\\list_history\\security.db";
		try {
			randomAccessFile = new RandomAccessFile(new File(file_path), "rws");
			fileLock =	randomAccessFile.getChannel().tryLock();
			
			if(fileLock!=null) {
				fileLock.release();
				randomAccessFile.close();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return fileLock==null;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==past_item) {popupMenu.setVisible(false);paste();}
		else if(e.getSource()==delete_item) {popupMenu.setVisible(false);delete_content();}
	}
}
