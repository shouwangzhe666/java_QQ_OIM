package Item;

import java.awt.Dimension;

import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;

import Private_chat.Face_pane;
import Private_chat.Write_pane;

public class Face_pane_MenuItem extends JMenuItem {

	public Face_pane_MenuItem(JPopupMenu popupMenu,W_pane write_pane) {
		
		setOpaque(false);
		setContentAreaFilled(false);
		setBorder(null);
		setBorderPainted(false);
		
		setPreferredSize(new Dimension(370,160));
		setMinimumSize(new Dimension(370,160));
		setMaximumSize(new Dimension(370,160));
		
		add(new Face_pane(popupMenu, write_pane));
	}
	
	public Face_pane_MenuItem(JScrollPane scrollPane) {
	
		setContentAreaFilled(false);
		setBorder(null);
		setBorderPainted(false);
		
		setPreferredSize(new Dimension(250,100));
		setMinimumSize(new Dimension(250,100));
		setMaximumSize(new Dimension(250,100));
		
		add(scrollPane);
	}

	
}
