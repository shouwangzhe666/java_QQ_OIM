package Item;

import javax.swing.*;
import Frame.Login_frame;
import tools.Icon_tools;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

public class Login_Item extends JMenuItem {

	Image head_image = null;
	String name  = null;
	String account = null;
	String password = null;
	
	boolean enter = false;
	
	Font font1 = null;
	Font font2 = null;
	
	public Login_Item(Login_frame login_frame,Image head_image,String name,String account, String password) {
			
		this.head_image = head_image;
		this.name = name;
		this.account = account;
		this.password = password;
		font1 = new Font("宋体", Font.PLAIN,17);
		font2 = new Font("宋体", Font.PLAIN, 15);
		
		setPreferredSize(new Dimension(150,50));
		setMinimumSize(new Dimension(150,50));
		setMaximumSize(new Dimension(150,50));
		
		addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseEntered(MouseEvent e) {
				enter = true;
				repaint();
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				enter = false;
				repaint();
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				enter = false;
				login_frame.Init_content(head_image, account, password);
		
			}
		});
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		g2.setColor(Color.white);
		g2.fillRect(0,0, 150, 50);
		
		if(enter) {
			g2.setColor(new Color(0, 180, 245));
			g2.fillRect(0, 0, 150, 50);
		}
		else {g2.setColor(Color.white);}
		
	    g2.drawImage(head_image, 5, 5,40,40,null);		
		
		g2.setStroke(new BasicStroke(2f));
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2.drawOval(4,4,41,41);
		
		g2.setColor(Color.BLACK);
		
		g2.setFont(font1);
		g2.drawString(name, 55, 20);
		
		g2.setFont(font2);
		g2.drawString(account, 55, 40);
		
	}
}
