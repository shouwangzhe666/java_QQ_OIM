package Item;

import java.awt.Color;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.VetoableChangeListener;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPopupMenu;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.StyledDocument;
import Frame.Chat_frame;
import Frame.Main_Frame;
import Group_chat.Group_show_pane;
import Group_chat.Write_pane;
import Main_frame_Item.Main_JMenu;
import Main_frame_Item.Main_JMenuItem;
import Message.Group.Group_chat_message;
import Message.Private.Private_info;
import ss.Group_Chat_Client;
import ss.Private_Chat_Client;
import sun.swing.SwingUtilities2;
import tool_Frame.Icon_show_frame;
import tool_Frame.ShutUp_frame;
import tool_Frame.TextFild_Frame;
import tool_Frame.Warn_frame;
import tools.Icon_tools;

public class Group_Chat_Item extends JTextPane implements ActionListener{
   
    StyledDocument document=null;
    ImageIcon imageIcon=null;
    byte[] icon_bytes = null;
	int  icon_width=0;
    int  icon_height=0;
    
    int group_account = 0;
    int member_account = 0;
	int total_width=0;
	int total_height=0;
	int type=1;
	long send_time = 0l;
	long time_code = 0l;
	String popu_message = "";
	String native_id = null;
	String group_id = null;
	String group_remark = null;
	
	JPopupMenu popupMenu = null;
	
	Main_JMenuItem remove_item = null;
	Main_JMenuItem reply_item = null;
	Main_JMenuItem copyt_item = null;
	Main_JMenuItem save_item = null;
	Main_JMenuItem shutup_item = null;
	
	Main_JMenu else_popupMenu = null;
	Main_JMenuItem info_item = null;
	
	Main_JMenuItem administer_item = null;
	Main_JMenuItem id_item = null;
	Main_JMenuItem delete_item = null;
	
	Main_JMenuItem delete_screen_item = null;
	
	boolean self = false;
	boolean reply = false;
	volatile boolean shutup = false;
	Write_pane write_pane = null;
	Group_show_pane show_pane = null;
	
	public Group_Chat_Item(int group_account,String native_id,Group_chat_message chat_message,Write_pane write_pane,Group_show_pane show_pane) {
		
		setOpaque(false);
		setEditable(false);
		setLayout(new FlowLayout());
		putClientProperty(SwingUtilities2.AA_TEXT_PROPERTY_KEY,null);
		setFont(new Font("宋体", Font.PLAIN, 14));
		
		this.group_account = group_account;
		this.type = chat_message.getType();
		this.reply = chat_message.isReply();
		this.native_id = native_id;
		this.group_id = chat_message.getGroup_id();
		this.group_remark = chat_message.getGroup_remark();
		this.send_time = chat_message.getSend_time();
		this.time_code = chat_message.getTime_code();
		this.popu_message = chat_message.get_popu_message();
		this.write_pane = write_pane;
		this.show_pane = show_pane;
		this.member_account = chat_message.getMember_account();
		
        this.self = Main_Frame.getNative_count().equals(String.valueOf(member_account))?true:false;
		
		if(type==1) {setStyledDocument(chat_message.getDocument());}
		else if(type==2) {
			this.icon_bytes = chat_message.get_iconbytes();
			this.imageIcon = new ImageIcon(icon_bytes);
			Init_IconItem_Mouselitioner();
		}
		
		update_Chat_Item(show_pane.getWidth());				
        
        Init_Pane_MouseListioner();
        
        if(reply) {Init_reply_Mouselitioner();}
    
     }	
	
	public void Init_general_MenuItem() {
		
		popupMenu = new JPopupMenu();
		popupMenu.setBackground(Color.white);
		
		if(self||native_id.equals("群主")||native_id.equals("管理员")) {Init_remove_item();}
		
		reply_item = new Main_JMenuItem("回复", null);
		copyt_item = new Main_JMenuItem("复制", null);
		popupMenu.add(reply_item);
		popupMenu.add(copyt_item);
		
		if(type==2) {
			save_item = new Main_JMenuItem("保存", null);
		    popupMenu.add(save_item);
		    save_item.addActionListener(this);
		    
		}
		
		else_popupMenu = new Main_JMenu("其他");
		else_popupMenu.setBackground(Color.white);
		popupMenu.add(else_popupMenu);
		
		info_item = new Main_JMenuItem("查看资料", null);
		else_popupMenu.add(info_item);		
		
		delete_screen_item = new Main_JMenuItem("清屏", null);		
		popupMenu.add(delete_screen_item);
		
		reply_item.addActionListener(this);		
		copyt_item.addActionListener(this);
		info_item.addActionListener(this);
		delete_screen_item.addActionListener(this);
	
	}
	
public void Init_owner_MenuItem() {
	    
	      Init_administer_MenuItem();  // add shutup_item
	
	      if(group_id.equals("管理员")) {administer_item = new Main_JMenuItem("撤销管理员", null);}
	      else{administer_item = new Main_JMenuItem("设为管理员", null);}
	      id_item = new Main_JMenuItem("封爵", null);
	      delete_item = new Main_JMenuItem("踢出", null);
	      	    
	      else_popupMenu.add(administer_item);
	      else_popupMenu.add(id_item);
	      else_popupMenu.add(delete_item);
	      
	      administer_item.addActionListener(this);
	      id_item.addActionListener(this);
	      delete_item.addActionListener(this);
	}

public void Init_remove_item() {
	
	remove_item = new Main_JMenuItem("撤销", null);
	popupMenu.add(remove_item);
	remove_item.addActionListener(this);
}

public void Init_administer_MenuItem() {
	 
	if(native_id.equals("群主")||Integer.parseInt(Main_Frame.getNative_count())!=member_account) {
				
	      if(shutup) { shutup_item = new Main_JMenuItem("取消禁言", null);}
	      else {shutup_item = new Main_JMenuItem("禁言", null);}
	      
	      shutup_item.addActionListener(this);
	      popupMenu.add(shutup_item);
	      
	}	 
}

public void Init_Pane_MouseListioner() {
		
		addMouseListener(new MouseAdapter() {
        	
			@Override
			public void mouseReleased(MouseEvent e) {
				
				if(e.getButton()==3) {
					Init_general_MenuItem(); 
			        if(native_id.equals("群主")) {Init_owner_MenuItem();}
			        else if(native_id.equals("管理员")) {Init_administer_MenuItem();}
			        
					popupMenu.show(Group_Chat_Item.this,e.getX(),e.getY());
					}
			}
		});
	}
	
	public void Init_reply_Mouselitioner() {
		
		 addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				
				 if(e.getButton()==1) {show_pane.lock_location(time_code);}
			}
		});
	}
	
public void update_IconItem(int chat_pane) {
	   
	    int i_wid=imageIcon.getIconWidth();
		int f_wid=(int) (chat_pane*0.3);

		this.icon_width=f_wid;
		if(i_wid<f_wid) {this.icon_width=i_wid;}
		
		double bi= (double)this.icon_width/i_wid;
		this.icon_height=(int) (imageIcon.getIconHeight()*bi);
		
	    this.repaint();
}

public void Init_IconItem_Mouselitioner() {
	
	addMouseListener(new MouseAdapter() {
		
		@Override
		public void mouseClicked(MouseEvent e) {
			
			if(e.getClickCount()==2) {
				new Icon_show_frame(imageIcon);
			}
		}
	});
}
	
	public void update_text_face(int chat_pane_width) {
		
		int max_width = (int) (chat_pane_width*0.6);
		
        this.total_width = 0;
        this.total_height = 0;
        
        int row_width = 0;
        int row_height = 16;
        int char_code = 0 ;
        
        StyledDocument document = this.getStyledDocument();
	    String type="";
	    
	for(int i=0;i<document.getLength();i++) {
		 
		  type= document.getCharacterElement(i).getName();
		 
		 if(type.equals("icon")) {
			 
			 row_width+=30;
			 row_height = 30;
			 
			 if(row_width>max_width) {
				 row_width = 0;
			     this.total_width = max_width;
				 this.total_height+=16;
			 }
		 } // if
		 
		 else  if(type.equals("content")){
			 
			 String text="";
			 try {
				text =document.getText(i, 1);
			} catch (BadLocationException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
			 
			 if(text.equals("\n")) {
				 
				 this.total_height+=row_height;
				 if(row_width>this.total_width) {this.total_width = row_width;}
				 
				 row_width = 0; row_height = 16;
			 }  // 如果是空格
			 
			 else {
				 
				  char_code = (int)text.toCharArray()[0];
				  
				  if(char_code<123) {row_width+=7;}
				  else {row_width+=14;}
				  
				  if(row_width>max_width) {
					     row_width = 0;
					     this.total_width = max_width;
						 this.total_height+=16;
					 }
				  
			 } // 如果是字符
			 
		 } // if
		 
		 if(i==document.getLength()-1) {
			 this.total_height+=row_height;
			 if(row_width>this.total_width) {this.total_width = row_width;}
			 
			 row_width = 0; row_height = 16;
		 }  // 最后一句进行清算
		 
}// for循环
	
	  this.total_width+=15;
	  this.total_height+=15;
		
	}
	
	public void update_Chat_Item(int chat_pane_width) {
		
		if(type==1) {update_text_face(chat_pane_width);}
		else if(type==2) {update_IconItem(chat_pane_width);}
	}
	public int get_total_width() {
		
		if(type==2) {return icon_width;}
		return total_width;
	}
	
	public int get_total_height() {
		if(type==2) {return icon_height;}
		return total_height;
	}
	
	public int get_type() {
		
		return this.type;
	}

	public int get_member_account() {
		return member_account;
	}
	
	public void set_shutup(boolean shutup) {
		
		 this.shutup = shutup;
//		 if(shutup_item==null) {return;}
//		 
//		 if(shutup) {shutup_item.setText("撤销禁言");}
//	     else {shutup_item.setText("禁言");}
		 
	}
	
	public void set_groupid(String group_id) {
		 
		 this.group_id = group_id;
//		 if(group_id.equals("管理员")&&administer_item!=null) {administer_item.setText("撤销管理员");}
//		 else  if(group_id.equals("成员")&&administer_item!=null) {administer_item.setText("设为管理员");}
	}
	
	public void set_nativeid(String native_id) {
		 this.native_id = native_id;
		 
//		 if(native_id.equals("管理员")) {
//			 
//			 Init_remove_item();
//			 Init_administer_MenuItem();
//			 
//			 popupMenu.removeAll();
//			 
//			 popupMenu.add(remove_item);
//			 popupMenu.add(reply_item);
//			 popupMenu.add(copyt_item);
//			 
//			 if(Integer.parseInt(Main_Frame.getNative_count())!=member_account) {popupMenu.add(shutup_item);}
//		     if(type==2) {popupMenu.add(save_item);}
//		     
//		     popupMenu.add(else_popupMenu);
//		     
//		     popupMenu.add(delete_screen_item);
//		 }
//		 
//		 else {
//			 
//			 if(!self&&remove_item!=null) { popupMenu.remove(remove_item);}
//			 if(shutup_item!=null) {popupMenu.remove(shutup_item);}
//	
//		 }
	}
	public String get_id() {
		return group_id;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==info_item) {
			
			   Private_info private_info = new Private_info();
			   private_info.setType(3);
			   private_info.setCount(String.valueOf(member_account));
			   Private_Chat_Client.send_message(private_info);
		}
		
		else if(e.getSource()==copyt_item) {
			if(type==1) {Chat_frame.set_copy_styledocment(this.getStyledDocument());}
			else if(type==2) {Chat_frame.set_copy_iconbytes(icon_bytes);}
		}
		else if(e.getSource()==reply_item) {
			
			 String reply_string = null;		    
			 reply_string = this.popu_message.substring(3);
			
			write_pane.reply_message(send_time,group_remark,reply_string);
			
		} //if(e.getSource()==reply_item)
		else if(e.getSource()==remove_item) {
			
            if(self||native_id.equals("群主")||native_id.equals("管理员")) {
            	
			Group_chat_message chat_Message = null;
			
			if(self) {chat_Message = new Group_chat_message(3, member_account, System.currentTimeMillis(), group_id, group_remark, send_time);}
			else {chat_Message = new Group_chat_message(3, Integer.parseInt(Main_Frame.getNative_count()), System.currentTimeMillis(),native_id, group_remark, send_time);}
			chat_Message.setSelf(self);
	//	
			if(self){
				try {
			
				show_pane.remove_Item(chat_Message, true);
			} catch (IOException e1) {
				
				e1.printStackTrace();
			}	
				}		
			
			Group_Chat_Client.send_message(group_account, chat_Message);
            }
		}  // if remove_item
		else if(e.getSource()==save_item) {
			FileDialog fileDialog = new FileDialog(new JFrame(), "保存图片", FileDialog.SAVE);
			fileDialog.setVisible(true);
			
			String file_name = fileDialog.getFile();
			if(file_name==null) {return;}
			
			String icon_path = fileDialog.getDirectory()+file_name;
			
			if(file_name.endsWith("png")||file_name.endsWith("jpg")) {
				Icon_tools.Write_image(icon_path, icon_bytes);
			}
			else {new Warn_frame("提示", "只能保存为“png”或“jpg”格式的图片！").set_aYouTu_click(5);}
			
		} // save_item
		
		else if(e.getSource()==shutup_item) {
			      
			      if(!shutup) {
			    	  new ShutUp_frame(group_account, member_account, group_id, group_remark);
			      }
			      else {
			    	  
			    	  Group_chat_message chat_message = new Group_chat_message(4, member_account,System.currentTimeMillis(), group_id, group_remark, time_code);	
			    	  chat_message.setOpen_shutup(false);
			    	  
			    	  Group_Chat_Client.send_message(group_account, chat_message);
			      }
			      
		} // shutup_item
		
		else if(e.getSource()==administer_item) {
			
			 boolean administer = this.group_id.equals("管理员")?false:true;
			 
			 Group_chat_message chat_message = new Group_chat_message(5, member_account, System.currentTimeMillis(), group_id, group_remark, time_code);	
			 chat_message.setSet_Administrator(administer);
			 Group_Chat_Client.send_message(group_account, chat_message);			 
		} 
		else if(e.getSource()==id_item) {
			
			TextFild_Frame textFild_Frame = new TextFild_Frame("封爵", "请输入爵位：");
			textFild_Frame.alter_ActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
				
					String new_id = textFild_Frame.get_input_text();
					textFild_Frame.dispose_frame();
					if(new_id.length()==0) {return;}
					
					 Group_chat_message chat_message = new Group_chat_message(6, member_account, System.currentTimeMillis(), new_id, group_remark, time_code);	
					 Group_Chat_Client.send_message(group_account, chat_message);
				}
			});
		}
		else if(e.getSource()==delete_item) {
			 Group_chat_message chat_message = new Group_chat_message(7, member_account, System.currentTimeMillis(), group_id, group_remark, time_code);	
			 Group_Chat_Client.send_message(group_account, chat_message);
			 
		} 
		
		else if(e.getSource()==delete_screen_item) {
			show_pane.delete_screen();
		}  // if delete_item
		
		popupMenu.removeAll();
		popupMenu = null;
	}  //actionPerformed
	
	@Override
	protected void paintComponent(Graphics g) {	
		super.paintComponent(g);
		
		if(type==2) {g.drawImage(imageIcon.getImage(), 0, 0,icon_width,icon_height, null);}
	}
}
