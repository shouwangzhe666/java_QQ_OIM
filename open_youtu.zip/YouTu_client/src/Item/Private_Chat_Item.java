package Item;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPopupMenu;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.StyledDocument;
import Frame.Chat_frame;
import Frame.Main_Frame;
import Main_frame_Item.Main_JMenuItem;
import Message.Private.Private_Chat_Message;
import Private_chat.Private_show_pane;
import Private_chat.Write_pane;
import ss.Private_Chat_Client;
import sun.swing.SwingUtilities2;
import tool_Frame.Icon_show_frame;
import tool_Frame.Warn_frame;
import tools.Icon_tools;

public class Private_Chat_Item extends JTextPane implements ActionListener{
	
    StyledDocument document=null;
    ImageIcon imageIcon=null;
    byte[] icon_bytes = null;
	int  icon_width=0;
    int  icon_height=0;
    
    int link_account = 0;
	int total_width=0;
	int total_height=0;
	int type=1;
	int time_len = 0;
	long send_time = 0l;
	long time_code = 0l;
	String popu_message = "";
	
	JPopupMenu popupMenu = null;
	Main_JMenuItem remove_item = null;
	Main_JMenuItem reply_item = null;
	Main_JMenuItem copyt_item = null;
	Main_JMenuItem save_item = null;
	
	Main_JMenuItem delete_screen_item = null;
	
	boolean self = false;
	boolean copy = false;
	boolean reply = false;
	Write_pane write_pane = null;
	Private_show_pane show_pane = null;
	
	public Private_Chat_Item(Private_Chat_Message chat_message,Write_pane write_pane,Private_show_pane show_pane) {
		
		setOpaque(false);
		setEditable(false);
		setLayout(new FlowLayout());
		putClientProperty(SwingUtilities2.AA_TEXT_PROPERTY_KEY,null);
		setFont(new Font("宋体", Font.PLAIN, 14));
		
		this.type = chat_message.getType();
		this.send_time = chat_message.getSend_time();
		this.time_code = chat_message.getTime_code();
		this.popu_message = chat_message.get_popu_message();
		this.write_pane = write_pane;
		this.show_pane = show_pane;
		long from_account = chat_message.getFrom_account();
		this.self = String.valueOf(from_account).equals(Main_Frame.getNative_count())?true:false;
		this.link_account = self?chat_message.getTo_account():chat_message.getFrom_account();
		this.reply = chat_message.isReply();
        
		if(type==6) {                // insert File_Item
			this.total_width = 300;
			this.total_height = 100;
			
			String file_path = chat_message.getFile_path();
			insertComponent(new File_Item(file_path));
			return;
		}
		if(type==7) {               // insert Audio_Item
			this.total_width = 150;
			this.total_height = 40;
			
			insertComponent(new Audio_Item(chat_message, show_pane));
			return;
		}
		if(type==1) {setStyledDocument(chat_message.getDocument());}
		else if(type==2) {
			this.icon_bytes = chat_message.get_iconbytes();
			this.imageIcon = new ImageIcon(icon_bytes);
			Init_IconItem_Mouselitioner();
		}
		
		update_Chat_Item(show_pane.getWidth());
        
        Init_Pane_MouseListioner();
        
        if(reply) {Init_reply_Mouselitioner();}
        
     }	
	
	public void Init_all_MenuItem(boolean remove) {
		
		popupMenu = new JPopupMenu();
		popupMenu.setBackground(Color.white);
		
		if(remove) {
			  remove_item = new Main_JMenuItem("撤销", null);
			  popupMenu.add(remove_item);
			  remove_item.addActionListener(this);}
		
		reply_item = new Main_JMenuItem("回复", null);
		copyt_item = new Main_JMenuItem("复制", null);
		
		
		delete_screen_item = new Main_JMenuItem("清屏", null);
		
		popupMenu.add(reply_item);
		popupMenu.add(copyt_item);
		
		if(type==2) {
			save_item = new Main_JMenuItem("保存", null);
		    popupMenu.add(save_item);
		    save_item.addActionListener(this);
		    
		}
		
		popupMenu.add(delete_screen_item);
		
		
		copyt_item.addActionListener(this);
		reply_item.addActionListener(this);		
		delete_screen_item.addActionListener(this);
	
	}
	
	
	public void Init_Pane_MouseListioner() {
		
		addMouseListener(new MouseAdapter() {
        	
			@Override
			public void mouseReleased(MouseEvent e) {
				
				if(e.getButton()==3) {
					 if(self) {Init_all_MenuItem(true);}
				     else {Init_all_MenuItem(false); }
					 
					popupMenu.show(Private_Chat_Item.this,e.getX(),e.getY());
				}
			}
		});
	}
	
	public void Init_reply_Mouselitioner() {
		
		 addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				
				 if(e.getButton()==1) {show_pane.lock_location(time_code);}
			}
		});
	}
	
public void update_IconItem(int chat_pane) {
	   
	    int i_wid=imageIcon.getIconWidth();
		int f_wid=(int) (chat_pane*0.3);

		this.icon_width=f_wid;
		if(i_wid<f_wid) {this.icon_width=i_wid;}
		
		double bi= (double)this.icon_width/i_wid;
		this.icon_height=(int) (imageIcon.getIconHeight()*bi);
		
	    this.repaint();
}

public void Init_IconItem_Mouselitioner() {
	
	addMouseListener(new MouseAdapter() {
		
		@Override
		public void mouseClicked(MouseEvent e) {
			
			if(e.getClickCount()==2) {
				new Icon_show_frame(imageIcon);
			}
		}
	});
}
	
	public void update_text_face(int chat_pane_width) {
		
		int max_width = (int) (chat_pane_width*0.6);
		
        this.total_width = 0;
        this.total_height = 0;
        
        int row_width = 0;
        int row_height = 16;
        int char_code = 0 ;
        
        StyledDocument document = this.getStyledDocument();
	    String type="";
	    
	for(int i=0;i<document.getLength();i++) {
		 
		  type= document.getCharacterElement(i).getName();
		 
		 if(type.equals("icon")) {
			 
			 row_width+=30;
			 row_height = 30;
			 
			 if(row_width>max_width) {
				 row_width = 0;
			     this.total_width = max_width;
				 this.total_height+=16;
			 }
		 } // if
		 
		 else  if(type.equals("content")){
			 
			 String text="";
			 try {
				text =document.getText(i, 1);
			} catch (BadLocationException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
			 
			 if(text.equals("\n")) {
				 
				 this.total_height+=row_height;
				 if(row_width>this.total_width) {this.total_width = row_width;}
				 
				 row_width = 0; row_height = 16;
			 }  // 如果是空格
			 
			 else {
				 
				  char_code = (int)text.toCharArray()[0];
				  
				  if(char_code<123) {row_width+=7;}
				  else {row_width+=14;}
				  
				  if(row_width>max_width) {
					     row_width = 0;
					     this.total_width = max_width;
						 this.total_height+=16;
					 }
				  
			 } // 如果是字符
			 
		 } // if
		 
		 if(i==document.getLength()-1) {
			 this.total_height+=row_height;
			 if(row_width>this.total_width) {this.total_width = row_width;}
			 
			 row_width = 0; row_height = 16;
		 }  // 最后一句进行清算
		 
}// for循环
	
		this.total_width+=15;
		this.total_height+=15;
	}
	
	public void update_Chat_Item(int chat_pane_width) {
		
		if(type==1) {update_text_face(chat_pane_width);}
		else if(type==2) {update_IconItem(chat_pane_width);}
	}
	public int get_total_width() {
		
		if(type==2) {return icon_width;}
		return total_width;
	}
	
	public int get_total_height() {
		if(type==2) {return icon_height;}
		return total_height;
	}
	
	public int get_type() {
		
		return this.type;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
	
		if(e.getSource()==copyt_item) {
			if(type==1) {Chat_frame.set_copy_styledocment(this.getStyledDocument());}
			else if(type==2) {Chat_frame.set_copy_iconbytes(icon_bytes);}
		}
		else if(e.getSource()==reply_item) {
			
			write_pane.reply_message(send_time, this.popu_message);
			
		} //if(e.getSource()==reply_item)
		else if(e.getSource()==remove_item) {

			String from = Main_Frame.getNative_count();
			Private_Chat_Message chat_Message = new Private_Chat_Message(3,Integer.parseInt(from),link_account, System.currentTimeMillis());
			chat_Message.setTime_code(send_time);
			
			boolean online =  Main_Frame.getMessage_pane().is_online(String.valueOf(link_account));
			chat_Message.setOnline(online);
			
			try {
				show_pane.remove_Item(chat_Message, true);
			} catch (IOException e1) {
				
				e1.printStackTrace();
			}
			
			Private_Chat_Client.send_message(chat_Message);
		}  // if remove_item
		else if(e.getSource()==save_item) {
			FileDialog fileDialog = new FileDialog(new JFrame(), "保存图片", FileDialog.SAVE);
			fileDialog.setVisible(true);
			
			String file_name = fileDialog.getFile();
			if(file_name==null) {return;}
			
			String icon_path = fileDialog.getDirectory()+file_name;
			
			if(file_name.endsWith("png")||file_name.endsWith("jpg")) {
				Icon_tools.Write_image(icon_path, icon_bytes);
			}
			else {new Warn_frame("提示", "只能保存为“png”或“jpg”格式的图片！").set_aYouTu_click(5);}
			
		} // save_item
		else if(e.getSource()==delete_screen_item) {
			show_pane.delete_screen();
		}  // if delete_item
		
		popupMenu.removeAll();
		popupMenu = null;
	}  //actionPerformed
	
	@Override
	protected void paintComponent(Graphics g) {		
		super.paintComponent(g);
		
		if(type==2) {g.drawImage(imageIcon.getImage(), 0, 0,icon_width,icon_height, null);}
	}
}
