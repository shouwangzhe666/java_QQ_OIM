package private_encoder_pack;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import message_login_register.Ping_Pong;

public class Ping_Pong_encoder extends MessageToByteEncoder<Ping_Pong>{

	@Override
	protected void encode(ChannelHandlerContext arg0, Ping_Pong ping_Pong, ByteBuf buf) throws Exception {
	
		buf.writeInt(310);
		buf.writeInt(ping_Pong.get_account());
	}

}
