package ssl_test;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.Socket;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;

public class SSLSocket_Server extends Thread{
	Socket socket =  null;
    SSLServerSocket serverSocket = null;

    public SSLSocket_Server() {
    	
		   SSLContext sslContext = SslContextFactory.get_serve_sslContext();
		   try {
			serverSocket = (SSLServerSocket) sslContext.getServerSocketFactory().createServerSocket(6666);
			serverSocket.setNeedClientAuth(true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    
    @Override
    public void run() {
    	
    	byte[] by = new byte[1024];
    	
    	try {
			socket = serverSocket.accept();
			socket.getInputStream().read(by);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	try {
			String s = new String(by,"UTF-8");
			System.out.println("服务端收到消息："+s);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	try {
			socket.close();
			serverSocket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    } // run
    
    public static void main(String[] args) {
		
    	new SSLSocket_Server().start();
    	System.out.println("服务端启动");
	}
}
