package custom_component;

import javax.swing.JTextPane;
import javax.swing.text.EditorKit;

public class My_text_pane extends JTextPane{

	public void update_pane() {
		
		EditorKit editorKit = createDefaultEditorKit();
        setEditorKit(editorKit);
	}
}
