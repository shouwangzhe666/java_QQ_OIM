package custom_component;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.geom.Rectangle2D;

import javax.swing.JLabel;

import com.sun.javafx.tk.FontMetrics;
import com.sun.org.apache.xerces.internal.util.SynchronizedSymbolTable;

import sun.font.FontDesignMetrics;

public class My_label extends JLabel{

	 Font f=null;
	 String text=null;
	 int label_width=0;
	 int label_height=0;
	 
         public My_label(String text,int font_size,Color font_color) {
			
        	 this.text=text;
        	 setOpaque(false);
        	 setBorder(null);
        	 setText(text);
        	 f =new Font(text, Font.PLAIN, font_size);
        	 setFont(f);
        	 setForeground(font_color);
        	
        	 java.awt.FontMetrics fMetrics = getFontMetrics(f);
        	 
        	 this.label_width=fMetrics.stringWidth(text);
        	 this.label_height=fMetrics.getHeight();
             
        	 setPreferredSize(new Dimension(this.label_width, this.label_height));
        	 setMaximumSize(new Dimension(this.label_width, this.label_height));
        	 
		}
         
        
        public int get_label_width() {
        	return this.label_width;
        }
        
      public int get_label_height() {
        	return this.label_height;
        }
       
}
