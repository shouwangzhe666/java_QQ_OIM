package custom_component;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
import javax.swing.plaf.basic.BasicArrowButton;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicComboPopup;
import javax.swing.plaf.basic.ComboPopup;

import jdk.nashorn.internal.ir.WhileNode;

public class My_combox extends JComboBox<String>{

	boolean enter=false;
	boolean down=true;
	
	JButton arrobutton= null;
	ImageIcon left_image = null;
	ImageIcon down_image = null;
	
	My_basicbox_UI basicbox_UI = null;
	
     public My_combox(String[] items) {
    	 super(items);
    	 
    	 setOpaque(false);
    
    	 left_image = new ImageIcon(getClass().getResource("/main_frame_image/combox_left.png"));
    	 down_image = new ImageIcon(getClass().getResource("/main_frame_image/combox_down.png"));
    	 
    	 addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				
		//		if(e.getStateChange()==ItemEvent.SELECTED) {
					arrobutton.setIcon(left_image);
		//		}
				
				
			}
		});
    	 
    	 setUI(new My_basicbox_UI());
    	
    	 setRenderer(new My_ListCellRenderer());
	}
     
     private class My_basicbox_UI extends BasicComboBoxUI{
    	 
    	Color blue = null;
     	Color white = null;
     	
     	Font font = null;
     	JLabel jl = null;
     	String s = null;
     	
     	 public My_basicbox_UI() {
 			
     		blue = new Color(35,134,235);
     		white = Color.white;
     		font = new Font("微软雅黑", Font.PLAIN, 15);
     		
 		}
     	 
    	 @Override
    	public void paint(Graphics g, JComponent c) {
    		 
    		  hasFocus = comboBox.hasFocus();
    		  Graphics2D g2 = (Graphics2D)g;
    		  Rectangle bounds = rectangleForCurrentValue();
              
    		  if(!hasFocus) {arrobutton.setIcon(left_image); }
    		 
    		  
    	      paintCurrentValueBackground(g2, bounds, hasFocus);
    	      paintCurrentValue(g2, bounds, hasFocus);   	  
    	}
 
    	 @Override
    	public void paintCurrentValue(Graphics g, Rectangle bounds, boolean hasFocus) {    		 
    		
//    		 comboBox.setForeground(white);
//    		 comboBox.setFont(font);
    //		 super.paintCurrentValue(g, bounds, hasFocus);   
    		 
    		 Graphics2D g2 = (Graphics2D) g;
    		 g2.setColor(white);
    		 g2.setFont(font);
   		
    		 s = (String)comboBox.getSelectedItem();
    		if(s.length()>2) {g2.drawString(s, 0, 17);}
    		else if(s.length()==2) {g2.drawString(s, 5, 17);}
    		else if(s.length()==1) {g2.drawString(s, 10, 17);}
    	}
    	 
    	 @Override
    	public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus) { 
   
    		 Graphics2D g2 = (Graphics2D) g;
    		 g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
    				    RenderingHints.VALUE_ANTIALIAS_ON);
    		 
    		   g2.setColor(blue);
    		   g2.fillRoundRect(0, 0,bounds.width,bounds.height, 5, 5);
    		   		    		
    	}
    	
    	 @Override
   protected JButton createArrowButton() {
    		
    		 arrobutton = new JButton();
    		 arrobutton.setIcon(left_image);
//    		 arrobutton.setRolloverEnabled(true);
    	        // arrow.setRolloverIcon(XUtil.defaultComboBoxArrowIcon_Into);
    		 arrobutton.setBorder(null);
    	        // arrow.setBackground(XUtil.defaultComboBoxColor);
    		 arrobutton.setOpaque(false);
    		 arrobutton.setContentAreaFilled(false);
    	        return arrobutton;
    	}
    	 
    	
    	 @Override
    	protected ComboPopup createPopup() {

    		 ComboPopup comboPopup = new BasicComboPopup(comboBox) {
    	
    			 @Override
    			protected JScrollPane createScroller() {
    			   				 
    			     My_ScrollPane my_ScrollPane = new My_ScrollPane();
    				 my_ScrollPane.setViewportView(list);
    				 my_ScrollPane.setOpaque(false);
    				 my_ScrollPane.set_thumb_color(Color.gray);
    				 my_ScrollPane.set_thumb_enterable(false);
    				 
    				return my_ScrollPane;
    			}
    			 
    			
    			 @Override
    			protected void paintBorder(Graphics g) {
    				    				
    				 Graphics2D g2 = (Graphics2D) g;
    	    		 g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
    	    				    RenderingHints.VALUE_ANTIALIAS_ON);
    	    		 
//    	    		 g2.setComposite(AlphaComposite
//    						    .getInstance(AlphaComposite.SRC_OVER, 0.5f));
    	    		 
    	    	     g2.setColor(Color.BLUE);
    	    		 g2.setStroke(new BasicStroke(4f));
    	    	   
    	    		 g2.drawRect(0,-27, getPreferredSize().width, getPreferredSize().height+27);  
    			}
    		 };   		 
    		 
    		return comboPopup;
    	}
     }
     
   public static void main(String[] args) {
	
	   String[] bir1=new String[120];
	   JLabel[]items = new JLabel[120];
		int i1=2019;
		for(int i=0;i<120;i++) {
			bir1[i]=""+i1+"年";
			i1--;
			items[i] = new JLabel(bir1[i]);
		}
		
		JComboBox<String> birth1 = new JComboBox<>(bir1);
		My_combox birth2 = new My_combox(bir1);
		birth2.setPreferredSize(new Dimension(80,25));
		
		  JFrame jFrame = new JFrame();
		  jFrame.getContentPane().setLayout(new FlowLayout());
		  jFrame.getContentPane().add(birth1);
		  jFrame.getContentPane().add(birth2);
		
		  jFrame.setBounds(500, 200, 500, 500);
		  jFrame.setVisible(true);
}
}
