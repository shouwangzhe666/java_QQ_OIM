package custom_component;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JButton;
import javax.swing.JFrame;

public class Roundrec_button extends JButton{

  int width=0;
  int height=0;
  int font_size=0;
  int x=0;
  int y=0;
  int str_width=0;
  int str_height=0;
  int arcWidth=0;
  int secondes = 0;
  
  Color background_color=null;
  String text=null;
  String temp_text=null;
  Color text_color=null;
  
  boolean pressed=false;
  boolean entered=false;
  
  boolean enable = true;
  boolean quite = false;
  Font font = null;
  FontRenderContext frc = null;
  
  public Roundrec_button(int width,int height,int arcWidth,Color background_color,String text,int font_size,Color text_color) {
	  
	  this.width=width;
	  this.height=height;
	  this.arcWidth=arcWidth;
	  this.font_size=font_size;
	  this.background_color=background_color;
	  this.temp_text=this.text=text;
	  this.text_color=text_color;
	  
	   setContentAreaFilled(false);
	   setBorderPainted(false);
	   
	  //Microsoft Yahei
	 font = new Font("Microsoft Yahei", Font.PLAIN,font_size);
	 frc = new FontRenderContext(new AffineTransform(),true,true);
	 Rectangle rec = font.getStringBounds(text, frc).getBounds();
	
	str_width= rec.width;
	str_height= rec.height;
	x=(width-str_width)/2;
	y=(int) ((height-str_height)/2+str_height*0.7);
	  
	   setPreferredSize(new Dimension(width,height));
	   setMaximumSize(new Dimension(width,height));
	   setMinimumSize(new Dimension(width,height));
	  
	   
	   addMouseListener(new MouseAdapter() {
		   
		   @Override
		public void mousePressed(MouseEvent e) {
           if(!enable) {return;}
			   pressed=true;
			  
			   repaint();

		}
		   
		   @Override
		public void mouseReleased(MouseEvent e) {
			   if(!enable) {return;}
			   pressed=false;
			   repaint();
		}
		   
		   @Override
		public void mouseEntered(MouseEvent e) {
			   if(!enable) {return;}
			   entered=true;
			   repaint();
		}
		   
		   @Override
		public void mouseExited(MouseEvent e) {
			   if(!enable) {return;}
			   entered=false;
			   repaint();
		}
	});
	   
	
  }
	
  public String get_text() {
	  return this.text;
  }
  
  public void set_ori_text(String text) {
	  
	  this.temp_text = text;
	  set_text(text);
  }
  
  private void set_text(String text) {
	  
	  this.text=text;
	  Rectangle rec = font.getStringBounds(text, frc).getBounds();
		
		str_width= rec.width;
		str_height= rec.height;
		x=(width-str_width)/2;
		y=(int) ((height-str_height)/2+str_height*0.7);
		
	    repaint();
  }
 
  @Override
	public void setEnabled(boolean enable) {
		super.setEnabled(enable);
		
		this.enable = enable;
		if(!enable) {entered = true;}
		else {entered = false;pressed=false;}
		
		repaint();
	}
  
  public void set_auto_click(int seconds,boolean auto_click) {
	  
	 if(!auto_click) {setEnabled(false);}
	 
	 Timer timer = new Timer();
	 timer.schedule(new Timer_task(timer,seconds,auto_click), 0, 1000);
  }
  public void cancle_aYouTu_click() {
	  quite = true;
  }
  public void set_timing_unable(int seconds) {
	  
	  setEnabled(false);
	  set_auto_click(seconds, false);
  }
  
  private class Timer_task extends TimerTask{

	  Timer timer = null;
	  int seconds = 0;
	  boolean auto_click = true;
	  
	  public Timer_task(Timer timer,int seconds, boolean auto_click) {
		  this.timer = timer;
		this.seconds = seconds;
		this.auto_click = auto_click;
	}
	  
	@Override
	public void run() {
		
		 String s = temp_text+" ("+seconds+"s)";
		 set_text(s);
		 seconds--;
		 
		 if(quite) {timer.cancel();return;}
		 
		 if(seconds==-1) {

		     set_text(temp_text);
		     
		    if(auto_click) { doClick();}
		    else {setEnabled(true);}
		    
		     timer.cancel();
		 }		
	}	  
  }
  
  @Override
	protected void paintBorder(Graphics g) {
		super.paintBorder(g);
	  Graphics2D g2 = (Graphics2D) g;
	  g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	  g2.setComposite(AlphaComposite
			    .getInstance(AlphaComposite.SRC_OVER, 1f));
	  
     if(entered) {
		  
		  g2.setComposite(AlphaComposite
				    .getInstance(AlphaComposite.SRC_OVER, 0.7f));
	  }
	  
	  if(pressed) {
		  
		  g2.setComposite(AlphaComposite
				    .getInstance(AlphaComposite.SRC_OVER, 0.3f));
	  }
	  
	  if(background_color!=null) {
		  
		  g2.setColor(background_color);		  
		  g2.fillRoundRect(3, 3, width-6, height-6,arcWidth, arcWidth);
	  }
	
	  g2.setColor(text_color);
	  g2.setFont(font);
      
      g2.drawString(text, x, y);
      
	}
  
  public static void main(String[] args) {
	  
	 JButton button1 = new JButton("按钮一");
     Roundrec_button button2 = new Roundrec_button(120, 35, 15, new Color(0, 131, 245), "按钮二", 16, Color.white);
     button2.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("按钮被点击");
		}
	});
     
	  JFrame jFrame = new JFrame();
	  jFrame.getContentPane().setLayout(new FlowLayout());
	  jFrame.getContentPane().add(button1);
	  jFrame.getContentPane().add(button2);
	  jFrame.setBounds(500, 200, 500, 500);
	  jFrame.setVisible(true);
	  
	  button2.set_auto_click(3, false);
//	  button2.setEnabled(false);
}
}
