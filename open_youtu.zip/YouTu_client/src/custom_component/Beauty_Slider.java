package custom_component;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import javax.swing.JFrame;
import javax.swing.JSlider;
import javax.swing.plaf.metal.MetalSliderUI;

public class Beauty_Slider extends JSlider{
	
	Color thumb_color = null;
	Color track_color = null;
	Image image = null;
	
	public Beauty_Slider(int min_value,int max_value,int preffer_value) {
	   super(min_value, max_value, preffer_value);
	   setOpaque(false);
	  
		track_color = Color.lightGray;
		thumb_color = new Color(0, 131,245);
//		image = new ImageIcon(Icon_button.class.getResource("/tool_image/face.png")).getImage();
	    setUI(new Beauty_UI());
	     
	}
	
	public void set_thumb_color(Color thumb_color) {
		this.thumb_color = thumb_color;
		repaint();

	}
	public void set_track_color(Color track_color) {
		this.track_color = track_color;
		repaint();
	}
	
	private class  Beauty_UI extends MetalSliderUI{
		
		@Override
    	public void paintThumb(Graphics g) {
          
    		Graphics2D g2d = (Graphics2D) g;
    		
    		g2d.setColor(thumb_color);
    		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    		
    		g2d.fillOval(thumbRect.x, thumbRect.y, thumbRect.width,thumbRect.height);
         
//          g2d.drawImage(image, thumbRect.x, thumbRect.y, thumbRect.width,thumbRect.height,null);

    	}
    	public void paintTrack(Graphics g) {
            //绘制刻度的轨迹
    		int ty;
    		Rectangle trackBounds = trackRect;
    		if (slider.getOrientation() == JSlider.HORIZONTAL) {
    			Graphics2D g2 = (Graphics2D) g;
    			g2.setPaint(track_color);//将背景设为黑色
    			ty = (trackBounds.height/2) - 2;
    			
    			
    			g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
    					RenderingHints.VALUE_ANTIALIAS_ON);
    			g2.translate(trackBounds.x, trackBounds.y + ty);
    			g2.fillRect(0, 0, trackBounds.width, trackBounds.height/2-2);
    			

    			g2.translate(-trackBounds.x, -(trackBounds.y + ty));   					
    		}
    		else {
				super.paintTrack(g);
				}
    	}
	}
	public static void main(String[] args) {
		
		Beauty_Slider beauty_Slider = new Beauty_Slider(0, 100, 50);
		  
		  JFrame jFrame = new JFrame();
		  jFrame.getContentPane().setLayout(new FlowLayout());
		  jFrame.getContentPane().add(new JSlider(0, 100, 50));
		  jFrame.getContentPane().add(beauty_Slider);
		  jFrame.setBounds(500, 200, 500, 500);
		  jFrame.setVisible(true);
		  
		  beauty_Slider.set_thumb_color(Color.red);
		  beauty_Slider.set_track_color(Color.black);
	}
}
