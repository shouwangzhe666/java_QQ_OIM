package custom_component;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import Frame.Group_info_frame;
import Message.Group.Group_info_message;
import Message.Private.Private_info;
import ss.Group_Chat_Client;
import ss.Private_Chat_Client;

public class Title_button extends Icon_button implements ActionListener{

	Font font = null;
	FontRenderContext frc = null;
	String link_account = null;
	String link_name = null;	
	int width = 0;
	int height = 0;
	long time = 0;
	
	public Title_button() {
		super(null, "点击查看资料");
		font = new Font("微软雅黑", Font.PLAIN, 18);
		frc = new FontRenderContext(new AffineTransform(),true,true);
		
		set_tip_y(15);
		addActionListener(this);
	}

    public void update(String link_account,String link_name) {
    	
    	 this.link_account = link_account;
    	 this.link_name = link_name;
    	 
    	 Rectangle rec = font.getStringBounds(link_name, frc).getBounds();
    	 width = (int) rec.getWidth()+25;
    	 height = (int) rec.getHeight();
    	 
    	 setPreferredSize(new Dimension(width, height));
    	 setMinimumSize(new Dimension(width, height));
    	 setMaximumSize(new Dimension(width, height));
    	 
    	 repaint();
    }
    
    public int get_buttonWidth() {
		return width;
	}

	public int get_buttonHeight() {
		return height;
	}

	@Override
    protected void paintComponent(Graphics g) {
    	super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
		
       if(link_name!=null) {
		g2.setColor(Color.black);
		g2.setFont(font);
		g2.drawString(link_name,10, 20);
       }
    }

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(System.currentTimeMillis()-time<2000) {return;}
		time = System.currentTimeMillis();
		
		if(link_account.length()==8) {
			  Private_info info = new Private_info();
			  info.setType(3);
			  info.setCount(link_account);
			  Private_Chat_Client.send_message(info);
		}
		else if(link_account.length()==9) {
			 int current_account = Integer.parseInt(link_account);
			  
			  if(!Group_info_frame.is_init()) {new Group_info_frame();}
			  
			  Group_info_frame.set_visiable(true);
			  if(Group_info_frame.get_group_account()!=current_account) {
				  Group_info_message group_info_message = new Group_info_message(1, current_account);
				  Group_Chat_Client.send_message(current_account, group_info_message);
			  }
		}
	}
	
}
