package custom_component;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;

import javax.swing.JButton;

public class Label_button extends JButton{
    
	String text = null;
	Font font = null;
	boolean  enter = false;
	int width = 0;
	int height = 0;
	
	public Label_button(String text,int font_size) {
		
		this.text = text;
		font = new Font("宋体", Font.PLAIN, font_size);
		FontRenderContext frc = new FontRenderContext(new AffineTransform(),true,true);
	    Rectangle rec = font.getStringBounds(text, frc).getBounds();
		this.width = (int) rec.getWidth();
		this.height = (int) rec.getHeight();
		
		setOpaque(false);
		setContentAreaFilled(false);
		setBorderPainted(false);
		setBorder(null);
		
		addMouseListener(new MouseAdapter() {
			
		  @Override
		public void mouseEntered(MouseEvent e) {
			// TODO AYouTu-generated method stub
			  enter = true;
				repaint();
		}
			
			@Override
			public void mouseExited(MouseEvent e) {
				
				enter = false;
				repaint();
			}
		});
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		// TODO AYouTu-generated method stub
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		if(!enter) {g2.setColor(new Color(18, 181, 245));}
		else {g2.setColor(Color.red);}
		
		g2.fillRect(0, 0, width, height);
		
		if(!enter) {g2.setColor(Color.black);g2.drawString(text, 2, 12);}
		else {g2.setColor(Color.white);g2.drawString("删除", (width-30)/2, 12);}
		
	}
	
	public String get_text() {
		return this.text;
	}
	public int get_width() {
		return this.width;
	}
	
	public int  get_height() {
		return this.height;
	}
}
