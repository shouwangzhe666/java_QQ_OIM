package custom_component;

import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;

public class My_Jlist extends JList<String>{

	public My_Jlist(String[]items) {
		super(items);
		
	    setOpaque(false);
	    setCellRenderer(new My_ListCellRenderer());
	    
	}
	
	public static My_ScrollPane getMy_Jlist(String[]items,int width,int height) {
		My_Jlist my_Jlist = new My_Jlist(items);
		
		My_ScrollPane scrollPane = new My_ScrollPane();
		scrollPane.setViewportView(my_Jlist);
		scrollPane.setPreferredSize(new Dimension(width,height));
		
		return scrollPane;
	}
	public static My_ScrollPane getMy_ScrollPane(JList<String> jList) {
		
		My_ScrollPane scrollPane = new My_ScrollPane();
		scrollPane.setViewportView(jList);
		scrollPane.setPreferredSize(new Dimension(100,200));
		
		return scrollPane;
	}
	 public static void main(String[] args) {
			
		   String[] bir1=new String[120];
		  
			int i1=2019;
			for(int i=0;i<120;i++) {
				bir1[i]=""+i1+"年";
				i1--;
				
			}
		  JList<String> jList = new JList<>(bir1);
		  My_Jlist my_Jlist = new My_Jlist(bir1);
				
		  JFrame jFrame = new JFrame();
		  jFrame.getContentPane().setLayout(new FlowLayout());
		  jFrame.getContentPane().add(getMy_ScrollPane(jList));
		  jFrame.getContentPane().add(getMy_Jlist(bir1, 100, 200));
		
		  jFrame.setBounds(500, 200, 500, 500);
		  jFrame.setVisible(true);
		
}
}
