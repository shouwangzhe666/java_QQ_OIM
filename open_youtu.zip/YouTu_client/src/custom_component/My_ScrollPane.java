package custom_component;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.plaf.ScrollBarUI;
import javax.swing.plaf.basic.BasicArrowButton;
import javax.swing.plaf.basic.BasicScrollBarUI;

import com.sun.org.glassfish.external.statistics.Statistic;
import com.sun.swing.internal.plaf.basic.resources.basic;

public class My_ScrollPane extends JScrollPane{

	boolean pane_enterable = true;
	boolean thumb_enterable = true;
	boolean pane_enter =true;
	boolean thump_enter= false;
	
	Color background_color = null;
	My_secroll_bar secroll_bar = null;
	My_ScrollBar_UI scrollbar_UI = null;
	Cursor cursor = null;
	
	public My_ScrollPane() {
	
		setOpaque(false);
		getViewport().setOpaque(false);
		setBorder(null);
	    
		cursor = new Cursor(Cursor.DEFAULT_CURSOR);
		background_color = Color.GRAY;
		scrollbar_UI = new My_ScrollBar_UI();
		secroll_bar = new My_secroll_bar();
		
		setVerticalScrollBar(secroll_bar);
		setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		
		addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseEntered(MouseEvent e) {
				
				setCursor(cursor);
				if(!pane_enterable||!thumb_enterable) {return;}
				
				pane_enter = true;
				thump_enter = false;
				
				secroll_bar.repaint();
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				
				if(!pane_enterable||!thumb_enterable) {return;}
				
				pane_enter = false;
				
				secroll_bar.repaint();
			}
		});
	}
	
	private class My_secroll_bar extends JScrollBar{

		Cursor cursor = null;
		
		public My_secroll_bar() {
			
			cursor = new Cursor(Cursor.DEFAULT_CURSOR);
			setUnitIncrement(50);
			setBlockIncrement(50);
			
			setOpaque(false);

			setUI(scrollbar_UI);
			
			addMouseListener(new MouseAdapter() {
				
				@Override
				public void mouseEntered(MouseEvent e) {
					
					setCursor(cursor);
					if(!pane_enterable||!thumb_enterable) {return;}
					
					pane_enter = false;
					thump_enter = true;
					repaint();
				}
				
				@Override
				public void mouseExited(MouseEvent e) {
					
					if(!pane_enterable||!thumb_enterable) {return;}
					
					thump_enter = false;
					
					repaint();
				}
			});
		   }
		
		
	}
	private class My_ScrollBar_UI extends BasicScrollBarUI{
		

		@Override
		protected void paintTrack(Graphics g, JComponent c, Rectangle trackBounds) {
			  super.paintTrack(g, c, trackBounds);
		}
		
		@Override
		protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
					
			 Graphics2D g2 = (Graphics2D)g;
			  g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
			          RenderingHints.VALUE_ANTIALIAS_ON);
			  
			  g2.translate(thumbBounds.x, thumbBounds.y);
           
			  g2.setComposite(AlphaComposite
	    			    .getInstance(AlphaComposite.SRC_OVER,0f));
			  
		       if(pane_enter) {g2.setComposite(AlphaComposite
	    			    .getInstance(AlphaComposite.SRC_OVER,0.7f));}
		       
		       if(thump_enter) {
		    	   g2.setComposite(AlphaComposite
		    			    .getInstance(AlphaComposite.SRC_OVER,1f));
		       }
		       
		   g2.setColor(background_color);
           g2.fillRoundRect(1, 1, thumbBounds.width, thumbBounds.height, 10, 10);
               
           g2.translate(-thumbBounds.x, -thumbBounds.y);
		}
		
		@Override
		protected JButton createDecreaseButton(int orientation) {
		    
			JButton jButton = new JButton();
			jButton.setVisible(false);
//			jButton.setOpaque(false);
//			jButton.setContentAreaFilled(false);
//			jButton.setBorder(null);
			return jButton;
		}
		
		@Override
		protected JButton createIncreaseButton(int orientation) {
			JButton jButton = new JButton();
			jButton.setVisible(false);
//			jButton.setOpaque(false);
//			jButton.setContentAreaFilled(false);
//			jButton.setBorder(null);
			return jButton;
		}
		@Override
		public Dimension getPreferredSize(JComponent c) {
			
			c.setPreferredSize(new Dimension(8, 0));
			return super.getPreferredSize(c);
		}
	}
	
	public void set_pane_enterable(boolean pane_enterable) {
		
		this.pane_enterable = pane_enterable;
		if(!pane_enterable) {
			pane_enter = true;
			thump_enter = false;
			}
		repaint();
	}
	
	public void set_thumb_enterable(boolean thumb_enterable) {
		
		this.thumb_enterable = thumb_enterable;
		if(!thumb_enterable) {thump_enter = true;}
		repaint();
	}
	public void set_enter(boolean pane_enter) {
		
		this.pane_enter = pane_enter;
		repaint();
	}
	
	public  void set_thumb_color(Color thumb_color) {
		
		this.background_color = thumb_color;
		repaint();
	}
 public static JScrollPane get_generalScrollPane() {
	 
	  JPanel jPanel =  new JPanel();
	  jPanel.setPreferredSize(new Dimension(300,1000));
	  jPanel.setBackground(Color.red);
	  
	  JScrollPane scrollPane = new JScrollPane();
	  scrollPane.setPreferredSize(new Dimension(400,300));
	  scrollPane.setViewportView(jPanel);
	  
	  return scrollPane;
 }
 public static My_ScrollPane get_My_ScrollPane() {
	 
	 JPanel jPanel =  new JPanel();
	  jPanel.setPreferredSize(new Dimension(300,1000));
	  jPanel.setBackground(Color.orange);
	  
	  My_ScrollPane scrollPane = new My_ScrollPane();
	  scrollPane.setPreferredSize(new Dimension(400,300));
	  scrollPane.setViewportView(jPanel);
	  
	  return scrollPane;
 }
 
 public static void main(String[] args) {
			
		 JScrollPane scrollPane1 = get_generalScrollPane();
		 My_ScrollPane scrollPane2 = get_My_ScrollPane();
			
			  JFrame jFrame = new JFrame();
			  jFrame.getContentPane().setLayout(new FlowLayout());
			  jFrame.getContentPane().add(scrollPane1);
			  jFrame.getContentPane().add(scrollPane2);
			
			  jFrame.setBounds(500, 200, 1000, 500);
			  jFrame.setVisible(true);
	}
}
