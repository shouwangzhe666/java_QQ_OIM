package custom_component;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPopupMenu;

import Main_frame_Item.Tip_Text_JMenuItem;

public class Focus_button extends JButton {

	int width = 0;
	int height = 0;
	boolean focus = false;
	Cursor cursor = null;
	
	ImageIcon namal_icon = null;
	ImageIcon focus_icon = null;
	
	JPopupMenu popupMenu = null;
	Tip_Text_JMenuItem item = null;
	
	public Focus_button(String tip_text,boolean focus,URL namal_icon_url,URL focus_icon_url) {
	  
		width = 60;
		height = 60;
		
		cursor = new Cursor(Cursor.DEFAULT_CURSOR);
		
		namal_icon = new ImageIcon(namal_icon_url);
		focus_icon = new ImageIcon(focus_icon_url);
		
		   setOpaque(false);
		   setContentAreaFilled(false);
		   setBorderPainted(false);
		   setBorder(null);
		  
		   setPreferredSize(new Dimension(width,height));
		   setMinimumSize(new Dimension(width,height));
		   setMaximumSize(new Dimension(width,height));
		   
		   set_focus(focus);
		   
		   popupMenu = new JPopupMenu();
		   popupMenu.setBorder(null);
		   popupMenu.setBorderPainted(false);
		   
		   if(tip_text!=null) {
			   item = new Tip_Text_JMenuItem(tip_text,35,20);
			   popupMenu.add(item);
		   }
		   
		   addMouseListener(new MouseAdapter() {
			   @Override
			public void mouseEntered(MouseEvent e) {
				
				   popupMenu.show(Focus_button.this, 30, 55);
			}
			   @Override
			public void mouseExited(MouseEvent e) {
				
				   popupMenu.setVisible(false);
			}
		});
	}


	public void set_focus(boolean focus) {
		
		this.focus = focus;
	    repaint();
	}
    
	
	@Override
	protected void paintComponent(Graphics g) {
		//	super.paintComponent(g);
		if(focus) {g.drawImage(focus_icon.getImage(), 0, 0, null);}
		else {g.drawImage(namal_icon.getImage(), 0, 0, null);}
	}
}
