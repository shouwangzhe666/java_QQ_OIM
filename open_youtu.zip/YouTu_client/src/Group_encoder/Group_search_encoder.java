package Group_encoder;

import java.io.UnsupportedEncodingException;

import Message.Group.Group_search_message;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

public class Group_search_encoder extends MessageToByteEncoder<Group_search_message>{

	@Override
	protected void encode(ChannelHandlerContext arg0, Group_search_message search_message, ByteBuf buf) throws Exception {
		
		     int type = search_message.getType();
		     
		     if(type==1) {encode_type1(search_message, buf);}
		     else if(type==2) {encode_type2(search_message, buf);}
		     else if(type==3) {encode_type3(search_message, buf);}
		     else if(type==4) {encode_type4(search_message, buf);}
		     else if(type==5) {encode_type5(search_message, buf);}
		     else if(type==6) {encode_type6(search_message, buf);}
		     else if(type==7) {encode_type7(search_message, buf);}
	}

	public void encode_type1(Group_search_message search_message, ByteBuf buf) {
		
		byte[] group_type = null;
		byte[] group_name = null;
		byte[] group_ower_account = null;
		
		buf.writeInt(212);
		buf.writeInt(1);
		
		try {
			group_type = search_message.getGroup_type().getBytes("UTF-8");
			group_name = search_message.getGroup_name().getBytes("UTF-8");
			group_ower_account = search_message.getGroup_ower_account().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		 buf.writeInt(group_type.length);
		 buf.writeBytes(group_type);
		 buf.writeInt(group_name.length);
		 buf.writeBytes(group_name);
		 buf.writeInt(group_ower_account.length);
		 buf.writeBytes(group_ower_account);
	}  //encode_type1
	
	public void encode_type2(Group_search_message search_message, ByteBuf buf) {
		
		boolean scuess = false;
		byte[] group_account = null;
		
		buf.writeInt(212);
		buf.writeInt(2);		
		
		try {
			scuess = search_message.isScuess();
			group_account = search_message.getGroup_account().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		 buf.writeBoolean(scuess);
		 buf.writeInt(group_account.length);
		 buf.writeBytes(group_account);
	}  // encode_type2
	
	public void encode_type3(Group_search_message search_message, ByteBuf buf) {
		
       byte[] group_account = null;
		
		buf.writeInt(212);
		buf.writeInt(3);	
		
		try {
			group_account = search_message.getGroup_account().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		 buf.writeInt(group_account.length);
		 buf.writeBytes(group_account);
		 
	} // encode_type3
	
	public void encode_type4(Group_search_message search_message, ByteBuf buf) {
		
	     byte[] group_type = null;
		 int pay_money = 0;
		 byte[] question = null;
		 byte[] answer = null;
		 
		 byte[] group_icon = null;
		 byte[] group_account = null;
		 byte[] group_name = null;

			buf.writeInt(212);
			buf.writeInt(4);
		 try {
				group_type = search_message.getGroup_type().getBytes("UTF-8");
				pay_money = search_message.getPay_money();
				question = search_message.getQuestion().getBytes("UTF-8");
				answer = search_message.getAnswer().getBytes("UTF-8");
				group_icon = search_message.getGroup_icon();
				group_account = search_message.getGroup_account().getBytes("UTF-8");
				group_name = search_message.getGroup_name().getBytes("UTF-8");
				
			} catch (UnsupportedEncodingException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
		 
		  buf.writeInt(group_type.length);
		  buf.writeBytes(group_type);
		  
		  buf.writeInt(pay_money);
		  buf.writeInt(question.length);
		  buf.writeBytes(question);
		  buf.writeInt(answer.length);
		  buf.writeBytes(answer);
		  
		  buf.writeInt(group_icon.length);
		  buf.writeBytes(group_icon);
		  
		  buf.writeInt(group_account.length);
		  buf.writeBytes(group_account);		  
		  buf.writeInt(group_name.length);
		  buf.writeBytes(group_name);
	}  // encode_type4
	
	public void encode_type5(Group_search_message search_message, ByteBuf buf) {
		
		byte[] group_type = null;
		byte[] group_account = null;
		byte[] native_icon = null;
		byte[] native_name = null;
		byte[] native_account = null;
		byte[] verify_message = null;

		buf.writeInt(212);
		buf.writeInt(5);
		try {
			group_type = search_message.getGroup_type().getBytes("UTF-8");
			group_account = search_message.getGroup_account().getBytes("UTF-8");
			native_icon = search_message.getNative_icon();
			native_name = search_message.getNative_name().getBytes("UTF-8");;
			native_account = search_message.getNative_account().getBytes("UTF-8");
			verify_message = search_message.getVerify_message().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		
		  buf.writeInt(group_type.length);
		  buf.writeBytes(group_type);
		  buf.writeInt(group_account.length);
		  buf.writeBytes(group_account);
		  buf.writeInt(native_icon.length);
		  buf.writeBytes(native_icon);
		  buf.writeInt(native_name.length);
		  buf.writeBytes(native_name);
		  buf.writeInt(native_account.length);
		  buf.writeBytes(native_account);
		  buf.writeInt(verify_message.length);
		  buf.writeBytes(verify_message);
		  
	}  // encode_type5
	
	public void encode_type6(Group_search_message search_message, ByteBuf buf) {
		
		boolean accept = false;
		byte[] group_account = null;
        byte[] native_account = null;
        
		buf.writeInt(212);
		buf.writeInt(6);
		try {
			accept = search_message.isAccept();
			group_account = search_message.getGroup_account().getBytes("UTF-8");
			native_account = search_message.getNative_account().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		 
		buf.writeBoolean(accept);
		buf.writeInt(group_account.length);
		buf.writeBytes(group_account);
		buf.writeInt(native_account.length);
		buf.writeBytes(native_account);
	}  // encode_type6
	
public void encode_type7(Group_search_message search_message, ByteBuf buf) {
		
		byte[] group_account = null;
        byte[] native_account = null;
        
		buf.writeInt(212);
		buf.writeInt(7);
		try {
			group_account = search_message.getGroup_account().getBytes("UTF-8");
			native_account = search_message.getNative_account().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		 
		buf.writeInt(group_account.length);
		buf.writeBytes(group_account);
		buf.writeInt(native_account.length);
		buf.writeBytes(native_account);
		
	}  // encode_type7
}
