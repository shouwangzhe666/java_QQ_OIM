package group_info_item;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JPopupMenu;

import Frame.Group_info_frame;
import Main_frame_Item.Main_JMenuItem;
import Message.Group.Group_info_message;
import custom_component.Box_pane;
import custom_component.Roundrec_button;
import group_info_pane.Group_icon_pane;
import net.coobird.thumbnailator.Thumbnails;
import ss.Group_Chat_Client;
import ss.Private_Chat_Client;
import tool_Frame.Icon_show_frame;
import tool_Frame.Warn_frame;

public class Group_icon_item extends Box_pane implements ActionListener{

	String sender = null;
	String send_str = null;
	long send_time = 0l;
	Font font = null;
	Color color = null;
	
	ImageIcon imageIcon = null;
	BufferedImage bufferedImage = null;
	
	Group_icon_pane icon_pane = null;
	
	JPopupMenu popupMenu = null;
	Main_JMenuItem look_item = null;
	Main_JMenuItem delete_item = null;
	
	public Group_icon_item(Group_icon_pane icon_pane,ArrayList<Object> icon) {
		super(BoxLayout.Y_AXIS);
		setOpaque(true);
		setBackground(Color.white);
		
		this.icon_pane = icon_pane;
		byte[] icon_bytes = (byte[]) icon.get(0);
		this.sender = (String) icon.get(1);
		this. send_time = (long) icon.get(2);
        String time_format = new SimpleDateFormat("yyyy-MM-dd HH:mm").format(send_time);
        this.send_str = sender+" 发表于"+time_format;
        
        font = new Font("宋体", Font.PLAIN, 16);
		color = new Color(140,140,140);
		setPreferredSize(new Dimension(340,350));
		setMinimumSize(new Dimension(340,350));
		setMaximumSize(new Dimension(340,350));
		
		this.imageIcon = new ImageIcon(icon_bytes);
		transfer_image(imageIcon);
		
		Init_MouseListioner();
		Init_Menu_item();
		
	}
	public void Init_Menu_item() {

		popupMenu = new JPopupMenu();
		
		look_item = new Main_JMenuItem("查看", null);
		look_item.addActionListener(this);
		popupMenu.add(look_item);
		
		if(Group_info_frame.get_group_id().equals("群主")) {
			delete_item = new Main_JMenuItem("删除", null);	
			delete_item.addActionListener(this);
			popupMenu.add(delete_item);
		}
		
	}
	
	public void Init_MouseListioner() {
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount()==2) {new Icon_show_frame(imageIcon);}
			}
			@Override
			public void mousePressed(MouseEvent e) {
				if(e.getButton()==3) {popupMenu.show(Group_icon_item.this,e.getX(),e.getY());}
			}
		});
	}
	public void transfer_image(ImageIcon imageIcon) {
		
		int width = imageIcon.getIconWidth();
		int height = imageIcon.getIconHeight();
		
	     bufferedImage = new BufferedImage(width,height, BufferedImage.TYPE_4BYTE_ABGR);
	     bufferedImage.getGraphics().drawImage(imageIcon.getImage(),0, 0, null);
	     
	   try {
		  this.bufferedImage = Thumbnails.of(bufferedImage).size(300, 300).asBufferedImage();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	}
	
	public long get_send_time() {
		return send_time;
	}
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		g2.setFont(font);
		
//		g2.setColor(Color.white);
//		g2.fillRect(0,0, 350,bufferedImage.getHeight()+50);
		
		g2.setColor(color);
		g2.drawString(send_str,20,20);
		g2.drawImage(bufferedImage,20,(350-bufferedImage.getHeight())/2,null);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==look_item) {new Icon_show_frame(imageIcon);}
		else {
		 icon_pane.remove_icon(send_time);
    	 
    	 Group_info_message  info_message = new Group_info_message(42, Group_info_frame.get_group_account());
    	 info_message.setSend_time(send_time);
    	 Group_Chat_Client.send_message(Group_info_frame.get_group_account(), info_message);
    	 new Warn_frame("提示","删除成功！").set_aYouTu_click(2);
		}
	}
}
