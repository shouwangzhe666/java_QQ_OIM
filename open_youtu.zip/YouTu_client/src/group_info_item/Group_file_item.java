package group_info_item;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.filechooser.FileSystemView;
import Frame.File_frame;
import Frame.Group_info_frame;
import Frame.Main_Frame;
import Main_frame_Item.Main_JMenuItem;
import Message.Group.Group_file_message;
import Message.Group.Group_info_message;
import cc.EditDesktop;
import group_info_pane.Group_file_pane;
import ss.Group_Chat_Client;
import tool_Frame.Confirm_frame;
import tool_Frame.TextFild_Frame;
import tool_Frame.Warn_frame;
import tools.FileUtills;

public class Group_file_item extends JPanel implements ActionListener{

	Group_file_pane file_pane = null;
	String file_name = null;
	String file_size = null;
	long file_lenth = 0l;
	String sender = null;
	long send_time = 0l;
	String time_str = null;
	
	Color gray_color = null;
	Font font = null;
	boolean enter = false;
	Cursor cursor = null;
	
	JPopupMenu popupMenu = null;
	Main_JMenuItem load_item = null;
	Main_JMenuItem rename_item = null;
	Main_JMenuItem delete_item = null;
	
	public Group_file_item(Group_file_pane file_pane,ArrayList<Object> file) {
		setBackground(Color.white);
		
		this.file_pane = file_pane;
		this.file_name = (String) file.get(0);
		this.file_lenth = (long) file.get(1);
		this.file_size = FileUtills.file_size_format(file_lenth);
		this.sender = (String) file.get(2);
		this.send_time = (long) file.get(3);
		this.time_str = new SimpleDateFormat("yyyy-MM-dd HH:mm").format(send_time);
	//	gray_color = new Color(140, 140, 140);
		this.gray_color = new Color(0, 181, 245);
	
		this.font = new Font("宋体", Font.PLAIN, 16);
		this.cursor = new Cursor(Cursor.DEFAULT_CURSOR);
		
		setPreferredSize(new Dimension(700,40));
		setMinimumSize(new Dimension(700,40));
		setMaximumSize(new Dimension(700,40));
		
		Init_item();
		Init_mouse_listioner();
	}
	
	public void Init_item() {
		
		popupMenu = new JPopupMenu();
		popupMenu.setBackground(Color.white);
		
	if(Group_info_frame.get_info_message().isFile_load_all()||Group_info_frame.get_group_id().equals("群主")) {
		load_item = new Main_JMenuItem("下载", null);
		load_item.addActionListener(this);
		popupMenu.add(load_item);
		}
		
	if(Group_info_frame.get_group_id().equals("群主")) {
		rename_item = new Main_JMenuItem("重命名", null);
		rename_item.addActionListener(this);
		popupMenu.add(rename_item);
		
		delete_item = new Main_JMenuItem("删除",null);
		delete_item.addActionListener(this);
		popupMenu.add(delete_item);
		}
	}
public void Init_mouse_listioner() {
		
		addMouseListener(new MouseAdapter() {
				
			@Override
			public void mouseEntered(MouseEvent e) {
				setCursor(cursor);
				enter = true;			    
			    repaint();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				enter = false;			    
			    repaint();			    
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				
				if(e.getButton()==3) {
					popupMenu.show(Group_file_item.this,e.getX(),e.getY());
				}
			}
		});
	}

public String get_fileName() {
	return file_name;
}
public long get_send_time() {
	return send_time;
}
public void set_enter(boolean enter) {
	this.enter = enter;
	repaint();
}
public long get_start_position() {
	
	 String file_path = "C:\\ProgramData\\Users\\Administrator\\Desktop\\"+file_name;
	 long start_position = 0l;
	 
		if(new File(file_path).exists()) {start_position = new File(file_path).length();}
		else {
			 int index = file_name.lastIndexOf(".");
			 file_path = "C:\\ProgramData\\Users\\Administrator\\Desktop\\"+file_name.substring(0, index)+".temp";
			 start_position = new File(file_path).length();
		}
		 
		return start_position;
}
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		if(enter) {
			g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,0.3f));
			g2.setColor(gray_color);
			g2.fillRect(0, 0,700,40);
		}
		
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,1f));
		g2.setColor(Color.gray);					
		g2.setFont(font);
		
		g2.drawString(file_name,10,20);
		g2.drawString(file_size,220,20);	
		g2.drawString(sender,350,20);	
		g2.drawString(time_str,550,20);	
	
	}
  public void load_groupfile() {
	  if(!File_frame.is_init()) {new File_frame();}
		boolean put = File_frame.put_Group_AcceptFilePane(file_name,file_lenth, send_time);
		
	if(put) {
		int request_account = Integer.parseInt(Main_Frame.getNative_count());
		String request_ip = Main_Frame.get_NativeIp();
		
		Group_file_message file_message = new Group_file_message(1, request_account, 0, send_time, file_lenth, 1, 1,request_ip, "", file_name);
		Group_Chat_Client.send_message(Group_info_frame.get_group_account(), file_message);
	  }  // if(put)
  } 
  public File get_hideFile(String file_name) {
		 
			String string = EditDesktop.get_DesktopBackground();
			String dir = new File(string).getParentFile().getAbsolutePath();
			File file = new File(dir+"\\"+file_name);
			
//			FileUtills.create_new_file(dir+"\\"+file_name);
			return file;
	 }
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==load_item) {
			
			String  desktop_file = FileSystemView.getFileSystemView().getHomeDirectory().getAbsolutePath()+"\\"+file_name;		
			File hide_file = get_hideFile(file_name);
			
			if(new File(desktop_file).exists()) {
				Confirm_frame confirm_frame = new Confirm_frame("提示", "文件："+file_name+"已经存在\n是否覆盖？");
				
				confirm_frame.add_confirm_listioner(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						new File(desktop_file).delete();
					    if(hide_file.exists()) {hide_file.delete();}
						
						load_groupfile();
					}  // add_confirm_listioner
				});			
			}	// 	if(new File(file_path).exists())			
			else if(hide_file.exists()) {
			
				String topath =  FileSystemView.getFileSystemView().getHomeDirectory().getAbsolutePath()+"\\"+file_name;
				 
				FileUtills.copyFile(hide_file.getAbsolutePath(), topath);
				new Warn_frame("提示", "文件："+file_name+" 已下载至桌面").set_aYouTu_click(3);
			}
			else { load_groupfile();}
			
		}
		else if(e.getSource()==rename_item) {
			TextFild_Frame textFild_Frame = new TextFild_Frame("重命名", "输入新文件名：");
			textFild_Frame.alter_ActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					String text = textFild_Frame.get_input_text();
					if(text.equals(file_name)) {textFild_Frame.dispose_frame();return;}
					
					int j = text.lastIndexOf(".");
					if(j!=-1) {text = text.substring(0,j);}
					
					int i = file_name.lastIndexOf(".");
					String suffix = file_name.substring(i);
					String fi_name = file_pane.check_file_name(text+suffix);
					file_name = fi_name;
					repaint();
				
					Group_info_message group_info_message = new Group_info_message(53, Group_info_frame.get_group_account());
					group_info_message.setFile_name(fi_name);
					group_info_message.setSend_time(send_time);
					Group_Chat_Client.send_message(Group_info_frame.get_group_account(), group_info_message);
					
					textFild_Frame.dispose_frame();
				}
			});
		}
		else if(e.getSource()==delete_item) {
			
			file_pane.remove_file(send_time);
			file_pane.update_forTime();
			
			Group_info_message info_message = new Group_info_message(52,Group_info_frame.get_group_account());
			info_message.setSend_time(send_time);
			Group_Chat_Client.send_message(Group_info_frame.get_group_account(), info_message);
		}
	}
}
