package group_info_item;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;

import Frame.Group_info_frame;
import Frame.Only_frame;
import Message.Group.Group_info_message;
import custom_component.Box_pane;
import custom_component.My_checkbox;
import custom_component.Roundrec_button;
import custom_component.Roundrec_textArear;

import group_info_pane.Group_notice_pane;
import ss.Group_Chat_Client;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;

public class Group_Send_notice_item extends Box_pane {

	long send_time = 0l;
	String send_str = null;
	
	boolean show_all = true;
	int text_height = 0;
	int total_height = 0;
	
	Only_frame only_frame = null;
	Group_notice_pane notice_pane = null;
	My_checkbox toggle_button = null;
	Roundrec_textArear textArear = null;
	Down_pane down_pane = null;
	Font font = null;
	Color color = null;
	
	public Group_Send_notice_item(Group_notice_pane notice_pane) {
		super(BoxLayout.Y_AXIS);
		
		this.notice_pane = notice_pane;
		String content = "";
				
		font = new Font("宋体", Font.PLAIN, 16);
		color = new Color(140,140,140);
		
		 int height = (content.length()/35)*20;
		 textArear = new Roundrec_textArear(700,height,2f,Color.LIGHT_GRAY, new Color(0, 131, 245), 16, Color.black);
		 
		 textArear.setText(content);	
		 textArear.setOpaque(true);
		 textArear.setBackground(Color.white);
		 textArear.set_watermark("请输入新公告：");
		
		 down_pane = new Down_pane();
		
		add(Box.createVerticalStrut(30));
		add(textArear);
		add(down_pane);
		
		Init_keyListioner();
		update_pane_size();
	}

public void Init_keyListioner() {
	
	textArear.addKeyListener(new KeyAdapter() {
		@Override
		public void keyReleased(KeyEvent e) {
			
			update_pane_size();
		}
	});
}

public void update_pane_size() {
	
	if(show_all) {
		
		text_height =  (textArear.getLineCount()+1)*20;
		total_height = text_height+70;
	}
	else {
		text_height = 65;
		total_height = text_height+70;
	}

	textArear.setSize(680,text_height);	
	
	setPreferredSize(new Dimension(700,total_height));
	setMinimumSize(new Dimension(700,total_height));
	setMaximumSize(new Dimension(700,total_height));	

	notice_pane.update_pane_size();
}

public int get_total_height() {
	return total_height;
}

public long get_send_time() {
	return send_time;
}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		g2.setFont(font);
		g2.setColor(color);
		
		g2.drawString("发布新公告",20,15);
	}
	
	private class Down_pane extends Box_pane implements ActionListener{

		Roundrec_button confirm_button = null;
		
		public Down_pane() {
			super(BoxLayout.X_AXIS);
			setOpaque(false);
			
			if(Group_info_frame.get_group_id().equals("群主")) {Init_button();}
				
			setPreferredSize(new Dimension(700,40));
			setMinimumSize(new Dimension(700,40));
			setMaximumSize(new Dimension(700,40));
		}
        
		public void Init_button() {
			
			confirm_button =  new Roundrec_button(60, 30, 15, new Color(0, 131, 245), "发布", 16, Color.white);
			confirm_button.addActionListener(this);
			
			add(Box.createHorizontalGlue());
			add(confirm_button);
			add(Box.createHorizontalStrut(20));
		}
		@Override
		public void actionPerformed(ActionEvent e) {
		   
		      if(e.getSource()==confirm_button) {
		    	 String content = textArear.getText();
		    	 textArear.setText("");
		    	 update_pane_size();
		    	 
		    	 if(content.trim().length()==0) {return;}
		    	 
		    	 long send_time = System.currentTimeMillis();
		    	 
		    	 Group_info_message  info_message = new Group_info_message(31, Group_info_frame.get_group_account());
		    	 info_message.setContent(content);
		    	 info_message.setSender(Group_info_frame.get_group_remark());
		    	 info_message.setSend_time(send_time);
		    	 
		    	 Group_Chat_Client.send_message(Group_info_frame.get_group_account(), info_message);
		    	 new Warn_frame("提示","发布成功！").set_aYouTu_click(3);
		    	 
		    	 ArrayList<Object> notice = new ArrayList<>();
		    	 notice.add(content);
		    	 notice.add(Group_info_frame.get_group_remark());
		    	 notice.add(send_time);
		    	 
		    	 notice_pane.put_notice(notice);
		    	 notice_pane.update_forTime();
		   
		     }
		} // actionPerformed
		
	} // Down_pane
}
