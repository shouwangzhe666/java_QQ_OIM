package Group_chat;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.swing.JPanel;

public class Tip_Top_pane extends JPanel{
	
	long send_time = -1l;
	String content = null;

	Group_show_pane show_pane = null;
	HashMap<Long,String> all_tip = null;
	
	public Tip_Top_pane(Group_show_pane show_pane) {
		
		   setVisible(false);
	       setLayout(new BorderLayout());
	       setBackground(new Color(0,181, 245));
	       this.show_pane = show_pane;
	       all_tip = new HashMap<>();
	       
	        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
			setPreferredSize(new Dimension(430, 26));
			setMinimumSize(new Dimension(430, 26));
			setMaximumSize(new Dimension(dimension.width,26));
			
			Init_mouselistioner();
	}
	
	public void Init_mouselistioner() {
		
		addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
				 if(send_time!=-1) { 
					 show_pane.lock_location(send_time);
					 all_tip.remove(send_time);
				 }			
				 
				 load_first_text();
			}
		});
	}
	
	public void add_top_tip(Long send_time,String content) {
		
		all_tip.put(send_time, content);
		
		load_first_text();
	}
	
	public void load_first_text() {
		
		this.send_time = get_first_key();
		if(send_time==-1) {setVisible(false);return;}
		
		setVisible(true);
		this.content = all_tip.get(send_time);
		repaint();
	}
	
	public long get_first_key() {
		
		Set<Long> set = all_tip.keySet();
		
		if(set.size()==0) {return -1;}
		
		Iterator<Long> it = set.iterator();
		long value = 0l;
				
		long[] all_int = new long[set.size()];
		
		int i = 0 ;
		while(it.hasNext()) {
			
			value = it.next();
			all_int[i] = value;
			i++;
		}
		
		Arrays.sort(all_int);
		
		return all_int[0];
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		if(content==null) {return;}
		
		g2.setColor(new Color(50,50, 50));
		g2.setFont(new Font("宋体",Font.PLAIN,14));
		g2.drawString(content,20,20);
	}
}
