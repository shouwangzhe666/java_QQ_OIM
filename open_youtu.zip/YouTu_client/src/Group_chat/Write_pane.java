package Group_chat;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.text.SimpleDateFormat;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JPopupMenu;
import javax.swing.TransferHandler;
import javax.swing.text.BadLocationException;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import Frame.Chat_frame;
import Frame.Main_Frame;
import Item.W_pane;
import Main_frame_Item.Main_JMenuItem;
import Main_thread.Shutup_thread;
import Message.Group.Group_chat_message;
import Message.Private.Link_info;
import Message.Private.Private_Chat_Message;
import chat_frame_pane.Group_chat_pane;
import chat_frame_pane.Private_chat_pane;
import custom_component.My_ScrollPane;
import custom_component.My_text_pane;
import ss.Group_Chat_Client;
import ss.Private_Chat_Client;
import sun.swing.SwingUtilities2;
import tool_Frame.Warn_frame;
import tools.Icon_tools;

public class Write_pane extends My_ScrollPane implements ActionListener,W_pane{

	Shutup_thread shutup_thread = null;
	My_text_pane textPane = null;
	Dimension dimension = null;
	
	JPopupMenu popupMenu = null;
    Main_JMenuItem past_item = null;
    Main_JMenuItem delete_item = null;
    
    SimpleDateFormat simpleDateFormat = null;
    long time_code = 0l;
    String native_count = null;
    String reply_total_message = null;
    int reply_lenth = 0;
    boolean reply = false;
    Group_chat_pane show_pane = null;
    Robot robot = null;
    StyledDocument native_styledocment = null;
    
    int group_account = 0;
    String native_id = null;
    String native_remark = null;
    boolean all_shutup = false;
    
	public Write_pane(int group_account, String native_id, String native_remark,Group_chat_pane show_pane) {
		
		
		setOpaque(false);
		getViewport().setOpaque(false);
		setViewportView(textPane);
		
		setPreferredSize(new Dimension(400,35));
		setMinimumSize(new Dimension(400,35));
		setMaximumSize(dimension);
		
		Init_text_pane();
		Init_textPane_keylistioner();
		Init_textPane_mouselistioner();
		Init_textPane_TransferHandler();
		
		Init_content(group_account, native_id, native_remark, show_pane);
		
		Init_popmenu();
	    
	}
    
	public void update_shutup(Group_chat_message chat_message) {
		
		boolean shutup = chat_message.isOpen_shutup();
		
		if(shutup) {
			if(shutup_thread!=null) {shutup_thread.stop_shutup();}
			
			shutup_thread = new Shutup_thread(textPane, chat_message);
			shutup_thread.start();
		} // if shutup
		else {
			if(shutup_thread!=null) {shutup_thread.stop_shutup();}
			
			textPane.setEditable(true);
			textPane.setText("");
		} // if conment
	}
	
	public void set_all_shutup(boolean all_shutup) {		
		this.all_shutup = all_shutup;
						
		if(all_shutup) {
			if(native_id.equals("群主")||native_id.equals("管理员")) {return;}
			
			textPane.setText("全员禁言");
			textPane.setEditable(false);
		}
		else {
			textPane.setEditable(true);
			textPane.setText("");
		}
	}
	
public void update_shutup(String conment_time) {
	 	
		if(!conment_time.equals("0")) {
			if(System.currentTimeMillis()>Long.parseLong(conment_time)) {return;}
			
			try {
				shutup_thread = new Shutup_thread(textPane, Long.parseLong(conment_time));
				shutup_thread.start();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		} // if shutup
		
	}

public void update_native_id(String native_id) {
	this.native_id = native_id;
	set_all_shutup(all_shutup);
	System.out.println("native_id=="+native_id);
	if(native_id.equals("管理员")) {
		textPane.setEditable(true);
		textPane.setText("");
	}
}
public void update_native_remark(String native_remark) {
	this.native_remark = native_remark;
}
    public void Init_content(int group_account, String native_id, String native_remark,Group_chat_pane show_pane) {
    	try {
			robot = new Robot();
		} catch (AWTException e2) {
			
			e2.printStackTrace();
		}
    	
		this.show_pane = show_pane;
		this.group_account = group_account;
		this.native_id = native_id;
		this.native_remark = native_remark;
		
		simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		dimension = Toolkit.getDefaultToolkit().getScreenSize();
		native_styledocment = textPane.getStyledDocument();
	//	link_info=null;
    }
    
    public void Init_text_pane() {
    	
    	textPane = new My_text_pane();
		textPane.setBorder(null);
		textPane.setOpaque(false);
		textPane.putClientProperty(SwingUtilities2.AA_TEXT_PROPERTY_KEY,null);
		textPane.setFont(new Font("宋体", Font.PLAIN, 14));
		
		setViewportView(textPane);
    }
    
   public void Init_textPane_keylistioner() {
    	
         textPane.addKeyListener(new KeyAdapter() {
			
			@Override
			public void keyReleased(KeyEvent e) {
				
				Chat_frame.update_ui();
				
				 if(e.isControlDown()&&e.getKeyCode()==KeyEvent.VK_ENTER) {
					 if(Main_Frame.get_send_type()==1) {
							try {
								textPane.getStyledDocument().insertString(textPane.getStyledDocument().getLength(), " \n", null);
							} catch (BadLocationException e1) {
								
								e1.printStackTrace();
							}
					 }
					 else {
						 Send_message();	
					 }
						} // if control && enter
					 
				 else if(e.getKeyCode()==KeyEvent.VK_ENTER) {
				//    robot.keyPress(KeyEvent.VK_BACK_SPACE);
					if(Main_Frame.get_send_type()==1) {
					    Send_message();	
					 }
					
					     }  // if enter
		  
		 else if(e.getKeyCode()==KeyEvent.VK_BACK_SPACE&&reply) {
			   if(native_styledocment.getLength()<reply_lenth) {
				   
				   reply = false;
				   textPane.setText("");
				   textPane.setCaretPosition(0);
			   } 
			
		 }  // if back_space
				
			}  //keyReleased
			
		});
    }
    
    public void Init_textPane_mouselistioner() {
    	
      textPane.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mousePressed(MouseEvent e) {
				
				if(e.getButton()==3) {
				//	popupMenu.show(textPane, getX(), e.getY());
					popupMenu.show(null,e.getXOnScreen(), e.getYOnScreen());
				}
				
				else {popupMenu.setVisible(false);}
				
			}
		});
    }
  public void Init_textPane_TransferHandler() {
    	
    	textPane.setTransferHandler(new TransferHandler() {
    		/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
    		public boolean importData(JComponent arg0, Transferable t) {
    			  try {
                      Object o = t.getTransferData(DataFlavor.javaFileListFlavor);
                      
                      String filepath = o.toString();
                  
                      if (filepath.startsWith("[")) {
                          filepath = filepath.substring(1);
                      }
                      if (filepath.endsWith("]")) {
                          filepath = filepath.substring(0, filepath.length() - 1);
                      }
                   
                      File file = null;
                      file = new File(filepath);
                      
                      if(!file.isFile()) {return true;}
                      
                      // if icon
                      if(filepath.endsWith("png")||filepath.endsWith("jpg")) {
                    	  byte[] icon_bytes = Icon_tools.get_IconBytes(filepath);
                    	  Insert_icon(icon_bytes);
                      }                     
                    
                      return true;
                  }
                  catch (Exception e) {
                  	
                  }
				return true;
    		}
			 @Override
	            public boolean canImport(JComponent comp, DataFlavor[] flavors) {
	                for (int i = 0; i < flavors.length; i++) {
	                    if (DataFlavor.javaFileListFlavor.equals(flavors[i])) {
	                        return true;
	                    }
	                }
	                return false;
	            }
    	});
    }
	public void Init_popmenu() {
		
		popupMenu = new JPopupMenu();
		past_item = new Main_JMenuItem("黏贴", null);
		delete_item = new Main_JMenuItem("清空", null);
		
		popupMenu.add(past_item);	
		popupMenu.add(delete_item);
		
		past_item.addActionListener(this);
		delete_item.addActionListener(this);
	}
	
	public boolean wrap_line() {
		  
		  String type  = textPane.getStyledDocument().getCharacterElement(0).getName();
		  
			if(textPane.getStyledDocument().getLength()>300) {
				new Warn_frame("提示", "最多输入300字").set_aYouTu_click(3);
				return false;
			}
			
			if(textPane.getText().trim().length()==0&&!type.equals("icon")) {
		
				textPane.setText("");
				textPane.setCaretPosition(0);
				return false;
			}
			
		   textPane.setSelectionStart(textPane.getCaretPosition()-1);
		   textPane.setSelectionEnd(textPane.getCaretPosition());
		   textPane.replaceSelection("");

		    return true;
		}

	public void Send_message() {
			
			boolean send = wrap_line();
			if(!send) {return;}
		
		String popu_message = null; 
		
		long send_time  = System.currentTimeMillis();
		int member_account  = Integer.parseInt(Main_Frame.getNative_count());
		Group_chat_message chat_Message = new Group_chat_message(1, member_account, send_time, native_id, native_remark, 0l);
		chat_Message.setReply(reply);
		chat_Message.setDocument(textPane.getStyledDocument());
		
		
		if(reply) {
			reply = false;
			chat_Message.setReply(true);
			chat_Message.setTime_code(time_code);
			}
		
		popu_message  = chat_Message.get_popu_message();
		Main_Frame.getMessage_pane().put_accept_message_item(String.valueOf(group_account),send_time, popu_message);
		Chat_frame.update_item_content(String.valueOf(group_account), popu_message);
		show_pane.put_chat_Message(chat_Message, true);		
		
		Group_Chat_Client.send_message(group_account, chat_Message);
	    
		textPane.update_pane();
		textPane.setText("");
		textPane.setCaretPosition(0);
	}
	
	public void delete_content() {
	
		this.reply = false;
		textPane.update_pane();
		textPane.setText("");
		textPane.setCaretPosition(0);
	}
	
	@Override
	public void Insert_face(ImageIcon face) {

		if(!textPane.isEditable()) {return;}
		
//		textPane.setCaretPosition(textPane.getCaretPosition());
		textPane.insertIcon(face);
	
		try {
			textPane.getStyledDocument().insertString(textPane.getCaretPosition(), " ", null);
		} catch (BadLocationException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public void Insert_icon(byte[] icon_bytes) {
		
		if(!textPane.isEditable()) {return;}
		
		long send_time = System.currentTimeMillis();
		int member_account = Integer.parseInt(Main_Frame.getNative_count());
		
		Group_chat_message chat_Message = new Group_chat_message(2, member_account, send_time, native_id, native_remark, 0l);
		chat_Message.setReply(reply);
		chat_Message.set_Icon(icon_bytes);
		
		String popu_message  = chat_Message.get_popu_message();
		Main_Frame.getMessage_pane().put_accept_message_item(String.valueOf(group_account),send_time,popu_message);
		Chat_frame.update_item_content(String.valueOf(group_account), popu_message);
		
		if(reply) {
			reply = false;
			chat_Message.setReply(true);
			chat_Message.setTime_code(time_code);
			}
	
		show_pane.put_chat_Message(chat_Message, true);
		
		Group_Chat_Client.send_message(group_account, chat_Message);
	    
		textPane.update_pane();
		textPane.setText("");
		textPane.setCaretPosition(0);
	}
	
	public void reply_message(long time_code,String group_remark,String reply_message) {
		
		if(!textPane.isEditable()) {return;}
		
		StyledDocument native_styledocment  = textPane.getStyledDocument();
		this.time_code  = time_code;
		this.reply = true;
		
		String that_time = new SimpleDateFormat("HH:mm:ss").format(time_code);
		
		String top_message = "“"+group_remark+"”   "+that_time+"   点击查看原文\n";
	    reply_message+="\n———————————————\n";
	    
		this.reply_total_message = top_message+reply_message;
		this.reply_lenth = reply_total_message.length();
		
		try {
			native_styledocment.insertString(0,reply_total_message, null);
		} catch (BadLocationException e) {
			
			e.printStackTrace();
		}

		textPane.setCaretPosition(native_styledocment.getLength());
		
	}
	
	public void paste() {
		
		StyledDocument styledDocument = Chat_frame.get_copy_styledocment();
		byte[] icon_bytes = Chat_frame.get_copy_iconbytes();
		
		if(styledDocument!=null) {
			paste_face_text(styledDocument);
		}		
		else if(icon_bytes!=null){
		
			Insert_icon(icon_bytes);
		}
	}

	public void paste_face_text(StyledDocument document) {
		
		String type = null;
		String temp_text="";
		
		for(int i=0;i<document.getLength();i++) {
  		 
  		  type= document.getCharacterElement(i).getName();
  		 
  		if(type.equals("content")){
 			 
 			 try {
 				temp_text =document.getText(i, 1);
				} catch (BadLocationException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
 			    
 			   int offset = textPane.getCaretPosition();
 			   try {
				textPane.getStyledDocument().insertString(offset, temp_text,null);
			} catch (BadLocationException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
 		 } // if text
  		
  		else if(type.equals("icon")) {
  			   			
  		//  add icon_name into the buf
  			
  			 Icon icon =StyleConstants.getIcon(document.getCharacterElement(i).getAttributes());
   			 ImageIcon imageIcon =(ImageIcon) icon;
   		      textPane.insertIcon(imageIcon);
		}
		} // for
		
		 robot.keyPress(KeyEvent.VK_BACK_SPACE);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==past_item) {popupMenu.setVisible(false);paste();}
		else if(e.getSource()==delete_item) {popupMenu.setVisible(false);delete_content();}
	}
}
