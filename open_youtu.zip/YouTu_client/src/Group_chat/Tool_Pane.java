package Group_chat;

import java.awt.*; 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.text.SimpleDateFormat;
import javax.swing.*;
import Item.Face_pane_MenuItem;
import custom_component.Box_pane;
import custom_component.Icon_button;
import tools.Icon_tools;
import tools.Screen_capter;

  public class Tool_Pane extends Box_pane implements ActionListener{
	
	Icon_button face_button=null;
	Icon_button icon_button=null;
	Icon_button file_button=null;
	Icon_button capter_button=null;
	
	String now= null;
	File file = null;
	String file_path=null;
	JPopupMenu face_pupMenu=null;
	
	Write_pane write_pane = null;
	Dimension dimension = null;
	
	SimpleDateFormat simpleDateFormat = null;
	Cursor cursor = null;
	
	 public Tool_Pane(Write_pane write_pane) {
		 super(BoxLayout.X_AXIS);
		 
		setOpaque(false);
		cursor = new Cursor(Cursor.DEFAULT_CURSOR);
		simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		dimension = Toolkit.getDefaultToolkit().getScreenSize();
		setPreferredSize(new Dimension(400, 30));
		setMinimumSize(new Dimension(400, 30));
		setMaximumSize(new Dimension(dimension.width,30));
		
	  this.write_pane = write_pane;
	  
	    face_pupMenu = new JPopupMenu();
	    face_pupMenu.setOpaque(false);
	    face_pupMenu.add(new Face_pane_MenuItem(face_pupMenu, write_pane));
		
		setBackground(new Color(250, 250, 250));
		setLayout(new FlowLayout(FlowLayout.LEFT));
		
		face_button = new Icon_button(getClass().getResource("/tool_image/face.png"),"表情");
		face_button.addActionListener(this);
		
		icon_button = new Icon_button(getClass().getResource("/tool_image/image.png"),"图片");
		icon_button.addActionListener(this);
		
//		file_button = new Icon_button(getClass().getResource("/tool_image/file.png"),"文件");
//		file_button.addActionListener(this);
		
		capter_button = new Icon_button(getClass().getResource("/tool_image/jieping.png"),"截屏");
		capter_button.addActionListener(this);
		
	//	super.add(Box.createHorizontalStrut(5));
		super.add(face_button);
		
		super.add(Box.createHorizontalStrut(3));
		super.add(icon_button);
		
//		super.add(Box.createHorizontalStrut(3));
//		super.add(file_button);
		
		super.add(Box.createHorizontalStrut(3));
		super.add(capter_button);
		
		addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				setCursor(cursor);
			};
		});
	 }
	
	@Override
	public void actionPerformed(ActionEvent e) {
	     
		if(e.getSource()==face_button) {face_pupMenu.show(this, 0,-170);}
	
		else if(e.getSource()==icon_button) {
			
			FileDialog fileDialog = new FileDialog(new JFrame());
			fileDialog.setDirectory("C:\\ProgramData\\Users\\Administrator\\Pictures");
			fileDialog.setVisible(true);
			
			String file_dir = fileDialog.getDirectory();
			String file_name= fileDialog.getFile();
			
			if(file_dir==null) {return;}
			if(file_name==null) {return;}
			if(!file_name.endsWith("png")&&!file_name.endsWith("gif")&&!file_name.endsWith("jpg")) {
				return;}
			
			    String icon_path = file_dir+file_name;
				
			    byte[] icon_bytes = Icon_tools.get_IconBytes(icon_path);
				write_pane.Insert_icon(icon_bytes);
			
		}
		
		else if(e.getSource()==capter_button) {
			
			new Screen_capter(write_pane).setVisible(true);
		
		}
	}

}