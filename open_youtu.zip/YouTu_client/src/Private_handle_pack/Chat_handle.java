package Private_handle_pack;

import java.io.ObjectOutputStream;

import Frame.Chat_frame;
import Frame.Main_Frame;
import Message.Private.Link_info;
import Message.Private.Private_Chat_Message;
import chat_frame_pane.Private_chat_pane;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import tools.My_Object_IO;
import tools.Play_sound;

public class Chat_handle extends SimpleChannelInboundHandler<Private_Chat_Message>{

	long shake_time = 0;
	
	@Override
	protected void messageReceived(ChannelHandlerContext arg0, Private_Chat_Message chat_Message) throws Exception {
	
		int type = chat_Message.getType();
		
		String from_account = String.valueOf(chat_Message.getFrom_account());
        Link_info link_info = Main_Frame.getMessage_pane().get_link_info(from_account);
        String inform_type = link_info.getInform_type();
               
       
        String file_path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\chat_history\\private_chat\\"+from_account+".db";
        ObjectOutputStream objectOutputStream = My_Object_IO.get_ObjectoutputStream(file_path, true);
        objectOutputStream.writeObject(chat_Message);
        objectOutputStream.close();
        
        if(inform_type.equals("屏蔽消息")) {chat_Message=null;return;}
        if(inform_type.equals("接收消息并提醒")) {
        	if(!Main_Frame.get_state().equals("勿扰")) {
        	if(chat_Message.getType()==4) {Play_sound.play_shake_sound();}
        	else {Play_sound.play_message_sound();}
        	}
        }
        
			Private_chat_pane chat_pane = Chat_frame.get_Private_chat_jpane(Integer.parseInt(from_account));
			
			if(type==1||type==2) {
								
				String popu_message  = chat_Message.get_popu_message();
				
				Main_Frame.getMessage_pane().put_accept_message_item(from_account,chat_Message.getSend_time(),popu_message);
				Chat_frame.update_item_content(from_account,popu_message);	
				
				if(chat_pane==null) {return;}
				else{chat_pane.put_chat_Message(chat_Message, true);}
			}
			else if(type==3) {
					
				Main_Frame.getMessage_pane().put_accept_message_item(from_account,chat_Message.getSend_time(),"对方撤回一条消息");
				Chat_frame.update_item_content(from_account, "对方撤回一条消息");	
				
				if(chat_pane==null) {return;}
				chat_pane.remove_chat_item(chat_Message, true);				
				}
			if(type==4) {
				
				Main_Frame.getMessage_pane().put_accept_message_item(from_account,chat_Message.getSend_time(),"对方发送窗口抖动");
				
				Chat_frame.put_select_Item(from_account);
				Chat_frame.update_item_content(from_account, "对方发送窗口抖动");	
				
				Chat_frame.set_visiable(true);
				
				if(chat_Message.getSend_time()-shake_time>30000) {
					Chat_frame.shake_frame(false, from_account);
					shake_time = chat_Message.getSend_time();
				}
				
				if(chat_pane==null) {return;}
				chat_pane.shake_Item(chat_Message, true);
				}
			else if(type==6) {
				if(chat_pane==null) {return;}
				chat_pane.put_file_message(null, true);
			  }				 
	}
}
