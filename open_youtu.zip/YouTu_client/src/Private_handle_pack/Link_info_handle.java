package Private_handle_pack;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import Frame.Chat_frame;
import Frame.Main_Frame;
import Frame.Search_frame;
import Message.Private.Link_info;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import message_login_register.List_message;
import ss.Group_Chat_Client;
import tool_Frame.Warn_frame;
import tools.Icon_tools;

public class Link_info_handle extends SimpleChannelInboundHandler<Link_info>{

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Link_info link_info) throws Exception {
		
		int type = link_info.getType();
		
		if(type==2) {handle_type2(ctx, link_info);}
		else if(type==3) {handle_type3(link_info);}
		else if(type==4) {handle_type4(ctx, link_info);}
		else if(type==5) {handle_type5(ctx, link_info);}
		else if(type==7) {handle_type7(link_info);}
		else if(type==8) {handle_type8(ctx, link_info);}
		else if(type==9) {handle_type9(link_info);}		
	}
	
	public void handle_type2(ChannelHandlerContext ctx, Link_info link_info) {
		// Init all head_Ioncs
	//	System.out.println("client Init all head_Ioncs ...");
		
		ArrayList<ArrayList<Object>> all_image = link_info.get_all_respose_head_image();
		ArrayList<Object> temp_image = null;
		int link_account = 0;
		byte[] icon_bytes = null;
		
		for(int i=0;i<all_image.size();i++) {
			
			temp_image = all_image.get(i);
			link_account = (int) temp_image.get(0);
			icon_bytes = (byte[]) temp_image.get(1);
			Icon_tools.Write_head_image(String.valueOf(link_account), icon_bytes);
			
		} // for
	}
	public void handle_type3(Link_info link_info) {
		
		String link_account = link_info.getAccount();
		byte[] icon_bytes = link_info.getHead_icon_bytes();
	
		if(Main_Frame.getNative_count().equals(link_account)) {return;}
		Icon_tools.Write_head_image(link_account, icon_bytes);
		
		Main_Frame.getFriend_pane().update_head_image(link_account, icon_bytes);
		Main_Frame.getMessage_pane().update_head_image(link_account, icon_bytes);
		Chat_frame.update_item_head_icon(link_account, icon_bytes);
		Chat_frame.update_private_other_head_image(link_account, icon_bytes);
	}
	public void handle_type4(ChannelHandlerContext ctx, Link_info link_info) {
		// Init the Main_frame's all groups ...
	//	System.out.println("client Init the Main_frame's all groups ...");
		
		ArrayList<String> all_group = link_info.getAll_group();
		String gstring = null;
		String first = null;
		int type = 3;
		String group = null;
		
		
		for(int i=0;i<all_group.size();i++) {
			gstring = all_group.get(i);
		
			first = gstring.split("、")[0];
			type = Integer.parseInt(first);
			
			group = gstring.split("、")[1];
					    
			if(type==3) {Main_Frame.getFriend_pane().put_group(true, group);}
			else if(type==4) {Main_Frame.getGroup_pane().put_group(true, group);}
		}
		
		Main_Frame.update_frame();
	}
	public void handle_type5(ChannelHandlerContext ctx, Link_info info) {
		// Init the Main_frame's all link_man ...
	//	System.out.println("client Init the Main_frame's all link_man ...");
		
		ArrayList<ArrayList<String>> all_link_man = info.getAll_link_man();
		ArrayList<String> link_man = null;
		Link_info link_info = null;
		
		for(int i=0;i<all_link_man.size();i++) {
			link_man = all_link_man.get(i);
			transfer_And_operate_LinkInfo(link_man);
		}

		Main_Frame.update_frame();
	}
	
	public void transfer_And_operate_LinkInfo(ArrayList<String> arrayList) {
				
		String tp = arrayList.get(0);
		int type = Integer.parseInt(tp);
		
		String link_count = arrayList.get(1);
	    String remark = arrayList.get(2);
	    String signature = arrayList.get(3);
	    String group  = arrayList.get(4);
		String []group_names = arrayList.get(5).split(",");
				
		String inform_type = arrayList.get(6);
		String state = arrayList.get(7);
		String id = arrayList.get(8);
		String ip_port = arrayList.get(9);
		String join_time =arrayList.get(10);
		String out_time = arrayList.get(11);		
//	    String remote_ip = arrayList.get(12);
	    
	Link_info link_info = new Link_info(link_count, remark, signature, group, group_names, inform_type, state, id,ip_port, out_time);
	link_info.setType(type);
	String icon_path = "C:\\ProgramData\\YouTu\\image\\head_image\\"+link_count+".png";
	byte[] icon_bytes = Icon_tools.get_IconBytes(icon_path);
	link_info.setHead_icon_bytes(icon_bytes);
	
	  Main_Frame.getMessage_pane().put_link_man(link_info);
	  Main_Frame.getMessage_pane().set_item_visiable(link_count);
	  
	  group_names = Main_Frame.getMessage_pane().get_link_info(link_count).getGroup_names();
		
	  if(type==1) {
		  Main_Frame.getFriend_pane().put_Linkman_Item(link_info);
	//	  Chat_frame.put_Private_chat_pane(Integer.parseInt(link_count));
	  }
	  else if(type==2) {
		  // signature: group_remark
		  // state: the time value in type of long to speak if true,or 0 if false
		  // ip_port = "25488m1i23.wicp.vip,54907";
		  
		    Main_Frame.getGroup_pane().put_Linkman_Item(link_info);
		//   Chat_frame.put_Group_chat_pane(Integer.parseInt(link_count),ip_port,id, signature,state);
		    String ip = ip_port.split(",")[0];
			int port = Integer.parseInt(ip_port.split(",")[1]);
			   
				try {
					new Group_Chat_Client(Integer.parseInt(link_count),InetAddress.getByName(ip), port).start();
				} catch (UnknownHostException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}		
	  }
	  
	return ;
	}
public void handle_type7(Link_info link_info) {
		
	// to show basic_info of the searching link_man
	if(link_info.getName().length()==0) {
		
		String account = link_info.getAccount();
		String notice = "账号："+account+"不存在!";
		new Warn_frame("提示", notice).set_aYouTu_click(3);
		return;
	}
	
		Search_frame search_frame  = new Search_frame();
		search_frame.put_friend_show_pane(link_info);
 }

public void handle_type8(ChannelHandlerContext ctx, Link_info link_info) {
	
     //  show add request
	
	String account = link_info.getAccount();
	String link_account = link_info.getLink_count();
//	byte[] icon_bytes = link_info.getHead_icon_bytes();
	ImageIcon head_image = new ImageIcon(link_info.getHead_icon_bytes());
	
	String name = link_info.getName();
	String verify_message = link_info.get_verify_message();
	long system_time = link_info.getSystem_time();
	
	List_message list_message = new List_message(3, account, head_image, "", name, verify_message,system_time, 0);	

	Main_Frame.getMessage_pane().put_request_message_item(true,list_message);
		
//	Main_Frame.update_UI();
	Main_Frame.update_frame();
}

public void handle_type9(Link_info link_info) {
	
	// inform that scuessfully to add
	
	String account = link_info.getAccount();
	String link_account = link_info.getLink_count();
//	byte[] icon_bytes = link_info.getHead_icon_bytes();
//	String name = link_info.getName();
	boolean accept = link_info.isAccept();
	
	if(accept) {
		Main_Frame.getMessage_pane().put_accept_message_item(link_account,link_info.getSystem_time(), "成功添加！");
	}	  
}
	
}
