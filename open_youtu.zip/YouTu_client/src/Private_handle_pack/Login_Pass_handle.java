package Private_handle_pack;

import Frame.Login_frame;
import Message.Private.Link_info;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import message_login_register.Login_pass_message;
import message_login_register.Ping_Pong;
import tcp_pack.TCP_Client;
import tool_Frame.Warn_frame;

public class Login_Pass_handle extends SimpleChannelInboundHandler<Login_pass_message>{

	static int account = 0 ;
	
	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Login_pass_message login_pass_message) throws Exception {
	    
		int type = login_pass_message.getType();
		String result = login_pass_message.getResult();
		int result_type = login_pass_message.getResult_type();
		boolean scuess = login_pass_message.isScuess();
		
		if(type==5) {
			 int tcp_port1 = login_pass_message.getTcp_port1();
			 int tcp_port2 = login_pass_message.getTcp_port2();
			 new TCP_Client(tcp_port1, tcp_port2).start();
		}
		else if(result_type==1) {
			if(scuess) {
			  new Warn_frame("提示", result).set_aYouTu_click(1);		
		      Ping_Pong.set_count(account);
			  ctx.writeAndFlush(new Ping_Pong());	
			}
			else {
				new Warn_frame("提示", result).set_aYouTu_click(5);
				Login_frame.login_failed();
	    	}
		}
		else {new Warn_frame("提示", result).set_aYouTu_click(10);}
	}
	
	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {	
		ctx.channel().close().sync();
	}

	public static void set_account(int account) {
		
		Login_Pass_handle.account = account;
	}
}
