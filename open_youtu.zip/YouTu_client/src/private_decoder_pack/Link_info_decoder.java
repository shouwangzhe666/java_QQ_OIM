package private_decoder_pack;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import Message.Private.Link_info;
import Message.Private.Private_info;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import javafx.geometry.Side;
import tool_Frame.Warn_frame;
import tools.Icon_tools;

public class Link_info_decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> list) throws Exception {
	
		buf.readerIndex(0);
		
		if(buf.readableBytes()==0) {
			System.out.println("client Link_info_decoder return;");
			return;}
		
		int protocol_code = buf.readInt();
		if(protocol_code==121) {
			
			int type = buf.readInt();
			
			if(type==1) {decode_type1(buf, list);}
			else if(type==2) {decode_type2(buf, list);}
			else if(type==3) {decode_type3(buf, list);}
			else if(type==4) {decode_type4(buf, list);}
			else if(type==5) {decode_type5(buf, list);}
			else if(type==6) {decode_type6(buf, list);}
			else if(type==7) {decode_type7(buf, list);}
			else if(type==8) {decode_type8(buf, list);}
			else if(type==9) {decode_type9(buf, list);}		
			else if(type==10) {decode_type10(buf, list);}
			
		} //if(protocol_code==121)
		
		else {
			buf.retain();
			ctx.fireChannelRead(buf);
		}
	}

public void decode_type1( ByteBuf buf, List<Object> list) {
		
	ArrayList<Integer> own_image = new ArrayList<>();
	byte[] by = null;
	int account = 0;
	
	int group_account = buf.readInt();
	int size = buf.readInt();
	
	for(int i=0;i<size;i++) {
		
		account = buf.readInt();	
		own_image.add(account);
	}
		
	Link_info link_info = new Link_info(1);
	link_info.setGroup_account(group_account);
	link_info.set_own_image(own_image);
	list.add(link_info);
	
	}

public void decode_type2( ByteBuf buf, List<Object> list) {
	
	 ArrayList<ArrayList<Object>> all_head_icon_byte = new ArrayList<>();
	 ArrayList<Object> row_list= null;
	 
	      int size = buf.readInt();       //size
	      
	      int account = 0;
	      byte[] by1 = null;
	      byte[] by2 = null;
	      
	      for(int i=0;i<size;i++) {
	    	  
	    	  account  = buf.readInt();
	    	  by2 = new byte[buf.readInt()];
	    	  buf.readBytes(by2);
	    	  
	    	  row_list = new ArrayList<>();
	    	  row_list.add(account);
	    	  row_list.add(by2);
	    	  all_head_icon_byte.add(row_list);
	    	
	      }
	      
	      Link_info link_info = new Link_info(2);
	      link_info.set_all_respose_head_image(all_head_icon_byte);
	      
	      list.add(link_info);
	}

public void decode_type3( ByteBuf buf, List<Object> list) {
	
	String account = null;
	byte[] by1 = null;
	byte[] icon_bytes = null;
	
	by1 = new byte[buf.readInt()];
	buf.readBytes(by1);
	try {
		account = new String(by1,"UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	
	icon_bytes = new byte[buf.readInt()];
	buf.readBytes(icon_bytes);
	
	Link_info link_info = new Link_info(3);
	link_info.setAccount(account);
	link_info.setHead_icon_bytes(icon_bytes);
	
	list.add(link_info);
}

public void decode_type4( ByteBuf buf, List<Object> list) {
	
	ArrayList<String> all_group = new ArrayList<>();
	byte[] by = null;
	String group = null;
	
	int size = buf.readInt();
	
	for(int i=0;i<size;i++) {
		
		 by = new byte[buf.readInt()];
		 buf.readBytes(by);
		try {
			group = new String(by,"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		all_group.add(group);
		
	}
	
	Link_info link_info = new Link_info(4);
	link_info.setAll_group(all_group);
	list.add(link_info);
	
}
public void decode_type5( ByteBuf buf, List<Object> list) {
	
	ArrayList<ArrayList<String>> all_link_man = new ArrayList<>();
	ArrayList<String> row_list = null;
	 
	 byte[] type = null;
	 byte[] link_account = null;
	 byte[] remark = null;
	 byte[] signature = null;
	 byte[] group_name = null;
	 byte[] group_names = null;
	 byte[] inform_type = null;
	 byte[] state = null;
	 byte[] id = null;
	 byte[] ip_port = null;
	 byte[] join_time = null;
	 byte[] out_time = null;
	 
	 int size = buf.readInt();
	 for(int i=0;i<size;i++) {
		 type = new byte[buf.readInt()];
		 buf.readBytes(type);
		 link_account = new byte[buf.readInt()];
		 buf.readBytes(link_account);
		 remark = new byte[buf.readInt()];
		 buf.readBytes(remark);
		 signature = new byte[buf.readInt()];
		 buf.readBytes(signature);
		 group_name = new byte[buf.readInt()];
		 buf.readBytes(group_name);
		 group_names = new byte[buf.readInt()];
		 buf.readBytes(group_names);
		 inform_type = new byte[buf.readInt()];
		 buf.readBytes(inform_type);
		 state = new byte[buf.readInt()];
		 buf.readBytes(state);
		 id = new byte[buf.readInt()];
		 buf.readBytes(id);
		 ip_port = new byte[buf.readInt()];
		 buf.readBytes(ip_port);
		 join_time = new byte[buf.readInt()];
		 buf.readBytes(join_time);
		 out_time = new byte[buf.readInt()];
		 buf.readBytes(out_time);
		 
		 row_list = new ArrayList<>();
		 
		 try {
			row_list.add(new String(type,"UTF-8"));
			row_list.add(new String(link_account,"UTF-8"));
			row_list.add(new String(remark,"UTF-8"));
			row_list.add(new String(signature,"UTF-8"));
			row_list.add(new String(group_name,"UTF-8"));
			row_list.add(new String(group_names,"UTF-8"));
			row_list.add(new String(inform_type,"UTF-8"));
			row_list.add(new String(state,"UTF-8"));
			row_list.add(new String(id,"UTF-8"));
			row_list.add(new String(ip_port,"UTF-8"));
			row_list.add(new String(join_time,"UTF-8"));
			row_list.add(new String(out_time,"UTF-8"));
			
		} catch (UnsupportedEncodingException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		 
		 all_link_man.add(row_list);
	 }  //  for
	 
	 Link_info link_info = new Link_info(5);
	 link_info.setAll_link_man(all_link_man);
	 list.add(link_info);
	 
}
public void decode_type6( ByteBuf buf, List<Object> list) {
	
	byte[] by = null;
	String account = null;
	by = new byte[buf.readInt()];
	buf.readBytes(by);
	try {
		account = new String(by, "UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	
	Link_info link_info = new Link_info(6);
	link_info.setAccount(account);
	list.add(link_info);
}
public void decode_type7( ByteBuf buf, List<Object> list) {
	
	byte[] account = null;
	byte[] head_icon_bytes = null;
	byte[] name = null;
	byte[] signature = null;     
	
	account = new byte[buf.readInt()];
	buf.readBytes(account);
	head_icon_bytes = new byte[buf.readInt()];
	buf.readBytes(head_icon_bytes);
	name = new byte[buf.readInt()];
	buf.readBytes(name);
	signature = new byte[buf.readInt()];
	buf.readBytes(signature);
	
	Link_info link_info = new Link_info(7);
	try {
		link_info.setAccount(new String(account,"UTF-8"));
		link_info.setHead_icon_bytes(head_icon_bytes);
		link_info.setName(new String(name,"UTF-8"));
		link_info.setSignature(new String(signature,"UTF-8"));
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	list.add(link_info);
}
public void decode_type8( ByteBuf buf, List<Object> list) {

	System.out.println("client start to decode_type8 ");
	
	byte[] account = null;
	byte[] link_account = null;
	byte[] head_icon_bytes = null;
	byte[] name = null;
	byte[] verify_message = null;     
	long system_time = 0l;
	
	account = new byte[buf.readInt()];
	buf.readBytes(account);
	link_account = new byte[buf.readInt()];
	buf.readBytes(link_account);
	
	head_icon_bytes = new byte[buf.readInt()];
	buf.readBytes(head_icon_bytes);
	name = new byte[buf.readInt()];
	buf.readBytes(name);
	verify_message = new byte[buf.readInt()];
	buf.readBytes(verify_message);
	system_time = buf.readLong();
	
	Link_info link_info = new Link_info(8);
	try {
		link_info.setAccount(new String(account,"UTF-8"));
		link_info.setLink_count(new String(link_account,"UTF-8"));
		link_info.setHead_icon_bytes(head_icon_bytes);
		link_info.setName(new String(name,"UTF-8"));
		link_info.set_verify_message(new String(verify_message,"UTF-8"));
		link_info.setSystem_time(system_time);
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	
	list.add(link_info);
}
public void decode_type9( ByteBuf buf, List<Object> list) {
	
	byte[] account = null;
	byte[] link_account = null;
	
	byte[] head_icon_bytes = null;
	byte[] name = null;
	boolean accept = false;
	long system_time = 0l;
	
	account = new byte[buf.readInt()];
	buf.readBytes(account);
	link_account = new byte[buf.readInt()];
	buf.readBytes(link_account);
	
	head_icon_bytes = new byte[buf.readInt()];
	buf.readBytes(head_icon_bytes);
	name = new byte[buf.readInt()];
	buf.readBytes(name);
	accept = buf.readBoolean();
	system_time = buf.readLong();
	
	Link_info link_info = new Link_info(9);
	try {
		link_info.setAccount(new String(account,"UTF-8"));
		link_info.setLink_count(new String(link_account,"UTF-8"));
		
		link_info.setHead_icon_bytes(head_icon_bytes);
		link_info.setName(new String(name,"UTF-8"));
		link_info.setAccept(accept);
		link_info.setSystem_time(system_time);
	} catch (UnsupportedEncodingException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	list.add(link_info);
}
public void decode_type10( ByteBuf buf, List<Object> list) {
	 
	  int group_account = buf.readInt();
	  
	  Link_info link_info = new Link_info(10);
	  link_info.setGroup_account(group_account);
	  
	  list.add(link_info);
}
}
