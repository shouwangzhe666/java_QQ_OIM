package netty_demo;

import com.sun.org.apache.bcel.internal.generic.NEW;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleStateEvent;

public class Client_PingPong_handler extends SimpleChannelInboundHandler<PingPong>{

	Client client = null;
	
	public Client_PingPong_handler(Client client) {

       this.client = client;
	}
	
	@Override
	protected void messageReceived(ChannelHandlerContext arg0, PingPong arg1) throws Exception {
	 
		  System.out.println("客户端收到心跳消息");
	}
	
	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		
		client.reconnet();         
	}
	
	@Override
	public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
		if (evt instanceof IdleStateEvent) {
	        IdleStateEvent e = (IdleStateEvent) evt;
	        
	        ByteBuf buf = Unpooled.buffer(10);
	        
	        switch (e.state()) {
	            case READER_IDLE:
	            	ctx.fireExceptionCaught(new Throwable("客户端 心跳超时"));
	                break;
	                
	            case WRITER_IDLE:
	            	System.out.println("客户端 写超时");

//	            	buf.writeInt(222);	            	
	                ctx.writeAndFlush(new PingPong());	              
	                break;
	                
	            case ALL_IDLE:
	            	 write_PingPong(ctx, buf);    
	                break;
	                
	            default:
	                break;
	        }
	    }

	}
	
	public void write_PingPong(ChannelHandlerContext ctx,ByteBuf buf) {
		System.out.println("心跳超时");

    	buf.writeInt(222);	            	
        ctx.writeAndFlush(buf);	    
	}
}
