package netty_demo;

import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLEngine;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.ssl.SslHandler;
import io.netty.handler.timeout.IdleStateHandler;
import tools.SslContextFactory;

public class Server extends Thread{
	
	EventLoopGroup boss_group = null;
	EventLoopGroup work_group = null;
	ServerBootstrap bootstrap = null;
	
	public Server() {
		
		boss_group = new NioEventLoopGroup(1);
		work_group = new NioEventLoopGroup(100);
		bootstrap = new ServerBootstrap();
	}
	
	@Override
	public void run() {
		
		bootstrap.group(boss_group, work_group).channel(NioServerSocketChannel.class).option(ChannelOption.SO_BACKLOG, 100).childHandler(new ChannelInitializer<Channel>() {

			@Override
			protected void initChannel(Channel channel) throws Exception {
				
				SSLEngine engine = SslContextFactory.get_serve_sslContext().createSSLEngine();
				engine.setUseClientMode(false);
				engine.setNeedClientAuth(true);
				channel.pipeline().addFirst(new SslHandler(engine));
				
				channel.pipeline().addLast(new PingPong_decoder());	
				channel.pipeline().addLast(new Cat_decoder());				
				
				channel.pipeline().addLast(new PingPong_encoder());	
				channel.pipeline().addLast(new Cat_encoder());
			     			
				channel.pipeline().addLast(new IdleStateHandler(6, 0, 0, TimeUnit.SECONDS));
				channel.pipeline().addLast(new Server_PingPong_handler());
				channel.pipeline().addLast(new Server_Handle());
			}
		});
		
		ChannelFuture future = null;
		try {
			 future = bootstrap.bind(6666).sync();
		} catch (InterruptedException e) {		
			e.printStackTrace();
		}
		
		 
		try {
			future.channel().closeFuture().sync();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	    boss_group.shutdownGracefully();
	    work_group.shutdownGracefully();
	    
	}  // run
	
	public static void main(String[] args) {
		
		 new Server().start();
		 System.out.println("Netty服务端启动");
	}
}
