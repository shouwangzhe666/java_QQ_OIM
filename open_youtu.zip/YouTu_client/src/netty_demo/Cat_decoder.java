package netty_demo;

import java.util.List;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

public class Cat_decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> list) throws Exception {
		
		int protocal_code = buf.readInt();
		
		if(protocal_code==111) {
			
			int lenth = buf.readInt();
			byte[] by = new byte[lenth];
			buf.readBytes(by);
			
			String name = new String(by,"UTF-8");
			int age = buf.readInt();
			
			Cat cat = new Cat(name, age);
			list.add(cat);
		}
		else {
			buf.retain();
			ctx.fireChannelRead(buf);
		}
	}
}
