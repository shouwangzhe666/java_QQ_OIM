package netty_demo;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

public class Cat_encoder extends MessageToByteEncoder<Cat>{

	@Override
	protected void encode(ChannelHandlerContext arg0, Cat cat, ByteBuf buf) throws Exception {
		 String name = cat.getName();
		 int age = cat.getAge();
		 byte[] by = name.getBytes("UTF-8");
		 
		 buf.writeInt(111);
		 
		 buf.writeInt(by.length);
		 buf.writeBytes(by, 0, by.length);
		 
		 buf.writeInt(age);
	}

}
