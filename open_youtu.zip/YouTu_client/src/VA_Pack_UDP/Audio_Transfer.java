package VA_Pack_UDP;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;
import javax.media.Format;
import javax.media.format.UnsupportedFormatException;
import javax.media.protocol.DataSource;
import javax.media.rtp.InvalidSessionAddressException;
import javax.media.rtp.RTPManager;
import javax.media.rtp.ReceiveStream;
import javax.media.rtp.ReceiveStreamListener;
import javax.media.rtp.SendStream;
import javax.media.rtp.SessionAddress;
import javax.media.rtp.event.ByeEvent;
import javax.media.rtp.event.NewReceiveStreamEvent;
import javax.media.rtp.event.ReceiveStreamEvent;
import udp_pack.UDP_P4P_Client;

public class Audio_Transfer extends Thread implements ReceiveStreamListener{
	
	 SessionAddress localaddr1 = null;
	 SessionAddress remoteaddr1 = null;
	 
	 RTPManager audioRTPManager = null;
	 SendStream audio_SendStream = null;
	 
	 Format audioFormat = null;
	
	InetAddress local_address = null;
	InetAddress remote_address = null;
	int[] ports = null;
    
    DataSource audio_datasourse = null;
    Object object = new Object();
    volatile boolean complate = false;
    volatile boolean connected = false;
    volatile long lastByte_time = 0;
    
    Audio_Transfer va_Transfer = null;
    
	public Audio_Transfer(String remote_ip,int[] ports) {
		
		System.out.println("Audio_Transfer");
		this.ports = ports;
		
		 try {
			 local_address = InetAddress.getLocalHost();
			 remote_address = InetAddress.getByName(remote_ip);
		} catch (UnknownHostException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	
		 new Check_thread().start();
	}
	public void import_VA_Transfer(Audio_Transfer va_Transfer) {
		this.va_Transfer = va_Transfer;
	}
    @Override
    public void run() {
    	
    	System.out.println("run");
    	
    	Init_RTPManeger();
    	
    	synchronized (object) {
			complate = true;
			object.notify();
		}
    	System.out.println("run over");
    }
    public void Init_RTPManeger() {  

		 audioRTPManager = RTPManager.newInstance();	
    
		  localaddr1 = new SessionAddress(local_address,ports[0], local_address, ports[1]);
		  remoteaddr1 = new SessionAddress(remote_address,ports[4], remote_address,ports[5]);
		 
					try {
						audioRTPManager.initialize(localaddr1);
						audioRTPManager.addTarget(remoteaddr1);
					} catch (InvalidSessionAddressException | IOException e1) {
						// TODO AYouTu-generated catch block
						e1.printStackTrace();
					}									
						 
		 audioRTPManager.addReceiveStreamListener(this);
	}   
    
    @Override
	public void update(ReceiveStreamEvent arg0) {
		
    	if(arg0 instanceof NewReceiveStreamEvent) {
			
    			System.out.println("收到——ReceiveStream");
    			connected = true;
    			
    			ReceiveStream re = arg0.getReceiveStream();	
    			audio_datasourse = re.getDataSource();
    			
    			boolean closed = va_Transfer.close_session();
    	    	if(closed) { va_Transfer.Init_RTPManeger();}
    	    	
    			va_Transfer.start_transfer(audio_datasourse);
    	
    }
    	else if(arg0 instanceof ByeEvent) {
			 System.out.println("Bye");		
			 
			 connected = false;
			 lastByte_time = System.currentTimeMillis();
			 
		    	 boolean close = close_session();
		    	 if(close) {Init_RTPManeger();}
		    	
		    	 close = va_Transfer.close_session();
		    	 if(close) va_Transfer.Init_RTPManeger();
		}
	}
 public boolean close_session() {
    	
    	boolean closed = false;
    	
    	if(audio_SendStream!=null) {closed = true;audio_SendStream.close();audio_SendStream=null;}
    	if(audioRTPManager!=null) {closed = true;audioRTPManager.dispose();audioRTPManager=null;}
    	
    	return closed;
    }
 
    public void start_transfer(DataSource audio_datasourse) {
    	System.out.println("start_transfer");
    	
    	synchronized (object) {
			while(!complate) {
				try {
					object.wait();
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
			}
		}
    	
    	 SendStream SendStream = null;
    	 try {
    		 SendStream = audioRTPManager.createSendStream(audio_datasourse, 0);
    		 SendStream.start();

		} catch (UnsupportedFormatException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
    	 
    	 System.out.println("transfer over!");
    }
   
    private class Check_thread extends Thread{
  	 
  		@Override
    	public void run() {
    		while(true) {
    			try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO AYouTu-generated catch block
					e.printStackTrace();
				}
    			
      	    	if(!connected&&System.currentTimeMillis()-lastByte_time>30000) {
      	    		close_session();
      	    		va_Transfer.close_session();
      	    		break;
      	    	}
    		}
    	}
   }
   
public static void main(String[] args) {
	 
	 Scanner scanner = new Scanner(System.in);
	  
	    System.out.println("server port: ");
	    int server_port = scanner.nextInt();
	  
	    UDP_P4P_Client client =  new UDP_P4P_Client(server_port,true);
	    String remote_ip = client.get_remoteIP();
		int[] ports = client.get_ports(60);
		
//	 	 String remote_ip = "192.168.31.247";
//	     int[] ports = new int[] {10005,10006,10007,10008,10001,10002,10003,10004};
//	     int[] ports = new int[] {10001,10002,10003,10004,10005,10006,10007,10008};
		
		Audio_Transfer va_Transfer = new Audio_Transfer(remote_ip, ports);			
		va_Transfer.start();
		
		System.out.println("start");
//		try {
//			Thread.sleep(60000);
//		} catch (InterruptedException e) {
//			// TODO AYouTu-generated catch block
//			e.printStackTrace();
//		}
}
}
