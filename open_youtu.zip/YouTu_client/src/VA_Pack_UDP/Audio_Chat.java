package VA_Pack_UDP;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.channels.FileLock;

import javax.media.ConfigureCompleteEvent;
import javax.media.ControllerEvent;
import javax.media.ControllerListener;
import javax.media.Format;
import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.NoDataSourceException;
import javax.media.NoPlayerException;
import javax.media.NoProcessorException;
import javax.media.Player;
import javax.media.PrefetchCompleteEvent;
import javax.media.Processor;
import javax.media.RealizeCompleteEvent;
import javax.media.control.TrackControl;
import javax.media.format.AudioFormat;
import javax.media.format.UnsupportedFormatException;
import javax.media.protocol.ContentDescriptor;
import javax.media.protocol.DataSource;
import javax.media.rtp.InvalidSessionAddressException;
import javax.media.rtp.RTPManager;
import javax.media.rtp.ReceiveStream;
import javax.media.rtp.ReceiveStreamListener;
import javax.media.rtp.SendStream;
import javax.media.rtp.SessionAddress;
import javax.media.rtp.event.ByeEvent;
import javax.media.rtp.event.NewReceiveStreamEvent;
import javax.media.rtp.event.ReceiveStreamEvent;

import Frame.Audio_chat_frame;
import Frame.Main_Frame;
import Message.Private.Apply_Message;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;
import tools.FileUtills;
import udp_pack.UDP_P4P_Client;

public class Audio_Chat extends Thread implements ReceiveStreamListener,ControllerListener{  
	
	RTPManager audioRTPManager = null;
	SendStream audio_SendStream = null;
	 
	Format audioFormat = null;
	Processor audio_processor = null;  
	DataSource audio_datasourse = null;
   
   InetAddress local_address = null;
   InetAddress remote_address = null;
   
   int sourse_num = 0;
   int bye_num = 0;   
   long time=0;

   int[] ports = null;
   
   Object sync1 = new Object();
   boolean complate = false;
   Object sync2 = new Object();
   boolean ready = false;
   int server_port = 0;
   volatile boolean receve = false;
   Audio_chat_frame audio_chat_frame = null;
   int link_account = 0;
   
    static String file_path = "C:\\ProgramData\\YouTu\\set\\vsecurity.db";
	static RandomAccessFile randomAccessFile = null;
	static FileLock fileLock =	null;
	static {
		
		FileUtills.create_new_file(file_path);
		
		try {
			randomAccessFile = new RandomAccessFile(new File(file_path), "rws");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
   public Audio_Chat(int server_port,int link_account) {	
   	  this.server_port = server_port;
   	  this.link_account = link_account;
   }
   
   public void import_Audio_chat_frame( Audio_chat_frame audio_chat_frame) {
	   this.audio_chat_frame = audio_chat_frame;
   }
   
   @Override
	public void run() {
   	 time = System.currentTimeMillis();
   	
   	  new Check_thread().start();
   	  
  	  Create_Processor();
//  	  System.out.println("Create_Processor");
//  	  System.out.println(System.currentTimeMillis()-time);
//  	  time = System.currentTimeMillis();
  	  
        Configure__Processor();
//        System.out.println("Configure__Processor");
//        System.out.println(System.currentTimeMillis()-time);
//  	  time = System.currentTimeMillis();
  	  
        start_processor();
//        System.out.println("start_processor");
//        System.out.println(System.currentTimeMillis()-time);
//  	    time = System.currentTimeMillis();
  	  
//  	  System.out.println(System.currentTimeMillis()-time);
//	  time = System.currentTimeMillis();
  	 UDP_P4P_Client udp_P4P_Client =  new UDP_P4P_Client(server_port,true);
		
		int[] ports = udp_P4P_Client.get_ports(10);
		String remote_ip = udp_P4P_Client.get_remoteIP();
		 
		if(remote_ip==null) {
			new Warn_frame("提示", "语音通话连接异常").set_aYouTu_click(5);
			Audio_Chat.ReleaseVAOccupy();
			audio_processor.close();
			return;
		}
    try {
		 this.remote_address = InetAddress.getByName(remote_ip);
		 this.local_address = InetAddress.getLocalHost();
	} catch (UnknownHostException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
     
      this.ports = ports;
      
    Init_RTPManeger();
 
//	   time = System.currentTimeMillis();
  
    System.out.println("正在连接中。。。。");
}
   
   public void Create_Processor() {
   
            try {
				audio_processor = Manager.createProcessor(new MediaLocator("javasound://44100"));
			} catch (NoProcessorException e) {
				e.printStackTrace();
				System.err.print("获取麦克风失败，请检查麦克风是否正确连接。");
			} catch (IOException e) {
				e.printStackTrace();
				System.err.print("获取麦克风失败，请检查麦克风是否正确连接。");
			}           

   }
   public void Configure__Processor() {
   	
	   audio_processor.configure();
       waitForState(audio_processor, javax.media.Processor.Configured);  
       
       Configure_Audio_Processor();
       
       audio_processor.realize();
       waitForState(audio_processor, javax.media.Processor.Realized); 
      
       audio_datasourse = audio_processor.getDataOutput();
   }
   /** 初始化启动摄像头 */  
   public void start_processor() {
	   
	   audio_processor.prefetch();
	   audio_processor.start();
   }
  
   public void Init_RTPManeger() {  
   	
         audioRTPManager = RTPManager.newInstance();		
		 audioRTPManager.addFormat(audioFormat, 73);
		 
		 SessionAddress localaddr1 = new SessionAddress(local_address,ports[0], local_address, ports[1]);
		 SessionAddress remoteaddr1 = new SessionAddress(remote_address,ports[4], remote_address, ports[5]);
      
					try {
						audioRTPManager.initialize(localaddr1);
						audioRTPManager.addTarget(remoteaddr1);
					} catch (InvalidSessionAddressException | IOException e1) {
						// TODO AYouTu-generated catch block
						e1.printStackTrace();
					}									
				
		 try {
	
				audioRTPManager.addReceiveStreamListener(this);
			    audio_SendStream = audioRTPManager.createSendStream(audio_datasourse,0);
			    audio_SendStream.start();
			   
		} catch (UnsupportedFormatException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}	
}   
 
  public boolean Configure_Audio_Processor() {
	   TrackControl[] tracks = audio_processor.getTrackControls();  
     
      if (tracks == null || tracks.length ==0) {return false;}
      
      ContentDescriptor cd = new ContentDescriptor(ContentDescriptor.RAW_RTP);  
      audio_processor.setContentDescriptor(cd);  
      
      Format ori_Format = null;
      audioFormat = null;
      Format supportedFormats[] = null;        
      boolean atLeastOneTrack = false;  

	   for (int i = 0; i < tracks.length; i++) {  
          if (tracks[i].isEnabled()) { 
       	   
       	   ori_Format = (AudioFormat) tracks[i].getFormat();
              supportedFormats = tracks[i].getSupportedFormats();  
           
              if (supportedFormats.length > 0) {  
                   
           	    audioFormat = checkFor_AudioFormat(ori_Format, supportedFormats);
        //    	    System.out.println(chosen_Format.getEncoding());
                   tracks[i].setFormat(audioFormat);                                
                   atLeastOneTrack = true;  

              } //if
      } // if
     } // for
	   return atLeastOneTrack;
  }
  
public Format checkFor_AudioFormat(Format original,Format[] supported) {
	 Format format = null;
	 
	 if((format=checkFor_gsmFormat(original, supported))!=null) {return format;}
	  if((format=checkFor_g723FormatFormat(original, supported))!=null) {return format;}
	 else if((format=checkFor_dviFormatFormat(original, supported))!=null) {return format;}
	 else {return original;}
}
public Format checkFor_gsmFormat(Format original,Format[] supported) {
	   Format gsmFormat = new Format(AudioFormat.GSM_RTP);
	   AudioFormat audioFormat = null;
	   
	    for(int i=0;i<supported.length;i++) {
	    	if(supported[i].matches(gsmFormat)) {
	    		audioFormat = (AudioFormat) supported[i];
//	    		System.out.println(audioFormat.getSampleRate());
//	    		System.out.println(audioFormat.getSampleSizeInBits());
//	    		System.out.println(audioFormat.getChannels());
//	    		return new AudioFormat(AudioFormat.GSM_RTP).intersects(supported[i]);
	    		return new AudioFormat(AudioFormat.GSM_RTP,8000,16, 1);
	    	}
	    }
	    return null;
}
public Format checkFor_g723FormatFormat(Format original,Format[] supported) {
	 Format g723Format = new Format(AudioFormat.G723_RTP);
	   
	    for(int i=0;i<supported.length;i++) {
	    	if(supported[i].matches(g723Format)) {
	    		
	    		return new AudioFormat(AudioFormat.G723_RTP,8000,16, 1);
	    	}
	    }
	    return null;
}
public Format checkFor_dviFormatFormat(Format original,Format[] supported) {
	 Format dviFormat = new Format(AudioFormat.DVI_RTP);
	   
	    for(int i=0;i<supported.length;i++) {
	    	if(supported[i].matches(dviFormat)) {
	    		
	    		return new AudioFormat(AudioFormat.DVI_RTP,8000,16, 1);
	    	}
	    }
	    return null;
}

   private void waitForState(javax.media.Processor p, int state) {  
	  
	   int i = 0;
	   p.addControllerListener(new ControllerListener() {
		
		@Override
		public void controllerUpdate(ControllerEvent arg0) {
		
			 if(arg0 instanceof ConfigureCompleteEvent || arg0 instanceof PrefetchCompleteEvent||arg0 instanceof RealizeCompleteEvent) {
				   if(p.getState()==state) {
					   synchronized (sync1) {
						   complate = true;						  
						   sync1.notify();
					}
				 }
			 }
		}
	});
     
	   synchronized (sync1) {
		  while(!complate) {
			  try {
				  sync1.wait();
			} catch (InterruptedException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
		}
	}
	   complate = false;
 }    
  
public void play_sourse(DataSource dataSource) {
   	
   	Player player = null;
   	try {
			player = Manager.createPlayer(dataSource);
		} catch (NoPlayerException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
   	
      player.addControllerListener(this);
      
	  player.realize();
      player.prefetch();
      player.start();
     
     System.out.println("play_sourse");
     
	}

@Override
public void controllerUpdate(ControllerEvent arg0) {
	  if(arg0 instanceof RealizeCompleteEvent) {
		  System.out.println("RealizeCompleteEvent");
		  System.out.println("audio_chat_frame==null ? "+(audio_chat_frame==null));
		  
		  if(audio_chat_frame!=null) {audio_chat_frame.setFrame_visiable(true);}
	  }
}	

   @Override
	public void update(ReceiveStreamEvent arg0) {
	
		if(arg0 instanceof NewReceiveStreamEvent) {
			
		System.out.println(System.currentTimeMillis()-time);
		System.out.println("收到——ReceiveStream");
		
		ReceiveStream re = arg0.getReceiveStream();	
		DataSource dataSource = re.getDataSource();
		
		receve = true;
		play_sourse(dataSource);
		
	}
		
		else if(arg0 instanceof ByeEvent) {
			System.out.println("收到  ByeEvent");
			
//			close_audio_chat();
//		   if(audio_chat_frame!=null) {audio_chat_frame.dispose_frame();}	
//			flush_audio();
		}
	}
  
	 public void stop_audio() {
		 try {
			audio_SendStream.stop();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	 }
	 public void start_audio() {
		 try {
			audio_SendStream.start();
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	 }
	 public void close_audio_chat() {
		   	
		    audio_chat_frame.dispose_frame();
		 
		    if(audioRTPManager!=null) {audioRTPManager.dispose();}
		   	if(audio_SendStream!=null) {audio_SendStream.close();}
		   	if(audio_processor!=null) { audio_processor.close();}	
		   	
		   	Audio_Chat.ReleaseVAOccupy();
     }
	
public static boolean Device_exist() {

	DataSource dataSource = null;
	boolean exist = true;

	try {
		dataSource = Manager.createDataSource(new MediaLocator("javasound://44100"));
	} catch (NoDataSourceException e) {
		exist = false;
		e.printStackTrace();
	} catch (IOException e) {
		exist = false;
		e.printStackTrace();
	}
	
   if(exist) {dataSource.disconnect();}

	return exist;
}
public void flush_audio() {
	
	 if(audioRTPManager!=null) {audioRTPManager.dispose();}
	 if(audio_SendStream!=null) {audio_SendStream.close();}
	 
	 audioRTPManager = RTPManager.newInstance();		
	 audioRTPManager.addFormat(audioFormat, 73);
	 
	 System.out.println("local_address==null? "+(local_address==null));
	 System.out.println("ports==null? "+(ports==null));
	 
	 SessionAddress localaddr1 = new SessionAddress(local_address,ports[0], local_address, ports[1]);
	 SessionAddress remoteaddr1 = new SessionAddress(remote_address,ports[4], remote_address, ports[5]);
  
				try {
					audioRTPManager.initialize(localaddr1);
					audioRTPManager.addTarget(remoteaddr1);
				} catch (InvalidSessionAddressException | IOException e1) {
					// TODO AYouTu-generated catch block
					e1.printStackTrace();
				}											
	 try {
			audioRTPManager.addReceiveStreamListener(this);
		    audio_SendStream = audioRTPManager.createSendStream(audio_datasourse,0);
		    audio_SendStream.start();
		   
	} catch (UnsupportedFormatException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}	
}
public void write_message(int type) {
	String reply_ip = Main_Frame.getMessage_pane().get_link_info(String.valueOf(link_account)).getRemote_ip();
	String request_ip = Main_Frame.get_NativeIp();
	int p2p_type = request_ip.equals(reply_ip)?2:1;
	
	int from_account  = Integer.parseInt(Main_Frame.getNative_count());
	int to_account = Integer.parseInt(String.valueOf(link_account));
	
	Apply_Message apply_Message = new Apply_Message(133, type, from_account, to_account, p2p_type, 1, 1, 1, true, request_ip, reply_ip);
	Private_Chat_Client.send_message(apply_Message);
}
private class Check_thread extends Thread{
	@Override
	public void run() {
	       try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	       
	      flush_audio();
	}
}
public static boolean isVAOccupy() {
	
	try {
		fileLock =	randomAccessFile.getChannel().tryLock();
		
		if(fileLock!=null) {
			fileLock.release();
		}
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
	//	e.printStackTrace();
		return true;
	}
	catch (Exception e) {
    //	e.printStackTrace();
		return true;
	}
	
	return false;
}
public static boolean VAOccupy() {
	
	try {
		fileLock =	randomAccessFile.getChannel().tryLock();
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
	//	e.printStackTrace();
		return false;
	}
	catch (Exception e) {
	//	e.printStackTrace();
		return false;
	}
	
	return true;
}
public static boolean ReleaseVAOccupy() {
	
	try {
		if(fileLock!=null) {fileLock.release();}
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
	//	e.printStackTrace();
		return false;
	}
	catch (Exception e) {
	//	e.printStackTrace();
		return false;	
	}
	
	return true;
}
 public static void main(String[] args) {
		
	    System.out.println(Audio_Chat.VAOccupy());
	    System.out.println(Audio_Chat.VAOccupy());
	    System.out.println(Audio_Chat.isVAOccupy());
  }
}  
