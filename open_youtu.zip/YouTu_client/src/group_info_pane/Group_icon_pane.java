package group_info_pane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JPanel;

import Frame.Group_info_frame;
import Frame.Only_frame;
import Message.Group.Group_info_message;
import custom_component.Box_pane;
import custom_component.My_ScrollPane;
import custom_component.My_radiobutton;
import custom_component.Roundrec_button;
import group_info_item.Group_Send_notice_item;
import group_info_item.Group_icon_item;
import group_info_item.Group_notice_item;
import ss.Group_Chat_Client;
import ss.Private_Chat_Client;
import tool_Frame.Warn_frame;
import tools.Icon_tools;

public class Group_icon_pane extends My_ScrollPane {

	Only_frame only_frame = null;
	JPanel list_pane = null;
	Send_pane send_pane = null;
	HashMap<Long,Group_icon_item> all_item = null;
	
	public Group_icon_pane(Group_info_message info_message) {
		
		   list_pane = new JPanel();
		   list_pane.setOpaque(false);
		   list_pane.setLayout(new FlowLayout(FlowLayout.LEFT));
		   setViewportView(list_pane);
		   
		   Init_all_icons(info_message);
		   update_forTime(); 
	}
	
	public void Init_all_icons(Group_info_message info_message) {
		
		 all_item = new HashMap<>();
		 ArrayList<ArrayList<Object>> all_icons = info_message.getAll_icons();
		 ArrayList<Object> icon = null;
		
		 if(Group_info_frame.is_icon_unload()||Group_info_frame.get_group_id().equals("群主")) {
			   send_pane = new Send_pane();
			   list_pane.add(send_pane);
		   }
		 
		 for(int i=0;i<all_icons.size();i++) {
			 icon = all_icons.get(i);
			 put_icon(icon);
		
		 }
	}
	public void callIn_frame(Only_frame only_frame) {
		
		  this.only_frame = only_frame;
	
	}
	public void put_icon(ArrayList<Object> icon) {
		 Group_icon_item item = new Group_icon_item(this,icon);
		 all_item.put(item.get_send_time(),item);
		 list_pane.add(item);
	}
	public void remove_icon(long send_time){
		Group_icon_item item = all_item.get(send_time);
		list_pane.remove(item);
		all_item.remove(send_time);
		
		update_pane_size();
	}
	public void update_pane_size() {
		
		int pane_height = (all_item.size()/2+(all_item.size()%2))*350;
		 
		if(Group_info_frame.is_icon_unload()||Group_info_frame.get_group_id().equals("群主")) { pane_height+=40;}
		 
		list_pane.setPreferredSize(new Dimension(700,pane_height));
		list_pane.setMinimumSize(new Dimension(700,pane_height));
		list_pane.setMaximumSize(new Dimension(700,pane_height));
		
		  if(only_frame!=null) {only_frame.update_frame();}
	}
	public void update_forTime() {
		
		Group_icon_item item = null;
		long[] all_time = get_sorted_array(all_item.keySet());
		long time = 0l;
		
		list_pane.removeAll();
		
		if(Group_info_frame.is_icon_unload()||Group_info_frame.get_group_id().equals("群主")) {
		list_pane.add(send_pane);
		 }
	
		for(int i=all_time.length-1;i>-1;i--) {
		      time = all_time[i];	
		      item = all_item.get(time);
		      list_pane.add(item);
		}
		
		update_pane_size();
	}
	
public long[] get_sorted_array(Set<Long> set) {
		
		Iterator<Long> it = set.iterator();
		long value = 0l;
				
		long[] all_int = new long[set.size()];
		
		int i = 0 ;
		while(it.hasNext()) {
			
			value = it.next();
			all_int[i] = value;
			i++;
		}
		
		Arrays.sort(all_int);
		
		return all_int;
	}

private class Send_pane extends Box_pane implements ActionListener{

	Font font = null;
	Color color = null;
	Roundrec_button send_button = null;
	ButtonGroup group = null;
	My_radiobutton low_item = null;
	My_radiobutton midum_item = null;
	My_radiobutton height_item = null;
	
	public Send_pane() {
		super(BoxLayout.X_AXIS);
		font = new Font("宋体", Font.PLAIN, 16);
	    color = new Color(140,140,140);
			
		Init_button();
		Init_radioButton();
		
		setPreferredSize(new Dimension(700,40));
		setMinimumSize(new Dimension(700,40));
		setMaximumSize(new Dimension(700,40));
	}
public void Init_button() {
		
		send_button = new Roundrec_button(300,35,20,new Color(0, 131, 245),"上传图片", 18, Color.white);
		send_button.addActionListener(this);
		add(send_button);
	}
public void Init_radioButton() {
	
	low_item = new My_radiobutton(false);
	midum_item = new My_radiobutton(true);
	height_item = new My_radiobutton(false);
	
	add(Box.createHorizontalStrut(150));
	add(low_item);
	add(Box.createHorizontalStrut(60));
	add(midum_item);
	add(Box.createHorizontalStrut(60));
	add(height_item);
	add(Box.createHorizontalGlue());
	
	group = new ButtonGroup();
	group.add(low_item);
	group.add(midum_item);
	group.add(height_item);
}
public float get_quality() {
	
	float quality = low_item.isSelected()?0.6f:midum_item.isSelected()?0.8f:1f;
	return quality;
}
@Override
protected void paintComponent(Graphics g) {
	super.paintComponent(g);
	Graphics2D g2 = (Graphics2D) g;
	
	g2.setFont(font);
	g2.setColor(color);
	
	g2.drawString("图片质量：低等",330,25);
	g2.drawString("中等",500,25);
	g2.drawString("高等",580,25);
}
@Override
public void actionPerformed(ActionEvent e) {
	FileDialog fileDialog = new FileDialog(only_frame);
	fileDialog.setVisible(true);
	
	String file_name = fileDialog.getFile();
	if(fileDialog.getDirectory()==null||file_name==null) {return;}
	if(!file_name.endsWith("jpg")&&!file_name.endsWith("png")) {new Warn_frame("提示","不是所支持的图片格式！").set_aYouTu_click(3);return;}
	
	String icon_path = fileDialog.getDirectory()+file_name;
	icon_path = Icon_tools.compress_image(icon_path, get_quality());
	byte[] icon_bytes = Icon_tools.get_IconBytes(icon_path);
	
	long time = System.currentTimeMillis();
	ArrayList<Object> icon = new ArrayList<>();
	icon.add(icon_bytes);
	icon.add(Group_info_frame.get_group_remark());
	icon.add(time);
	put_icon(icon);
	update_forTime();
	
	Group_info_message info_message = new Group_info_message(41,Group_info_frame.get_group_account());
	info_message.setGroup_icon(icon_bytes);
	info_message.setSender(Group_info_frame.get_group_remark());
	info_message.setSend_time(time);
	Group_Chat_Client.send_message(Group_info_frame.get_group_account(), info_message);
	
	new Warn_frame("提示","上传成功！").set_aYouTu_click(2);
}
}
}
