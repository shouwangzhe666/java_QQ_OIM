package group_info_pane;

import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.text.html.StyleSheet.ListPainter;

import Frame.Group_info_frame;
import Frame.Only_frame;
import Message.Group.Group_info_message;
import custom_component.Box_pane;
import custom_component.Icon_button;
import custom_component.My_ScrollPane;
import custom_component.My_checkbox;
import group_info_item.Group_Send_notice_item;
import group_info_item.Group_notice_item;

public class Group_notice_pane extends My_ScrollPane{

	String sender = null;
	String send_time = null;
	
	Only_frame only_frame = null;
	Box_pane list_pane = null;
	Group_Send_notice_item send_item = null;
	HashMap<Long,Group_notice_item> all_item = null;
	
	public Group_notice_pane(Group_info_message info_message) {
	   
	   list_pane = new Box_pane(BoxLayout.Y_AXIS);
	   setViewportView(list_pane);
	   
	   Init_all_notices(info_message);
	   update_forTime();
	}	
	
	public void Init_all_notices(Group_info_message info_message) {
		
		 all_item = new HashMap<>();
		 ArrayList<ArrayList<Object>> all_notices = info_message.getAll_notices();
		 ArrayList<Object> notice = null;
		 Group_notice_item item = null;
		 
		 if(Group_info_frame.get_group_id().equals("群主")) {
		 send_item = new Group_Send_notice_item(this);
		 list_pane.add(send_item);
		 }
		 
		 for(int i=0;i<all_notices.size();i++) {
			 notice = all_notices.get(i);
			 put_notice(notice);
		
		 }
	}
	
	public void callIn_frame(Only_frame only_frame) {
		
		  this.only_frame = only_frame;
	
	}
	public void put_notice(ArrayList<Object> notice) {
		 Group_notice_item item = new Group_notice_item(this,notice);
		 all_item.put(item.get_send_time(),item);
		 list_pane.add(item);
	}
	public void remove_notice(long send_time) {
		
		Group_notice_item item = all_item.get(send_time);
		list_pane.remove(item);
		all_item.remove(send_time);
		
		update_pane_size();
	}
	
	public void update_pane_size() {
	
		int pane_height = 0;
		int total_height = 0;
		
		 for( Group_notice_item item:all_item.values()) {
			 total_height = item.get_total_height();
			 pane_height+=total_height;
		 }
		 
		 if(Group_info_frame.get_group_id().equals("群主")&&send_item!=null) { pane_height+=send_item.get_total_height();}
		 
		list_pane.setPreferredSize(new Dimension(700,pane_height));
		list_pane.setMinimumSize(new Dimension(700,pane_height));
		list_pane.setMaximumSize(new Dimension(700,pane_height));
		
		  if(only_frame!=null) {only_frame.update_frame();}
	}
	public void update_forTime() {
		
		Group_notice_item item = null;
		long[] all_time = get_sorted_array(all_item.keySet());
		long time = 0l;
		
		list_pane.removeAll();
		
		if(Group_info_frame.get_group_id().equals("群主")) {
		list_pane.add(send_item);
		 }
	
		for(int i=all_time.length-1;i>-1;i--) {
		      time = all_time[i];	
		      item = all_item.get(time);
		      list_pane.add(item);
		}
		
		update_pane_size();
	}
	
public long[] get_sorted_array(Set<Long> set) {
		
		Iterator<Long> it = set.iterator();
		long value = 0l;
				
		long[] all_int = new long[set.size()];
		
		int i = 0 ;
		while(it.hasNext()) {
			
			value = it.next();
			all_int[i] = value;
			i++;
		}
		
		Arrays.sort(all_int);
		
		return all_int;
	}
}
