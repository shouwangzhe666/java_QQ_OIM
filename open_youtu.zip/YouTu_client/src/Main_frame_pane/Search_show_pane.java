package Main_frame_pane;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import Frame.Main_Frame;
import Frame.Search_frame;
import Message.Group.Group_search_message;
import Message.Private.Link_info;
import Message.Private.Private_info;
import custom_component.Roundrec_button;
import ss.Private_Chat_Client;
import tool_Frame.TextFild_Frame;
import tool_Frame.Warn_frame;
import tools.Icon_tools;

public class Search_show_pane extends JPanel implements ActionListener{

	Image head_image = null;
	String link_account = null;
	String name = null;
	String info = null;
	
	int add_type = 1;
	Roundrec_button info_button = null;
	Roundrec_button add_button = null;
	TextFild_Frame textFild_Frame = null;
	Search_frame search_frame = null;
	Group_search_message search_message = null;
	
	public Search_show_pane(int add_type,Search_frame search_frame,byte[] icon_bytes, String link_account, String name) {
	    setLayout(null);
	  //  setOpaque(false);
	    setBackground(Color.LIGHT_GRAY);
	    
	    this.add_type = add_type;
	    this.search_frame = search_frame;
		this.head_image = new ImageIcon(icon_bytes).getImage();
		this.link_account = link_account;
		this.name = name;
		info = name+" ("+link_account+")";
		
		Init_componnets();

	}
	
	public Search_show_pane(Search_frame search_frame,Group_search_message search_message) {
		this(2,search_frame, search_message.getGroup_icon(), search_message.getGroup_account(), search_message.getGroup_name());
	    this.search_message = search_message;
	}
	
	public void Init_componnets() {
		
		info_button = new Roundrec_button(90, 30, 10, new Color(0, 131, 245), "查看资料", 14, Color.white);
		
		if(add_type==1) {add_button = new Roundrec_button(90, 30, 10, new Color(0, 131, 245), "添加好友", 14, Color.white);}
		else {add_button = new Roundrec_button(90, 30, 10, new Color(0, 131, 245), "加入群聊", 14, Color.white);}
		
		info_button.addActionListener(this);
		add_button.addActionListener(this);
		
		info_button.setBounds(50, 55, 90, 30);
		add_button.setBounds(140, 55, 90, 30);
		add(info_button);
		add(add_button);
	}
	
	public void Init_addfriend_frame() {
				
		textFild_Frame = new TextFild_Frame("加好友", "请输入验证消息：");
		textFild_Frame.alter_ActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				String verify_message = textFild_Frame.get_input_text();
				if(verify_message.length()==0) {new Warn_frame("提示", "验证消息不能为空！").set_aYouTu_click(3);return;}				
				
				String icon_path ="C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\image\\head_image\\"+Main_Frame.getNative_count()+".png";
				byte[] icon_bytes = Icon_tools.get_IconBytes(icon_path);
				if(icon_bytes==null) {new Warn_frame("提示", "无法找到本人头像图片").set_aYouTu_click(5);return;}
				
				verify_message = "验证消息："+verify_message;
				
				Link_info link_info = new Link_info(8);
				link_info.setAccount(Main_Frame.getNative_count());
				link_info.setLink_count(link_account);
				link_info.setHead_icon_bytes(icon_bytes);
				
				Private_info private_info = Main_Frame.get_PrivateInfo();
				link_info.setName(private_info.getName());
				
				link_info.set_verify_message(verify_message);
				link_info.setSystem_time(System.currentTimeMillis());
				
				Private_Chat_Client.send_message(link_info);
				
				new Warn_frame("提示", "验证消息发送成功！").set_aYouTu_click(1);
				search_frame.dispose_frame();
			}
		});
	}
	
	public void Init_addgroup_frame() {
			
			if(search_message.getGroup_type().equals("1")) {
				search_message = get_group_search_message();
				search_message.setVerify_message("无");
				send_group_message();
			}
			else if(search_message.getGroup_type().equals("2")) {
				new Warn_frame("提示", "验证消息发送成功！").set_aYouTu_click(1);
				search_frame.dispose_frame();
				textFild_Frame.dispose_frame();
			}
			else if(search_message.getGroup_type().equals("3")) {
				
				textFild_Frame = new TextFild_Frame("加入群聊", search_message.getQuestion());
				
				textFild_Frame.alter_ActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						
						search_message = get_group_search_message();
						search_message.setVerify_message(textFild_Frame.get_input_text());
						send_group_message();
					}
				});
			}  // type 3
			else if(search_message.getGroup_type().equals("4")) {
				
				textFild_Frame = new TextFild_Frame("加入群聊", search_message.getQuestion());
				textFild_Frame.alter_ActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						
						search_message = get_group_search_message();
						String text = textFild_Frame.get_input_text();
						search_message.setVerify_message(textFild_Frame.get_input_text());
						
						if(text.equals(search_message.getAnswer())) {send_group_message();}
						else {new Warn_frame("提示", "回答错误！").set_aYouTu_click(3);return;}
					}
				});
			}  // type 4
			else if(search_message.getGroup_type().equals("5")) {
				
				int money = search_message.getPay_money();
				// pay money....
			}
	}
	public Group_search_message get_group_search_message() {
		
		search_message.setType(5);
		String icon_path ="C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\image\\head_image\\"+Main_Frame.getNative_count()+".png";
		byte[] icon_bytes = Icon_tools.get_IconBytes(icon_path);
		if(icon_bytes==null) {new Warn_frame("提示", "无法找到本人头像图片").set_aYouTu_click(5);return null;}
		search_message.setNative_icon(icon_bytes);
		
		String native_name = Main_Frame.get_PrivateInfo().getName();
		search_message.setNative_name(native_name);
		search_message.setNative_account(Main_Frame.getNative_count());
		
		return search_message;
	}
	public void send_group_message() {
		
		Private_Chat_Client.send_message(search_message);
		new Warn_frame("提示", "验证消息发送成功！").set_aYouTu_click(1);
		search_frame.dispose_frame();
		
		if(textFild_Frame!=null) {textFild_Frame.dispose_frame();}
	}
   @Override
protected void paintComponent(Graphics g) {
	super.paintComponent(g);
	Graphics2D g2 = (Graphics2D) g;
	
	g2.drawImage(head_image, 5, 15, null);
	
	g2.setColor(Color.red);
	g2.setFont(new Font("微软雅黑", Font.PLAIN, 16));
	g2.drawString(info, 50, 30);
}

@Override
public void actionPerformed(ActionEvent e) {
	
	if(e.getSource()==info_button) {
		
		if(add_type==1) {
			Private_info private_info = new Private_info();
			private_info.setType(3);
			private_info.setCount(link_account);
			Private_Chat_Client.send_message(private_info);
		}
	}
	
	else if(e.getSource()==add_button) {
		
		if(add_type==1) {Init_addfriend_frame();}
		else {Init_addgroup_frame();}
	}
}
}
