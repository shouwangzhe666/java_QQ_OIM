package Main_frame_pane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.BoxLayout;
import Frame.Main_Frame;
import Frame.Only_frame;
import custom_component.Box_pane;
import custom_component.Focus_button;

public class Main_control_pane extends Box_pane implements ActionListener{

	Focus_button message_button = null;
	Focus_button friend_button = null;
	Focus_button group_button = null;
	
	Main_Frame main_Frame = null;
	
	int num = 0;
	Color color = null;
	
	public Main_control_pane(Main_Frame main_Frame) {
		super(BoxLayout.X_AXIS);
		
		this.main_Frame = main_Frame;
		
		setOpaque(false);
		setPreferredSize(new Dimension(280, 60));
		setMinimumSize(new Dimension(265, 60));
		setMaximumSize(new Dimension(595, 60));
		
		message_button = new Focus_button("消息 ", true, getClass().getResource("/main_frame_image/message_namal.png"), getClass().getResource("/main_frame_image/message_focus.png"));
		friend_button = new Focus_button("好友 ", false, getClass().getResource("/main_frame_image/friend_namal.png"), getClass().getResource("/main_frame_image/friend_focus.png"));
		group_button = new Focus_button("群聊 ", false, getClass().getResource("/main_frame_image/group_namal.png"), getClass().getResource("/main_frame_image/group_focus.png"));
		
		message_button.addActionListener(this);
		friend_button.addActionListener(this);
		group_button.addActionListener(this);
		
		add(Box.createHorizontalStrut(20));
		add(message_button);
		
		add(Box.createHorizontalGlue());
		add(friend_button);
		
		add(Box.createHorizontalGlue());
		add(group_button);
		
		add(Box.createHorizontalStrut(20));	
				
	}

	public void click_message_button() {
		message_button.doClick();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
	
		if(e.getSource()==message_button) {
			message_button.set_focus(true);
			friend_button.set_focus(false);
			group_button.set_focus(false);
			Main_Frame.update_pane(1);
			num = 0;
			}
		else if(e.getSource()==friend_button) {
			message_button.set_focus(false);
			friend_button.set_focus(true);
			group_button.set_focus(false);
			Main_Frame.update_pane(2);
			num = 1;
			}
		else if(e.getSource()==group_button) {
			message_button.set_focus(false);
			friend_button.set_focus(false);
			group_button.set_focus(true);
			Main_Frame.update_pane(3);
			num = 2;
		}
		
		repaint();
	}
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
	//	g2.setColor(Color.gray);
		g2.setColor(Color.lightGray);
		g2.fillRect(0, 45, getWidth(), 3);
		
		g2.setColor(new Color(0, 131, 245));
	//	g2.setColor(Color.red);
		g2.fillRect((getWidth()/3)*num, 45, getWidth()/3, 3);
  }
}
