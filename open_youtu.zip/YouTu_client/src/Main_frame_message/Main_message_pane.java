package Main_frame_message;

import java.util.*;
import java.awt.Dimension;
import java.awt.Image;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import Frame.Main_Frame;
import Message.Private.Link_info;
import custom_component.Box_pane;
import custom_component.My_ScrollPane;
import message_login_register.List_message;
import tools.Icon_tools;
import tools.My_Object_IO;

public class Main_message_pane extends My_ScrollPane{
	
	 Box_pane list_pane = null;
	 int width = 280;
	 int height = 445;
	 int item_num = 0;
    HashMap<String,Main_message_Item> all_item = null;
    HashMap<String, Link_info> all_link_man = null; // type==1
    Main_Frame main_Frame = null;
    String file_path = null;
   
	public Main_message_pane(Main_Frame main_Frame) {
	 //   setOpaque(false);
	 
		file_path = "C:\\ProgramData\\YouTu\\YouTu_"+Main_Frame.getNative_count()+"\\list_history\\list_history.db";
		this.main_Frame = main_Frame;
		
		getVerticalScrollBar().setUnitIncrement(50);
		getVerticalScrollBar().setBlockIncrement(50);
		
		list_pane = new Box_pane(BoxLayout.Y_AXIS);
		list_pane.setOpaque(false);
		setViewportView(list_pane);
		
		all_item = new HashMap<>();
	    all_link_man = new HashMap<>();
	   
		
		setPreferredSize(new Dimension(290, 490));
		setMinimumSize(new Dimension(265, 320));
		setMaximumSize(new Dimension(590, 1000));
		
	    load_all_message();
	   
	}

	public boolean is_online(String link_account) {
		
		Link_info link_info = all_link_man.get(link_account);
		String state = link_info.getState();
		
		if(state.equals("离线")) {return false;}
		
		return true;
	}
	
	public void update_state(String link_account,String state) {
		
		Main_message_Item message_Item = all_item.get(link_account);
		if(message_Item==null) {return;}
		
		message_Item.update_state(state);
	}
	
	public void update_head_image(String link_account,byte[] icon_bytes) {
		
		Main_message_Item message_Item = all_item.get(link_account);
		if(message_Item==null) {return;}
		
		message_Item.update_head_image(icon_bytes);
	}
	
public void rename_remark(String link_count,String remark) {
		
	Main_message_Item item = all_item.get(link_count);
	
	if(item==null) {return;}
	
	 item.update_remark(remark);
	}
	
	public void Set_Top_Item(String link_count) {
		
		list_pane.removeAll();
	
		for(Main_message_Item main_message_Item:all_item.values()) {
		
			if(main_message_Item.get_link_count().equals(link_count)) {
				list_pane.add(main_message_Item);
				
			}			
		}
		for(Main_message_Item main_message_Item:all_item.values()) {
			
			if(main_message_Item.get_link_count().equals(link_count)) {continue;}
				list_pane.add(main_message_Item);									
		}
		
		Main_Frame.update_frame();
	
	}
public void put_link_man(Link_info link_info) {
		
		String link_account = link_info.getLink_count();
		all_link_man.put(link_account, link_info);
	}
	
	public void remove_link_man(String link_count) {
		all_link_man.remove(link_count);
	}
	
	public void put_request_message_item(boolean privat ,List_message list_message) {
		
		String link_count  = list_message.getLink_count();
		Main_message_Item item = null;
		
	    item = new Main_message_Item(main_Frame, list_message);
	    
	    link_count = privat?link_count+"00":link_count+"000";
		all_item.put(link_count, item);
		list_pane.add(item);
	
		item_num++;
		list_pane.setPreferredSize(new Dimension(280, item_num*60));
		list_pane.setMinimumSize(new Dimension(255, item_num*60));
		list_pane.setMaximumSize(new Dimension(595, item_num*60));
		
		Set_Top_Item(link_count);
		
		Main_Frame.update_UI();
		
	}
	public void put_ori_message_item(List_message list_message) {
		
		String link_count  = list_message.getLink_count();
		Main_message_Item item = null;
		
		if(all_item.get(link_count)==null) {
  
	    item = new Main_message_Item(main_Frame, list_message);
		all_item.put(link_count, item);
		list_pane.add(item);
	
		item_num++;
		list_pane.setPreferredSize(new Dimension(280, item_num*60));
		list_pane.setMinimumSize(new Dimension(255, item_num*60));
		list_pane.setMaximumSize(new Dimension(595, item_num*60));
		
		}
	}
	
	public void put_send_message_item(String link_account) {
		
		Link_info link_info = all_link_man.get(link_account);
		String link_count = link_info.getLink_count();
		int type = link_count.length()==8?1:2;
	//	byte[] icon_bytes = link_info.getHead_icon_bytes();
		Image head_image = Icon_tools.get_client_head_image(link_account);
		String group_name = link_info.getGroup();
		String remark = link_info.getRemark();
		
		List_message list_message = new List_message(type, link_count, new ImageIcon(head_image), group_name, remark, "", System.currentTimeMillis(), 0);
		put_ori_message_item(list_message);
		
		Set_Top_Item(link_count);
	}
	
	public void put_accept_message_item(String link_account,Long send_time,String chat_content) {
	
		
		if(all_item.get(link_account)==null) {
		
			Link_info link_man = all_link_man.get(link_account);
			
			int type = link_account.length()==8?1:link_account.length()==9?2:0;
//			byte[] icon_bytes = link_info.getHead_icon_bytes();
			Image head_image = Icon_tools.get_client_head_image(link_account);
			String group_name = link_man.getGroup();
			String remark = link_man.getRemark();
			
		 List_message list_message = new List_message(type, link_account, new ImageIcon(head_image), group_name, remark, chat_content,send_time,0);
		 put_ori_message_item(list_message);
		}
		
		Main_message_Item item =  all_item.get(link_account);
		item.update_chat_content(send_time,chat_content);
		Set_Top_Item(link_account);
	
	}
	
	public void remove_message_item(String link_count) {
		
		Main_message_Item main_message_Item = all_item.get(link_count);
		
		if(main_message_Item==null) {return;}
		
		list_pane.remove(main_message_Item);
		all_item.remove(link_count);
		
		item_num--;
		list_pane.setPreferredSize(new Dimension(280, item_num*60));
		list_pane.setMinimumSize(new Dimension(255, item_num*60));
		list_pane.setMaximumSize(new Dimension(595, item_num*60));
		
		Main_Frame.update_UI();
	}
	
	public void remove_all_message_item() {
		
		Iterator<String> it = all_item.keySet().iterator();
		String link_account = null;
		Main_message_Item message_Item = null;
		
		while(it.hasNext()) {
			
			link_account = (String)it.next();
			message_Item = all_item.get(link_account);
			list_pane.remove(message_Item);
			it.remove();
			item_num--;
		}
		
		list_pane.setPreferredSize(new Dimension(280, item_num*60));
		list_pane.setMinimumSize(new Dimension(255, item_num*60));
		list_pane.setMaximumSize(new Dimension(595, item_num*60));
		
		Main_Frame.update_UI();
	}
	
  public void mark_all_item_readed() {
		
		for(Main_message_Item message_Item:all_item.values()) {
			message_Item.mark_readed();
		}
		
	}
	
	public Link_info get_link_info(String link_account) {
		return all_link_man.get(link_account);
	}
	public Main_message_Item get_message_Item(String link_account) {
		return all_item.get(link_account);
	}
	public ArrayList<Integer> get_all_group_account(){
		
		ArrayList<Integer> all_account = new ArrayList<>();
			
		for(Link_info link_info:all_link_man.values()) {
		
			if(link_info==null) {System.out.println("link_info==null");break;}
			
			if(link_info.getType()==2) {
				int account = Integer.parseInt(link_info.getLink_count());
				all_account.add(account);
				}
		}
		
		return all_account;
	}
	public void load_all_message() {
		
		ObjectInputStream objectInputStream = My_Object_IO.get_ObjectInputStream(file_path);
		
		if(objectInputStream==null) {return;}
		
		List_message list_message = null;
		
		while(true) {
			
			try {
				list_message = (List_message) objectInputStream.readObject();
			} catch (ClassNotFoundException e) {
				break;
			} catch (IOException e) {
				break;
			}
			
			if(list_message.getLink_count().equals(Main_Frame.getNative_count())) {continue;}
			
			 put_ori_message_item(list_message);
			 
			 Main_message_Item item = all_item.get(list_message.getLink_count());
			 item.setVisible(false);
		}//while
	}
	
  public void set_item_visiable(String link_account) {
	  
	  Main_message_Item item = all_item.get(link_account);
	  if(item!=null) {item.setVisible(true);}
  }
  
 public void save_all_message() {
	  	  
	  List_message list_message = null;
	  ObjectOutputStream objectOutputStream = My_Object_IO.get_ObjectoutputStream(file_path,false);
	  
	  for(Main_message_Item item:all_item.values()) {
		  
		  list_message = item.get_list_message();
		  if(list_message==null) {continue;}
		  
		  try {
			objectOutputStream.writeObject(list_message);
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	  } // for
	  
	  try {
		objectOutputStream.flush();
	} catch (IOException e1) {
		// TODO AYouTu-generated catch block
		e1.printStackTrace();
	}
	  try {
		objectOutputStream.close();
	} catch (IOException e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
	  
	}
}
