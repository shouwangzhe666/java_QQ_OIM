package ss;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
import io.netty.handler.codec.LengthFieldPrepender;
import io.netty.handler.ssl.SslHandler;
import io.netty.handler.timeout.IdleStateHandler;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import tool_Frame.Warn_frame;
import tools.SslContextFactory;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLEngine;
import Frame.Main_Frame;
import Group_chat.Group_show_pane;
import Group_decoder.Group_Ping_Pong_decoder;
import Group_decoder.Group_chat_decoder;
import Group_decoder.Group_file_message_decoder;
import Group_decoder.Group_info_decoder;
import Group_decoder.Group_search_decoder;
import Group_encoder.Group_Ping_Pong_encoder;
import Group_encoder.Group_chat_encoder;
import Group_encoder.Group_file_message_encoder;
import Group_encoder.Group_info_encoder;
import Group_encoder.Group_search_encoder;
import Group_handle.Group_Ping_Pong_handle;
import Group_handle.Group_chat_handle;
import Group_handle.Group_file_message_handle;
import Group_handle.Group_info_handle;
import Group_handle.Group_search_handle;
import Main_thread.TelnetCheck_thread;
import Message.Group.Group_Ping_Pong;

public class Group_Chat_Client extends Thread{

	EventLoopGroup work_group = null;
	Bootstrap bootstrap = null;
	int group_account = 0;
	int connect_failed = 0 ;
   
    ScheduledThreadPoolExecutor execYouTur = null;
    ConcurrentLinkedQueue<Object> message_queue = null;
    InetAddress address = null;
    int port = 0;
    static volatile ChannelFuture future = null;
    volatile Channel channel ;
    
	public static HashMap<Integer,Group_Chat_Client> all_group_client = null;	
	static {
		
		all_group_client = new HashMap<>();
	}
	
	public Group_Chat_Client(int group_account,InetAddress address,int port) {
		
		this.group_account = group_account;
		this.address = address;
		this.port = port;
		message_queue = new ConcurrentLinkedQueue<>();
		execYouTur = new ScheduledThreadPoolExecutor(1);
		start_excYouTur();
		
	}
	
	@Override
	public void run() {
		
		start_client();
	}
	public void start_client() {
	
		 work_group = new NioEventLoopGroup();        
		
		 bootstrap = new Bootstrap();
		 bootstrap.group(work_group).channel(NioSocketChannel.class).option(ChannelOption.TCP_NODELAY, true).handler(new ChannelInitializer<Channel>() {

			@Override
			protected void initChannel(Channel channel) throws Exception {
			
				SSLEngine engine = SslContextFactory.get_client_sslContext().createSSLEngine();
				engine.setUseClientMode(true);
				engine.setNeedClientAuth(false);
				channel.pipeline().addFirst(new SslHandler(engine));
				
				channel.pipeline().addLast(new LengthFieldBasedFrameDecoder(1024*1024, 0, 4, 0, 4));
				channel.pipeline().addLast(new Group_Ping_Pong_decoder());
				channel.pipeline().addLast(new Group_chat_decoder());	
				channel.pipeline().addLast(new Group_info_decoder());
				channel.pipeline().addLast(new Group_file_message_decoder());		
			    	
				channel.pipeline().addLast(new LengthFieldPrepender(4));
				channel.pipeline().addLast(new Group_Ping_Pong_encoder());
				channel.pipeline().addLast(new Group_chat_encoder());	
				channel.pipeline().addLast(new Group_info_encoder());
				channel.pipeline().addLast(new Group_file_message_encoder());		
			     	
				channel.pipeline().addLast(new IdleStateHandler(1300, 600, 0, TimeUnit.SECONDS));
				channel.pipeline().addLast(new Group_Ping_Pong_handle(Group_Chat_Client.this,address,port));
				channel.pipeline().addLast(new Group_chat_handle(group_account));
				channel.pipeline().addLast(new Group_info_handle());
				channel.pipeline().addLast(new Group_file_message_handle());						
			}			
		});
		 
         Group_Chat_Client.all_group_client.put(group_account, this);
		 
		 re_connect(address, port);
		 
	}
	
	public void re_connect(InetAddress inetHost,int port) {
		
		if(connect_failed>20) {
			
			new Warn_frame("提示", "网络过于异常，请检查网络链路,\n并尝试重启！").set_aYouTu_click(5);
			new Timer().schedule(new TimerTask() {
				
				@Override
				public void run() {
					 System.out.println( future.cancel(true));
					 System.exit(0);					
				}
			}, 5000);
						
			return;}	
		
		 future = bootstrap.connect(inetHost, port);
		 future.addListener(new GenericFutureListener<Future<? super Void>>() {

			@Override
			public void operationComplete(Future<? super Void> arg0) throws Exception {
				
				if(future.isSuccess()) {
					
					System.out.println("连接成功！");
					connect_failed=0;
				
					channel = future.channel();						  			
					   
					   int native_account = Integer.parseInt(Main_Frame.getNative_count());
					  					  
					   send_group_message(new Group_Ping_Pong(native_account));
					   
					}
				else if(!future.isSuccess()) {
					
					connect_failed++;
					channel = null;
					
					future.channel().eventLoop().schedule(new Runnable() {
						
						@Override
						public void run() {
						
							System.out.println("群聊 第"+connect_failed+"连接失败,尝试重连。。。");					
							re_connect(inetHost, port);
							
						}
					}, 3, TimeUnit.SECONDS);
										
				}
			}
		});
		
	}	

	public static void send_message(int group_account,Object object) {
		
		Group_Chat_Client client = Group_Chat_Client.all_group_client.get(group_account);
		client.send_group_message(object);
	}
	
   private void send_group_message(Object object) {
		
		message_queue.add(object);
	}

	public void start_excYouTur() {
				
		execYouTur.scheduleWithFixedDelay(new Runnable() {
			
			@Override
			public void run() {
				
				Object object = message_queue.peek();		
				
				if(object==null||channel==null) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO AYouTu-generated catch block
						e.printStackTrace();
					}
					return;
				}
				
				if(!TelnetCheck_thread.isavisiable()) {
					new Warn_frame("提示", "网络异常，消息发送失败！").set_aYouTu_click(3);
					return;
				}
//				
				System.out.println(object.getClass());
				
				ChannelFuture future = channel.writeAndFlush(object);
				future.addListener(new GenericFutureListener<Future<? super Void>>() {

					@Override
					public void operationComplete(Future<? super Void> arg0) throws Exception {
					
						if(future.isSuccess()) {message_queue.remove();}
						else {System.out.println("group client 重发 message");}
					}
				});  //GenericFutureListener
			} // execYouTur run
		}, 0,1, TimeUnit.SECONDS);
	}
	
}
