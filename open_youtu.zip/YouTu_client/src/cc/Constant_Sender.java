package cc;

import java.awt.AWTException;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.color.ColorSpace;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowStateListener;
import java.awt.image.BufferedImage;
import java.awt.image.ColorConvertOp;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;

import com.sun.image.codec.jpeg.ImageFormatException;
import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageDecoder;
import com.sun.image.codec.jpeg.JPEGImageEncoder;
import com.sun.org.apache.xerces.internal.util.SynchronizedSymbolTable;

import VA_Pack_UDP.Audio_Chat;
import jna.GlobleKey;
import jna.GlobleKeyListioner;
import tcp_pack.TCP_P2P_Pointer;
import tool_Frame.Warn_frame;

public class Constant_Sender extends JFrame implements Runnable{

	JScrollPane jScrollPane=null;
	Show_pane show_pane=null;
	JLabel jLabel=null;
	Socket socket=null;
	DataInputStream dataInputStream = null;
	DataOutputStream dataOutputStream = null;
	JPEGImageDecoder decoder=null;
	GlobleKey globleKey =  null;
	
	java.awt.Image image=null;
	long bin=0l;
	InetAddress remote_inetAddress = null;
	int remote_port = 3322;
	int width = 0;
	int height = 0;
	volatile int frames = 0;
	int constant_x1 = -1;
	int constant_x2 = -1;
	int constant_y1 = -1;
	int constant_y2 = -1;
	int p2p_type = 1;
	int server_port = 0;
	/**
	 * event type:
	 * type=1 mouse move
	 * type=2 mouse drag
	 * type=3 mouse press
	 * type=4 mouse wheel
	 * type=5 key press
	 * 
	 * @param remote_ip
	 * @param remote_screen_width
	 * @param remote_screen_height
	 */
	public Constant_Sender(int p2p_type,int server_port) {
		this.p2p_type = p2p_type;
		this.server_port = server_port;
		setTitle("控制端");		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);		
		
	}
	
@Override
 public void run() {
	
	if(p2p_type==1||p2p_type==2) {
		  TCP_P2P_Pointer p2p_Pointer = new TCP_P2P_Pointer("TCP_Pointer", server_port);
		  p2p_Pointer.start();
		  socket = p2p_Pointer.get_socket(60);
		}
		else if(p2p_type==3) {
			try {
				socket = new Socket(InetAddress.getByName("115.28.186.188"), server_port);
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	 if(socket==null) {
		 Audio_Chat.ReleaseVAOccupy();
		 new Warn_frame("提示", "远程桌面连接异常").set_aYouTu_click(5);				
		 return;
	 }
	 else {System.out.println("远程连接成功！");}
//	try {
//		socket = new Socket(InetAddress.getByName("192.168.31.247"),10000);
//	} catch (UnknownHostException e1) {
//		// TODO AYouTu-generated catch block
//		e1.printStackTrace();
//	} catch (IOException e1) {
//		// TODO AYouTu-generated catch block
//		e1.printStackTrace();
//	}
	
	 try {
		    get_SizeData();	
			BufferedImage bufferedImage = get_FirstImage();
			Init_componets(bufferedImage);
	} catch (Exception e) {
		e.printStackTrace();
		close_constant();
	}
	
	Init_Frame();
	
    Init_listioner();
	new Receive_iamge().start();
	System.out.println("new Receive_iamge().start();");
//	new Caculate_FrameRate().start();
	}
public void Init_Frame() {
	
	Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	int w = (int) dimension.getWidth();
	int h = (int) dimension.getHeight();
	
	if(width>w&&height>h) { 
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		constant_x1 = w-30;
		constant_y1 = h-90;
		constant_x2 = width-w+30;
		constant_y2 = height-h+90;
	}
	else {
		setBounds(0, 0, width+50, height+50);
		addWindowStateListener(new WindowStateListener() {
			
			@Override
			public void windowStateChanged(WindowEvent e) {
			     if(e.getNewState()==WindowEvent.RESERVED_ID_MAX) {
			    	 setBounds(0, 0, width, height);
			     }
			}
		});
	}
	
	addWindowListener(new WindowAdapter() {
		@Override
		public void windowClosing(WindowEvent e) {
			close_constant();
		}
	});
	Container container = getContentPane();
	
	  container.remove(jScrollPane);	  
	  container.add(jScrollPane);
	  
	  container.invalidate();
	  container.repaint();
	  container.setVisible(true);
	  
	  setVisible(true);
}
public void close_constant() {
	
	 Audio_Chat.ReleaseVAOccupy();
	 
	try {
		 dataOutputStream.close();
		 dataInputStream.close();
		 if(!socket.isClosed()) {socket.close();}
		 
		 globleKey.stopListion();
		 dispose();
	} catch (Exception e) {
		// TODO AYouTu-generated catch block
		e.printStackTrace();
	}
}
public void Init_componets(BufferedImage bufferedImage) {
	
	   Container container=getContentPane();
       jLabel = new JLabel();
		
        show_pane = new Show_pane(bufferedImage);
        show_pane.setPreferredSize(new Dimension(width,height));
        show_pane.setMaximumSize(new Dimension(width,height));
		
		jScrollPane = new JScrollPane(show_pane);
		
		container.add(jScrollPane);
		
	}
public void get_SizeData() throws Exception{
	
		dataInputStream = new DataInputStream(socket.getInputStream());
		dataOutputStream = new DataOutputStream(socket.getOutputStream());
		
		GlobleKeyListioner keyListioner = new GlobleKeyListioner(dataOutputStream);
		globleKey = new GlobleKey(keyListioner);
	
		 width = dataInputStream.readInt();
		 height = dataInputStream.readInt();
		 System.out.println("width="+width+" ,height="+height);
	
}
public BufferedImage get_FirstImage() throws Exception{
	 
	 BufferedImage bufferedImage = null;
	  
		int len = dataInputStream.readInt();
		byte[] by = new byte[len];
		dataInputStream.readFully(by);
		
		try {
			bufferedImage = decode_Image(by);
		} catch (Exception e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
	
	return bufferedImage;
}
public BufferedImage decode_Image(byte[] by) throws Exception{
	
	ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(by);
	JPEGImageDecoder decoder = JPEGCodec.createJPEGDecoder(byteArrayInputStream);
	BufferedImage bufferedImage=null;
	
	bufferedImage = decoder.decodeAsBufferedImage();
	
	return bufferedImage;
}

public void Init_listioner() {
	
	show_pane.addMouseMotionListener(new MouseMotionListener() {
			
			@Override
			public void mouseMoved(MouseEvent e) {
				 int x = e.getX();
				 int y = e.getY();
				 
			        write_MouseMoveEvent(x,y);
			        
			        if(x>constant_x1&&x<constant_x1+10) {jScrollPane.getHorizontalScrollBar().setValue(jScrollPane.getHorizontalScrollBar().getMaximum());}
			        if(x<constant_x2&&x>constant_x2-10) {jScrollPane.getHorizontalScrollBar().setValue(0);}
			        if(y>constant_y1&&y<constant_y1+10) {jScrollPane.getVerticalScrollBar().setValue(jScrollPane.getVerticalScrollBar().getMaximum());}
			        if(y<constant_y2&&y>constant_y2-10) {jScrollPane.getVerticalScrollBar().setValue(0);}
			}
			
			@Override
			public void mouseDragged(MouseEvent e) {
//				drag_value++;
//				if(drag_value==10) {
//					drag_value = 0;
//					write_MouseMoveEvent(e.getX(),e.getY());
//				}
				  write_MouseMoveEvent(e.getX(),e.getY());
			}
		});
	show_pane.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
				write_MousePressReleasedEvent(2, e.getButton());
			}
			@Override
			public void mouseReleased(MouseEvent e) {
				
				write_MousePressReleasedEvent(3, e.getButton());
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				globleKey.startListion();
			}
			@Override
			public void mouseExited(MouseEvent e) {
				globleKey.stopListion();
			}
		});
		
	show_pane.addMouseWheelListener(new MouseWheelListener() {
			
		@Override
		public void mouseWheelMoved(MouseWheelEvent e) {
			write_mouseWheelEvent(e.getWheelRotation());
		}
		});
		
	}
	public void write_MouseMoveEvent(int x,int y) {
		try {
			dataOutputStream.writeByte(1);
			dataOutputStream.writeShort(x);
			dataOutputStream.writeShort(y);
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}		
	}
	public void write_MousePressReleasedEvent(int MouseType,int button) {
		try {
			dataOutputStream.writeByte(MouseType);
			dataOutputStream.writeShort(button);
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}	
	}
	public void write_mouseWheelEvent(int mouseValue) {
		try {
			dataOutputStream.writeByte(4);
			dataOutputStream.writeShort(mouseValue);
		} catch (IOException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}		
	}
	
	private class Receive_iamge extends Thread {
		
	 int x = 0;
	 int y = 0;
	 int len = 0;
	 byte[] by = null;
	 BufferedImage bufferedImage = null;
	 
	 @Override
		public void run() {
		
				 try {
					 while(true) {
					    read_Image();		
						frames++;
					  }
				} catch (Exception e) {
					e.printStackTrace();
				}
				 
					close_constant();
					System.out.println("远程退出！");								    			
		}

	public void read_Image() throws Exception{
					
				int x = dataInputStream.readShort();
				int y = dataInputStream.readShort();
			
				len = dataInputStream.readInt();

				by = new byte[len];
				dataInputStream.readFully(by);
				
				bufferedImage = decode_Image(by);
				
				show_pane.paint_Image(x, y, bufferedImage);

	}	
}
	private class Show_pane extends JPanel{
		
		 BufferedImage bufferedImage = null;

		 public Show_pane(BufferedImage bufferedImage) {
			 this.bufferedImage = bufferedImage;
		}
		
		public void paint_Image(int x,int y,BufferedImage bufferedImage) {
		
          //     System.out.println(x+","+y);
		       this.bufferedImage.createGraphics().drawImage(bufferedImage, x, y, null);
		       repaint();
		     
		}
		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
		   g.drawImage(bufferedImage,0,0, null);  // Read_Image 
		 
		}
	}
	
	private class Caculate_FrameRate extends Thread{
		
		int temp_frame = 0;
		
	   @Override
	public void run() {
		while(true) {
			temp_frame = frames;
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
			System.out.println("FrameRate: "+(frames-temp_frame));
		}
	}
	}
	public static void test() {
		Robot robot = null;
		Rectangle rectangle1 = null;
		Rectangle rectangle2 = null;
		try {
			 robot = new Robot();
		} catch (AWTException e) {
			// TODO AYouTu-generated catch block
			e.printStackTrace();
		}
		rectangle1 = new Rectangle(1920, 1080);
		rectangle2 = new Rectangle(0,1080-40, 1920, 40);
		
		BufferedImage bufferedImage1 = robot.createScreenCapture(rectangle1);
		BufferedImage bufferedImage2 = new BufferedImage(1920,1080,BufferedImage.TYPE_4BYTE_ABGR);
		
		long time = System.currentTimeMillis();
		bufferedImage2.getGraphics().drawImage(bufferedImage1, 0, 0, null);
		System.out.println(System.currentTimeMillis()-time);
		
	}
 public static void main(String[] args) {
//	 test();
	 
	//118.190.134.102
	//192.168.31.203
//	 Socket socket = null;
//	 try {
//		socket = new Socket(InetAddress.getByName("115.28.186.188"),3322);
//	} catch (UnknownHostException e) {
//		// TODO AYouTu-generated catch block
//		e.printStackTrace();
//	} catch (IOException e) {
//		// TODO AYouTu-generated catch block
//		e.printStackTrace();
//	}
//	 Scanner scanner = new Scanner(System.in);
//	
//	 System.out.println("server port: ");
//	 int server_port1 = scanner.nextInt();
//	 
//	 long time = System.currentTimeMillis();
//	  
//	 TCP_P2P_Pointer p2p_Pointer = new TCP_P2P_Pointer("TCP_Pointer", server_port1);
//	 p2p_Pointer.start();
//	 Socket socket = p2p_Pointer.get_socket(60);
	 
	 new Thread(new Constant_Sender(1,10000)).start();
	// java libjpeg-turbo  jpeg encoder library
	
}

}
