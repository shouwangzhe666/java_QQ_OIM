package Main_frame_group;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JPopupMenu;
import Frame.Chat_frame;
import Frame.Group_info_frame;
import Frame.Look_info_frame;
import Frame.Main_Frame;
import Main_frame_Item.Main_JMenu;
import Main_frame_Item.Main_JMenuItem;
import Message.Group.Group_chat_message;
import Message.Group.Group_info_message;
import Message.Group.Group_search_message;
import Message.Private.Link_info;
import Message.Private.Link_set;
import chat_frame_pane.Group_chat_pane;
import custom_component.Box_pane;
import ss.Group_Chat_Client;
import ss.Private_Chat_Client;
import tool_Frame.TextFild_Frame;
import tools.Icon_tools;

class Group_Item extends Box_pane implements ActionListener{
    
	Link_info link_info = null;
	String link_count = null;
	Image image = null;
	ImageIcon imageIcon = null;

	String name = null;
	String signature = null;
	String inform_type = null;
    String state = null;
    String group = null;
    String []group_names = null; 
	boolean enter = false;
	
	JPopupMenu popupMenu = null;
	Main_JMenuItem send_item = null;
	Main_JMenuItem info_item = null;
	Main_JMenuItem remark_item = null;
	Main_JMenuItem group_remark_item = null;
	Main_JMenu set_menu = null;
	Main_JMenu group_menu = null;
	Main_inform_RadioItem accept_remaind_item = null;
	Main_inform_RadioItem accept_item = null;
	Main_inform_RadioItem block_item = null;	
	Main_JMenuItem delete_item = null;
	
	Look_info_frame look_info_frame = null;
	
	TextFild_Frame remark_Frame = null;
	TextFild_Frame group_remark_Frame = null;
	Cursor cursor = null;
	Color focus_color = null;
	
public Group_Item(Link_info link_info) {
         super(BoxLayout.X_AXIS);
         setOpaque(false);
         Init_content(link_info);
		 Init_pane_listioner();
		
	}

public void Init_content(Link_info link_info) {
	
	cursor = new Cursor(Cursor.DEFAULT_CURSOR);
	focus_color = new Color(160, 160, 160);
	this.link_info = link_info;
	this.link_count = link_info.getLink_count();
	this.name = link_info.getRemark();
	this.signature = link_info.getSignature();
	this.group  = link_info.getGroup();
	this.group_names = link_info.getGroup_names();
    this.inform_type = link_info.getInform_type();
    this.state  = link_info.getState();
    this.image = Icon_tools.get_client_head_image(link_count);
    
    System.out.println("Init friend_item group_names: ");
    for(int i=0;i<group_names.length;i++) {
    	System.out.print(group_names[i]+",");
    }
    setPreferredSize(new Dimension(280, 60));
	setMinimumSize(new Dimension(260, 60));
	setMaximumSize(new Dimension(595, 60));
}
public void Init_component() {
	
	 popupMenu = new JPopupMenu();
//	 popupMenu.setBackground(Color.white);
     
     send_item = new Main_JMenuItem("发送消息",null);
     info_item = new Main_JMenuItem("查看资料",null);
     remark_item = new Main_JMenuItem( "修改备注",null);
     group_remark_item = new Main_JMenuItem("修改昵称", null);
     set_menu  = new Main_JMenu("设置权限");
     group_menu = new Main_JMenu("移动分组");   
     delete_item = new Main_JMenuItem("退出群聊", null);
     
     popupMenu.add(send_item);
     popupMenu.add(info_item);
     popupMenu.add(remark_item);
     popupMenu.add(group_remark_item);
     popupMenu.add(set_menu);    
     popupMenu.add(group_menu);
     popupMenu.add(delete_item);
     
     accept_remaind_item = new Main_inform_RadioItem(group, link_count, "接收消息并提醒", inform_type);
     accept_item = new Main_inform_RadioItem(group, link_count, "接收消息但不提醒", inform_type);
     block_item = new Main_inform_RadioItem(group, link_count, "屏蔽消息", inform_type);
     
     set_menu.add(accept_remaind_item);
     set_menu.add(accept_item);
     set_menu.add(block_item);
     
     for(int i=0;i<group_names.length;i++) {
    	 
    	put_group(group_names[i]);
     }
     // popupMenu.updateUI();
}
public void Init_pane_listioner() {
	
	addMouseListener(new MouseAdapter() {
		@Override
		public void mousePressed(MouseEvent e) {
			if(e.getButton()==1&&e.getClickCount()==2) {open_chat_frame();}
			else if(e.getButton()==3) {
				Init_component();
				Init_item_listioner();
				popupMenu.show(Group_Item.this, e.getX(), e.getY());
			}
		}
		@Override
		public void mouseEntered(MouseEvent e) {
			enter = true;
			repaint();
		}
		@Override
		public void mouseExited(MouseEvent e) {
			enter = false;
			repaint();
		}
	});
}
public void Init_item_listioner() {
	
	send_item.addActionListener(this);
	info_item.addActionListener(this);
	remark_item.addActionListener(this);
	group_remark_item.addActionListener(this);
	set_menu.addActionListener(this);
	group_menu.addActionListener(this);
	delete_item.addActionListener(this);
}
public void Init_remark_Frame() {
	
	remark_Frame = new TextFild_Frame("修改备注名","请输入新备注名：");
	remark_Frame.alter_ActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String new_remark = remark_Frame.get_input_text();
				remark_Frame.dispose_frame();
				name = new_remark;
				link_info.setRemark(new_remark);
				repaint();
				
	    		if(new_remark.trim().trim().length()==0) {return;}	 
	    		
	    		Link_info link_account = Main_Frame.getMessage_pane().get_link_info(link_count);
	    		if(link_info==null) {return;}
	    		link_account.setRemark(new_remark);
	    		 
	    		Main_Frame.getMessage_pane().rename_remark(link_count, new_remark);
	    		
		        Link_set link_set = new Link_set(6);
		        link_set.setNative_count(Main_Frame.getNative_count());
		        link_set.setLink_account(link_count);
		        link_set.setNew_remark(new_remark);
		        Private_Chat_Client.send_message(link_set);
		   }
		});
}
public void Init_group_remark_Frame() {	
	
	group_remark_Frame = new TextFild_Frame("修改我的群昵称", "请输入你的新群昵称：");
	group_remark_Frame.alter_ActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
		
			String group_remark = group_remark_Frame.get_input_text();
			group_remark_Frame.dispose_frame();
			if(group_remark.length()==0||group_remark.length()>10) {return;}
			
			int group_account = Integer.parseInt(link_count);
			int member_account = Integer.parseInt(Main_Frame.getNative_count());
			Group_chat_message chat_message = new Group_chat_message(8, member_account, System.currentTimeMillis(), "id", group_remark, 0l);
			
			Group_chat_pane chat_pane = Chat_frame.get_Group_chat_jpane(group_account);
			chat_pane.update_native_remark(chat_message, false);
			Group_Chat_Client.send_message(group_account, chat_message);
		}
	});
}

public void put_group(String new_group_name) {
	
	 Main_group_Radio_Item group_item = new Main_group_Radio_Item(new_group_name, link_count, group.equals(new_group_name));
	 group_menu.add(group_item);
	 
}
public void put_new_group(String new_group_name) {
	 
	String[] temp_group = new String[group_names.length+1];
	
	for(int i=0;i<group_names.length;i++) {
		temp_group[i] = group_names[i];
	}
	temp_group[temp_group.length-1] = new_group_name;
	this.group_names = temp_group;
}
public void rename_group(String old_group,String new_group) {
	 
    if(old_group.equals(this.group)) {
    	
    	this.group = new_group;
    	Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_count);
    	link_info.setGroup(this.group);		    
    }
    
replace_array(group_names, old_group, new_group);
}
public void replace_array(String[] array,String oldValue,String newValue) {
int index = 0;

for(int i=0;i<array.length;i++) {
 if(array[i].equals(oldValue)) {index = i;}
}
array[index] = newValue;
}
public void delete_group(String delete_group,String new_group) {
	
	if(delete_group.equals(this.group)) {
		
		this.group = new_group;
		Link_info link_info = Main_Frame.getMessage_pane().get_link_info(link_count);
    	link_info.setGroup(this.group);			
	} // if  
	
	this.group_names = deleteArray_element(group_names, delete_group);
}
public String[] deleteArray_element(String[] array,String delete_value) {
  String[] temp_array = new String[array.length-1];
  int index = 0;
  
   for(int i=0;i<array.length;i++) {
	  if(!array[i].equals(delete_value)) {
		  temp_array[index] = array[i];
		  index++;
	  }
  }
  return temp_array;
}
public void open_chat_frame() {
	
	     Main_Frame.setCurrent_link_count(link_count);
		 Main_Frame.getMessage_pane().put_send_message_item(link_count);
		 
		 Main_Frame.update_pane(1);
		 Main_Frame.get_control_pane().click_message_button();
		 Chat_frame.put_select_Item(link_count);
		 
}

public void rename_group_name(String old_group,String new_group) {
  
	String[] groups = new String[group_names.length];
	String s = null;
	
	for(int i=0;i<group_names.length;i++) {
		
		s  = group_names[i];
		if(s.equals(old_group)) {
			
			groups[i] = new_group;
			continue;
		}
		
		groups[i] = group_names[i];
	}
	
}

public void update_selectedgroup(String new_group_name) {
	 this.group = new_group_name;
}
public void update_inform_type(String inform_type) {
	 this.inform_type = inform_type;
}
public void update_head_image(byte[] icon_bytes) {
	
	 this.image = new ImageIcon(icon_bytes).getImage();
	 repaint();
}

public void rename_remark(String remark) {
	
	this.name = remark;
	repaint();
}

	@Override
	protected void paintComponent(Graphics g) {	
		super.paintComponent(g);
		Graphics2D  g2 = (Graphics2D) g;
		
		if(enter){
			g2.setColor(focus_color);
			g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
			g2.fillRect(0, 0, 600, 60);
		}
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
		if(image!=null) {
		g2.drawImage(image, 10, 10, null);}
		
		if(name!=null) {
		g2.setColor(Color.RED);
		g2.setFont(new Font("宋体", Font.PLAIN, 18));
		g2.drawString(name, 60, 25);}
		
		if(signature!=null) {
		g2.setColor(Color.black);
		g2.setFont(new Font("Microsoft Yahei", Font.PLAIN, 14));
		g2.drawString(link_count, 60, 46);}
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
     if(e.getSource()==send_item) {
    	 open_chat_frame();
    	 popupMenu.removeAll();
		 popupMenu = null;
     }
	 else if(e.getSource()==info_item) {
		  
		  int current_account = Integer.parseInt(link_count);
		  
		  if(!Group_info_frame.is_init()) {new Group_info_frame();}
		  
		  Group_info_frame.set_visiable(true);
		  if(Group_info_frame.get_group_account()!=current_account) {
			  Group_info_message group_info_message = new Group_info_message(1, current_account);
			  Group_Chat_Client.send_message(current_account, group_info_message);
		  }
		  popupMenu.removeAll();
		  popupMenu = null;
	  } // if info
	 else if(e.getSource()==remark_item) {
		   Init_remark_Frame();
		   popupMenu.removeAll();
		   popupMenu = null;
	  } // remark_item
	 else if(e.getSource()==group_remark_item) {
		   Init_group_remark_Frame();
		   popupMenu.removeAll();
		   popupMenu = null;
	  } // remark_item
	 else if(e.getSource()==delete_item) {
		 
		 Main_Frame.getGroup_pane().remove_link_Item(link_count);
		 Main_Frame.getMessage_pane().remove_message_item(link_count);
		 Main_Frame.getMessage_pane().remove_link_man(link_count);
		 Chat_frame.remove_Item(link_count);
		 
		 Group_search_message search_message = new Group_search_message(7);
		 search_message.setGroup_account(link_count);
		 search_message.setNative_account(Main_Frame.getNative_count());
		 
		 Private_Chat_Client.send_message(search_message);
		 popupMenu.removeAll();
		 popupMenu = null;
	 }
	}
	
   } //friend_Item