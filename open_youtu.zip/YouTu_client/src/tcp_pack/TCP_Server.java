package tcp_pack;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

import javax.swing.JFrame;

public class TCP_Server {
	
	int local_port1 = 0;
	int local_port2 = 0;
	int remote_port1 = 0;
	int remote_port2 = 0;
	
	Listion_thread thread1 = null;
	Listion_thread thread2 = null;
	
	volatile boolean accept_over = false;
	Object sync = new Object();
	
public TCP_Server() {	
	// 默认优先IP4
	  System.setProperty("java.net.preferIPv4Stack", "true");
	  local_port1 = get_port();
	  local_port2 = get_port();
			
	  thread1 = new Listion_thread(1, local_port1);
	  thread2 = new Listion_thread(2, local_port2);
	  thread1.start();
	  thread2.start();
}

public boolean isConeType(int wait_second) {
	int second = 0;
	
	 synchronized (sync) {
	         while(!accept_over&&second++<wait_second) {
	        	 try {
					sync.wait(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	         }	
	}  // synchronized
	 
	 return remote_port1==remote_port2;
}
private class Listion_thread extends Thread{
	int num = 1;
	int server_port = 0;
	ServerSocket serverSocket = null;
	Socket socket = null;
	  public Listion_thread(int num,int server_port) {
		  this.num = num;
		  this.server_port = server_port;
	}
	  @Override
	public void run() {
		  try {
			serverSocket = new ServerSocket(server_port);
			socket = serverSocket.accept();
			
		 if(num==1) {remote_port1 = socket.getPort();}
		 else {remote_port2 = socket.getPort();}
		 
		 if(remote_port1!=0&&remote_port2!=0) {
			 synchronized (sync) {
			    accept_over = true;
			    sync.notify();
			 }}
		 
		  close();
		 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		  
	}
	public void close() {
		  try {
			  
			 if(socket!=null) {socket.close();}
			 serverSocket.close();
			 
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		  
	  }
   }
public int get_port() {
	  int port = 0;
	  try {
		DatagramSocket datagramSocket = new DatagramSocket();
		port = datagramSocket.getLocalPort();
		datagramSocket.close();
	} catch (SocketException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  return port;
}

 public int getLocal_port1() {
	return local_port1;
}

public int getLocal_port2() {
	return local_port2;
}

   public static void main(String[] args) {
	
	         new TCP_Server().toString();
	         System.out.println("TCP_Server org.libjpegturbo.turbojpeg...");
}
}
