package Group_decoder;

import java.io.UnsupportedEncodingException;
import java.util.List;

import Message.Group.Group_file_message;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;

public class Group_file_message_decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> list) throws Exception {
		buf.readerIndex(0);
		if(buf.readableBytes()==0) {return;}
		
		int protocol_code = buf.readInt();
		
		if(protocol_code==214) {
			Group_file_message file_message = decode(buf);
			System.out.println("Group_file_message_decoder type="+file_message.getType());
			list.add(file_message);
		}
		else {
			buf.retain();
			ctx.fireChannelRead(buf);
		}
	}

	public Group_file_message decode(ByteBuf buf) {
		
		    int type = buf.readInt();
			int request_account =  buf.readInt();
			int reply_account =  buf.readInt();
			long file_code =  buf.readLong();
			long file_lenth = buf.readLong();
			int tcp_type =  buf.readInt();
			int server_port =  buf.readInt();
			
			byte[] request_ip = null;
			byte[] reply_ip = null;
			byte[] file_name = null;
			
			request_ip = new byte[buf.readInt()];
			buf.readBytes(request_ip);
			reply_ip = new byte[buf.readInt()];
			buf.readBytes(reply_ip);
			file_name = new byte[buf.readInt()];
			buf.readBytes(file_name);
			
			Group_file_message file_message = null;
			try {
				 file_message = new Group_file_message(type, request_account, reply_account, file_code,file_lenth,tcp_type, server_port,new String(request_ip, "UTF-8"), new String(reply_ip, "UTF-8"), new String(file_name, "UTF-8"));
			} catch (UnsupportedEncodingException e) {
				// TODO AYouTu-generated catch block
				e.printStackTrace();
			}
			
			return file_message;
	}
}
