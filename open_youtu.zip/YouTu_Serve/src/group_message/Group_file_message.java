package group_message;

public class Group_file_message {
	 
	    int type = 1;
	   
		int request_account = 0;
		int reply_account = 0;
		long file_code = 0;	
		long file_lenth = 0;
		int tcp_type = 0;
		int server_port = 0;
		
		String request_ip = "";
		String reply_ip = "";
		String file_name = "";				
		
		public Group_file_message(int type, int request_account, int reply_account, long file_code, long file_lenth,
				int tcp_type, int server_port, String request_ip, String reply_ip, String file_name) {

			this.type = type;
			this.request_account = request_account;
			this.reply_account = reply_account;
			this.file_code = file_code;
			this.file_lenth = file_lenth;
			this.tcp_type = tcp_type;
			this.server_port = server_port;
			this.request_ip = request_ip;
			this.reply_ip = reply_ip;
			this.file_name = file_name;
		}
		public int getType() {
			return type;
		}
		public void setType(int type) {
			this.type = type;
		}
       public int getRequest_account() {
			return request_account;
		}
		public void setRequest_account(int request_account) {
			this.request_account = request_account;
		}
		public int getReply_account() {
			return reply_account;
		}
		public void setReply_account(int reply_account) {
			this.reply_account = reply_account;
		}
		public long getFile_code() {
			return file_code;
		}
		public void setFile_code(long file_code) {
			this.file_code = file_code;
		}
		public long getFile_lenth() {
			return file_lenth;
		}
		public void setFile_lenth(long file_lenth) {
			this.file_lenth = file_lenth;
		}
		public int getTcp_type() {
			return tcp_type;
		}
		public void setTcp_type(int tcp_type) {
			this.tcp_type = tcp_type;
		}
		public int getServer_port() {
			return server_port;
		}
		public void setServer_port(int server_port) {
			this.server_port = server_port;
		}
		public String getRequest_ip() {
			return request_ip;
		}
		public void setRequest_ip(String request_ip) {
			this.request_ip = request_ip;
		}
		public String getReply_ip() {
			return reply_ip;
		}
		public void setReply_ip(String reply_ip) {
			this.reply_ip = reply_ip;
		}
		public String getFile_name() {
			return file_name;
		}
		public void setFile_name(String file_name) {
			this.file_name = file_name;
		}
}
