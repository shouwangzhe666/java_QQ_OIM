package tcp_pack;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class TCP_P2P_Pointer extends Thread{
int server_port = 0;
ServerSocket serverSocket = null;
Socket socket = null;
byte[] by = null;
String addr = null;
String ip = null;
int port = 0;
int local_port = 0;
volatile int num = 0;
volatile boolean scuess1 = false;
volatile boolean scuess2 = false;
Object sync = null;

public TCP_P2P_Pointer(String message,int server_port) {
	// 默认优先IP4
	   System.setProperty("java.net.preferIPv4Stack", "true");
		
	 this.server_port = server_port;
	 sync = new Object();
	 try {
		by = message.getBytes("UTF-8");
	} catch (UnsupportedEncodingException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	// 115.28.186.188
	// 192.168.31.203
	 long time = System.currentTimeMillis();
	
	 time = System.currentTimeMillis()-time;
	 System.out.println("用时："+time);
	 
	
}
@Override
	public void run() {
	
	       try {
	    	 socket = new Socket(InetAddress.getByName("115.28.186.188"),server_port);
	    	 this.local_port = socket.getLocalPort();
	    	 
			 socket.getOutputStream().write(by, 0, by.length);
			 
			 by = new byte[1024];
		     int len = socket.getInputStream().read(by);
		     socket.close();
		     
		     addr = new String(by, "UTF-8");
		     addr = addr.trim().substring(1);
		     ip = addr.split(":")[0];
		     port = Integer.parseInt(addr.split(":")[1]);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	       System.out.println(ip.length());
		   System.out.println(ip+","+port);
			
		   // connect
		   connect();
		   
	} // run
public void connect() {
	
	   try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     
		      socket = new Socket();
		      try {
					socket.bind(new InetSocketAddress(InetAddress.getLocalHost(),local_port));
					socket.connect(new InetSocketAddress(ip,port),1450);
				} catch (IOException e1) {
					num++;
					e1.printStackTrace();
				}
				
				if(num>0) {
					num=0;
					try {
						socket.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					new Server_thread().start();
					new Check_thread().start();
				}
				else {
			   synchronized(sync) {
					scuess1=true;
					sync.notify();
			    }
			 }
}
private class Server_thread extends Thread{
	
	public Server_thread() {
		
		num = 0;
		
	    try {
			serverSocket = new ServerSocket(local_port);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	}
	@Override
		public void run() {
		
		System.out.println("wait connect...");
		
		       try {
				socket = serverSocket.accept();
			} catch (IOException e) {
				num++;
//				e.printStackTrace();
			}
		       if(num==0) {
		    	 synchronized(sync) {
		    	   scuess2=true;
		    	   sync.notify();
		    	 }}
		       
		       num = 0;
		}
}
private class Check_thread extends Thread{
	@Override
	public void run() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(!scuess2) {
			
			try {
				serverSocket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			connect();
			
	}  // if
 }
}
public Socket get_socket(int wait_seconds) {
	int s = 0;
	
	synchronized(sync) {
		while(!scuess1&&!scuess2) {
			try {
				sync.wait(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			s++;
			if(s>wait_seconds) {return null;}
		}
	}
	
	return socket;	
}

private static class Sender_thread extends Thread{
	DataOutputStream dataOutputStream = null;
	OutputStream outputStream = null;
	byte[] by = null;
	
	public Sender_thread(OutputStream outputStream) {
		System.out.println("Sender_thread");
		 this.dataOutputStream = new DataOutputStream(outputStream);
	//	 this.outputStream = outputStream;
		 try {
			this.by = "hello!".getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void run() {
	    while(true) {
	    //	System.out.println("send");
	    	try {
	    		dataOutputStream.writeInt(6);
	    		dataOutputStream.write(by, 0, by.length);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	}
}
private static class Recever_thread extends Thread{
    DataInputStream dataInputStream = null;
    InputStream inputStream = null;
	byte[] by = null;
	int len = 0;
	String string = null;
	
	public Recever_thread(InputStream inputStream) {
		this.dataInputStream = new DataInputStream(inputStream);
		// this.inputStream = inputStream;
		 by = new byte[1024];
	}
	@Override
	public void run() {
	    try {
			while(true) {
				len = dataInputStream.readInt();
				by = new byte[len];
				dataInputStream.readFully(by, 0, len);
				
				if(len==-1) {continue;}
				
				string = new String(by, "UTF-8");
				string = string.trim();
				System.out.println("recever: "+string);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

public static void main(String[] args) {
	
	 Scanner scanner = new Scanner(System.in);
	
	 System.out.println("server port: ");
	 int server_port1 = scanner.nextInt();
	 
	 long time = System.currentTimeMillis();
	  
	 TCP_P2P_Pointer p2p_Pointer = new TCP_P2P_Pointer("TCP_Pointer", server_port1);
	 p2p_Pointer.start();
	 Socket socket = p2p_Pointer.get_socket(60);
	 
	 if(socket!=null) {
		 System.out.println("socket scuess!");

		 			 try {
						 new Sender_thread(socket.getOutputStream()).start();
						 new Recever_thread(socket.getInputStream()).start();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
		 //          new Constant_Receive(socket);
			
	 }
	 else {System.err.println("connect failed !");}
	 System.out.println(System.currentTimeMillis()-time);
	 try {
		Thread.sleep(30000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
