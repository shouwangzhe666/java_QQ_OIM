
package private_message;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

public class Private_Chat_Message implements Serializable{

	private static final long serialVersionUID = 1L;
	
	
	int type = 1;
	int from_account = 0;
	int to_account = 0;
	long send_time = 0l;
	
	boolean online = false;
	boolean reply = false; 	
	long time_code = 0l;
	
	byte[] bytes = null;
	StyledDocument document=null;
	
	String file_path = null;
	
	
	public Private_Chat_Message(int type,int from_account,int to_account,long send_time) {
		
		this.type = type;
	    this.from_account = from_account;
	    this.to_account = to_account;
	    this.send_time = send_time;
		
	}

	public int getFrom_account() {
		return from_account;
	}

	public void setFrom_account(int from_account) {
		this.from_account = from_account;
	}

	public int getTo_account() {
		return to_account;
	}

	public void setTo_account(int to_account) {
		this.to_account = to_account;
	}

	public long getSend_time() {
		return send_time;
	}

	public void setSend_time(long send_time) {
		this.send_time = send_time;
	}

	
	public boolean isOnline() {
		return online;
	}

	public void setOnline(boolean online) {
		this.online = online;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public boolean isReply() {
		return reply;
	}

	public void setReply(boolean reply) {
		this.reply = reply;
	}

	public long getTime_code() {
		return time_code;
	}

	public void setTime_code(long time_code) {
		this.time_code = time_code;
	}

   public byte[] getBytes() {
		return bytes;
	}

	public void setBytes(byte[] bytes) {
		
		this.bytes = bytes;
	}

public void set_Icon(byte[] icon_bytes) {
		
	    ByteBuf buf = Unpooled.buffer(1024, 1024*2048);
		buf.writeInt(icon_bytes.length);
		buf.writeBytes(icon_bytes);
	
		this.bytes = new byte[buf.readableBytes()];
		buf.readBytes(this.bytes);
	}

	public ImageIcon get_Icon() {
		
		ByteBuf buf = Unpooled.copiedBuffer(bytes);
		buf.readerIndex(0);
		int len = buf.readInt();
		byte[] icon_bytes = new byte[len];
		buf.readBytes(icon_bytes);
		
		return new ImageIcon(icon_bytes);
	}
	
	public byte[] get_iconbytes() {
		
		ByteBuf buf = Unpooled.copiedBuffer(bytes);
		buf.readerIndex(0);
		int len = buf.readInt();
		byte[] icon_bytes = new byte[len];
		buf.readBytes(icon_bytes);
		
		return icon_bytes;
	}
	public void setDocument(StyledDocument document) {
		this.document = document;
		
		ByteBuf buf = Unpooled.buffer(1024, 1024*2048);
		String type="";
		String temp_text="";
		String text = "";
		byte[] text_bytes = null;
		byte[] icon_bytes = null;
		
		for(int i=0;i<document.getLength();i++) {
  		 
  		  type= document.getCharacterElement(i).getName();
  		 
  		if(type.equals("content")){
 			 
 			 try {
 				temp_text =document.getText(i, 1);
				} catch (BadLocationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
 			 
 			   text+=temp_text;
 			   
 			  // if up to the end of message 
 			  if(i==document.getLength()-1) {
 	  			  
 		  			try {
 						text_bytes = text.getBytes("UTF-8");
 					} catch (UnsupportedEncodingException e1) {
 						// TODO Auto-generated catch block
 						e1.printStackTrace();
 					}
 		  			
 		  			buf.writeShort(1);
 		  			buf.writeInt(text_bytes.length);
 		  			buf.writeBytes(text_bytes);
 		  			text = "";
 		  			
 		  			break;
 		  		  }
 		 } // if text
  		
  		else if(type.equals("icon")) {
  			 
  			// first to add text into the buf
  			
  			try {
				text_bytes = text.getBytes("UTF-8");
			} catch (UnsupportedEncodingException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
  			
  			buf.writeShort(1);
  			buf.writeInt(text_bytes.length);
  			buf.writeBytes(text_bytes);
  			text = "";
  			
  		// second to add icon_name into the buf
  			
  			 Icon icon =StyleConstants.getIcon(document.getCharacterElement(i).getAttributes());
   			 ImageIcon imageIcon =(ImageIcon) icon;
   			 
   		  String all_path=imageIcon.getDescription();
   		  int last_indext = all_path.lastIndexOf("/");
   		  String icon_name = all_path.substring(last_indext+1);
   		
  		  try {
  			icon_bytes = icon_name.getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  		  
   		  buf.writeShort(2);
   		  buf.writeInt(icon_bytes.length);
   		  buf.writeBytes(icon_bytes);
   		  
  		 } // if face_icon
  		 
   }// for循环
		
		this.bytes = new byte[buf.readableBytes()];
		buf.readBytes(this.bytes);
	}
	
	public StyledDocument getDocument() {
		
		JTextPane jTextPane = new JTextPane();
		StyledDocument styledDocument = jTextPane.getStyledDocument();
		
		short type = 1;
		int len = 0;
		byte[] bytes = null;
		String text = null;
		ImageIcon face_icon = null;
		
		ByteBuf buf = Unpooled.copiedBuffer(this.bytes);
		buf.readerIndex(0);
		
		while(buf.readableBytes()>0) {
			
			type = buf.readShort();
			len  = buf.readInt();
			
			bytes = new byte[len];
			buf.readBytes(bytes);
			
			try {
				text = new String(bytes,"UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if(type==1) {
				
				try {
					styledDocument.insertString(styledDocument.getLength(), text,null);
				} catch (BadLocationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}     // type=1
			else if(type==2){
				
				face_icon = new ImageIcon(getClass().getResource("/little_emoji/"+text));
				jTextPane.insertIcon(face_icon);
			}  // type=2
		}  // while
		
		return styledDocument;
	}
	
  public String get_popu_message() {
		
	  if(type==2) {return "图片";}
	  
		String popu_message = "";
		String type="";
		String text="";
		 
		for(int i=0;i<document.getLength();i++) {
  		 
  		  type= document.getCharacterElement(i).getName();
  		 
  		 
  		 if(type.equals("icon")) {
  			 
  			 popu_message+="[表情]";
  			 
  		 } // if
  		 
  		 else  if(type.equals("content")){
  			 
  			 try {
					text =document.getText(i, 1);
				} catch (BadLocationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
  			 
  			 popu_message+=text; 			 
  			 
  		 } // if
  		 	
   }// for循环
		
		return popu_message;
	}

  public String getFile_path() {
		return file_path;
	}

	public void setFile_path(String file_path) {
		this.file_path = file_path;
	}

}
