package database_generat;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.concurrent.SynchronousQueue;

import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;

import io.netty.channel.Channel;
import io.netty.channel.embedded.EmbeddedChannel;
import private_handle_pack.Ping_Pong_Handle;
import private_message.Link_set;

public class Login_generate {

	// 经实测，全部合格
	
	public static short login_check(Connection loginConnection,String account,String password) {
		
	//	if(!account_exist(account)) {type = 1;return type; }
		if(!check_account_password_online(loginConnection,account, password)) {return 2;}
	//	if(is_online(account)) {return 3;}
		
		return 0;
		
	}
	
	public static boolean put_new_user(String account,String password,String email) {
		Connection connection=Connection_Pool.get_login_connection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		String tb_name = "tb_"+account.subSequence(0, account.length()-2)+"00";
	    
	    String sql = "insert into "+tb_name+" values(?,?,?,?,?,?)";
	 
	    
	    try {
	    	connection.setAutoCommit(false);
	    	
	    	preparedStatement = connection.prepareStatement(sql);
	    	
	    	preparedStatement.setInt(1, Integer.parseInt(account));
	    	preparedStatement.setString(2,password);
	    	preparedStatement.setString(3, "0");
	    	preparedStatement.setString(4, "我在线上");
	    	preparedStatement.setString(5, email);
	    	preparedStatement.setString(6, "remoteip");
	    	
	    	preparedStatement.executeUpdate();
	    	
	    	connection.commit();
			
		} catch (Exception e) {
			
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return false;
		}
	    
	    Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
	    
	    return true;
	}
	
//	public static boolean account_exist(String account) {
//		   
//		Connection connection=Connection_Pool.get_login_connection();
//		PreparedStatement preparedStatement=null;
//		ResultSet resultSet = null;
//		
//		String tb_name = "tb_"+account.substring(0, 6);
//		String sql = "select account from "+tb_name+" where account=?";
//		try {
//			preparedStatement = connection.prepareStatement(sql);
//			preparedStatement.setInt(1,Integer.parseInt(account));
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		try {
//			resultSet = preparedStatement.executeQuery();
//		} catch (SQLException e) {
//			return false;
//		}
//		try {
//			if(resultSet.next()) {return true;}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		finally {
//			Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
//		}
//		return false;
//	}
	
	public static boolean check_account_password_online(Connection loginConnection,String account,String password) {
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
	    
		 String tb_name  = "tb_"+account.substring(0,account.length()-2)+"00";
	  
	      int ac = Integer.parseInt(account);
	      
	      String sql = "select account from "+tb_name+" where account =? and password =? and online=?";
		  
		   try {
				preparedStatement = loginConnection.prepareStatement(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   
		   try {
			preparedStatement.setInt(1,ac);
			preparedStatement.setString(2,password);
			preparedStatement.setString(3, "0");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		  
		   try {
			resultSet = preparedStatement.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		  
		   try {
			if(resultSet.next()) {return true;}
			else {return false;}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   
		return false;	      
	}
	
	public static boolean set_password(String account,String old_pass,String new_pass) {
		
		Connection connection=Connection_Pool.get_login_connection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
//		boolean right = check_password(account, old_pass);
//		
//		if(!right) {return false;}
	
		  String tb_name  = "tb_"+account.substring(0,account.length()-2)+"00";
	     
	      String sql = "update "+tb_name+" set password=? where account=? and password=?";
		 
		 
		  try {
			   connection.setAutoCommit(false);
			   
			   preparedStatement = connection.prepareStatement(sql);
			   preparedStatement.setString(1,new_pass);
			   preparedStatement.setInt(2,Integer.parseInt(account));
			   preparedStatement.setString(3,old_pass);
			   preparedStatement.executeUpdate();
				
			   connection.commit();
			  
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			return false;
		}
		  
		finally {
			       Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		}
		  
	    return true;   
	}
	
	public static String get_password(String account,String email) {
		Connection connection=Connection_Pool.get_login_connection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		String tb_name  = "tb_"+account.substring(0,account.length()-2)+"00";
	 
	    String sql = "select password from "+tb_name+" where account =? and email=?";
	  
		  
		   try {
				preparedStatement = connection.prepareStatement(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   
		   try {
			preparedStatement.setInt(1, Integer.parseInt(account));
		} catch (NumberFormatException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		   try {
			preparedStatement.setString(2, email);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		   try {
			resultSet = preparedStatement.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		 String password = null;
		 
		 try {
			if(resultSet.next()) {
				password = resultSet.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		
	       return password;
	}
public static boolean set_remoteip(Connection loginConnection,String account,String remoteip) {
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
	
		  String tb_name  = "tb_"+account.substring(0,account.length()-2)+"00";
	     
	      String sql = "update "+tb_name+" set remoteip=? where account=?";
		 
		 
		  try {
			  loginConnection.setAutoCommit(false);
			   
			   preparedStatement = loginConnection.prepareStatement(sql);
			   preparedStatement.setString(1,remoteip);
			   preparedStatement.setInt(2,Integer.parseInt(account));
			  
			   preparedStatement.executeUpdate();
				
			   loginConnection.commit();
			  
		} catch (Exception e) {
			try {
				loginConnection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			return false;
		}		
		  
	    return true;   
	}
	
	public static String get_remoteip(Connection loginConnection,String account) {
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		String tb_name  = "tb_"+account.substring(0,account.length()-2)+"00";
	 
	    String sql = "select remoteip from "+tb_name+" where account=?";
		  
		   try {
				preparedStatement = loginConnection.prepareStatement(sql);
				preparedStatement.setInt(1, Integer.parseInt(account));
				resultSet = preparedStatement.executeQuery();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  
		 String remoteip = null;
		 
		 try {
			if(resultSet.next()) {
				remoteip = resultSet.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	    return remoteip;
	}
	public static boolean set_online(String account,String online) {
		
		Connection login_connection = Connection_Pool.get_login_connection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		String tb_name  = "tb_"+account.substring(0,account.length()-2)+"00";
	     
	      String sql = "update "+tb_name+" set online=? where account=?";
	  
		     try {
		    	 login_connection.setAutoCommit(false);
		    	 
		    	 preparedStatement = login_connection.prepareStatement(sql);
					
				 preparedStatement.setString(1, online);
				 preparedStatement.setInt(2,Integer.parseInt(account));
				 preparedStatement.executeUpdate();
				 
				 login_connection.commit();
				
			} catch (Exception e) {
				try {
					login_connection.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		
				return false;
			}			
		     
		   return true;
	}
	
// public static boolean is_online(Connection login_connection,String account) {
//		
//		PreparedStatement preparedStatement=null;
//		ResultSet resultSet = null;
//		
//		String tb_name  = "tb_"+account.substring(0,account.length()-2)+"00";
//		
//	      String sql = "select online from "+tb_name+" where account =?";
//	  
//		  
//		   try {
//				preparedStatement = login_connection.prepareStatement(sql);
//			} catch (SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		   try {
//			preparedStatement.setInt(1,Integer.parseInt(account));
//		} catch (NumberFormatException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		} catch (SQLException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		   try {
//			resultSet = preparedStatement.executeQuery();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		  
//		 String re = null;
//		 
//		  try {
//			if(resultSet.next()) {
//				  re = resultSet.getString(1);
//			  }
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		  boolean online = re.equals("1")?true:false;
//		  
//		  Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
//	   
//	       return online;
//	}

//	public static boolean is_online(String account) {
//		
//		Connection connection=Connection_Pool.get_login_connection();
//		PreparedStatement preparedStatement=null;
//		ResultSet resultSet = null;
//		
//		String tb_name  = "tb_"+account.substring(0,account.length()-2)+"00";
//		
//	      String sql = "select online from "+tb_name+" where account =?";
//	  
//		  
//		   try {
//				preparedStatement = connection.prepareStatement(sql);
//			} catch (SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		   try {
//			preparedStatement.setInt(1,Integer.parseInt(account));
//		} catch (NumberFormatException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		} catch (SQLException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		   try {
//			resultSet = preparedStatement.executeQuery();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		  
//		 String re = null;
//		 
//		  try {
//			if(resultSet.next()) {
//				  re = resultSet.getString(1);
//			  }
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		  boolean online = re.equals("1")?true:false;
//		  
//		  Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
//	   
//	       return online;
//	}
	
	public static boolean set_email(String account,String new_email) {
		Connection connection=Connection_Pool.get_login_connection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		  String tb_name  = "tb_"+account.substring(0,account.length()-2)+"00";
		
	      String sql = "update "+tb_name+" set email=? where account=?";
	  
		 
		   try {
			   connection.setAutoCommit(false);
			   
			   preparedStatement = connection.prepareStatement(sql);
			   preparedStatement.setString(1, new_email);
			   preparedStatement.setInt(2,Integer.parseInt(account));
			   preparedStatement.executeUpdate();
			   
			   connection.commit();
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return false;
		}
			
		   Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
	       return true;
		
	}
	
	public static boolean set_state(String account,String state) {
		
		Connection login_connection = Connection_Pool.get_login_connection();
		PreparedStatement preparedStatement=null;
		
		String tb_name  = "tb_"+account.substring(0,account.length()-2)+"00";
			
	    String sql = "update "+tb_name+" set state=? where account=?";
	  		 
		   try {
			   login_connection.setAutoCommit(false);
			   
			   preparedStatement = login_connection.prepareStatement(sql);
			   preparedStatement.setString(1, state);
			   preparedStatement.setInt(2,Integer.parseInt(account));
			   preparedStatement.executeUpdate();
			   
			   login_connection.commit();
		} catch (Exception e) {
			try {
				login_connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			return false;
		}   
	     
	     return true;
	}
	
	public static String get_state(String account) {
		
		Connection connection=Connection_Pool.get_login_connection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		String tb_name  = "tb_"+account.substring(0,account.length()-2)+"00";
		
	      String sql = "select state from "+tb_name+" where account =?";
	  
		  
		   try {
				preparedStatement = connection.prepareStatement(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   try {
			preparedStatement.setInt(1,Integer.parseInt(account));
		} catch (NumberFormatException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		   try {
			resultSet = preparedStatement.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		 String state = null;
		 
		  try {
			if(resultSet.next()) {
				state = resultSet.getString(1);
			  }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		  Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		   
	       return state;
	}
	
	public static boolean Init_login_table(String tb_name) {
		
			Connection connection=Connection_Pool.get_login_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
		String sql = "create table "+tb_name+" as select * from tb_10000000 where account=1";		
		
		try {
			connection.setAutoCommit(false);
			
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.executeUpdate(sql);
			
			connection.commit();
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return false;
		}
		
		Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		
		return true;
	}
	
	public static void close_server() {
		
		Connection login_connection=Connection_Pool.get_login_connection();
		ArrayList<String> all_tables = Register_generate.get_all_tables();
		String login_table_name = null;
		
		for(int i=0;i<all_tables.size();i++) {
			login_table_name = all_tables.get(i);
			set_off_line(login_connection,login_table_name);
		}
		
		Connection_Pool.close_Resourse(login_connection, null, null);
	}
	
	public static void set_off_line(Connection login_connection,String login_table_name) {
		
		ArrayList<String> all_account = Login_generate.get_all_account(login_connection, login_table_name);
		String account = null;
		
		for(int i=0;i<all_account.size();i++) {
			account = all_account.get(i);
			force_off_line(login_connection, account);
		}
	}
	
	public static ArrayList<String> get_all_account(Connection login_connection,String login_table_name){
		
		ArrayList<String> all_account = new ArrayList<>();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
	   	      
	      String sql = "select account from "+login_table_name;
		  
		   try {
				preparedStatement = login_connection.prepareStatement(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  
		   try {
			resultSet = preparedStatement.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		   String account = null;
		  try {
			while(resultSet.next()) {
				  account = resultSet.getString(1);
				  all_account.add(account);
			  }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		  Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
		  return all_account;
		  
	}
	
	public static boolean force_off_line(Connection login_connection,String account) {
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		String tb_name  = "tb_"+account.substring(0,account.length()-2)+"00";
	     
	      String sql = "update "+tb_name+" set online='0' where account=?";
	  
		     try {
		    	 login_connection.setAutoCommit(false);
		    	 
		    	 preparedStatement = login_connection.prepareStatement(sql);
					
				 preparedStatement.setInt(1,Integer.parseInt(account));
				 preparedStatement.executeUpdate();
				 
				 login_connection.commit();
				
			} catch (Exception e) {
				try {
					login_connection.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				 Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
				return false;
			}			
		     Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
		     
	       return true;
	}
	 public static void main(String[] args) {
	  
	    new Login_generate();
		   
	}
}
