package database_generat;

import java.util.TimerTask;

public class Truncate_timer_task extends TimerTask{
    
	String group_account = null;
	
	public Truncate_timer_task(String group_account) {

        this.group_account = group_account;
	}
	
	@Override
	public void run() {
		
		Group_message_generate.truncate_timedOut_message(group_account);
		
	}

}
