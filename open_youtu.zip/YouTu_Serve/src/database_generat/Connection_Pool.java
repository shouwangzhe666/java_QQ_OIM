package database_generat;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.mchange.v2.log.ModifyLogLevel;

public class Connection_Pool {
	
	static ComboPooledDataSource default_datasourse = null;
	static ComboPooledDataSource db_login = null;
	static ComboPooledDataSource db_link_man = null;
	static ComboPooledDataSource db_off_message = null;
	static ComboPooledDataSource db_private_info = null;
	static ComboPooledDataSource db_group = null;
	static String login_table_sql = null;
	static String link_table_sql = null;
	static String off_table_sql = null;
	static String info_table_sql = null;
	static String group_restore_sql =null;
	
	static {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		login_table_sql = "CREATE TABLE `tb_10000000` (\r\n" + 
				"`account`  int(11) NOT NULL ,\r\n" + 
				"`password`  varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`online`  varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`state`  varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`email`  varchar(19) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, \r\n" + 
				"`remoteip`  varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL \r\n" + 
				")\r\n" + 
				"ENGINE=InnoDB\r\n" + 
				"DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci\r\n" + 
				"ROW_FORMAT=DYNAMIC";
		
		link_table_sql = "CREATE TABLE `tb_10000000` (\r\n" + 
				"`type`  int(11) NOT NULL ,\r\n" + 
				"`link_account`  int(11) NOT NULL ,\r\n" + 
				"`remark`  varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`signature`  varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ,\r\n" + 
				"`group_name`  varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`group_names`  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`inform_type`  varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '1' ,\r\n" + 
				"`state`  varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`id`  varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`ip_port`  varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`jion_time`  datetime NOT NULL ,\r\n" + 
				"`out_time`  datetime NOT NULL \r\n" + 
				")\r\n" + 
				"ENGINE=InnoDB\r\n" + 
				"DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci\r\n" + 
				"ROW_FORMAT=DYNAMIC";
		
		off_table_sql = "CREATE TABLE `tb_10000000` (\r\n" + 
				"`datetime`  datetime NOT NULL ,\r\n" + 
				"`type`  int(11) NULL DEFAULT NULL ,\r\n" + 
				"`from_account`  int(11) NOT NULL ,\r\n" + 
				"`content`  mediumblob NOT NULL \r\n" + 
				")\r\n" + 
				"ENGINE=InnoDB\r\n" + 
				"DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci\r\n" + 
				"ROW_FORMAT=DYNAMIC";
		
		info_table_sql = "CREATE TABLE `tb_10000000` (\r\n" + 
				"`account`  int(11) NOT NULL ,\r\n" + 
				"`head_icon`  varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`name`  varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`sex`  varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`birth`  varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`blood`  varchar(3) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`home`  varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`phone`  varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`email`  varchar(19) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`signature`  varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`state`  varchar(230) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL \r\n" + 
				")\r\n" + 
				"ENGINE=InnoDB\r\n" + 
				"DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci\r\n" + 
				"ROW_FORMAT=DYNAMIC";
		//tb_restore
		  group_restore_sql = "CREATE TABLE `tb_restore` (\r\n" + 
		  		"`account`  varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
		  		"`ip_port`  varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
		  		"`type`  varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL \r\n" + 
		  		")\r\n" + 
		  		"ENGINE=InnoDB\r\n" + 
		  		"DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci\r\n" + 
		  		"ROW_FORMAT=DYNAMIC";
		
		ModifyLogLevel.modifyInfoLevel(Level.ALL);
		
		default_datasourse = new ComboPooledDataSource();
		
		init_database("db_login");
		init_database("db_link_man");
		init_database("db_off_message");
		init_database("db_private_info");
		init_database("db_group");
		
		Init_test_table("db_login");
		Init_test_table("db_link_man");
		Init_test_table("db_off_message");
		Init_test_table("db_private_info");
		Init_test_table("db_group");
		
		db_login = new ComboPooledDataSource("db_login");		
		db_link_man = new ComboPooledDataSource("db_link_man");		
		db_off_message = new ComboPooledDataSource("db_off_message");
		db_private_info = new ComboPooledDataSource("db_private_info");
		db_group = new ComboPooledDataSource("db_group");
		
		Init_table("db_login","tb_10000000", login_table_sql);
		Init_table("db_link_man","tb_10000000",link_table_sql);
		Init_table("db_off_message","tb_10000000", off_table_sql);
		Init_table("db_private_info","tb_10000000", info_table_sql);
		Init_table("db_group", "tb_restore", group_restore_sql);
		Group_restore_generate.Init_first_data("115.28.186.188", "10000", "60000");
		
 }	

	public static Connection get_default_connection() {
		
		synchronized(default_datasourse) {
			try {
				return default_datasourse.getConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block		
				e.printStackTrace();
			}
		}
		return null;
	}
	
	public static Connection get_login_connection() {
		synchronized(db_login) {
			try {
				return db_login.getConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}
	public static Connection get_linkman_connection() {
		synchronized(db_link_man) {
			try {
				return db_link_man.getConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}
	public static Connection get_off_message_connection() {
		synchronized(db_off_message) {
			try {
				return db_off_message.getConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}
	public static Connection get_private_info_connection() {
		
		synchronized(db_private_info) {
			try {
				return db_private_info.getConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}
	
	public static Connection get_group_connection() {
		synchronized(db_group) {
			try {
				return db_group.getConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}
	
public static boolean is_DatabaseExist(String db_name) {
		
		Connection connection = get_default_connection();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		String sql = "SELECT CATALOG_NAME FROM schemata WHERE schema_name=?";
		
		try {
			preparedStatement = connection.prepareStatement(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			preparedStatement.setString(1, db_name);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        try {
			resultSet = preparedStatement.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        try {
			try {
				if(resultSet.next()) {return true;}
				else {return false;}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} finally {
			
			Connection_Pool.close_Resourse(connection, null, resultSet);
		}
        
		return false;		
	}

public static void init_database(String db_name) {
		
		if(!is_DatabaseExist(db_name)) {
			
			Connection connection=Connection_Pool.get_default_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			String sql =  " CREATE database "+db_name+" DEFAULT CHARACTER SET utf8";
			
			 try {
				preparedStatement = connection.prepareStatement(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 try {
				preparedStatement.execute();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		}   // if database exists
		
		return ;
	}

public static boolean is_TableExist(String db_name,String tb_name) {
		
		Connection connection=get_default_connection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
				
        String sql = "select * from TABLES where TABLE_SCHEMA='"+db_name+"' and `table_name` ='"+tb_name+"'";
		
		try {
			preparedStatement = connection.prepareStatement(sql);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			resultSet = preparedStatement.executeQuery();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			try {
				return resultSet.next();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} finally {
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		}
		return false;			
	}

public static void Init_table(String db_name,String tb_name,String create_tb_sql) {
	
	Connection connection = null;
	PreparedStatement preparedStatement=null;
	
	if(is_TableExist(db_name,tb_name)) {return;}
	
	if(db_name.equals("db_login")) {connection = get_login_connection();}
	else if(db_name.equals("db_link_man")) {connection = get_linkman_connection();}
	else if(db_name.equals("db_off_message")) {connection = get_off_message_connection();}
	else if(db_name.equals("db_private_info")) {connection = get_private_info_connection();}
	else if(db_name.equals("db_group")) {connection = get_group_connection();}
	
	try {
		preparedStatement = connection.prepareStatement(create_tb_sql);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		preparedStatement.executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	Connection_Pool.close_Resourse(connection, preparedStatement, null);
}
   
public static void Init_test_table(String db_name) {
	
	if(is_TableExist(db_name, "test_table")) {return;}
	Connection connection = null;
	PreparedStatement preparedStatement = null;
	String sql = "CREATE TABLE `test_table` (\r\n" + 
			"`a`  int(11) NULL DEFAULT NULL \r\n" + 
			")\r\n" + 
			"ENGINE=InnoDB\r\n" + 
			"DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci\r\n" + 
			"ROW_FORMAT=DYNAMIC";
	
	try {
		connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+db_name+"?useUnicode=true&characterEncoding=UTF-8&serverTimezone=GMT%2B8", "admin", "admin");
		preparedStatement = connection.prepareStatement(sql);
		preparedStatement.executeUpdate();
		connection.close();
		preparedStatement.close();
	} catch (SQLException e) {
	
		e.printStackTrace();
	}
	return;
}
	public static void close_Resourse(Connection connection,PreparedStatement preparedStatement,ResultSet resultSet) {
		
		try {
			if(connection!=null&&!connection.isClosed()) {connection.close();}
			if(preparedStatement!=null&&!preparedStatement.isClosed()) {preparedStatement.close();}
			if(resultSet!=null&&!resultSet.isClosed()) {resultSet.close();}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public static void main(String[] args) {
		 
	  new Connection_Pool();
	  System.out.println("over!");
	}
}
 