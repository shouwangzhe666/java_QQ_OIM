package serve;

import java.sql.Connection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLEngine;

import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;

import Group_decoder.Group_Ping_Pong_decoder;
import Group_decoder.Group_chat_decoder;
import Group_decoder.Group_file_message_decoder;
import Group_decoder.Group_info_decoder;
import Group_encoder.Group_Ping_Pong_encoder;
import Group_encoder.Group_chat_encoder;
import Group_encoder.Group_file_message_encoder;
import Group_encoder.Group_info_encoder;
import Group_handle.Group_Ping_Pong_handle;
import Group_handle.Group_chat_handle;
import Group_handle.Group_file_message_handle;
import Group_handle.Group_info_handle;
import MainThread_pack.GroupFile_Load_Handle;
import database_generat.Connection_Pool;
import database_generat.Group_message_generate;
import group_message.Group_chat_message;
import group_message.Group_file_message;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
import io.netty.handler.codec.LengthFieldPrepender;
import io.netty.handler.ssl.SslHandler;
import io.netty.handler.timeout.IdleStateHandler;
import tools.SslContextFactory;

public class Group_Chat_Serve {
	
	String group_account = null;
	int time_seconds = 0;
	volatile boolean all_shutup = false;
	volatile boolean temp_chat = false;
	
	Connection message_connection = null;
	ConcurrentLinkedQueue<Connection> connection_poor = null;
	
    ConcurrentLinkedQueue<Object> message_queue = null;
    ConcurrentLinkedQueue<byte[]> buf_queue = null;
    
	ScheduledThreadPoolExecutor message_executor = null;
	ConcurrentHashMap<Integer, Channel> all_users = null;	
	ConcurrentHashMap<String, GroupFile_Load_Handle> groupfile_handles = null;	
	PooledByteBufAllocator bufAllocator = null;
	
	public Group_Chat_Serve(String group_account) {
		
		this.group_account = group_account;
		
		message_connection = Connection_Pool.get_group_connection();
		connection_poor = new ConcurrentLinkedQueue<>();
		add_needed_connection();
		
		message_queue = new ConcurrentLinkedQueue<>();
		buf_queue = new ConcurrentLinkedQueue<>();
				
		message_executor = new ScheduledThreadPoolExecutor(1);
		all_users = new ConcurrentHashMap<>();
		groupfile_handles = new ConcurrentHashMap<>();
		bufAllocator = new PooledByteBufAllocator(false);
	}
	
	public boolean isAll_shutup() {
		return all_shutup;
	}
	public void setAll_shutup(boolean all_shutup) {
		this.all_shutup = all_shutup;
	}
	public boolean isTemp_chat() {
		return temp_chat;
	}
	public void setTemp_chat(boolean temp_chat) {
		this.temp_chat = temp_chat;
	}
	public ConcurrentHashMap<Integer, Channel> getAll_users() {
		return all_users;
	}

	public void setAll_users(ConcurrentHashMap<Integer, Channel> all_users) {
		this.all_users = all_users;
	}

	public Channel get_channel(int memeber_account) {
		
		return all_users.get(memeber_account);
	}
	public String get_group_account() {
		
		return group_account;
	}
	public void remove_GroupFile_Load_Handle(String key) {
		groupfile_handles.remove(key);
	}
	public void start_message_thread() {
		
		message_executor.scheduleWithFixedDelay(new Runnable() {
			
			@Override
			public void run() {
				
				//handle_group_message
				Object object = message_queue.poll();
				byte[] by = buf_queue.poll();
				
				if(object==null) {					
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					return;
				}				
							
			if(object instanceof Group_chat_message) {
				Group_chat_message chat_message = (Group_chat_message) object;
				Group_chat_handle.handle_group_message(group_account, Group_Chat_Serve.this, chat_message);
				
				// save_message					
				save_message(by, chat_message.getSend_time());
			}
			else if(object instanceof Group_file_message){
				Group_file_message file_message = (Group_file_message) object;
				
				 if(file_message.getType()==1) {
					 GroupFile_Load_Handle handle = new GroupFile_Load_Handle(Group_Chat_Serve.this, file_message);
					 String key = file_message.getRequest_account()+file_message.getFile_name();
					 groupfile_handles.put(key, handle);
					 
					 handle.start();
				 }
				 else if(file_message.getType()==2) {
					 String key = file_message.getRequest_account()+file_message.getFile_name();
					 GroupFile_Load_Handle handle = groupfile_handles.get(key);
					 if(handle==null) {System.out.println("GroupFile_Load_Handle==null");return;}
					 
					 handle.import_provider(file_message);	
					 System.out.println("handle.import_provider(file_message);	");
					 return;
				 }				
			}
				
				ByteBuf b = bufAllocator.directBuffer(1024, 5*1024*1024);
				b.writeBytes(by);
				
				for(Channel channel:all_users.values()) {
				
					ByteBuf buf = b.duplicate();
					buf.retain();
					channel.writeAndFlush(buf);		   
				}		
			}
		},1000, 500, TimeUnit.MILLISECONDS);
	}
	public void save_message(byte[] content,long send_time) {
		
		Connection connection = get_group_connection();
		Group_message_generate.put_group_message(connection, group_account,send_time, content);
		return_group_connection(connection);
	}
	public void add_needed_connection() {
		
		for(int i=0;i<3;i++) {
			Connection connection = Connection_Pool.get_group_connection();
			connection_poor.add(connection);
		}
	}
	
public Connection get_group_connection() {
	
	  Connection connection =  connection_poor.poll();
	  
		if(connection==null) {
			add_needed_connection();			
			return get_group_connection();
		}
	      
	      return connection;
	}
public void return_group_connection( Connection connection) {
	
	  connection_poor.offer(connection);
}
public void put_user(int member_account,Channel channel) {

	 all_users.put(member_account, channel);
	
	}
	
public void remove_user(int member_account) {
	
		all_users.remove(member_account);
	}

public void send_group_message(ByteBuf buf,Object message) {
	
	      byte[] by = new byte[buf.readableBytes()];
	      buf.readBytes(by);
	      buf_queue.offer(by);
	      message_queue.offer(message);
}

public void start_serve(int port) {
		
		EventLoopGroup boss_group = new NioEventLoopGroup(10);
		EventLoopGroup work_group = new NioEventLoopGroup(50);
		
		ServerBootstrap bootstrap = new ServerBootstrap();
		bootstrap.group(boss_group, work_group).channel(NioServerSocketChannel.class).option(ChannelOption.SO_BACKLOG, 100).childHandler(new ChannelInitializer<Channel>() {

			@Override
			protected void initChannel(Channel channel) throws Exception {
        
				SSLEngine engine = SslContextFactory.get_client_sslContext().createSSLEngine();
				engine.setUseClientMode(false);
				engine.setNeedClientAuth(true);
				channel.pipeline().addFirst(new SslHandler(engine));
				
				channel.pipeline().addLast(new LengthFieldBasedFrameDecoder(1024*1024, 0, 4, 0, 4));
				channel.pipeline().addLast(new Group_Ping_Pong_decoder());
				channel.pipeline().addLast(new Group_chat_decoder(Group_Chat_Serve.this));
				channel.pipeline().addLast(new Group_info_decoder());
				channel.pipeline().addLast(new Group_file_message_decoder(Group_Chat_Serve.this));		
			    	
				channel.pipeline().addLast(new LengthFieldPrepender(4));
				channel.pipeline().addLast(new Group_Ping_Pong_encoder());
				channel.pipeline().addLast(new Group_chat_encoder());           //  discarded
				channel.pipeline().addLast(new Group_info_encoder());
				channel.pipeline().addLast(new Group_file_message_encoder());		//  discarded
			     	
				channel.pipeline().addLast(new IdleStateHandler(1300, 600, 0, TimeUnit.SECONDS));
				channel.pipeline().addLast(new Group_Ping_Pong_handle(group_account,Group_Chat_Serve.this));
				channel.pipeline().addLast(new Group_info_handle());
	//			channel.pipeline().addLast(new Group_file_message_handle());	 // discarded，instead to use group deocder
				//group_chat_handle        // is there
			}
		});
		
		ChannelFuture future = null;
		try {
			 future = bootstrap.bind(port).sync();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 start_message_thread();         // start to transfer group_message
		
		 System.out.println("Group_server:"+group_account+" start !");
		 
		try {
			future.channel().closeFuture().sync();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	    boss_group.shutdownGracefully();
	    work_group.shutdownGracefully();
	}

public static void main(String[] args) {
	 
	 //    new Group_Chat_Serve("100000001").start_serve(3250);
	 ConcurrentLinkedQueue<ByteBuf> buf_queue = new ConcurrentLinkedQueue<>();
	 ByteBuf buf = Unpooled.copiedBuffer("sdfsdf".getBytes());

	 buf_queue.offer(buf);
	 buf = buf_queue.poll();
	 System.out.println(buf.readableBytes());
	 System.out.println(buf_queue.size());
}
}
