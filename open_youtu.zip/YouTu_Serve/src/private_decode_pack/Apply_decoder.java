package private_decode_pack;

import java.io.UnsupportedEncodingException;
import java.util.List;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import private_message.Apply_Message;

public class Apply_decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> list) throws Exception {
		buf.readerIndex(0);
		if(buf.readableBytes()==0) {
	//		System.out.println("client Link_info_decoder return;");
			return;}
		
		int protocol_code = buf.readInt();
		if(protocol_code>130&&protocol_code<138) {
			
			Apply_Message apply_Message = general_decode(protocol_code, buf);
			if(apply_Message.getProtocal_code()==131) {apply_Message = decode_fileType(apply_Message, buf);}
			
			list.add(apply_Message);
		} //if(Apply_Message)
		
		else {
			buf.retain();
			ctx.fireChannelRead(buf);
		}
	}
	public Apply_Message decode_fileType(Apply_Message apply_Message,ByteBuf buf) {
		byte[] file_name = null;
		
		long file_code = buf.readLong();
		int len = buf.readInt();
		file_name = new byte[len];
		buf.readBytes(file_name);
		long file_size = buf.readLong();
		long file_location = buf.readLong();
		
		apply_Message.setFile_code(file_code);
		try {
			apply_Message.setFile_name(new String(file_name, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		apply_Message.setFile_size(file_size);
		apply_Message.setFilebin_location(file_location);
		
		return apply_Message;
	}
	public Apply_Message general_decode(int protocol_code,ByteBuf buf) {
		byte[] request_ip = null;
		byte[] reply_ip = null;
		
		int type = buf.readInt();
		int from_account = buf.readInt();
		int to_account = buf.readInt();
		
		int p2p_type = buf.readInt();   
		int tcp_server_port = buf.readInt();   
		int udp_server_port1 = buf.readInt();   
		int udp_server_port2 = buf.readInt();   
		boolean accept = buf.readBoolean();
		
		request_ip = new byte[buf.readInt()];
		buf.readBytes(request_ip);
		reply_ip = new byte[buf.readInt()];
		buf.readBytes(reply_ip);
		
		Apply_Message apply_Message = null;
		try {
			apply_Message = new Apply_Message(protocol_code, type, from_account, to_account, p2p_type, tcp_server_port, udp_server_port1, udp_server_port2, accept,new String(request_ip, "UTF-8"),new String(reply_ip, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return apply_Message;
	}
}
