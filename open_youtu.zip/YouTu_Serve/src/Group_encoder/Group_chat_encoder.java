package Group_encoder;

import java.io.UnsupportedEncodingException;

import group_message.Group_chat_message;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

public class Group_chat_encoder extends MessageToByteEncoder<Group_chat_message>{
	
	@Override
	protected void encode(ChannelHandlerContext arg0, Group_chat_message chat_message, ByteBuf buf) throws Exception {
	
		   int type = chat_message.getType();
		   general_encode(chat_message, buf);
		  
		   if(type==1||type==2) {encode_type1_or2(chat_message, buf);}
		   else if(type==3) {encode_type3(chat_message, buf);}
		   else if(type==4) {encode_type4(chat_message, buf);}
		   else if(type==5) {encode_type5(chat_message, buf);}
		   else if(type==6) {encode_type6(chat_message, buf);}
		 //else if type==7 general_encode done already;
		   else if(type==8||type==9) {encode_type8_9(chat_message, buf);}
		   else if(type==10||type==11) {encode_type10_11(chat_message, buf);}
		   else if(type==12) {encode_type12(chat_message, buf);}
	}

	public void encode_type1_or2(Group_chat_message chat_message, ByteBuf buf) {
		
		byte[] content = chat_message.getBytes();				
		buf.writeInt(content.length);
		buf.writeBytes(content);
	}
public void encode_type3(Group_chat_message chat_message, ByteBuf buf) {
		
		buf.writeBoolean(chat_message.isSelf());
	}
public void encode_type4(Group_chat_message chat_message, ByteBuf buf) {
	
	buf.writeBoolean(chat_message.isOpen_shutup());
	buf.writeInt(chat_message.getShutup_minites());
}
public void encode_type5(Group_chat_message chat_message, ByteBuf buf) {
	
	buf.writeBoolean(chat_message.isSet_Administrator());

}
public void encode_type6(Group_chat_message chat_message, ByteBuf buf) {
	
	byte[] group_id = null;
	try {
		group_id = chat_message.getGroup_id().getBytes("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	buf.writeInt(group_id.length);
	buf.writeBytes(group_id);

}

public void encode_type8_9(Group_chat_message chat_message, ByteBuf buf) {
	
	byte[] group_remark = null;
	try {
		group_remark = chat_message.getGroup_remark().getBytes("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	buf.writeInt(group_remark.length);
	buf.writeBytes(group_remark);

}
public void encode_type10_11(Group_chat_message chat_message, ByteBuf buf) {
	
	byte[] icon_bytes = null;
	icon_bytes = chat_message.getIcon_bytes();

	buf.writeInt(icon_bytes.length);
	buf.writeBytes(icon_bytes);
}

public void encode_type12(Group_chat_message chat_message, ByteBuf buf) {

	buf.writeBoolean(chat_message.isAll_shutup());
	buf.writeBoolean(chat_message.isTemp_chat());
}
public void general_encode(Group_chat_message chat_message, ByteBuf buf) {
		
	byte[] group_id = null;
	byte[] group_remark = null;
	
	try {
		group_id = chat_message.getGroup_id().getBytes("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		group_remark = chat_message.getGroup_remark().getBytes("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
		buf.writeInt(211);
		
		buf.writeInt(chat_message.getType());
		buf.writeInt(chat_message.getMember_account());
		
		buf.writeInt(group_id.length);
		buf.writeBytes(group_id);
		
		buf.writeInt(group_remark.length);
		buf.writeBytes(group_remark);
		
		buf.writeLong(chat_message.getSend_time());
		buf.writeLong(chat_message.getTime_code());
		
		buf.writeBoolean(chat_message.isAite());
		buf.writeBoolean(chat_message.isReply());
	}
}
