package private_handle_pack;

import java.sql.Connection;
import java.util.ArrayList;
import database_generat.Connection_Pool;
import database_generat.Link_man_generate;
import database_generat.Login_generate;
import database_generat.Off_message_generage;
import database_generat.Private_info_generate;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import message_log_regis.*;
import private_message.Link_info;
import private_message.Private_info;
import tcp_pack.TCP_Server;
import tools.Icon_tools;
import tools.RedisUtill;
import tools.SendMailUtills;

public class Login_Pass_handle extends SimpleChannelInboundHandler<Login_pass_message>{
			 
	public Login_Pass_handle() {
	//	System.out.println("new Login_Pass_handle");
	}
	 @Override
	 protected void messageReceived(ChannelHandlerContext ctx, Login_pass_message login_pass_message) throws Exception {
	 
			int type = login_pass_message.getType();
			
			if(type==1) {handle_type1(ctx, login_pass_message);}      //登录
			else if(type==2) {handle_type2(ctx, login_pass_message);}  //找回密码
			else if(type==3) {handle_type3(ctx, login_pass_message);}  //修改密码
	 }
		
    public void handle_type1(ChannelHandlerContext ctx,Login_pass_message login_pass_message) {
		   
 //   	System.out.println("server 收到 login_message");
    	String account = login_pass_message.getAccount();
		String password = login_pass_message.getPassword();
		
		String ip = ctx.channel().remoteAddress().toString().substring(1);
		ip = ip.split(":")[0].trim();  // get the remote ip
		
		Connection loginConnection = Connection_Pool.get_login_connection();
		int type = Login_generate.login_check(loginConnection,account, password);
		String remote_ip = Login_generate.get_remoteip(loginConnection, account);
		if(!remote_ip.startsWith(ip)) {
			
			 TCP_Server tcp_Server = new TCP_Server();
			 int tcp_port1 = tcp_Server.getLocal_port1();
			 int tcp_port2 = tcp_Server.getLocal_port2();
			 
			 Login_pass_message login_pass_message2 = new Login_pass_message(tcp_port1, tcp_port2);
			 ctx.writeAndFlush(login_pass_message2);
			 
			 boolean isConeType = tcp_Server.isConeType(10);
			if(isConeType) {remote_ip = ip;}
			else {remote_ip = ip+"0000";}
			
			Login_generate.set_remoteip(loginConnection, account, remote_ip);
			Link_man_generate.update_related_LinkRemoteIP(account, remote_ip);
		}
		
		Connection_Pool.close_Resourse(loginConnection, null, null);
		
		if(type==0) {
//			RedisUtill.set_Account_IP(account, ip);
			System.out.println("登陆成功！");
			RedisUtill.set_IP_Info(ip, remote_ip);
			login_scuess(account,login_pass_message.isNativeImage_exist(),remote_ip,ctx);
		    System.out.println("登陆成功完成发送！");
		}
		else {
			System.out.println("登陆失败！");
			login_failed(ctx, type);
			
		}
	   }
    
    public void handle_type2(ChannelHandlerContext ctx,Login_pass_message login_pass_message) {
		   
    	String result = null;
    	String account = login_pass_message.getAccount();
    	String email = login_pass_message.getEmail();
    	String password = null;
    	
    	password = Login_generate.get_password(account, email);
    	
    	if(password==null) {result = "账号: "+account+"\n或邮箱："+email+"不正确，\n无法找回密码！";}
    	else {
    		 SendMailUtills.SendMail_WithQQ(email, "优兔即时通信", "账号: "+account+" 密码：\n"+password);
    		 result = "账号："+account+" 的密码已发送至\nqq邮箱： "+email+",\n请注意查收。";
    	}
    	
    	boolean scuess = password==null?false:true;
    	login_pass_message = new Login_pass_message(scuess, result);
    	login_pass_message.setResult_type(2);
    	
    	ctx.writeAndFlush(login_pass_message);    	
	   }
    
    public void handle_type3(ChannelHandlerContext ctx,Login_pass_message login_pass_message) {
	   
    	String result = null;
    	String account = login_pass_message.getAccount();
    	String password = login_pass_message.getPassword();
    	String new_password = login_pass_message.getNew_password();
    	
    	boolean scuess = Login_generate.set_password(account, password, new_password);
    	
    	if(!scuess) {result = "密码修改失败！\n账号："+account+"\n或密码："+password+"不正确";}
    	else {result = "密码修改成功！\n账号："+account+"的\n新密码："+new_password;}
    	
    	login_pass_message = new Login_pass_message(scuess, result);
    	login_pass_message.setResult_type(3);
    	
    	ctx.writeAndFlush(login_pass_message);
 }
    
	public void login_scuess(String account,boolean NativeImage_exist,String remote_ip,ChannelHandlerContext ctx) {
		
		// send the message of login scuess
		Login_pass_message login_pass_message = new Login_pass_message(true, "登陆成功！");
		login_pass_message.setType(4);
		login_pass_message.setResult_type(1);
		ctx.writeAndFlush(login_pass_message);
		
		Private_info private_info = Private_info_generate.get_info(account);
		byte[] icon_bytes = NativeImage_exist?new byte[0]:Icon_tools.get_Big_HeadIcon_Bytes(account);
		private_info.setType(1);
		private_info.set_icon_bytes(icon_bytes);
		private_info.setIp(remote_ip);
		
		ctx.writeAndFlush(private_info);
		
		 Ping_Pong_Handle.all_users.putIfAbsent(Integer.parseInt(account), ctx.channel());
  	     Login_generate.set_online(account, "1");	  
  	  
	//	System.out.println("服务端收到头像，联系人请求");
		  
		try {			
		
	 if(!NativeImage_exist) {
		// send all related link_man's head_image when receive message of head_icon request
		Link_info link_info = new Link_info(2);
		
		ArrayList<Integer> total_account = Link_man_generate.get_all_related_link_account(account);
		total_account.add(Integer.parseInt(account));  // add the native headIcon
		
		link_info.Init_respose_head_image(total_account);
		ctx.writeAndFlush(link_info);
	  }
		// send all related link_group
		Link_info link_info1 = new Link_info(4);
		link_info1.Init_all_link_group(account);
   	ctx.writeAndFlush(link_info1);	
		
		// send all related link_man		
		Link_info link_info2 = new Link_info(5);
		link_info2.Init_all_link_man(account);
		ctx.writeAndFlush(link_info2);				
		
		// send all Off_message
		ArrayList<byte[]> all_message = Off_message_generage.get_all_off_message(account);
		PooledByteBufAllocator pooledByteBufAllocator = new PooledByteBufAllocator();
		ByteBuf buf = null;
		byte[] by = null;
		
		for(int i=0;i<all_message.size();i++) {
			
			by = all_message.get(i);
			buf = pooledByteBufAllocator.heapBuffer(1024, 102400);
			buf.writeBytes(by);
			ctx.writeAndFlush(buf);
		}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
  public void login_failed(ChannelHandlerContext ctx,int type) {
		
	Login_pass_message login_pass_message = null;
	
	if(type==1||type==2) {login_pass_message = new Login_pass_message(false, "账号或密码错误！");}
	else if(type==3) {login_pass_message = new Login_pass_message(false, "该账号已登录！");}
	login_pass_message.setResult_type(1);
	
	ctx.writeAndFlush(login_pass_message);
	
	} 
}
