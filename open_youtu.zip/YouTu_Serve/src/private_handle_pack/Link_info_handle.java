package private_handle_pack;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import org.omg.CORBA.CTX_RESTRICT_SCOPE;

import database_generat.Connection_Pool;
import database_generat.Group_member_generate;
import database_generat.Link_man_generate;
import database_generat.Login_generate;
import database_generat.Off_message_generage;
import database_generat.Private_info_generate;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import private_encode_pack.Link_info_encoder;
import private_message.Link_info;
import private_message.Private_info;
import tools.Icon_tools;

public class Link_info_handle extends SimpleChannelInboundHandler<Link_info>{

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Link_info link_info) throws Exception {
		
		int type = link_info.getType();
		
		 if(type==1) {handle_type1(ctx, link_info);}
		 if(type==6) {handle_type6(ctx, link_info);}
		else if(type==8) {handle_type8(ctx, link_info);}
		else if(type==9) {handle_type9(ctx, link_info);}
		else if(type==10) {handle_type10(ctx, link_info);}
	}

 public void handle_type1(ChannelHandlerContext ctx, Link_info info) {
		// send all related group_member`s head_image when receive message of head_icon request
		
	try {
			
		int group_account = info.getGroup_account();
		Link_info link_info = new Link_info(2);
		
		ArrayList<Integer> own_account = info.get_own_image();
		ArrayList<Integer> total_account = Group_member_generate.get_member_account(String.valueOf(group_account));
		total_account.removeAll(own_account);
		
		link_info.Init_respose_head_image(total_account);
		ctx.writeAndFlush(link_info);
		System.out.println("link_info handle_type1");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void handle_type6(ChannelHandlerContext ctx, Link_info info) {
		
		// search the link_man
		String account = info.getAccount();
		byte[] icon_bytes = null;
		String name = null;
		String signature = null;
		Link_info link_info = new Link_info(7);
		
	    Private_info private_info = Private_info_generate.get_info(account);
		    
		if(private_info!=null) {
		    icon_bytes = Icon_tools.get_Small_HeadIcon_Bytes(account);
		    name = private_info.getName();
		    signature = private_info.getSignature();
		    
		    link_info.setAccount(account);
		    link_info.setHead_icon_bytes(icon_bytes);
		    link_info.setName(name);
		    link_info.setSignature(signature);
		    
		    ctx.writeAndFlush(link_info);
		}
		else {
			  link_info.setAccount(account);
			  link_info.setHead_icon_bytes(new byte[1]);
			  link_info.setName("");
			  link_info.setSignature("");
					    
			  ctx.writeAndFlush(link_info);
		}
	}
	public void handle_type8(ChannelHandlerContext ctx, Link_info info) {
		
		String account =  info.getAccount();
		String link_account = info.getLink_count();
		
		Link_man_generate.delete_blacklist(account, link_account);
		boolean is_blacklist = Link_man_generate.is_blacklist(link_account, account);
		if(is_blacklist) {info=null; return;}
		
		boolean online = Ping_Pong_Handle.all_users.get(Integer.parseInt(link_account))==null?false:true;
		
		if(online) {
			
			Ping_Pong_Handle.all_users.get(Integer.parseInt(link_account)).writeAndFlush(info);
		}
		else {
			ByteBuf buf = Unpooled.buffer(1024, 102400);
			new Link_info_encoder().encode_type8(info, buf);
			byte[] by = null;
			by = new byte[buf.readableBytes()];
			buf.readBytes(by);
			Off_message_generage.put_off_message(link_account, System.currentTimeMillis(), 8,Integer.parseInt(account), by);
		} //!online
		// 转发
	}
	
	public void handle_type9(ChannelHandlerContext ctx, Link_info info) {
		
		String account = info.getAccount();
		String link_account = info.getLink_count();
//		byte[] icon_bytes = info.getHead_icon_bytes();
//		String name = info.getName();
		
		boolean accept = info.isAccept();
		boolean online = Ping_Pong_Handle.all_users.get(Integer.parseInt(link_account))==null?false:true;  // link_man is onlise?
		
		if(accept) {
				
			ArrayList<ArrayList<String>> link_man_list = Link_man_generate.get_specified_link_man(account, link_account);
			if(link_man_list.size()>0) {return;}
			
				try {
				Connection loginConnetion = Connection_Pool.get_login_connection();
				String remoteIp1 = Login_generate.get_remoteip(loginConnetion, link_account);
				String remoteIp2 = Login_generate.get_remoteip(loginConnetion, account);
				Connection_Pool.close_Resourse(loginConnetion, null, null);
				
				Link_man_generate.put_link_man(account, link_account, "好友", remoteIp1,3742762088000l);
				Link_man_generate.put_link_man(link_account, account, "好友", remoteIp2,3742762088000l);
				
				Link_info link_info1 = new Link_info(2);
				link_info1.Init_specified_respose_head_image(link_account);
				
				Link_info link_info11 = new Link_info(5);				
				link_info11.Init_specified_link_man(account, link_account);
				
				
				ctx.writeAndFlush(link_info1);
				ctx.writeAndFlush(link_info11);
				ctx.writeAndFlush(info);	
				
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				if(online) {
					
					try {
											
					Link_info link_info2 = new Link_info(2);
					link_info2.Init_specified_respose_head_image(account);
					
					Link_info link_info22 = new Link_info(5);
					ArrayList<ArrayList<String>> all_link_man22 = Link_man_generate.get_specified_link_man(link_account, account);
					link_info22.setAll_link_man(all_link_man22);
					
					Channel channel = Ping_Pong_Handle.all_users.get(Integer.parseInt(link_account));
					
					channel.writeAndFlush(link_info2);
					channel.writeAndFlush(link_info22);
					info.setLink_count(account);
					channel.writeAndFlush(info);
						
					} catch (Exception e) {
						e.printStackTrace();
					}
				}   //if(online) 
				
				else {
					info.setLink_count(account);
					ByteBuf buf = Unpooled.buffer(1024, 102400);
					new Link_info_encoder().encode_type9(info,buf);
					byte[] by = new byte[buf.readableBytes()];
					buf.readBytes(by);
					Off_message_generage.put_off_message(link_account, System.currentTimeMillis(), 9, Integer.parseInt(account), by);
				} // off_line
			
		} //if(accept)
		
		else {
			if(online) { Ping_Pong_Handle.all_users.get(Integer.parseInt(link_account)).writeAndFlush(info);}
			else {
				ByteBuf buf = Unpooled.buffer(1024, 102400);
				new Link_info_encoder().encode_type9(info,buf);
				byte[] by = new byte[buf.readableBytes()];
				buf.readBytes(by);
				Off_message_generage.put_off_message(link_account, System.currentTimeMillis(), 9, Integer.parseInt(account), by);
			}
		} // if !accept
	}
	
	public void handle_type10(ChannelHandlerContext ctx, Link_info info) {
		// send all related group_member`s head_image when receive message of head_icon request
		
		try {
			
			int group_account = info.getGroup_account();
			Link_info link_info = new Link_info(2);
			
			ArrayList<Integer> total_account = Group_member_generate.get_member_account(String.valueOf(group_account));
			
			link_info.Init_respose_head_image(total_account);
			ctx.writeAndFlush(link_info);
			System.out.println("link_info_handle handle_type10");
			} catch (Exception e) {
				e.printStackTrace();
			}
		
	}
	public static void main(String[] args) {
		
		ByteBuf buf = Unpooled.buffer(1024, 102400);
		buf.writeInt(10);
		buf.writeBoolean(true);
		byte[] by = new byte[buf.readableBytes()];
		buf.readBytes(by);
		 
	//	buf.readerIndex(0);
		buf.clear();
		buf.writeBytes(by);
		System.out.println(buf.readInt());
		System.out.println(buf.readBoolean());
//		System.out.println(buf.readableBytes());
//		System.out.println(by.length);
	}
}
