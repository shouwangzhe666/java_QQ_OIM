package private_encode_pack;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import private_message.Private_Chat_Message;

public class Private_Chat_encoder extends MessageToByteEncoder<Private_Chat_Message>{

	@Override
	protected void encode(ChannelHandlerContext ctx, Private_Chat_Message chat_Message, ByteBuf buf) throws Exception {
		
		 int type = chat_Message.getType();
			
		    general_encode(chat_Message, buf);
	
		    if(type==1||type==2) {
		    	
			byte[] content = chat_Message.getBytes();				
			buf.writeInt(content.length);
			buf.writeBytes(content);
		    }
	}
	
	public void general_encode(Private_Chat_Message chat_Message, ByteBuf buf) {
		
		buf.writeInt(111);
		
		buf.writeInt(chat_Message.getType());
		buf.writeInt(chat_Message.getFrom_account());
		buf.writeInt(chat_Message.getTo_account());
		buf.writeLong(chat_Message.getSend_time());
		
		buf.writeBoolean(chat_Message.isOnline());
		buf.writeBoolean(chat_Message.isReply());
		buf.writeLong(chat_Message.getTime_code());
	}
}
