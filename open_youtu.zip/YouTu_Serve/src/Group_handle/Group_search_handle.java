package Group_handle;

import database_generat.Group_info_generate;
import database_generat.Group_member_generate;
import database_generat.Group_restore_generate;
import database_generat.Link_man_generate;
import group_message.Group_info_message;
import group_message.Group_search_message;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import private_message.Link_info;
import tools.Icon_tools;

public class Group_search_handle extends SimpleChannelInboundHandler<Group_search_message>{

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Group_search_message search_message) throws Exception {
	
		int type = search_message.getType();
		
		if(type==1) {handle_type1(ctx, search_message);}
		else if(type==3) {handle_type3(ctx, search_message);}
	//	else if(type==5) {handle_type5(search_message);}
	//	else if(type==6) {handle_type5(search_message);}
		else if(type==7) {handle_type7(search_message);}
	}

	public void handle_type1(ChannelHandlerContext ctx, Group_search_message search_message) {
		
		String group_type = search_message.getGroup_type();
		String group_name = search_message.getGroup_name();
		String group_ower_account = search_message.getGroup_ower_account();
		
		String group_account = Group_restore_generate.get_and_Init_new_group(group_type, group_name, group_ower_account);
		
		System.out.println("group_account="+group_account);
		
		boolean scuess = group_account==null?false:true;
		
		if(scuess) {
		
		// Init group's head_image
		Link_info link_info = new Link_info(2);
		link_info.Init_specified_respose_head_image(group_account);
		ctx.writeAndFlush(link_info);
		
		// Init the group link_man
		Link_info link_info2 = new Link_info(5);
		link_info2.Init_specified_link_man(group_ower_account, group_account);
		ctx.writeAndFlush(link_info2);	

		}
		
		// send the inform
		Group_search_message message = new Group_search_message(2);
		message.setScuess(scuess);
		message.setGroup_account(group_account);
		
		ctx.writeAndFlush(message);
	
	}
	
	public void handle_type3(ChannelHandlerContext ctx, Group_search_message search_message) {
		
		String group_account = search_message.getGroup_account();
		Group_info_message group_info_message = Group_info_generate.get_group_info(Integer.parseInt(group_account));
		
		Group_search_message message = new Group_search_message(4);
		message.setGroup_type(String.valueOf(group_info_message.getGroup_type()));
		message.setGroup_name(group_info_message.getGroup_name());           // 0 or 1 or 2
		message.setGroup_account(group_account);
		message.setPay_money(group_info_message.getPay_money());
		message.setQuestion(group_info_message.getQuestion());
		message.setAnswer(group_info_message.getAnswer());
		
		byte[] group_icon = Icon_tools.get_Small_HeadIcon_Bytes(group_account);
		message.setGroup_icon(group_icon);
		
		ctx.writeAndFlush(message);
	}
	
	public void handle_type7(Group_search_message search_message) {
		
		String group_account = search_message.getGroup_account();
		String native_account = search_message.getNative_account();
		
		Group_member_generate.delete_member(group_account, native_account);
		Link_man_generate.delete_link_man(native_account, group_account);
		
        //  inform all members of the group
	}
	
	public static void main(String[] args) {
		  
		String group_account = "100000001";
		String native_account = "10000001";
		
		Group_member_generate.delete_member(group_account, native_account);
		Link_man_generate.delete_link_man(native_account, group_account);
	}
}
