package tcp_pack;

// author: jiang quan feng
// date : 2020.01.11

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

public class TCP_P4P_Server extends Thread{
	ServerSocket serverSocket = null;
	Socket transfer_send_socket = null;
	Socket transfer_recever_socket = null;
	Socket send_socket = null;
	Socket receve_socket = null;
	
	String message = null;
	byte[] by = null;
	
	byte[] by1 = null;
	byte[] by2 = null;
	byte[] by3 = null;
	byte[] by4 = null;

	volatile boolean scuess = false;
    volatile int num = 0;
    int local_port = 0;
    
	public TCP_P4P_Server() {
		
		DatagramSocket datagramSocket=null;
		try {
			datagramSocket = new DatagramSocket();
		} catch (SocketException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		this.local_port  = datagramSocket.getLocalPort();
		datagramSocket.close();
		
		  by = new byte[1024];
		  by1 = new byte[1024];
		  by2 = new byte[1024];
		  by3 = new byte[1024];
		  by4 = new byte[1024];
		  
		   try {
			serverSocket = new ServerSocket(local_port);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   
		   new Test_thread().start();
	}
	
	public int get_server_port() {
		return local_port;
	}
	
	@Override
		public void run() {
	Socket socket = null;
	for(int i=0;i<4;i++) {
		  try {
			by = new byte[1024];
			socket = serverSocket.accept();
			socket.getInputStream().read(by);
			message = new String(by, "UTF-8");
			message = message.trim();
			
			if(message.equals("TCP_Transfer_Pointer_Sender")) {transfer_send_socket=socket;}
			else if(message.equals("TCP_Transfer_Pointer_Recever")) {transfer_recever_socket=socket;}
			else if(message.equals("TCP_Pointer")&&send_socket==null) {send_socket=socket;}
			else {receve_socket=socket;}

			scuess = true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} // for
	
	  try {
	
		by1 = transfer_send_socket.getRemoteSocketAddress().toString().getBytes("UTF-8");
		by2 = transfer_recever_socket.getRemoteSocketAddress().toString().getBytes("UTF-8");
		by3 = send_socket.getRemoteSocketAddress().toString().getBytes("UTF-8");
		by4 = receve_socket.getRemoteSocketAddress().toString().getBytes("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	  try {
		  transfer_send_socket.getOutputStream().write(by3, 0, by3.length);
		  transfer_recever_socket.getOutputStream().write(by4, 0, by4.length);
		  transfer_send_socket.close();
		  transfer_recever_socket.close();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		send_socket.getOutputStream().write(by1, 0, by1.length);
		receve_socket.getOutputStream().write(by2, 0, by2.length);
		send_socket.close();
		receve_socket.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
	private class Test_thread extends Thread{
		@Override
		public void run() {
			try {
				Thread.sleep(60000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(!scuess) {try {
				serverSocket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}}
		}
}
	
	public static void main(String[] args) {
		
		TCP_P4P_Server p4p_Server1 = new TCP_P4P_Server();
		p4p_Server1.start();
		int server_port = p4p_Server1.get_server_port();
		
		System.out.println("server_port: "+server_port);
	}
}
