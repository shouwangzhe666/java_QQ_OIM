package MainThread_pack;

import java.util.HashMap;
import group_message.Group_file_message;
import io.netty.channel.Channel;
import private_handle_pack.Ping_Pong_Handle;
import private_message.Apply_Message;
import serve.Group_Chat_Serve;
import tcp_pack.TCP_P2P_Server;
import tcp_pack.TCP_P4P_Server;

public class GroupFile_Load_Handle extends Thread{

	Group_Chat_Serve group_Chat_Serve = null;
	HashMap<Integer, Group_file_message> all_provider = null;
	Group_file_message request_fileMessage = null;
	String request_ip = null;
	int request_account = 0;
	String group_account = null;
	String groupFile_name = null;
	
	public GroupFile_Load_Handle(Group_Chat_Serve group_Chat_Serve,Group_file_message request_fileMessage) {
		
		this.all_provider = new HashMap<>();
		
		this.group_Chat_Serve = group_Chat_Serve;
		this.group_account = group_Chat_Serve.get_group_account();
				
		this.request_ip = request_fileMessage.getRequest_ip();
		this.request_account = request_fileMessage.getRequest_account();
		this.groupFile_name = request_fileMessage.getFile_name();
		this.request_fileMessage = request_fileMessage;
	}
	
	public void import_provider(Group_file_message file_message) {
		all_provider.put(file_message.getReply_account(), file_message);
	}
	
	@Override
	public void run() {
		
		     System.out.println("启动 GroupFile_Load_Handle");
		     
	        try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	        Group_file_message file_message = null;
	        
	        if((file_message=check_first())!=null) {handle_tcp1(file_message);}
	        else if((file_message=check_second())!=null) {handle_tcp2(file_message);}
	        else {System.out.println("handle_tcp3"); handle_tcp3(request_fileMessage);}
	        
	        String key = request_account+groupFile_name;
	        group_Chat_Serve.remove_GroupFile_Load_Handle(key);
	        System.out.println("group_file key: "+key);
	}
	
public Group_file_message check_first() {
		for(Group_file_message file_message:all_provider.values()) {
			if(!file_message.getReply_ip().equals(request_ip)) {
				return file_message;
			}
		}
		return null;
	}
public Group_file_message check_second() {
	for(Group_file_message file_message:all_provider.values()) {
		if(file_message.getReply_ip().equals(request_ip)) {
			return file_message;
		}
	}
	return null;
}
public void handle_tcp1(Group_file_message group_file_message) {
	
	int tcp_server_port = start_TCP_P2P_Server();
	
	group_file_message.setType(3);
	group_file_message.setTcp_type(1);
	group_file_message.setServer_port(tcp_server_port);
	Channel channel = group_Chat_Serve.get_channel(request_account);
	channel.writeAndFlush(group_file_message);
	System.out.println("handle_tcp1  write type3 request_account:　"+request_account+" channel==null? "+(channel==null));
	
	Group_file_message file_message = copy_GroupFileMessage(group_file_message);
	file_message.setType(4);
	channel = group_Chat_Serve.get_channel(file_message.getReply_account());
	channel.writeAndFlush(file_message);
	System.out.println("handle_tcp1  write type4 Reply_account():　"+file_message.getReply_account()+" channel==null? "+(channel==null));
}
public void handle_tcp2(Group_file_message group_file_message) {
	
	int tcp_server_port = start_TCP_P4P_Server(request_ip);
	
	group_file_message.setType(3);
	group_file_message.setTcp_type(2);
	group_file_message.setServer_port(tcp_server_port);
	group_Chat_Serve.get_channel(request_account).writeAndFlush(group_file_message);
	
	Group_file_message file_message = copy_GroupFileMessage(group_file_message);
	file_message.setType(4);
	group_Chat_Serve.get_channel(file_message.getReply_account()).writeAndFlush(file_message);
}
public void handle_tcp3(Group_file_message group_file_message) {
	
	GroupFile_load_server server = new GroupFile_load_server(Integer.parseInt(group_account), groupFile_name);
	server.start();
	int tcp_server_port = server.get_port();
	
	group_file_message.setType(3);
	group_file_message.setTcp_type(3);
	group_file_message.setServer_port(tcp_server_port);
	group_Chat_Serve.get_channel(request_account).writeAndFlush(group_file_message);
	System.out.println("已经启动群文件服务器开准备下载...");
}
public int start_TCP_P2P_Server() {
	
    TCP_P2P_Server p2p_Server = new TCP_P2P_Server();
	p2p_Server.start();
	int tcp_server_port = p2p_Server.get_server_port();
	
	return tcp_server_port;
}

public int start_TCP_P4P_Server(String request_ip) {
    TCP_P4P_Server p4p_Server = new TCP_P4P_Server();
	p4p_Server.start();
	int tcp_server_port = p4p_Server.get_server_port();
	
	Apply_Message apply_Message = new Apply_Message(136, 1, 1, 1, 1, tcp_server_port, 1, 1, true,"1","1");
	Channel channel = Ping_Pong_Handle.get_diffentChannel(request_ip);
	channel.writeAndFlush(apply_Message);
	
return tcp_server_port;
}
public Group_file_message copy_GroupFileMessage(Group_file_message group_file_message) {
	
	Group_file_message file_message = new Group_file_message(group_file_message.getType(), group_file_message.getRequest_account(), group_file_message.getReply_account(), group_file_message.getFile_code(), group_file_message.getFile_lenth(), group_file_message.getTcp_type(), group_file_message.getServer_port(), group_file_message.getRequest_ip(), group_file_message.getReply_ip(), group_file_message.getFile_name());			
	
	return file_message;
}
}
