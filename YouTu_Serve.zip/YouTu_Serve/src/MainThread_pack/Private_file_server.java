package MainThread_pack;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;

public class Private_file_server {

	int from_port = 10000;
	int to_port = 60000;
	int port = 0;
	boolean transfer = false;
	long file_pro = 0l;
	
	ServerSocket server = null;
	Timer timer = null;
	Accept_thread accept_thread = null;
	
	Socket accept_socket = null;
	Socket send_socket = null;
	DataInputStream dataInputStream =null;
	DataOutputStream dataOutputStream = null;
	
	public int get_and_start_server() {
		
		for(int i=from_port;i<to_port;i++) {
			
			try {
				server = new ServerSocket(i);
			} catch (IOException e) {
				continue;
			}
			
			accept_thread = new Accept_thread();
			accept_thread.start();
			
			timer = new Timer();
			timer.schedule(new Time_check(),30000);
		
			System.out.println("port: "+i);
			return i;
		}
		return 0;
	}  //get_new_port
	
	public boolean is_transfer() {
		
		return transfer;
	}
	
	public void stop_server() {
		
		transfer = false;
		
		try {
			server.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
		timer.cancel();
	}
	
	private class Accept_thread extends Thread{
		
		public Accept_thread() {
			
		}
		
		@Override
		public void run() {
			
			try {
				accept_socket = server.accept();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return;
			}
			
			try {
				dataOutputStream = new DataOutputStream(accept_socket.getOutputStream());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				send_socket = server.accept();
			} catch (IOException e) {
				e.printStackTrace();
				return;
			}
			try {
				dataInputStream = new DataInputStream(send_socket.getInputStream());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			// start tranfer file
			   transfer = true;
			   new File_transfer().start();
		} // run
	}
	
	private class File_transfer extends Thread{
		byte[] by = null;
		int len =0;
		
		public File_transfer() {
		     by = new byte[1024];
		}
		
		@Override
		public void run() {
			
			try {
				while((len=dataInputStream.read(by))!=-1) {
					
					dataOutputStream.write(by, 0, len);
			      
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  // while
			
			try {
								
				dataOutputStream.close();
				dataInputStream.close();
			
				transfer = false;
				server.close();
			
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} // run
	}
	
	private class Time_check extends TimerTask{

		@Override
		public void run() {
			
			if(!transfer) {stop_server();}
		} // run
		
	}
}
