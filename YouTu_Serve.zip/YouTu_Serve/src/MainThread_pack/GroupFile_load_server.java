package MainThread_pack;

// author: jiang quan feng
// date : 2020.01.11

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Timer;
import java.util.TimerTask;

public class GroupFile_load_server extends Thread{
	
	ServerSocket server = null;
	int group_account = 0;
	String file_name = null;
	int port = 0;
	boolean connect = false;
	Socket socket = null;
	File file = null;
	DataOutputStream dataOutputStream = null;
//	FileInputStream fileInputStream = null;
	RandomAccessFile read_file = null;
	
	public GroupFile_load_server(int group_account,String file_name) {
	    
         this.port = get_and_start_server();
		 
		String path = "D:\\UTO_server\\group_"+group_account+"\\file\\"+file_name;
		file = new File(path);
		try {
			read_file = new RandomAccessFile(file, "r");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		new Timer().schedule(new Time_check(),10000);  // ten seconds to wait
	}
private int get_and_start_server() {
		
		try {
			DatagramSocket datagramSocket = new DatagramSocket();
			this.port = datagramSocket.getLocalPort();
			datagramSocket.close();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			server = new ServerSocket(this.port);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this.port;
	}  //get_new_port
	
	public int get_port() {
		return this.port;
	}
	
	@Override
	public void run() {
	
		if(this.port==0) {return;}
		
		byte[]by = new byte[1024];
		int len = 0;
		
		try {
			socket = server.accept();
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
		//	fileInputStream = new FileInputStream(file);
			connect = true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			while((len=read_file.read(by))!=-1) {
				dataOutputStream.write(by, 0, len);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		close_resourse();
	} // run
	
	private class Time_check extends TimerTask{

		@Override
		public void run() {
			
			if(!connect) {
				close_resourse();
			}
		} // run
		
	}
	public void close_resourse() {
		try {
			if(dataOutputStream!=null) {dataOutputStream.close();}
			if(socket!=null&&!socket.isClosed()) {socket.close();}
			if(read_file!=null) {read_file.close();}
			if(server!=null&&!server.isClosed()) {server.close();}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
}
