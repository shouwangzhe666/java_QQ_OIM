package group_message;

public class Group_search_message {

	int type = 1;
	String group_type = null;
	String group_name = null;
	String group_ower_account = null;
	boolean scuess = false;
	boolean accept = false;
	String group_account = null;
	byte[] group_icon = null;
	int pay_money = 0;
	
	byte[] native_icon = null;
	String native_name = null;
	String native_account = null;
	String verify_message = null;
	String question = null;
	String answer = null;
	
	
	public Group_search_message(int type) {
	       this.type = type;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getGroup_type() {
		return group_type;
	}

	public void setGroup_type(String group_type) {
		this.group_type = group_type;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getGroup_name() {
		return group_name;
	}

	public void setGroup_name(String group_name) {
		this.group_name = group_name;
	}

	public String getGroup_ower_account() {
		return group_ower_account;
	}

	public void setGroup_ower_account(String group_ower_account) {
		this.group_ower_account = group_ower_account;
	}

	public boolean isScuess() {
		return scuess;
	}

	public void setScuess(boolean scuess) {
		this.scuess = scuess;
	}

	public boolean isAccept() {
		return accept;
	}

	public void setAccept(boolean accept) {
		this.accept = accept;
	}

	public String getGroup_account() {
		return group_account;
	}

	public void setGroup_account(String group_account) {
		this.group_account = group_account;
	}

	public byte[] getGroup_icon() {
		return group_icon;
	}

	public void setGroup_icon(byte[] group_icon) {
		this.group_icon = group_icon;
	}

	public int getPay_money() {
		return pay_money;
	}

	public void setPay_money(int pay_money) {
		this.pay_money = pay_money;
	}

	public byte[] getNative_icon() {
		return native_icon;
	}

	public void setNative_icon(byte[] native_icon) {
		this.native_icon = native_icon;
	}

	public String getNative_name() {
		return native_name;
	}

	public void setNative_name(String native_name) {
		this.native_name = native_name;
	}

	public String getNative_account() {
		return native_account;
	}

	public void setNative_account(String native_account) {
		this.native_account = native_account;
	}

	public String getVerify_message() {
		return verify_message;
	}

	public void setVerify_message(String verify_message) {
		this.verify_message = verify_message;
	}
	
}
