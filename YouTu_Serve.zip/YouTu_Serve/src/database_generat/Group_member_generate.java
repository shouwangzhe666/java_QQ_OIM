package database_generat;

// author: jiang quan feng
// date : 2020.01.11

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import group_message.Group_info_message;
import private_message.Private_info;

public class Group_member_generate {
	
	 public static String get_create_table_sql(String group_account) {
		   //`tb_member_"+group_account+"`
		   String  table_sql = "CREATE TABLE `tb_member_"+group_account+"` (\r\n" + 
		   		"`account`  int(11) NOT NULL ,\r\n" + 
		   		"`id`  varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
		   		"`group_remark`  varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
		   		"`jion_time`  bigint(20) NOT NULL ,\r\n" + 
		   		"`last_time`  bigint(20) NOT NULL \r\n" + 
		   		")\r\n" + 
		   		"ENGINE=InnoDB\r\n" + 
		   		"DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci\r\n" + 
		   		"ROW_FORMAT=DYNAMIC";
		   return table_sql;
	   }
	 
	  public static ArrayList<String> get_administer_array(String group_account) {
		    Connection connection=Connection_Pool.get_group_connection();
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
		   ArrayList<String> all_account = new ArrayList<>();
		   
		   String sql = "select account from tb_member_"+group_account+" where id=? or id=?";
		   
		   try {					 
			   preparedStatement = connection.prepareStatement(sql);
			   preparedStatement.setString(1,"群主");
			   preparedStatement.setString(2,"管理员");
			   resultSet = preparedStatement.executeQuery();
			   
		} catch (Exception e) {
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return all_account;
		}
		   String account = null;
		   try {
			while(resultSet.next()) {
				account = resultSet.getString(1);
				all_account.add(account);
			   }
		} catch (SQLException e) {
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return all_account;
		}
		   
		  Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		   return all_account;
	  }
   public static boolean put_group_ower(String group_account,String account) {
	    Connection connection=Connection_Pool.get_group_connection();
	    PreparedStatement preparedStatement=null;
	    ResultSet resultSet = null;
	  
       String sql = "insert into tb_member_"+group_account+" values(?,?,?,?,?)";
	  
       Private_info info = Private_info_generate.get_info(account);
	   String group_remark = info.getName();
	   
	   try {
		connection.setAutoCommit(false);
		
		preparedStatement = connection.prepareStatement(sql);
		
		preparedStatement.setInt(1, Integer.parseInt(account));
		preparedStatement.setString(2, "群主");
		preparedStatement.setString(3, group_remark);
		preparedStatement.setLong(4, System.currentTimeMillis());
		preparedStatement.setLong(5, System.currentTimeMillis());
		
		preparedStatement.executeUpdate();
		connection.commit();
		
	} catch (Exception e) {
		
		try {
			connection.rollback();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		return false;
	}
	
	    Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
	 return true;
   }
   
   public static boolean put_new_member(String group_account,String account) {
	   Connection connection=Connection_Pool.get_group_connection();
	    PreparedStatement preparedStatement=null;
	    ResultSet resultSet = null;
	    
	   String sql = "insert into tb_member_"+group_account+" values(?,?,?,?,?)";
	   
	   Private_info info = Private_info_generate.get_info(account);
	   String group_remark = info.getName();
	   
	   try {
		connection.setAutoCommit(false);
		
		preparedStatement = connection.prepareStatement(sql);
		
		preparedStatement.setInt(1, Integer.parseInt(account));
		preparedStatement.setString(2, "成员");
		preparedStatement.setString(3, group_remark);
		preparedStatement.setLong(4, System.currentTimeMillis());
		preparedStatement.setLong(5, System.currentTimeMillis());
		
		preparedStatement.executeUpdate();
		connection.commit();
		
	} catch (Exception e) {
		
		try {
			connection.rollback();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		return false;
	}
	
	    Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
	 return true;
	   
   }
   
   public static boolean delete_member(String group_account,String account) {
	   Connection connection=Connection_Pool.get_group_connection();
	    PreparedStatement preparedStatement=null;
	    ResultSet resultSet = null;
	    
       String sql = "delete from tb_member_"+group_account+" where account=?";
	   
	   
	   try {
		connection.setAutoCommit(false);
		
		preparedStatement = connection.prepareStatement(sql);
		
		preparedStatement.setInt(1, Integer.parseInt(account));
		
		preparedStatement.executeUpdate();
		connection.commit();
		
	} catch (Exception e) {
		
		try {
			connection.rollback();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		return false;
	}
	
	 Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
	 return true;
   }
   
   public static boolean alter_member_info( Connection connection,String group_account,String account,String fild,String new_value) {
	 
	    PreparedStatement preparedStatement=null;
	    ResultSet resultSet = null;
	    
       String sql = "update tb_member_"+group_account+" set "+fild+"=? where account=?";
	   
	   try {
		connection.setAutoCommit(false);
		
		preparedStatement = connection.prepareStatement(sql);
		
		if(fild.equals("last_time")) {preparedStatement.setLong(1, Long.parseLong(new_value));}		
		else{preparedStatement.setString(1, new_value);}
		
		preparedStatement.setInt(2,Integer.parseInt(account));
		
		preparedStatement.executeUpdate();
		connection.commit();
		
	} catch (Exception e) {
		
		try {
			connection.rollback();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
		return false;
	}
	
	 Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
	 return true;
   }
  
   public static Group_info_message get_all_members(int group_account){
	   
	    Connection connection=Connection_Pool.get_group_connection();
	    PreparedStatement preparedStatement=null;
	    ResultSet resultSet = null;
	    
	   ArrayList<ArrayList<Object>> all_members = new ArrayList<>();
	   ArrayList<Object> member = null;
	   
	   String sql = "select * from tb_member_"+group_account;
	   
	   try {				 
		   preparedStatement = connection.prepareStatement(sql);
		   resultSet = preparedStatement.executeQuery();
	} catch (Exception e) {
		Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		return null;
	}
	   
	   try {
		while(resultSet.next()) {
			   
			member = new ArrayList<>();
			
			member.add(resultSet.getInt(1));
			member.add(resultSet.getString(2));
			member.add(resultSet.getString(3));
			member.add(resultSet.getLong(4));
			member.add(resultSet.getLong(5));
			
			all_members.add(member);
		   }
	} catch (SQLException e) {
		Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		return null;
	}
	  Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
	  
	  Group_info_message group_info_message = new Group_info_message(24,group_account);
	  group_info_message.setAll_members(all_members);
	  
	   return group_info_message;
   }
   
   public static ArrayList<Integer> get_member_account(String group_account){
	   
	    Connection connection=Connection_Pool.get_group_connection();
	    PreparedStatement preparedStatement=null;
	    ResultSet resultSet = null;
	    
	   ArrayList<Integer> all_account = new ArrayList<>();
	   int link_account = 0;
	   
	   String sql = "select account from tb_member_"+group_account;
	     
	     try {
			preparedStatement = connection.prepareStatement(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     try {
			resultSet = preparedStatement.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     try {
			while(resultSet.next()) {
				 link_account = resultSet.getInt(1);
				 all_account.add(link_account);
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	     Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
	     
	     return all_account;
	}
   public static long get_last_time(Connection group_connection,String group_account,int member_account) {
	   
	   PreparedStatement preparedStatement=null;
	   ResultSet resultSet = null;
		    
	    //  last_time
		String sql = "select last_time from tb_member_"+group_account+"  where account=?";
		long send_time = 0l;
		
		try {
			 preparedStatement = group_connection.prepareStatement(sql);
             preparedStatement.setInt(1,member_account);
			 resultSet = preparedStatement.executeQuery();
			 
			 if(resultSet.next()) {				
				send_time = resultSet.getLong(1);
				 }
			 
		} catch (Exception e) {
			e.printStackTrace();
			Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
			return 0l;
		}
		
		Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
		
		return send_time;
	}
   public static boolean create_member_table(String group_account) {
		
	    Connection connection=Connection_Pool.get_group_connection();
	    PreparedStatement preparedStatement=null;
	    ResultSet resultSet = null;
	    
	    String table_sql = get_create_table_sql(group_account);
		
		try {
			connection.setAutoCommit(false);
			try {
				preparedStatement = connection.prepareStatement(table_sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			preparedStatement.executeUpdate();
			
			connection.commit();
		} catch (Exception e) {
		
			try {
				connection.rollback();
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			} catch (Exception e2) {
				// TODO: handle exception
			}
			
			return false;
		}
		
		try {
			connection.rollback();
		Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		} catch (Exception e2) {
			// TODO: handle exception
		}
		
		return true;
	}
  
}
