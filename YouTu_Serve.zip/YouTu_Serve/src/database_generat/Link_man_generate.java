package database_generat;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import message_log_regis.Ping_Pong;
import private_handle_pack.Ping_Pong_Handle;
import private_message.Private_info;

public class Link_man_generate {

	    // 黑名单
	
 public static void open_shutup(String member_account,String group_account,boolean shutup,long start_time,int minites) {
		 
	     minites*=60000;
	     start_time+=minites;
	     String chat_time = String.valueOf(start_time);
	     
		 if(shutup) {alter_link_man(member_account, group_account, "state", chat_time);}
		 else {alter_link_man(member_account, group_account, "state", "0");}
	 }
 
	 public static boolean join_blacklist(String account,String link_account) {
		  
		    Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			String tb_name = "tb_"+account;
			
			String sql = "insert into "+tb_name+" values(5,?,'1','1','1','1','1','1','1','1',?,?)";	
			
           try {
				
				connection.setAutoCommit(false);
				
				preparedStatement = connection.prepareStatement(sql);
				
				preparedStatement.setInt(1, Integer.parseInt(link_account));
				preparedStatement.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
				preparedStatement.setTimestamp(3, new Timestamp(System.currentTimeMillis()));	
				
				preparedStatement.executeUpdate();
				connection.commit();
				
			} catch (Exception e) {
				System.out.println("rollback");
				e.printStackTrace();
				try {
					connection.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return false;
			}  //catch
           
           Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		return true;
		 
	 }
	 
	 public static boolean delete_blacklist(String account,String link_account) {
		 
		    Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
		     String tb_name = "tb_"+account;
		     String sql = "delete from "+tb_name+" where link_account=? and type=5";	     
		     
		     try {
				
					connection.setAutoCommit(false);
					
					preparedStatement = connection.prepareStatement(sql);
					
					preparedStatement.setInt(1,Integer.parseInt(link_account));
					preparedStatement.executeUpdate();
					
					connection.commit();
				} catch (Exception e) {
					System.out.println("rollback");
					try {
						connection.rollback();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
					return false;
				}
				
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return true;
	 }
	 
	 public static boolean is_blacklist(String account,String link_account) {
		 
		    Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			String tb_name = "tb_"+account;
			String sql = "select * from "+tb_name+" where link_account=? and type=5";	
			 
			boolean is_blacklist = false;
			
			try {
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setInt(1, Integer.parseInt(link_account));
				
				resultSet = preparedStatement.executeQuery();
				is_blacklist = resultSet.next();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return is_blacklist;
	 }
		// no.1 联系人（好友/群聊）操作函数
	
		public static boolean put_link_man(String account,String link_account,String id,String ip_port,long out_time) {
			// add a new link man (private or group)
			Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			String tb_name = "tb_"+account;
			
			Init_link_table(tb_name);
			
			int type = link_account.length()==8?1:2;
			boolean privat = link_account.length()==8?true:false;
			long current_time = System.currentTimeMillis();
			long long_out_time = 3742762088000l;  //2088-8-8 8:8:8
			long day_out_time = current_time+86400;
			long month_out_time = current_time+2678400;
			
		//	long out_time = out_type==1?long_out_time:out_type==2?day_out_time:month_out_time;
			
			String state = "state";
			if(privat) {state = Login_generate.get_state(link_account);}
			
			Private_info private_info = Private_info_generate.get_info(link_account);
			String remark = private_info.getName();
			String signature = private_info.getSignature();
			String group_names = get_all_group(account, privat);
			String group_name = to_StringArray(group_names)[0];
			
			String sql = "insert into "+tb_name+" values(?,?,?,?,?,?,?,?,?,?,?,?)";	
			
			try {
				
				connection.setAutoCommit(false);
				
				preparedStatement = connection.prepareStatement(sql);
				
				preparedStatement.setInt(1, type);
				preparedStatement.setInt(2, Integer.parseInt(link_account));
				preparedStatement.setString(3, remark);
				preparedStatement.setString(4, signature);
				preparedStatement.setString(5, group_name);
				preparedStatement.setString(6,group_names);
				preparedStatement.setString(7,"接收消息并提醒");
				preparedStatement.setString(8,state);
				preparedStatement.setString(9,id);
				preparedStatement.setString(10, ip_port);
				preparedStatement.setTimestamp(11, new Timestamp(current_time));
				preparedStatement.setTimestamp(12, new Timestamp(out_time));	
				
				preparedStatement.executeUpdate();
				connection.commit();
			} catch (Exception e) {
				System.out.println("rollback");
				e.printStackTrace();
				try {
					connection.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return false;
			}
			
			    Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return true;
			
		}
		
		public static boolean put_link_group(String account,String link_account,String join_group_name,String id,String ip_port,long out_time) {
			// add a new link man (private or group)
			Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			String tb_name = "tb_"+account;
			
			Init_link_table(tb_name);
			
			int type = link_account.length()==8?1:2;
			boolean privat = link_account.length()==8?true:false;
			long current_time = System.currentTimeMillis();
			String group_remark = Private_info_generate.get_info(account).getName();
			long long_out_time = 3742762088000l;  //2088-8-8 8:8:8
			long day_out_time = current_time+86400;
			long month_out_time = current_time+2678400;
			
		//	long out_time = out_type==1?long_out_time:out_type==2?day_out_time:month_out_time;
			
			String state = "0";
			if(privat) {state = Login_generate.get_state(link_account);}
			
			String group_names = get_all_group(account, privat);
			String group_name = to_StringArray(group_names)[0];
			
			String sql = "insert into "+tb_name+" values(?,?,?,?,?,?,?,?,?,?,?,?)";	
			
			try {
				
				connection.setAutoCommit(false);
				
				preparedStatement = connection.prepareStatement(sql);
				
				preparedStatement.setInt(1, type);
				preparedStatement.setInt(2, Integer.parseInt(link_account));
				preparedStatement.setString(3, join_group_name);
				preparedStatement.setString(4,group_remark);
				preparedStatement.setString(5, group_name);
				preparedStatement.setString(6,group_names);
				preparedStatement.setString(7,"接收消息并提醒");
				preparedStatement.setString(8,state);
				preparedStatement.setString(9,id);
				preparedStatement.setString(10, ip_port);
				preparedStatement.setTimestamp(11, new Timestamp(current_time));
				preparedStatement.setTimestamp(12, new Timestamp(out_time));	
				
				preparedStatement.executeUpdate();
				connection.commit();
			} catch (Exception e) {
				System.out.println("rollback");
				e.printStackTrace();
				try {
					connection.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return false;
			}
			
			    Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return true;
			
		}
		public static boolean delete_link_man(String account,String link_account) {
			
			// delete a new link man (private or group)
			Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
		     String tb_name = "tb_"+account;
		     String sql = "delete from "+tb_name+" where link_account=?";	     
		     
		     try {
				
					connection.setAutoCommit(false);
					
					preparedStatement = connection.prepareStatement(sql);
					
					preparedStatement.setInt(1,Integer.parseInt(link_account));
					preparedStatement.executeUpdate();
					
					connection.commit();
				} catch (Exception e) {
					System.out.println("rollback");
					try {
						connection.rollback();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
					return false;
				}
				
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return true;
			
		}
		
		public static boolean alter_link_man(Connection link_connection,String account,String link_account,String fild,String new_value) {
			// alter some information of a link man (private or group)
		
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
		     String tb_name = "tb_"+account;
		     String sql = "update "+tb_name+" set "+fild+"=? where link_account=?";
		    
		     
		     try {		    	 
		    	   link_connection.setAutoCommit(false);
					
					preparedStatement = link_connection.prepareStatement(sql);
					
				    if(fild.equals("out_time")) {preparedStatement.setTimestamp(1,new Timestamp(Long.parseLong(new_value)));}
					else {preparedStatement.setString(1,new_value);}
					
					preparedStatement.setInt(2,Integer.parseInt(link_account));
					preparedStatement.executeUpdate();
					
					link_connection.commit();
				} catch (Exception e) {
					System.out.println("rollback");
					e.printStackTrace();
					try {
						link_connection.rollback();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
					return false;
				}
				
				Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
				
				return true;
		}
		
		public static boolean alter_link_man(String account,String link_account,String fild,String new_value) {
			// alter some information of a link man (private or group)
			Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
		     String tb_name = "tb_"+account;
		     String sql = "update "+tb_name+" set "+fild+"=? where link_account=?";
		    
		     
		     try {		    	 
		    	 	connection.setAutoCommit(false);
					
					preparedStatement = connection.prepareStatement(sql);
					
				    if(fild.equals("out_time")) {preparedStatement.setTimestamp(1,new Timestamp(Long.parseLong(new_value)));}
					else {preparedStatement.setString(1,new_value);}
					
					preparedStatement.setInt(2,Integer.parseInt(link_account));
					preparedStatement.executeUpdate();
					
					connection.commit();
				} catch (Exception e) {
					System.out.println("rollback");
					e.printStackTrace();
					try {
						connection.rollback();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
					return false;
				}
				
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				
				return true;
		}
		
		public static ArrayList<ArrayList<String>> get_specified_link_man(String account,String link_account){	
			
			ArrayList<String> link_man = null;
		    ArrayList<ArrayList<String>> all_link_man = new ArrayList<>();
			
			Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			 String tb_name = "tb_"+account;
		     String sql = "select * from "+tb_name+" where link_account=?";
		    
		     try {
				preparedStatement = connection.prepareStatement(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     try {
				preparedStatement.setInt(1, Integer.parseInt(link_account));
			} catch (NumberFormatException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		     try {
				resultSet = preparedStatement.executeQuery();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     int link_count = 0;
		     Channel channel = null;
		     String remote_ip = null;
		     try {
				while(resultSet.next()) {
							
					link_man = new ArrayList<>();
					
					link_man.add(resultSet.getString(1));
					link_man.add(resultSet.getString(2));
					link_man.add(resultSet.getString(3));
					link_man.add(resultSet.getString(4));
					link_man.add(resultSet.getString(5));
					link_man.add(resultSet.getString(6));
					link_man.add(resultSet.getString(7));
					link_man.add(resultSet.getString(8));
					link_man.add(resultSet.getString(9));
					link_man.add(resultSet.getString(10));
					link_man.add(resultSet.getString(11));
					link_man.add(resultSet.getString(12));
				
					link_count = Integer.parseInt(resultSet.getString(2));
					channel = Ping_Pong_Handle.all_users.get(link_count);
					
					if(channel==null) {link_man.add("1");}
					else {
						  remote_ip = channel.remoteAddress().toString().substring(1);
						  remote_ip = remote_ip.split(":")[0].trim();
						  link_man.add(remote_ip);  // 13th
					}				  
				    
					all_link_man.add(link_man);
				 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     
		    Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		     
			return all_link_man;
		}
		public static ArrayList<ArrayList<String>> get_all_link_man(String account){			
			// get all information of all link_man (private or group)
			Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			 String tb_name = "tb_"+account;
		     String sql = "select * from "+tb_name+" where type=1 or type=2";
		     ArrayList<String> link_man = null;
		     ArrayList<ArrayList<String>> all_link_man = new ArrayList<>();
		    
		     try {
				preparedStatement = connection.prepareStatement(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     try {
				resultSet = preparedStatement.executeQuery();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
             		     
		     try {
				while(resultSet.next()) {
					 
					link_man = new ArrayList<>();
										
					link_man.add(resultSet.getString(1));
					link_man.add(resultSet.getString(2));
					link_man.add(resultSet.getString(3));
					link_man.add(resultSet.getString(4));
					link_man.add(resultSet.getString(5));
					link_man.add(resultSet.getString(6));
					link_man.add(resultSet.getString(7));
					link_man.add(resultSet.getString(8));
					link_man.add(resultSet.getString(9));
					link_man.add(resultSet.getString(10));
					link_man.add(resultSet.getString(11));
					link_man.add(resultSet.getString(12));			  
				    
					all_link_man.add(link_man);
				 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     
		    Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		     
			return all_link_man;
		}
		
		public static ArrayList<Integer> get_all_related_link_account(String account){
			
			ArrayList<Integer> all_account1  = get_all_Private_link_man(account);
			ArrayList<Integer> all_account2  = get_group_link_account(account);
			
			ArrayList<Integer> all_group_member_account = new ArrayList<>();
			ArrayList<Integer> group_member_account = new ArrayList<>();
			int group_account = 0;
			
			for(int i=0;i<all_account2.size();i++) {
				group_account = all_account2.get(i);
				group_member_account = Group_member_generate.get_member_account(String.valueOf(group_account));
				all_group_member_account.addAll(group_member_account);
			}
			
			all_account1.addAll(all_account2);
			all_account1.addAll(all_group_member_account);
			
			return all_account1;
		}
 
		public static ArrayList<String> get_private_link_account(String account){
			
			Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			ArrayList<String> all_account = new ArrayList<>();
			String link_account = null;
			
			 String tb_name = "tb_"+account;
		     String sql = "select link_account from "+tb_name+" where type=1";
		     
		     try {
				preparedStatement = connection.prepareStatement(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     try {
				resultSet = preparedStatement.executeQuery();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     try {
				while(resultSet.next()) {
					 link_account = resultSet.getString(1);
					 all_account.add(link_account);
				 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     
		     Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		     
		     return all_account;
		}
		
  public static ArrayList<Integer> get_group_link_account(String account){
			
	    Connection connection=Connection_Pool.get_linkman_connection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		ArrayList<Integer> all_account = new ArrayList<>();
		
		 String tb_name = "tb_"+account;
	     String sql = "select link_account from "+tb_name+" where type=2";
	     
	     try {
			preparedStatement = connection.prepareStatement(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     try {
			resultSet = preparedStatement.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     try {
			while(resultSet.next()) {

				 all_account.add(resultSet.getInt(1));
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	     Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
	     
	   
			return all_account;		     
}
  
public static boolean update_related_LinkState(String account,String state) {
			// update the state of account shown on the link_table of account's link_man
			
		     Connection link_connectione = Connection_Pool.get_linkman_connection();
		     
			 ArrayList<Integer> all_link_man = get_all_Private_link_man(account);
			 int link_account = 0;
			 boolean scuess = false;
			 
			 byte[] native_account = null;
			 byte[] statebytes = null;
			 try {
				native_account = account.getBytes("UTF-8");
				statebytes = state.getBytes("UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
			 
			 ByteBuf buf = Unpooled.buffer(1024);
			 buf.writeInt(122);
			 buf.writeInt(8);
			    
			 buf.writeInt(native_account.length);
			 buf.writeBytes(native_account);
			 buf.writeInt(statebytes.length);
			 buf.writeBytes(statebytes);
			    
			 for(int i=0;i<all_link_man.size();i++) {
				 link_account = all_link_man.get(i);
				
				 scuess = alter_link_man(link_connectione,String.valueOf(link_account), account, "state", state);
		//		 if(!scuess) {return false;}
				 Channel channel = Ping_Pong_Handle.all_users.get(link_account);
				 if(channel!=null) {channel.writeAndFlush(buf.duplicate().retain());}
			 }
			 
			 Connection_Pool.close_Resourse(link_connectione, null, null);
			 
			 return true;
		}

public static boolean update_related_LinkRemoteIP(String account,String remoteip) {
	// update the state of account shown on the link_table of account's link_man
	
     Connection link_connectione = Connection_Pool.get_linkman_connection();
     
	 ArrayList<Integer> all_link_man = get_all_Private_link_man(account);
	 int link_account = 0;
	 boolean scuess = false;
	 
	 byte[] native_account = null;
	 byte[] remoteipbytes = null;
	 try {
		native_account = account.getBytes("UTF-8");
		remoteipbytes = remoteip.getBytes("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}		
	 
	 ByteBuf buf = Unpooled.buffer(1024);
	 buf.writeInt(122);
	 buf.writeInt(10);
	    
	 buf.writeInt(native_account.length);
	 buf.writeBytes(native_account);
	 buf.writeInt(remoteipbytes.length);
	 buf.writeBytes(remoteipbytes);
	 
	 for(int i=0;i<all_link_man.size();i++) {
		 link_account = all_link_man.get(i);
		 
		 scuess = alter_link_man(link_connectione,String.valueOf(link_account), account, "ip_port", remoteip);
//		 if(!scuess) {return false;}
		 Channel channel = Ping_Pong_Handle.all_users.get(link_account);
		 if(channel!=null) {channel.writeAndFlush(buf.duplicate().retain());}
	 }
	 
	 Connection_Pool.close_Resourse(link_connectione, null, null);
	 
	 return true;
}		

public static ArrayList<Integer> get_all_Private_link_man(String account){			
			// get all information of all link_man (private or group)
			Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			 String tb_name = "tb_"+account;
		     String sql = "select link_account from "+tb_name+" where type=1";
		     ArrayList<Integer> all_link_man = new ArrayList<>();	  
		     
		     try {
				preparedStatement = connection.prepareStatement(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     try {
				resultSet = preparedStatement.executeQuery();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     
		     try {
				while(resultSet.next()) {
					
					all_link_man.add(resultSet.getInt(1));
				 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     
		    Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		     
			return all_link_man;
		}
		
		// no.2 分组（好友/群聊）操作函数
		
		public static boolean put_new_group(String account,boolean privat,String group) {
			Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			boolean exist = check_groupName_exist(account, privat, group);
			
			if(exist) {return true;}
			
			 String tb_name = "tb_"+account;
			 int type = privat?3:4;
			 long long_out_time = 3742762088000l;
			 String sql = "insert into "+tb_name+" values(?,?,?,?,?,?,?,?,?,?,?,?)";			 
						 
				try {
					
					connection.setAutoCommit(false);
					
					preparedStatement = connection.prepareStatement(sql);
					
					preparedStatement.setInt(1, type);
					preparedStatement.setInt(2, 1);
					preparedStatement.setString(3, "1");
					preparedStatement.setString(4, "1");
					preparedStatement.setString(5, group);
					preparedStatement.setString(6,"1");
					preparedStatement.setInt(7, 1);
					preparedStatement.setString(8,"1");
					preparedStatement.setString(9,"1");
					preparedStatement.setString(10, "1");
					preparedStatement.setTimestamp(11, new Timestamp(System.currentTimeMillis()));
					preparedStatement.setTimestamp(12, new Timestamp(long_out_time));	
										
					preparedStatement.executeUpdate();
					
					connection.commit();
					
				} catch (Exception e) {
					System.out.println("put_new_group rollback");
					e.printStackTrace();
					try {
						connection.rollback();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
					return false;
				}
				
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				
				String all_group = get_all_group(account, privat);
				
				boolean scuess = set_all_gorup(account, privat, all_group);
			
				return scuess;
		}
		
		public static boolean rename_group_name(String account,boolean privat,String old_group,String new_group) {
			
			boolean b1 = update_rename_group_names(account, privat, old_group, new_group);
			boolean b2 = update_rename_group_name(account, privat, old_group, new_group);
			boolean b3 = update_select_LinkGroup(account, old_group, new_group);
			
			return b1&&b2&&b3;
			
		}
		
		public static boolean update_rename_group_name(String account,boolean privat,String old_group,String new_group) {
			Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			String tb_name = "tb_"+account;
			String sql = "update "+tb_name+" set group_name=? where group_name=? and (type=3 or type=4)";
			
			
			 try {		    	 
		    	 	connection.setAutoCommit(false);
					
					preparedStatement = connection.prepareStatement(sql);
					
					preparedStatement.setString(1, new_group);
					preparedStatement.setString(2, old_group);
					
					preparedStatement.executeUpdate();
					connection.commit();
					
				} catch (Exception e) {
					System.out.println("rollback");
					try {
						connection.rollback();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
					return false;
				}
				
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return true;
		}
		
		public static boolean update_rename_group_names(String account,boolean privat,String old_group,String new_group) {
			Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			String tb_name = "tb_"+account;
			int type = privat?1:2;
			String sql = "update "+tb_name+" set group_names=? where group_names=? and type=?";
			
			String old_groups = get_all_group(account, privat);
			String new_groups = change_group_name(old_groups, old_group, new_group);
			
			
			 try {		    	 
		    	 	connection.setAutoCommit(false);
					
					preparedStatement = connection.prepareStatement(sql);
					
					preparedStatement.setString(1, new_groups);
					preparedStatement.setString(2, old_groups);
					preparedStatement.setInt(3, type);
					
					preparedStatement.executeUpdate();
					connection.commit();
					
				} catch (Exception e) {
					System.out.println("rollback");
					try {
						connection.rollback();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
					return false;
				}
				
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return true;
			
		}
		
		public static boolean delete_group_name(String account,boolean privat,String delete_group,String NewSelected_group) {
			
			boolean b1 = update_delete_groupNames(account, privat, delete_group, NewSelected_group);
			boolean b2 = update_delete_groupName(account, delete_group);
			boolean b3 = update_select_LinkGroup(account, delete_group, NewSelected_group);
			
			return b1&&b2&&b3;
			
		}
		public static boolean update_delete_groupNames(String account,boolean privat,String delete_group,String NewSelected_group) {
			// update the colum "group_names"to the latest ;
			Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			String tb_name = "tb_"+account;
			int type = privat?1:2;
			String sql = "update "+tb_name+" set group_names=? where group_names=? and type=?";
			
			String old_groups = get_all_group(account, privat);			
			String new_groups = remove_group_name(old_groups, delete_group);
			System.out.println("old_groups"+old_groups);
			System.out.println("new_groups"+new_groups);
			
			 try {		    	 
		    	 	connection.setAutoCommit(false);
					
					preparedStatement = connection.prepareStatement(sql);
					
					preparedStatement.setString(1, new_groups);
					preparedStatement.setString(2, old_groups);
					preparedStatement.setInt(3, type);
					
					preparedStatement.executeUpdate();
					connection.commit();
					
				} catch (Exception e) {
					System.out.println("rollback");
					try {
						connection.rollback();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);				
					return false;
				}
				
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return true;
		}
		
		public static boolean update_delete_groupName(String account,String delete_group) {
			// delete the group whose group_name is the specifed "delete_group" ;
			Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			String tb_name = "tb_"+account;
			String sql = "delete from "+tb_name+" where (type=3 or type=4) and group_name=?";
			
			
			 try {		    	 
		    	 	connection.setAutoCommit(false);
					
					preparedStatement = connection.prepareStatement(sql);
					
					preparedStatement.setString(1, delete_group);
					
					preparedStatement.executeUpdate();
					connection.commit();
					
				} catch (Exception e) {
					System.out.println("rollback");
					try {
						connection.rollback();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				    Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
					return false;
				}
				
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			    return true;
			
		}
		
		public static boolean update_select_LinkGroup(String account,String selected_group,String selected_new_group) {
			// udpate the group_name of link_man whose group_name  equals "selected_group" to "selected_new_group";
			Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			System.out.println("selected_group "+selected_group+" selected_new_group "+selected_new_group );
			String tb_name = "tb_"+account;
			String sql = "update "+tb_name+" set group_name=? where group_name=?";
			 
			try {		    	 
	    	 	connection.setAutoCommit(false);
				
				preparedStatement = connection.prepareStatement(sql);
				
				preparedStatement.setString(1, selected_new_group);
				preparedStatement.setString(2, selected_group);
				
				preparedStatement.executeUpdate();
				connection.commit();
			} catch (Exception e) {
				System.out.println("rollback");
				e.printStackTrace();
				try {
					connection.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return false;
			}
			
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return true;
			
		}
		
		public static boolean check_groupName_exist(String account,boolean privat,String group_name) {
			Connection connection=Connection_Pool.get_linkman_connection();
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			
			String tb_name = "tb_"+account;
			String sql = "select group_name from "+tb_name+" where type=? and group_name=?";
			int type = privat?3:4;
	
			
			try {
				preparedStatement = connection.prepareStatement(sql);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				preparedStatement.setInt(1, type);
			} catch (SQLException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			try {
				preparedStatement.setString(2, group_name);
			} catch (SQLException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			try {
				resultSet = preparedStatement.executeQuery();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			try {
				if(resultSet.next()) {
					Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
					return true;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return false;
		}
		
		public static String change_group_name(String group_names,String old_group,String new_group) {
			
			String[] groups = to_StringArray(group_names);
			
			for(int i=0;i<groups.length;i++) {
				if(groups[i].equals(old_group)) {groups[i]=new_group;return toString(groups);}
			}
			
			return null;
			
		}
		
		public static String remove_group_name(String group_names,String delete_group) {
			
			ArrayList<String> list = new ArrayList<>();
			
			String[] groups = to_StringArray(group_names);
			
			for(int i=0;i<groups.length;i++) {
				if(groups[i].equals(delete_group)) {continue;}
				list.add(groups[i]);
			}
			
			String new_groups = toString(Array_to_StringArray(list));
			
			return new_groups;
		}
		
	public static ArrayList<String> get_all_Needed_groups(String account){
		
		Connection connection=Connection_Pool.get_linkman_connection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
			String table_name = "tb_"+account;
		 
			ArrayList<String> all_group = new ArrayList<>();						
			String sql = "select * from "+table_name+" where type=3 or type=4";		
		
			try {
				preparedStatement = connection.prepareStatement(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				resultSet = preparedStatement.executeQuery();
			} catch (SQLException e) {	            
			  
				e.printStackTrace();
			}
			
			String type = null;
			String group = null;
			String need_group = null;
			try {
				while(resultSet.next()) {
				    
					type = resultSet.getString(1);
					group = resultSet.getString(5);
					need_group  = type+"、"+group;
					all_group.add(need_group);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			
			return all_group;			
	}
	public static String get_all_group(String account,boolean privat) {
			// get all names of group that is private or group
		Connection connection=Connection_Pool.get_linkman_connection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
			String table_name = "tb_"+account;
		 
			ArrayList<String> all_group = new ArrayList<>();
			int type = privat?3:4;
			String tp = String.valueOf(type);
			
			String sql = "select group_name from "+table_name+" where type=?";
			String group = null;
		
			try {
				preparedStatement = connection.prepareStatement(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				preparedStatement.setInt(1, type);
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				resultSet = preparedStatement.executeQuery();
			} catch (SQLException e) {	            
			  
				e.printStackTrace();
			}
			
			try {
				while(resultSet.next()) {
				
					group = resultSet.getString(1);
			//	    tp+=","+group;
					all_group.add(group);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			group = toString(Array_to_StringArray(all_group));
			
			return group;			
		}
		
	public static boolean set_all_gorup(String account,boolean privat,String new_groups) {
			// set all of the related groups to the new_groups
		Connection connection=Connection_Pool.get_linkman_connection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
			String table_name = "tb_"+account;
			int type = privat?1:2;
			
			String sql = "update "+table_name+" set group_names=? where type=?";
			
			 try {	
				    connection.setAutoCommit(false);					
					preparedStatement = connection.prepareStatement(sql);
										
					preparedStatement.setString(1,new_groups);
					preparedStatement.setInt(2, type);
					
					preparedStatement.executeUpdate();
					connection.commit();
				} catch (Exception e) {
					System.out.println("rollback");
					try {
						connection.rollback();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
					return false;
				}
		
				  Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return true;
		}
		
	public static String toString(String[] groups) {
			
		if(groups==null||groups.length==0) {return null;}
		if(groups.length==1) {return groups[0];}
	
			StringBuilder builder = new StringBuilder();
		    
			for(int i=0;i<groups.length;i++) {
				builder.append(groups[i]);
				builder.append(",");
			}
			
			String group_string = builder.toString();
			group_string = group_string.substring(0, group_string.length()-1);
			
			return group_string;
			
		}
		
		public static String[] to_StringArray(String group_string) {
			
			return group_string.split(",");
		}
		
		public static String[] Array_to_StringArray(ArrayList<String> list) {
			
			String[] strings = new String[list.size()];
		
			for(int i=0;i<list.size();i++) {
				strings[i] = list.get(i);
			}
			
			return strings;
		}
		
	public static boolean Init_link_table(String tb_name) {
			
				Connection connection=Connection_Pool.get_linkman_connection();
				PreparedStatement preparedStatement=null;
				ResultSet resultSet = null;
				
			String sql = "create table "+tb_name+" as select * from tb_10000000 where link_account=1";
			
			try {
				connection.setAutoCommit(false);
				
				preparedStatement = connection.prepareStatement(sql);
				
				preparedStatement.executeUpdate(sql);
				
				connection.commit();
			} catch (Exception e) {
				try {
					connection.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return false;
			}
			
			   Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			
			return true;			
		}
	
	public static void main(String[] args) {
		
		ArrayList<ArrayList<String>> all_link_man11 = Link_man_generate.get_specified_link_man("10000001", "10000002");
		
		ArrayList<String> arrayList = all_link_man11.get(0);
		System.out.println("link_size: "+all_link_man11.size());
        for(int i=0;i<arrayList.size();i++) {
        	System.out.println(arrayList.get(i));
        }
	}
}
