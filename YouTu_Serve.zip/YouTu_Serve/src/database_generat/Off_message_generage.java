package database_generat;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;
import org.omg.PortableServer.ServantActivator;

public class Off_message_generage {
	
	// 经实测，全部通过
		
	public static boolean put_off_message(String account,long time,int type,int from_account,byte[]content) {
	        Connection connection = Connection_Pool.get_off_message_connection();
	        PreparedStatement preparedStatement = null;
	        ResultSet resultSet = null;
	        
			String tb_name = "tb_"+account;
			
			String sql = "insert into "+tb_name+" values(?,?,?,?)";		
			       
		       try {
				
		    	   connection.setAutoCommit(false);
		    	   
		    	   preparedStatement = connection.prepareStatement(sql);
					
					preparedStatement.setTimestamp(1,new Timestamp(time));
				    preparedStatement.setInt(2, type);
					preparedStatement.setInt(3,from_account);				    
					preparedStatement.setBytes(4,content);
					
					preparedStatement.executeUpdate();
					
					connection.commit();
					
			} catch (Exception e) {
				e.printStackTrace();
				
				try {
					connection.rollback();
				} catch (Exception e2) {
					// TODO: handle exception
				}
		
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return false;
			}
		       
		        Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return true;
		}
		
 public static boolean delete_off_message(String account,long datetime) {
	 Connection connection = Connection_Pool.get_off_message_connection();
     PreparedStatement preparedStatement = null;
     ResultSet resultSet = null;
     
			String tb_name = "tb_"+account;
			String sql = "delete from "+tb_name+" where datetime=?";
			
		      try {
		    	    connection.setAutoCommit(false);
		    	    
		    	    preparedStatement = connection.prepareStatement(sql);
					
					preparedStatement.setTimestamp(1,new Timestamp(datetime));
				
					preparedStatement.executeUpdate();
					
					connection.commit();
					
			} catch (Exception e) {
				try {
					connection.rollback();
				} catch (Exception e2) {
					// TODO: handle exception
				}
		
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return false;
			}
			
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return true;
		}
		
	public static boolean truncate_off_message(String account) {
		
		 Connection connection = Connection_Pool.get_off_message_connection();
	        PreparedStatement preparedStatement = null;
	        ResultSet resultSet = null;
	        
			String tb_name = "tb_"+account;
			String sql = "truncate table "+tb_name;
			
			
			try {
				connection.setAutoCommit(false);
				
				preparedStatement = connection.prepareStatement(sql);
				
			    preparedStatement.executeUpdate();
			     
			    connection.commit();
			     
			} catch (Exception e) {
				try {
					connection.rollback();
				} catch (Exception e2) {
					// TODO: handle exception
				}
		
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return false;
			}
				
			
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return true;
		}
		
	public static ArrayList<byte[]> get_all_off_message(String account){
			 Connection connection = Connection_Pool.get_off_message_connection();
		     PreparedStatement preparedStatement = null;
		     ResultSet resultSet = null;
		        
			String tb_name = "tb_"+account;
			String sql = "select content from "+tb_name+" where type<>3";
			
			try {
				preparedStatement = connection.prepareStatement(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				resultSet = preparedStatement.executeQuery();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			ArrayList<byte[]> all_message = new ArrayList<>();
			byte[] content = null;
			
			try {
				while(resultSet.next()) {
					
					content = resultSet.getBytes(1);
					all_message.add(content);

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			
			truncate_off_message(account);
		
			return all_message;
		}
		
	
	public static boolean Init_off_table(String tb_name) {
		
			 Connection connection = Connection_Pool.get_off_message_connection();
		     PreparedStatement preparedStatement = null;
		     ResultSet resultSet = null;
		        
			String sql = "create table "+tb_name+" as select * from tb_10000000 where from_account=1";
			
			try {
				connection.setAutoCommit(false);
				
				preparedStatement = connection.prepareStatement(sql);
				
				preparedStatement.executeUpdate(sql);
				
				connection.commit();
			
			} catch (Exception e) {
				System.out.println("rollback");
				try {
					connection.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return false;
			}
			
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		
			return true;
		}
		
	public static void main(String[] args) {
	
	     
}}
