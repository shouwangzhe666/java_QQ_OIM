package database_generat;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sound.midi.MidiDevice.Info;

import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;

import private_message.Private_info;

public class Private_info_generate {
	
	//经实测全部通过

	public static boolean put_new_info(int account,String head_icon,String name,String sex,String birth,String blood,String home,String phone,String email,String signature,String state) {
		Connection connection = Connection_Pool.get_private_info_connection();
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    
		String c = String.valueOf(account);
		String tb_name = "tb_"+c.substring(0, c.length()-2)+"00";
		
		String sql = "insert into "+tb_name+" values(?,?,?,?,?,?,?,?,?,?,?)";
		
		try {
		connection.setAutoCommit(false);
		
		preparedStatement = connection.prepareStatement(sql);
		
		preparedStatement.setInt(1, account);
		preparedStatement.setString(2, head_icon);
		preparedStatement.setString(3, name);
		preparedStatement.setString(4, sex);
		preparedStatement.setString(5, birth);
		preparedStatement.setString(6, blood);
		preparedStatement.setString(7,home);
		preparedStatement.setString(8, phone);
		preparedStatement.setString(9, email);
		preparedStatement.setString(10, signature);
		preparedStatement.setString(11, state);
		
		preparedStatement.executeUpdate();
		
		connection.commit();
		
		} catch (Exception e) {
              
			e.printStackTrace();
			System.out.println("rollback");
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return false;
		}
		  
		  Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		  return true;
	}
	
	public static boolean update_info(Private_info private_info) {
		
		Connection connection = Connection_Pool.get_private_info_connection();
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    
		String account = private_info.getCount();
		
		String tb_name = "tb_"+account.substring(0,account.length()-2)+"00";
		String sql = "update "+tb_name+" set name=?,sex=?,birth=?,blood=?,home=?,phone=?,email=?,signature=?,state=? where account=?";
		
		
		try {
		  connection.setAutoCommit(false);
			
		  preparedStatement = connection.prepareStatement(sql);
		
		  preparedStatement.setString(1, private_info.getName());
		  preparedStatement.setString(2, private_info.getSex());
		  preparedStatement.setString(3, private_info.getBirth());
		  preparedStatement.setString(4, private_info.getBlood());
		  preparedStatement.setString(5, private_info.getHome());
		  preparedStatement.setString(6, private_info.getPhone());
		  preparedStatement.setString(7, private_info.getE_mail());
		  preparedStatement.setString(8, private_info.getSignature());
		  preparedStatement.setString(9, private_info.getState());
		  preparedStatement.setString(10, private_info.getCount());
		  
		  preparedStatement.executeUpdate();
		  
		 connection.commit();
			
		} catch (Exception e) {
			
		    try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		    
		  Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		    return false;
		}
			
		 Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		
		  return true;
	}
	
	public static Private_info get_info(String account) {
		Connection connection = Connection_Pool.get_private_info_connection();
	    PreparedStatement preparedStatement = null;
	    ResultSet resultSet = null;
	    
		String tb_name = "tb_"+account.substring(0,account.length()-2)+"00";
		String sql = "select * from "+tb_name+" where account=?";
		Private_info private_info = null;

		try {
			preparedStatement = connection.prepareStatement(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			preparedStatement.setInt(1, Integer.parseInt(account));
		} catch (NumberFormatException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			resultSet = preparedStatement.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		
		try {
			if(resultSet.next()) {
			
				private_info = new Private_info();
				
				private_info.setCount(resultSet.getString(1));
				private_info.setName(resultSet.getString(3));
				private_info.setSex(resultSet.getString(4));
				private_info.setBirth(resultSet.getString(5));
				private_info.setBlood(resultSet.getString(6));
				private_info.setHome(resultSet.getString(7));
				private_info.setPhone(resultSet.getString(8));
				private_info.setE_mail(resultSet.getString(9));
				private_info.setSignature(resultSet.getString(10));
				private_info.setState(resultSet.getString(11));
			}
			else {return null;}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally {
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		}
		
		return private_info;
	}
	
	public static boolean Init_info_table(String tb_name) {
		
			Connection connection = Connection_Pool.get_private_info_connection();
		    PreparedStatement preparedStatement = null;
		    ResultSet resultSet = null;
		    
		String sql = "create table "+tb_name+" as select * from tb_10000000 where account=1";	
		
		try {
			connection.setAutoCommit(false);
			
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.executeUpdate(sql);
			
			connection.commit();
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return false;
		}
		
		  Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		
		return true;
		
	}
	 
	 public static void main(String[] args) {
	
	     new Private_info_generate();
	}
}
