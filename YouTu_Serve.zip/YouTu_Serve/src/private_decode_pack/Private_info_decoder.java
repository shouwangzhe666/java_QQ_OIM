package private_decode_pack;

import java.io.UnsupportedEncodingException;
import java.util.List;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import private_message.Private_info;

public class Private_info_decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> list) throws Exception {
	  		
		buf.readerIndex(0);
		if(buf.readableBytes()==0) {return;}
		
		int protocal_code = buf.readInt();
		if(protocal_code==331) {
		int type = buf.readInt();
    	if(type==1) {decode1(buf, list);}
    	else if(type==2) {decode2(buf, list);}
		else if(type==3) {decode3(buf, list);}
		else if(type==4) {decode4(buf, list);}
		}
		else {
			buf.retain();
			ctx.fireChannelRead(buf);
		}
	}

	public void decode1( ByteBuf buf, List<Object> list) {
		
		   Private_info private_info = Private_info_decode(buf);
		   private_info.setType(1);
		   list.add(private_info);
	}
	
	public void decode2( ByteBuf buf, List<Object> list) {
		
		 boolean scuess = buf.readBoolean();
		 
		 byte[] result = new byte[buf.readInt()];
		 buf.readBytes(result);
		 
		 Private_info private_info = new Private_info();
		 private_info.setScuess(scuess);
		 try {
			private_info.setResult(new String(result,"UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 private_info.setType(2);
		 list.add(private_info);
		
	}
	
   public void decode3( ByteBuf buf, List<Object> list) {
		
	   Private_info private_info = null;
	   
	   byte[] account = null;
	   account = new byte[buf.readInt()];
	   buf.readBytes(account);
	   
	   private_info = new Private_info();
	   try {
		private_info.setCount(new String(account,"UTF-8"));
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   private_info.setType(3);
	   list.add(private_info);
	}
   
   public void decode4( ByteBuf buf, List<Object> list) {
		
	   Private_info private_info = Private_info_decode(buf);
	   private_info.setType(4);
	   list.add(private_info);
}
   
   public Private_info Private_info_decode( ByteBuf buf) {
	
	   Private_info private_info = null;
	   
	    byte[] account = null;
	    byte[] head_icon = null;
		byte[] name = null;
		byte[] sex=null;
		byte[] birth=null;
		byte[] blood=null;
		byte[] home=null;
		byte[] phone=null;

		byte[] e_mail=null;
		byte[] signature=null;
		byte[] state=null;
		
		account = new byte[buf.readInt()];
		buf.readBytes(account);
		
		head_icon = new byte[buf.readInt()];
		buf.readBytes(head_icon);
		
		name = new byte[buf.readInt()];
		buf.readBytes(name);
		
		sex = new byte[buf.readInt()];
		buf.readBytes(sex);
		
		birth = new byte[buf.readInt()];
		buf.readBytes(birth);
		
		blood = new byte[buf.readInt()];
		buf.readBytes(blood);
		
		home = new byte[buf.readInt()];
		buf.readBytes(home);
		
		phone = new byte[buf.readInt()];
		buf.readBytes(phone);
		
		e_mail = new byte[buf.readInt()];
		buf.readBytes(e_mail);
		
		signature = new byte[buf.readInt()];
		buf.readBytes(signature);
		
		state = new byte[buf.readInt()];
		buf.readBytes(state);
		
		try {
			private_info = new Private_info(new String(account, "UTF-8"), head_icon, new String(name, "UTF-8"), new String(sex, "UTF-8"), new String(birth, "UTF-8"), new String(blood, "UTF-8"), new String(home, "UTF-8"), new String(phone, "UTF-8"), new String(e_mail, "UTF-8"), new String(signature, "UTF-8"), new String(state, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return private_info;
		
}
  
}
