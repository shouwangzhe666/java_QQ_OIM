package private_message;

// author: jiang quan feng
// date : 2020.01.11

public class Link_set{

	int type = 1;
	boolean privat = true;
	String native_count = null;          
	String link_account = null;
	String old_group = null;
	String new_group = null;
	String new_remark = null;
	String inform_type = null;
	String state = null;
	String rmeote_ip = null;
	
	
	public Link_set(int type) {
		this.type = type;
	}
	
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	
	public boolean isPrivat() {
		return privat;
	}

	public void setPrivat(boolean privat) {
		this.privat = privat;
	}
    
	public String getNew_remark() {
		return new_remark;
	}

	public void setNew_remark(String new_remark) {
		this.new_remark = new_remark;
	}

	public String getNative_count() {
		return native_count;
	}
	public void setNative_count(String native_count) {
		this.native_count = native_count;
	}
	public String getLink_account() {
		return link_account;
	}
	public void setLink_account(String link_account) {
		this.link_account = link_account;
	}
	public String getOld_group() {
		return old_group;
	}
	public void setOld_group(String old_group) {
		this.old_group = old_group;
	}
	public String getNew_group() {
		return new_group;
	}
	public void setNew_group(String new_group) {
		this.new_group = new_group;
	}

	public String getInform_type() {
		return inform_type;
	}

	public void setInform_type(String inform_type) {
		this.inform_type = inform_type;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}	
	public String getRmeote_ip() {
		return rmeote_ip;
	}
	public void setRmeote_ip(String rmeote_ip) {
		this.rmeote_ip = rmeote_ip;
	}	
}
