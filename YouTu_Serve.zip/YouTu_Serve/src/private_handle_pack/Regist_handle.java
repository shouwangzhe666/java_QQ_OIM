package private_handle_pack;

import database_generat.Private_info_generate;
import database_generat.Register_generate;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import message_log_regis.Register_message;
import private_message.Private_info;
import serve.Private_Chat_Serve;
import tools.Icon_tools;
import tools.RedisUtill;
import tools.SendMailUtills;

public class Regist_handle extends SimpleChannelInboundHandler<Register_message>{
	
	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Register_message register_message) throws Exception {

		System.out.println("服务器收到 Register_message");
	
		int step = register_message.getStep();
		
		if(step==1) {heandle_type1(ctx, register_message);}
		else if(step==3) {heandle_type3(ctx, register_message);}
	}
	
	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {		
	
		ctx.channel().close().sync();
	}
	
	public void heandle_type1(ChannelHandlerContext ctx, Register_message register_message) {
		
		String email = register_message.getEmail();
		String password = register_message.getPassword();
		String verify_code = null;
		
			int random_code = (int)(Math.random()*888888+111111);
			String body = "验证码： "+random_code+", 5分钟内有效，请尽快完成后续注册步骤！";
			
			try {
				RedisUtill.put_register_info(email, password);
			} catch (Exception e) {
				e.printStackTrace();
			}
						
			SendMailUtills.SendMail_WithQQ(email, "优兔即时通信", body);
			
			verify_code = email+","+random_code;
			register_message = new Register_message(2,verify_code);
		
		ctx.writeAndFlush(register_message);
	}
	
public void heandle_type3(ChannelHandlerContext ctx, Register_message register_message) {
		
	byte[] head_icon = register_message.getHead_icon();
	String name = register_message.getName();
	String sex = register_message.getSex();
	String birth = register_message.getBirth();
	String blood = register_message.getBlood();
	String home = register_message.getHome();
	String phone = register_message.getPhone();
	String e_mail = register_message.getEmail();
	String signature = register_message.getSignature();
	String state = register_message.getState();
	
	String password = RedisUtill.get_register_info(e_mail);
	String account = null;
	
	if(password==null) {
		register_message = new Register_message(4, "", "", "192.168.31.203", 3253);
		ctx.writeAndFlush(register_message);
		return;
	}

	account =  Register_generate.getAnd_Init_new_user(name, password, e_mail);
	
   	String out_file = "D:\\UTO_server\\image\\private_head_image\\big_head_image\\"+account+".png";
		
	  Icon_tools.Write_image(head_icon, out_file);
	  Icon_tools.compress_head_image(account,head_icon);
	  
	Private_info private_info = new Private_info(account, null, name, sex, birth, blood, home, phone, e_mail, signature, state);
	Private_info_generate.update_info(private_info);
	
	Private_Chat_Serve.add_user();
	
	System.out.println("服务端开始返回账号。。。"+account);
	register_message = new Register_message(4, account, password, "192.168.31.203", 3253);
	ctx.writeAndFlush(register_message);
	
	}
}
