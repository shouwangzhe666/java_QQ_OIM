package udp_pack;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class UDP_P4P_Server extends Thread{

	InetAddress address1 = null;
	InetAddress address2 = null;
	String ip1 = null;
	String ip2 = null;
	byte[] by = null;
	DatagramSocket socket = null;
	DatagramPacket packet = null;
	
	int[] port1 = null;
	int[] port2 = null;
	volatile boolean first = false;
	int server_port = 0;
	
	public UDP_P4P_Server() {
		this(get_freePort(), true);
	}
	
	public UDP_P4P_Server(int server_port,boolean first) {
		this.server_port = server_port;
		this.first = first;
		
		port1 = new int[4];
		port2 = new int[4];
		
		by = new byte[1024];
		packet = new DatagramPacket(by, by.length);
		
		try {
			socket = new DatagramSocket(server_port);
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		new Time_thread().start();
	}
	
	@Override
	public void run() {
		 while(true) {
			 try {
				socket.receive(packet);
			} catch (IOException e) {
				// TODO Auto-generated catch block
			//	e.printStackTrace();
				break;
			}
			 try {
				String message = new String(packet.getData(),"UTF-8");
		//		System.out.println(message);
				boolean over = resove_string(message.trim(),packet.getSocketAddress().toString().substring(1));
				
				if(over) {
					System.out.println("全部信息收集完毕");
					new Inform_thread().start();
					
					break;
					}   // 全部信息收集完毕
				
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 } //  while(true)
	}
	
	public boolean resove_string(String message,String ipString) {
		
		int num = Integer.parseInt(message);
		String ip = ipString.split(":")[0];
		int port = Integer.parseInt(ipString.split(":")[1]);
				
				if(port1[num-1]==0) {
				//	System.out.println("port1");
					ip1 = ip;
					port1[num-1] = port;
				}
				else if(port1[num-1]!=port){
				//	System.out.println("port2");
					ip2 = ip;
					port2[num-1] = port;					
				}
		        
		      int total = port1[0]*port1[1]*port1[2]*port1[3]*port2[0]*port2[1]*port2[2]*port2[3];
		      boolean over = false;
		      
		      if(total!=0&&ip1!=null&&ip2!=null) {
		    	  try {
					address1 = InetAddress.getByName(ip1);
					address2 = InetAddress.getByName(ip2);
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    	     over = true;
		    	  }
		      
		      return over;
	}  // resove_string
	
	private class Inform_thread extends Thread{
		DatagramPacket packet = null;
		String string = null;
		byte[] by = null;
		
		public Inform_thread() {
			// TODO Auto-generated constructor stub
		}
		
		@Override
		public void run() {
			 for(int i=0;i<1;i++) {
				 for(int j=0;j<4;j++) {
					
					 string = String.valueOf(j+1)+":"+ip1+":"+port1[j];
		//			 System.out.println("sender "+string);
					 try {
						by = string.getBytes("UTF-8");
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					 packet = new DatagramPacket(by,by.length, address2,port2[j]);
					 try {
						socket.send(packet);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					 try {
						Thread.sleep(50);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				 }// for
				 } // for
//			 try {
//				Thread.sleep(1000);
//			} catch (InterruptedException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
			 for(int i=0;i<1;i++) {
				 for(int j=0;j<4;j++) {
					 string = String.valueOf(j+1)+":"+ip2+":"+port2[j];
		//			 System.out.println("receiver "+string);
					 try {
						by = string.getBytes("UTF-8");
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					 packet = new DatagramPacket(by,by.length, address1,port1[j]);
					 try {
						socket.send(packet);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					 try {
							Thread.sleep(50);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}				
			 } // for
		}// for
			 socket.close();
			 if(first) {new Check_thread().start();}
	}
}
	private class Check_thread extends Thread{
		@Override
		public void run() {
		    try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    System.out.println("Check_thread start");
		    new UDP_P4P_Server(server_port, false).start();
		}
	}
	private class Time_thread extends Thread{
		@Override
		public void run() {
		    try {
				Thread.sleep(60000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
		    if(!socket.isClosed()) {socket.close();}	  
		}
	}
	public int get_server_port() {
		return server_port;
	}
	private static int get_freePort() {
		DatagramSocket datagramSocket=null;
		try {
			datagramSocket = new DatagramSocket();
		} catch (SocketException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int server_port = datagramSocket.getLocalPort();
		datagramSocket.close();
		
		return server_port;
	}
	
	public static void main(String[] args) {
		
		UDP_P4P_Server server1 = new UDP_P4P_Server();
		server1.start();
		
		UDP_P4P_Server server2 = new UDP_P4P_Server();
		server2.start();
//		
//		UDP_P4P_Server server3 = new UDP_P4P_Server();
//		server3.start();
//		UDP_P4P_Server server4 = new UDP_P4P_Server();
//		server4.start();
		
		System.out.println("server_port1: "+server1.get_server_port());
		System.out.println("server_port2: "+server2.get_server_port());
		
	}
}
