package Group_handle;

import java.sql.Connection;
import database_generat.Group_member_generate;
import database_generat.Link_man_generate;
import group_message.Group_chat_message;
import serve.Group_Chat_Serve;

public class Group_chat_handle{
			
	public static void handle_group_message(String group_account,Group_Chat_Serve chat_Serve,Group_chat_message chat_message) {
		
		       int type = chat_message.getType();
		       
		       if(type==4) {handle_type4(group_account, chat_message);}
		       else if(type==5) {handle_type5(group_account, chat_Serve, chat_message);}
		       else if(type==6) {handle_type6(group_account, chat_Serve, chat_message);}
		       else if(type==7) {handle_type7(group_account, chat_message);}
		       else if(type==8||type==9) {handle_type8_9(type,group_account, chat_Serve, chat_message);return;}
		       else if(type==12) {handle_type12(chat_message, chat_Serve);}
	}

	public static void handle_type4(String group_account,Group_chat_message chat_message) {
		
		int member_account = chat_message.getMember_account();
		boolean open_shutup = chat_message.isOpen_shutup();
		long send_time = chat_message.getSend_time();
		int shutup_minites = chat_message.getShutup_minites();
		
		if(open_shutup) {
			shutup_minites*=60000;
			send_time+=shutup_minites;
			Link_man_generate.alter_link_man(String.valueOf(member_account),group_account,"state",String.valueOf(send_time));
		}
		else {Link_man_generate.alter_link_man(String.valueOf(member_account),group_account,"state","0");}
	}
public static void handle_type5(String group_account,Group_Chat_Serve chat_Serve,Group_chat_message chat_message) {
		
	     int member_account = chat_message.getMember_account();
	     boolean set_Administrator = chat_message.isSet_Administrator();
	     String group_id = set_Administrator?"管理员":"成员";
	     
	     Connection connection = chat_Serve.get_group_connection();
	     Group_member_generate.alter_member_info(connection,group_account,String.valueOf(member_account),"id",group_id);
	     chat_Serve.return_group_connection(connection);
	     
	     Link_man_generate.alter_link_man(String.valueOf(member_account),group_account,"id",group_id);
	}
public static void handle_type6(String group_account,Group_Chat_Serve chat_Serve,Group_chat_message chat_message) {
	
	int member_account = chat_message.getMember_account();
    String group_id = chat_message.getGroup_id();
    
    Connection connection = chat_Serve.get_group_connection();
    Group_member_generate.alter_member_info(connection,group_account,String.valueOf(member_account),"id",group_id);
    chat_Serve.return_group_connection(connection);
    
    Link_man_generate.alter_link_man(String.valueOf(member_account),group_account,"id",group_id);
}
public static void handle_type7(String group_account,Group_chat_message chat_message) {
	
	int member_account = chat_message.getMember_account();
	Group_member_generate.delete_member(group_account, String.valueOf(member_account));
	Link_man_generate.delete_link_man(String.valueOf(member_account), group_account);
}

public static void handle_type8_9(int type,String group_account,Group_Chat_Serve chat_Serve,Group_chat_message chat_message) {
	
	if(type==8) {
		int member_account = chat_message.getMember_account();
		String group_remark = chat_message.getGroup_remark();
		
		 Connection connection =chat_Serve.get_group_connection();
		 Group_member_generate.alter_member_info(connection,group_account,String.valueOf(member_account),"group_remark",group_remark);
		 chat_Serve.return_group_connection(connection);
		 
		 Link_man_generate.alter_link_man(String.valueOf(member_account), group_account, "signature", group_remark);
	}
}
public static void handle_type12(Group_chat_message chat_message,Group_Chat_Serve chat_Serve) {
	
	chat_Serve.setAll_shutup(chat_message.isAll_shutup());
	chat_Serve.setTemp_chat(chat_message.isTemp_chat());
}
}
