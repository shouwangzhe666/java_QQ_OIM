package Group_handle;

// author: jiang quan feng
// date : 2020.01.11

import java.io.UnsupportedEncodingException;

import MainThread_pack.GroupFile_load_server;
import MainThread_pack.GroupFile_unload_server;
import database_generat.Group_file_generate;
import database_generat.Group_icon_generate;
import database_generat.Group_info_generate;
import database_generat.Group_member_generate;
import database_generat.Group_notice_generate;
import database_generat.Group_restore_generate;
import group_message.Group_chat_message;
import group_message.Group_info_message;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import serve.Group_Chat_Serve;
import tools.File_tool;

public class Group_info_handle extends SimpleChannelInboundHandler<Group_info_message> {
   
	public Group_info_handle() {
	}
	
	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Group_info_message group_info) throws Exception {
		
		int type =  group_info.getType();
		System.out.println("server 收到 Group_info_message type="+type);
		
		switch (type) {
		
		case 1:handle_info_request(ctx, group_info);break;
		case 13:handle_info_update(group_info);break;
		
		case 2: handle_member_request(ctx, group_info);break;
		
		case 3:  handle_notice_request(ctx, group_info);break;
		case 31: handle_notice_put(group_info);break;
		case 32: handle_notice_delete(group_info);break;
		case 33: handle_notice_alter(group_info);break;
		
		case 4:  handle_icon_request(ctx, group_info);break;
		case 41: handle_icon_put(group_info);break;
		case 42: handle_icon_delete(group_info);break;
		
		case 5: handle_file_request(ctx, group_info);break;		
		case 52: handle_file_delete(group_info);break;
		case 53: handle_file_rename(group_info);break;
		
		case 55: handle_file_unload(ctx, group_info);break;
		
		default:System.out.println("服务端无法处理此Group_info_message");break;			
	}
	}
   
	public void handle_info_request(ChannelHandlerContext ctx, Group_info_message group_info) {
		 Group_info_message group_info_message = Group_info_generate.get_group_info(group_info.getGroup_account());
		 ctx.writeAndFlush(group_info_message);
	}
	public void handle_info_update(Group_info_message group_info) {
		Group_info_generate.alter_group_info(group_info);
		
	}
	public ByteBuf encode_groupSet_message(Group_chat_message chat_message) {
		byte[] group_id = null;
		byte[] group_remark = null;
		ByteBuf buf = Unpooled.buffer(1024, 1024*5);
		try {
			group_id = chat_message.getGroup_id().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			group_remark = chat_message.getGroup_remark().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			buf.writeInt(211);
			
			buf.writeInt(chat_message.getType());
			buf.writeInt(chat_message.getMember_account());
			
			buf.writeInt(group_id.length);
			buf.writeBytes(group_id);
			
			buf.writeInt(group_remark.length);
			buf.writeBytes(group_remark);
			
			buf.writeLong(chat_message.getSend_time());
			buf.writeLong(chat_message.getTime_code());
			
			buf.writeBoolean(chat_message.isAite());
			buf.writeBoolean(chat_message.isReply());
			
			buf.writeBoolean(chat_message.isAll_shutup());
			buf.writeBoolean(chat_message.isTemp_chat());
			
			return buf;
	}
	
	public void handle_member_request(ChannelHandlerContext ctx, Group_info_message group_info) {
		 Group_info_message group_info_message = Group_member_generate.get_all_members(group_info.getGroup_account());
		 ctx.writeAndFlush(group_info_message);
	}
	
	
	public void handle_notice_request(ChannelHandlerContext ctx, Group_info_message group_info) {
		 Group_info_message group_info_message = Group_notice_generate.get_all_notices(String.valueOf(group_info.getGroup_account()));
		 ctx.writeAndFlush(group_info_message);
		
	}
	public void handle_notice_put(Group_info_message group_info) {
		Group_notice_generate.put_new_notice(String.valueOf(group_info.getGroup_account()), group_info.getContent(), group_info.getSender(), group_info.getSend_time());
	}
	public void handle_notice_delete(Group_info_message group_info) {
		Group_notice_generate.delete_notice(String.valueOf(group_info.getGroup_account()), group_info.getSend_time());
	}
	public void handle_notice_alter(Group_info_message group_info) {
		Group_notice_generate.alter_notice_info(String.valueOf(group_info.getGroup_account()), group_info.getContent(),group_info.getSend_time());
	}
	
	
	public void handle_icon_request(ChannelHandlerContext ctx, Group_info_message group_info) {
		 Group_info_message group_info_message = Group_icon_generate.get_all_icons(group_info.getGroup_account());
		 ctx.writeAndFlush(group_info_message);
	}
	public void handle_icon_put(Group_info_message group_info) {
		Group_icon_generate.put_new_icon(group_info);
	}
	public void handle_icon_delete(Group_info_message group_info) {
		Group_icon_generate.delete_icon(group_info);
	}
	
	
	public void handle_file_request(ChannelHandlerContext ctx, Group_info_message group_info) {
		 Group_info_message group_info_message = Group_file_generate.get_all_file(group_info.getGroup_account());
		 ctx.writeAndFlush(group_info_message);
	}
	
	public void handle_file_delete(Group_info_message group_info) {
		Group_file_generate.delete_file(group_info.getGroup_account(),group_info.getSend_time());
	}
	public void handle_file_rename(Group_info_message group_info) {
		boolean s  = Group_file_generate.alter_file_name(group_info);
	
	}
	public void handle_file_unload(ChannelHandlerContext ctx,Group_info_message group_info) {
		System.out.println("群文件上传");
		int group_account = group_info.getGroup_account();
		
		String file_name = group_info.getFile_name();
		long file_size = group_info.getFile_size();
		String sender = group_info.getSender();
		long send_time = group_info.getSend_time();
		
		// put file_record
		Group_file_generate.put_new_file(group_account, file_name, file_size, sender, send_time);
		
		GroupFile_unload_server send_server = new GroupFile_unload_server(group_account, file_name, file_size, sender, send_time);
		send_server.start();
		int port = send_server.get_port();
		String ip = Group_restore_generate.get_ip();
		String ip_port = ip+","+port;
		
		Group_info_message group_info_message = new Group_info_message(57, group_account);
		group_info_message.setIp_port(ip_port);
		group_info_message.setSend_time(send_time);
		ctx.writeAndFlush(group_info_message);
	}
}
