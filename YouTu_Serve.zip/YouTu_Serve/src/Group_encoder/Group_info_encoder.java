package Group_encoder;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import group_message.Group_info_message;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

public class Group_info_encoder extends MessageToByteEncoder<Group_info_message>{

	@Override
	protected void encode(ChannelHandlerContext arg0, Group_info_message group_info, ByteBuf buf) throws Exception {
		
		int type = group_info.getType();
		
		buf.writeInt(213);
		buf.writeInt(type);
		buf.writeInt(group_info.getGroup_account());
		
		if(type<10) { }  // search_request
		else if(type<20) {encode_info(group_info, buf);}
		else if(type<30) {encode_members(group_info, buf);}
		
		else if(type==31) {encode_notice1(group_info, buf);}
		else if(type==32) {encode_notice2(group_info, buf);}
		else if(type==33) {encode_notice3(group_info, buf);}
		else if(type==34) {encode_notice4(group_info, buf);}
		
		else if(type==41) {encode_icon1(group_info, buf);}
		else if(type==42) {encode_icon2(group_info, buf);}
		else if(type==44) {encode_icon4(group_info, buf);}
		
		else if(type==52) {encode_file2(group_info, buf);}
		else if(type==53) {encode_file3(group_info, buf);}
		else if(type==54) {encode_file4(group_info, buf);}
		
		else if(type==55) {encode_file5(group_info, buf);}
		else if(type==56) {encode_file6(group_info, buf);}
		else if(type==57||type==58) {encode_file7_8(group_info, buf);}
		
	}
	
public void encode_info(Group_info_message group_info, ByteBuf buf) {
	  // type==13,14
	byte[] question = null;
	byte[] answer = null;
	
	try {
		 question = group_info.getQuestion().getBytes("UTF-8");
		 answer = group_info.getAnswer().getBytes("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
		try {
			buf.writeInt(group_info.getGroup_name().getBytes("UTF-8").length);
			buf.writeBytes(group_info.getGroup_name().getBytes("UTF-8"));

			buf.writeInt(group_info.getGroup_head_icon().length);
			buf.writeBytes(group_info.getGroup_head_icon());
			
			buf.writeInt(group_info.getGroup_introduce().getBytes("UTF-8").length);
			buf.writeBytes(group_info.getGroup_introduce().getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		buf.writeInt(group_info.getGroup_type());
		buf.writeInt(group_info.getPay_days());
		buf.writeInt(group_info.getPay_money());
		
		buf.writeInt(question.length);
		buf.writeBytes(question);
		buf.writeInt(answer.length);
		buf.writeBytes(answer);
		
		buf.writeBoolean(group_info.isTemporary_chat());
		buf.writeBoolean(group_info.isStop_all_chat());
		buf.writeBoolean(group_info.isFile_upload_all());
		buf.writeBoolean(group_info.isFile_load_all());
		buf.writeBoolean(group_info.isIcon_upload_all());		
	
	}
public void encode_members(Group_info_message group_info, ByteBuf buf) {
	
    ArrayList<ArrayList<Object>> all_members = group_info.getAll_members();
    ArrayList<Object> member = null;
    
    int member_account = 0;
    String member_id = null;
    String group_remark = null;
    long join_time = 0l;
    long last_time = 0l;
    
    buf.writeInt(all_members.size());
    
    for(int i=0;i<all_members.size();i++) {
    	member = all_members.get(i);
    	
    	member_account = (int) member.get(0);
    	member_id =  (String) member.get(1);
    	group_remark = (String) member.get(2);
    	join_time = (long) member.get(3);
    	last_time = (long) member.get(4);
    	
    	try {
    		buf.writeInt(member_account);
			buf.writeInt(member_id.getBytes("UTF-8").length);
			buf.writeBytes(member_id.getBytes("UTF-8"));
			buf.writeInt(group_remark.getBytes("UTF-8").length);
			buf.writeBytes(group_remark.getBytes("UTF-8"));
			buf.writeLong(join_time);
			buf.writeLong(last_time);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }  // member
}

public void encode_notice1(Group_info_message group_info, ByteBuf buf) {
	
	byte[] content = null;
	byte[] sender = null;
	
	try {
		content = group_info.getContent().getBytes("UTF-8");
		sender = group_info.getSender().getBytes("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	buf.writeInt(content.length);
	buf.writeBytes(content);
	buf.writeInt(sender.length);
	buf.writeBytes(sender);
	
	buf.writeLong(group_info.getSend_time());
	System.out.println("client group_info.getContent(): "+group_info.getContent());
}
public void encode_notice2(Group_info_message group_info, ByteBuf buf) {
	
	buf.writeLong(group_info.getSend_time());
}
public void encode_notice3(Group_info_message group_info, ByteBuf buf) {
	
	  encode_notice1(group_info, buf);
}
public void encode_notice4(Group_info_message group_info, ByteBuf buf) {
	
	 ArrayList<ArrayList<Object>> all_notices = group_info.getAll_notices();
     ArrayList<Object> notice = null;
       
     String content = null;
     String sender = null;
     long send_time = 0l;
     
     buf.writeInt(all_notices.size());
     
     for(int i=0;i<all_notices.size();i++) {
     	notice = all_notices.get(i);
     	
     	content = (String) notice.get(0);
     	sender = (String) notice.get(1);
     	send_time = (long) notice.get(2);
     	
     	try {
				buf.writeInt(content.getBytes("UTF-8").length);
				buf.writeBytes(content.getBytes("UTF-8"));
				buf.writeInt(sender.getBytes("UTF-8").length);
				buf.writeBytes(sender.getBytes("UTF-8"));
				buf.writeLong(send_time);

			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
     	
     }  // group_notice
}
public void encode_icon1(Group_info_message group_info, ByteBuf buf) {
	byte[] group_icon = group_info.getGroup_icon();
	byte[] sender = null;
		try {
			sender = group_info.getSender().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		buf.writeInt(group_icon.length);
		buf.writeBytes(group_icon);
		
		buf.writeInt(sender.length);
		buf.writeBytes(sender);
		
		buf.writeLong(group_info.getSend_time());
}
public void encode_icon2(Group_info_message group_info, ByteBuf buf) {
	buf.writeLong(group_info.getSend_time());
}
public void encode_icon4(Group_info_message group_info, ByteBuf buf) {
	 ArrayList<ArrayList<Object>> all_icon = group_info.getAll_icons();
     ArrayList<Object> icon = null;
       
     byte[] icon_bytes = null;
     String sender = null;
     long send_time = 0l;
     
     buf.writeInt(all_icon.size());
     
     for(int i=0;i<all_icon.size();i++) {
     	icon = all_icon.get(i);
     	
     	icon_bytes = (byte[]) icon.get(0);
     	sender = (String) icon.get(1);
     	send_time = (long) icon.get(2);
     	
     	try {

				buf.writeInt(icon_bytes.length);
				buf.writeBytes(icon_bytes);
				buf.writeInt(sender.getBytes("UTF-8").length);
				buf.writeBytes(sender.getBytes("UTF-8"));
				buf.writeLong(send_time);

			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
     	
     }  // group_icon
}

public void encode_file2(Group_info_message group_info, ByteBuf buf) {
	buf.writeLong(group_info.getSend_time());	
}
public void encode_file3(Group_info_message group_info, ByteBuf buf) {
	byte[] file_name = null;
	long send_time = 0l;
	
	try {
		file_name = group_info.getFile_name().getBytes("UTF-8");
		send_time = group_info.getSend_time();
	} catch (UnsupportedEncodingException e) {
		e.printStackTrace();
	}
	
	buf.writeInt(file_name.length);
	buf.writeBytes(file_name);
	buf.writeLong(send_time);
}
public void encode_file4(Group_info_message group_info, ByteBuf buf) {
	 ArrayList<ArrayList<Object>> all_file = group_info.getAll_files();
     ArrayList<Object> file = null;
       
     String name = null;
     long size = 0l;
     String sender = null;
     long send_time = 0l;
     
     buf.writeInt(all_file.size());
     
     for(int i=0;i<all_file.size();i++) {
     	file = all_file.get(i);
     	
     	name =  (String) file.get(0);
     	size =  (long) file.get(1);
     	sender = (String) file.get(2);
     	send_time = (long) file.get(3);
     	
     	try {
				buf.writeInt(name.getBytes("UTF-8").length);
				buf.writeBytes(name.getBytes("UTF-8"));
				buf.writeLong(size);
				buf.writeInt(sender.getBytes("UTF-8").length);
				buf.writeBytes(sender.getBytes("UTF-8"));
				buf.writeLong(send_time);

			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
     	
     }  // group_file
}
public void encode_file5(Group_info_message group_info, ByteBuf buf) {
	byte[] file_name = null;
	long file_size = group_info.getFile_size();
	byte[] sender = null;
	long send_time = group_info.getSend_time();
	try {
		file_name = group_info.getFile_name().getBytes("UTF-8");
		sender = group_info.getSender().getBytes("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	buf.writeInt(file_name.length);
	buf.writeBytes(file_name);
	buf.writeLong(file_size);
	
	buf.writeInt(sender.length);
	buf.writeBytes(sender);
	buf.writeLong(send_time);
	
}
public void encode_file6(Group_info_message group_info, ByteBuf buf) {
	
	byte[] file_name = null;
	long start_position = group_info.getStart_position();
	long send_time = group_info.getSend_time();
	try {
		file_name = group_info.getFile_name().getBytes("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	buf.writeInt(file_name.length);
	buf.writeBytes(file_name);
	buf.writeLong(start_position);		
	buf.writeLong(send_time);
}
public void encode_file7_8(Group_info_message group_info, ByteBuf buf) {
	byte[] ip_port = null;
	long send_time = group_info.getSend_time();
	try {
		ip_port = group_info.getIp_port().getBytes("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	buf.writeInt(ip_port.length);
	buf.writeBytes(ip_port);
	buf.writeLong(send_time);
}

}
