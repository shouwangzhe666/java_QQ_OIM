package Group_encoder;

import group_message.Group_Ping_Pong;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

public class Group_Ping_Pong_encoder extends MessageToByteEncoder<Group_Ping_Pong>{

	@Override
	protected void encode(ChannelHandlerContext arg0, Group_Ping_Pong ping_Pong, ByteBuf buf) throws Exception {
	
		buf.writeInt(210);
		buf.writeInt(ping_Pong.getMember_account());
	}

}
