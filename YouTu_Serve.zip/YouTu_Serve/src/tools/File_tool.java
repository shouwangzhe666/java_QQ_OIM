package tools;

import java.io.File;
import java.io.IOException;

import org.omg.CosNaming.NamingContextExtPackage.StringNameHelper;

public class File_tool {
	
	public static boolean create_new_file(String file_path) {
		
		File file = null;
		file = new File(file_path);
		
		file.getParentFile().mkdirs();
		
		if(!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {			
				e.printStackTrace();
				return false;
			}
		}
		
		return true;
	} // create file
  public  static boolean create_file_folder(String file_path) {
		
		File file = null;
		file = new File(file_path);
		
		if(!file.exists()) {
			file.mkdirs();
			return true;
		}
		
		return false;
	} // create file
  public  static boolean delete_file(String file_path) {
		
		File file = null;
		file = new File(file_path);
		
		if(file.exists()) {
			file.delete();
			return true;
		}
		
		return false;
	} // create file
  public  static boolean rename_file(String file_path,String new_name) {
		
		File file = null;
		file = new File(file_path);
		
	if(file.exists()) {
		String new_path = file.getParentFile().getAbsolutePath()+"\\"+new_name;
		file.renameTo(new File(new_path));
	
		return true;
		}
		
		return false;
	} // create file
public static void main(String[] args) {
	
     File_tool.create_file_folder("D:\\Users\\Administrator\\Desktop\\dff");
}
}
