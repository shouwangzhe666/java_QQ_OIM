package message_log_regis;

// author: jiang quan feng
// date : 2020.01.11

public class Ping_Pong {
	
	static int count = 0;
	int account = 0;
	
	public Ping_Pong() {
		
	  if(Ping_Pong.count!=0) { this.account = Ping_Pong.count;}
	}
	
	public Ping_Pong(int account) {
		this.account = account;
	}
	
	public int get_account() {
		return this.account;
	}
	
	
	public static void set_count(int count) {
		
		Ping_Pong.count = count;
	}
}
