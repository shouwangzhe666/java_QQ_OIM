package message_log_regis;

public class Login_pass_message {
	
	int type = 1;
	String account=null;
	String password=null;
	String new_password = null;
	String email = null;
	
	boolean NativeImage_exist = false;
	int result_type = 1;
	boolean scuess = true;
	String result=null;
	
	int tcp_port1 = 0;
	int tcp_port2 = 0;
	
	public Login_pass_message(int type,String account,String password_email) {
	
		this.type = type;
		this.account = account;
		
		if(type==1) {this.password=password_email;}
		
		else {this.email=password_email;}
	}
	
	public Login_pass_message(String account,String password,String new_password) {
		
		this.type = 2;
		this.account = account;
		this.password=password;
		this.new_password=new_password;
	}
	
	public Login_pass_message(boolean scuess,String result) {
		
		this.type = 4;
		this.scuess = scuess;
		this.result = result;
	}
	
	public Login_pass_message(int tcp_port1, int tcp_port2) {
		this.type = 5;
		this.tcp_port1 = tcp_port1;
		this.tcp_port2 = tcp_port2;
	}
	
	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public boolean isNativeImage_exist() {
		return NativeImage_exist;
	}

	public void setNativeImage_exist(boolean nativeImage_exist) {
		NativeImage_exist = nativeImage_exist;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNew_password() {
		return new_password;
	}

	public void setNew_password(String new_password) {
		this.new_password = new_password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public boolean isScuess() {
		return scuess;
	}
	public void setScuess(boolean scuess) {
		this.scuess = scuess;
	}
	public int getResult_type() {
		return result_type;
	}

	public void setResult_type(int result_type) {
		this.result_type = result_type;
	}
	public int getTcp_port1() {
		return tcp_port1;
	}

	public void setTcp_port1(int tcp_port1) {
		this.tcp_port1 = tcp_port1;
	}

	public int getTcp_port2() {
		return tcp_port2;
	}

	public void setTcp_port2(int tcp_port2) {
		this.tcp_port2 = tcp_port2;
	}	
}
