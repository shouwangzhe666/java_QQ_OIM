package MainThread_pack;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;
import database_generat.Group_file_generate;
import tools.File_tool;

public class GroupFile_unload_server extends Thread{
	
	ServerSocket server = null;
	int group_account = 0;
	
	String file_name = null;
	long file_size = 0;
	String sender = null;
	long send_time = 0l;
	
	long progress = 0l;
	int port = 0;
	boolean connect = false;
	Socket socket = null;
	File file = null;
	DataInputStream dataInputStream = null;
	FileOutputStream fileOutputStream = null;
	
	public GroupFile_unload_server(int group_account,String file_name,long file_size,String sender,long send_time) {
	       
		this.group_account = group_account;
		
		this.file_name = file_name;
		this.file_size = file_size;
		this.sender = sender;
		this.send_time = send_time;
		
		this.port = get_and_start_server();
		
		String path = "D:\\UTO_server\\group_"+group_account+"\\file\\"+file_name;
		File_tool.create_new_file(path);
		file = new File(path);
		
		new Timer().schedule(new Time_check(),10000);  // ten seconds to wait
	}
	
	private int get_and_start_server() {
		
		for(int i=10000;i<60000;i++) {
			
			try {
				server = new ServerSocket(i);
			} catch (IOException e) {
				continue;
			}
		
			return i;
		}
		return 0;
	}  //get_new_port
	
	public int get_port() {
		return this.port;
	}
	
	@Override
	public void run() {
	
		if(this.port==0) {return;}
		
		byte[]by = new byte[1024];
		int len = 0;
		
		try {
			socket = server.accept();
			dataInputStream = new DataInputStream(socket.getInputStream());
			fileOutputStream = new FileOutputStream(file);
			connect = true;
		} catch (IOException e) {		
			e.printStackTrace();
		}
		
		try {
			while((len=dataInputStream.read(by))!=-1) {
				fileOutputStream.write(by, 0, len);
				progress+=len;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		close_resourse();
		if(progress<file_size) {Group_file_generate.delete_file(group_account, send_time);}
	
	} // run
	
	private class Time_check extends TimerTask{

		@Override
		public void run() {
			
			if(!connect) {
				close_resourse();
				if(progress<file_size) {Group_file_generate.delete_file(group_account, send_time);}
			}
		} // run
		
	}
	public void close_resourse() {
		try {
			if(fileOutputStream!=null) {fileOutputStream.close();}
			if(dataInputStream!=null) {dataInputStream.close();}
			if(socket!=null&&!socket.isClosed()) {socket.close();}
			if(server!=null&&!server.isClosed()) {server.close();}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
}
