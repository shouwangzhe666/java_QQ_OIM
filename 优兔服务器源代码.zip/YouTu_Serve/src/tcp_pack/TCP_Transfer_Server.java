package tcp_pack;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.Timer;
import java.util.TimerTask;

public class TCP_Transfer_Server extends Thread{
    int port = 0;
    ServerSocket serverSocket = null;
    Socket socket1 = null;
    Socket socket2 = null;
    volatile boolean accept_over = false;
    
	public TCP_Transfer_Server() {
		port = get_port();
		
	}
	@Override
	public void run() {
		 // 检查是否连接
		 new Timer().schedule(new TimerTask() {
			
			@Override
			public void run() {
				if(!accept_over) {
					close();
				}
				
			}
		}, 30000);
		 
		try {
			serverSocket = new ServerSocket(port);
			socket1 = serverSocket.accept();
			socket2 = serverSocket.accept();
			
			new Transfer_thread(socket1.getInputStream(), socket2.getOutputStream()).start();
			new Transfer_thread(socket2.getInputStream(), socket1.getOutputStream()).start();
			
			accept_over = true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public int getPort() {
		return port;
	}
	private int get_port() {
		try {
			DatagramSocket datagramSocket = new DatagramSocket();
			this.port = datagramSocket.getLocalPort();
			datagramSocket.close();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this.port;
	}
	public void close() {
		try {
			if(socket1!=null&&!socket1.isClosed()) {socket1.close();}
			if(socket2!=null&&!socket2.isClosed()) {socket2.close();}
			serverSocket.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	private class Transfer_thread extends Thread{
		byte[] by = null;
		int len = 0;
		InputStream inputStream = null;
		OutputStream outputStream = null;
		
		public Transfer_thread(InputStream inputStream,OutputStream outputStream) {
			    this.inputStream = inputStream;
			    this.outputStream = outputStream;
			    by = new byte[1024*8];
		}
		@Override
		public void run() {
		       try {
				while((len=inputStream.read(by))!=-1) {
					     outputStream.write(by, 0,len);
				   }
			} catch (IOException e) {
				e.printStackTrace();
			}
		       try {
					inputStream.close();
					outputStream.close();
				} catch (IOException e1) {
					// TODO AYouTu-generated catch block
					e1.printStackTrace();
				}
		       
		       close();
		}
	}
}
