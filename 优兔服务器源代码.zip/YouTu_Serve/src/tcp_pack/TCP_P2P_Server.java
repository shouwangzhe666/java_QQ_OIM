package tcp_pack;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

public class TCP_P2P_Server extends Thread{
ServerSocket serverSocket = null;
Socket socket = null;
Socket send_socket = null;
Socket receve_socket = null;
byte[] by = null;
String message = null;
byte[] by1 = null;
byte[] by2 = null;
volatile boolean scuess = false;
int local_port = 0;

public TCP_P2P_Server() {
	  
	DatagramSocket datagramSocket=null;
	try {
		datagramSocket = new DatagramSocket();
	} catch (SocketException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	this.local_port  = datagramSocket.getLocalPort();
	datagramSocket.close();
	
	  by = new byte[1024];
	   try {
		serverSocket = new ServerSocket(local_port);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   
	   new Test_thread().start();
}

public int get_server_port() {
	return local_port;
}

@Override
	public void run() {
	  try {
	 for(int i=0;i<2;i++) {
		 
		by = new byte[1024];
		socket = serverSocket.accept();
		socket.getInputStream().read(by);
		message = new String(by, "UTF-8");
		message = message.trim();
		
		if(i==0) {send_socket = socket;}
		else if(i==1) {receve_socket = socket;}
	 }
	 
		by1 = send_socket.getRemoteSocketAddress().toString().getBytes("UTF-8");
		by2 = receve_socket.getRemoteSocketAddress().toString().getBytes("UTF-8");
		
		send_socket.getOutputStream().write(by2, 0, by2.length);
		send_socket.close();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		receve_socket.getOutputStream().write(by1, 0, by1.length);
		receve_socket.close();
		
		serverSocket.close();
		scuess = true;
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
private class Test_thread extends Thread{
	@Override
	public void run() {
		try {
			Thread.sleep(60000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(!scuess) {try {
			serverSocket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}
	}
}

public static void main(String[] args) {
	
	TCP_P2P_Server p2p_Server = new TCP_P2P_Server();
	p2p_Server.start();
	int port = p2p_Server.get_server_port();
	
	System.out.println("port: "+port);
}
}
