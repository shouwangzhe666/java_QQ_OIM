package serve;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLEngine;
import javax.swing.JFrame;

import Group_decoder.Group_info_decoder;
import Group_decoder.Group_search_decoder;
import Group_encoder.Group_info_encoder;
import Group_encoder.Group_search_encoder;
import Group_handle.Group_info_handle;
import Group_handle.Group_search_handle;
import database_generat.Group_restore_generate;
import database_generat.Login_generate;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
import io.netty.handler.codec.LengthFieldPrepender;
import io.netty.handler.ssl.SslHandler;
import io.netty.handler.timeout.IdleStateHandler;
import private_decode_pack.*;
import private_encode_pack.*;
import private_handle_pack.*;
import tools.SslContextFactory;

public class Private_Chat_Serve {
	
	static JFrame jFrame = null;
	static int online_num = 0;
	static int total_num = 3;
	static int group_num = 0;
	
	public Private_Chat_Serve() {
         	
	}
	
	public void start_serve(int port) {
		
	    jFrame = new JFrame();
		jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jFrame.setBounds(400, 100, 400, 400);
		jFrame.setVisible(true);
		update_frame_info();
		
		jFrame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				Login_generate.close_server();
			}
		});
		
		EventLoopGroup boss_group = new NioEventLoopGroup(10);
		EventLoopGroup work_group = new NioEventLoopGroup(100);
		
		ServerBootstrap bootstrap = new ServerBootstrap();
		bootstrap.group(boss_group, work_group).channel(NioServerSocketChannel.class).option(ChannelOption.SO_BACKLOG, 100).childHandler(new ChannelInitializer<Channel>() {

			@Override
			protected void initChannel(Channel channel) throws Exception {
        
//				SSLEngine engine = SslContextFactory.get_serve_sslContext().createSSLEngine();
//				engine.setUseClientMode(false);
//				engine.setNeedClientAuth(true);
//				channel.pipeline().addFirst(new SslHandler(engine));
				
				channel.pipeline().addLast(new LengthFieldBasedFrameDecoder(2*1024*1024, 0, 4, 0, 4));
				channel.pipeline().addLast(new Ping_Pong_Decoder());
				channel.pipeline().addLast(new Private_Chat_Decoder());
				channel.pipeline().addLast(new Link_info_decoder());
				channel.pipeline().addLast(new Link_set_decoder());
				channel.pipeline().addLast(new Private_info_decoder());
				channel.pipeline().addLast(new Login_Pass_decoder());
				channel.pipeline().addLast(new Register_decoder());
				channel.pipeline().addLast(new Group_search_decoder());
				channel.pipeline().addLast(new Apply_decoder());
				
				channel.pipeline().addLast(new LengthFieldPrepender(4));
				channel.pipeline().addLast(new Ping_Pong_encoder());
				channel.pipeline().addLast(new Private_Chat_encoder());
				channel.pipeline().addLast(new Link_info_encoder());
				channel.pipeline().addLast(new Link_set_encoder());
				channel.pipeline().addLast(new Private_info_encoder());
				channel.pipeline().addLast(new Login_Pass_encoder());
				channel.pipeline().addLast(new Register_encoder());
				channel.pipeline().addLast(new Group_search_encoder());				
				channel.pipeline().addLast(new Apply_encoder());
		                  
				channel.pipeline().addLast(new IdleStateHandler(1300,600, 0, TimeUnit.SECONDS));
				channel.pipeline().addLast(new Ping_Pong_Handle());
				channel.pipeline().addLast(new Chat_handle());
				channel.pipeline().addLast(new Private_info_handle());
				channel.pipeline().addLast(new Link_info_handle());
				channel.pipeline().addLast(new Link_set_handle());
				channel.pipeline().addLast(new Login_Pass_handle());
				channel.pipeline().addLast(new Regist_handle());
				channel.pipeline().addLast(new Group_search_handle());				
				channel.pipeline().addLast(new Apply_handle());
				
			}
		});
		
		ChannelFuture future = null;
		try {
			 future = bootstrap.bind(port).sync();
		} catch (InterruptedException e) {		
			e.printStackTrace();
		}
		
		 System.out.println("server start !");
		 
		try {
			future.channel().closeFuture().sync();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	    boss_group.shutdownGracefully();
	    work_group.shutdownGracefully();
	}
	
	public static void update_online() {
		online_num = Ping_Pong_Handle.all_users.size();
		update_frame_info();
	}
	public static void add_user() {
		total_num++;
		update_frame_info();
	}
	public static void add_group() {
		group_num++;
	}
	public static void update_frame_info() {
		String title = "在线人数："+online_num+"    总人数："+total_num+"    群聊："+group_num;
		jFrame.setTitle(title);
	}
	public static void main(String[] args) {
		   
		   Group_restore_generate.restart_all_group_server();
		   new Private_Chat_Serve().start_serve(3253);
		  
	}
}
