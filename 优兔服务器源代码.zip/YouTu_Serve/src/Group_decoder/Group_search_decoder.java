package Group_decoder;

import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import database_generat.Connection_Pool;
import database_generat.Group_info_generate;
import database_generat.Group_member_generate;
import database_generat.Group_restore_generate;
import database_generat.Link_man_generate;
import database_generat.Login_generate;
import database_generat.Off_message_generage;
import group_message.Group_info_message;
import group_message.Group_search_message;
import io.netty.buffer.ByteBuf;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import private_handle_pack.Ping_Pong_Handle;
import private_message.Link_info;

public class Group_search_decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> list) throws Exception {
		buf.readerIndex(0);
		if(buf.readableBytes()==0) {return;}
		
		int protocol_code = buf.readInt();
		
		if(protocol_code==212) {
			
			int type = buf.readInt();
			
			System.out.println("server decoder type="+type);
			
			if(type==1) {decode_type1(buf, list);}
			else if(type==2) {decode_type2(buf, list);}
			else if(type==3) {decode_type3(buf, list);}
			else if(type==4) {decode_type4(buf, list);}
			else if(type==5) {decode_type5(buf, list);}
			else if(type==6) {decode_type6(buf, list);}
			else if(type==7) {decode_type7(buf, list);}
		}
		else {
			buf.retain();
			ctx.fireChannelRead(buf);
		}
		
	}

   public void decode_type1(ByteBuf buf, List<Object> list) {
	   
	    byte[] group_type = null;
		byte[] group_name = null;
		byte[] group_ower_account = null;
		
		group_type = new byte[buf.readInt()];
		buf.readBytes(group_type);
		group_name = new byte[buf.readInt()];
		buf.readBytes(group_name);
		group_ower_account = new byte[buf.readInt()];
		buf.readBytes(group_ower_account);
		
		Group_search_message search_message = new Group_search_message(1);
		try {
			search_message.setGroup_type(new String(group_type,"UTF-8"));
			search_message.setGroup_name(new String(group_name,"UTF-8"));
			search_message.setGroup_ower_account(new String(group_ower_account,"UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		list.add(search_message);
   } // decode_type1
   
   public void decode_type2(ByteBuf buf, List<Object> list) {
	   
	    boolean scuess = false;
		byte[] group_account = null;
		
		scuess = buf.readBoolean();
		group_account = new byte[buf.readInt()];
		buf.readBytes(group_account);
		
		Group_search_message search_message = new Group_search_message(2);
		try {
		      search_message.setScuess(scuess);
		      search_message.setGroup_account(new String(group_account,"UTF-8"));
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		list.add(search_message);
   } // decode_type2
   
   public void decode_type3(ByteBuf buf, List<Object> list) {
	   
	    byte[] group_account = null;
	   
	    group_account = new byte[buf.readInt()];
		buf.readBytes(group_account);
		
		Group_search_message search_message = new Group_search_message(3);
		try {
		      search_message.setGroup_account(new String(group_account,"UTF-8"));
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		list.add(search_message);
	   
   }  // decode_type3
   
   public void decode_type4(ByteBuf buf, List<Object> list) {
	   
	     byte[] group_type = null;
		 int pay_money = 0;
		 byte[] question = null;
		 byte[] answer = null;
		 byte[] group_icon = null;
		 byte[] group_account = null;
		 byte[] group_name = null;
		 
		    group_type = new byte[buf.readInt()];
			buf.readBytes(group_type);
			
			pay_money = buf.readInt();
			question = new byte[buf.readInt()];
			buf.readBytes(question);
			answer = new byte[buf.readInt()];
			buf.readBytes(answer);
			
			group_icon = new byte[buf.readInt()];
			buf.readBytes(group_icon);
			group_account = new byte[buf.readInt()];
			buf.readBytes(group_account);
			group_name = new byte[buf.readInt()];
			buf.readBytes(group_name);
			
			Group_search_message search_message = new Group_search_message(4);
			try {
			      search_message.setGroup_type(new String(group_type,"UTF-8"));
			      search_message.setPay_money(pay_money);
			      search_message.setGroup_icon(group_icon);
			      search_message.setGroup_account(new String(group_account,"UTF-8"));
			      search_message.setGroup_name(new String(group_name,"UTF-8"));
				
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			list.add(search_message);
   }  // decode_type4
   
   public void decode_type5(ByteBuf buf, List<Object> list) {
	   
	    byte[] group_type = null;
	    byte[] group_account = null;
		byte[] native_icon = null;
		byte[] native_name = null;
		byte[] native_account = null;
		byte[] verify_message = null;
		
		group_type = new byte[buf.readInt()];
		buf.readBytes(group_type);
		group_account = new byte[buf.readInt()];
		buf.readBytes(group_account);
		native_icon = new byte[buf.readInt()];
		buf.readBytes(native_icon);
		native_name = new byte[buf.readInt()];
		buf.readBytes(native_name);
		native_account = new byte[buf.readInt()];
		buf.readBytes(native_account);
		verify_message = new byte[buf.readInt()];
		buf.readBytes(verify_message);
		
		Group_search_message search_message = new Group_search_message(5);
		try {
		      search_message.setGroup_type(new String(group_type,"UTF-8"));
		      search_message.setGroup_account(new String(group_account,"UTF-8"));
		      search_message.setNative_icon(native_icon);
		      search_message.setNative_name(new String(native_name,"UTF-8"));
		      search_message.setNative_account(new String(native_account,"UTF-8"));
		      search_message.setVerify_message(new String(verify_message,"UTF-8"));
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		list.add(search_message);	   
	 
		// direct_join
		System.out.println("group_type: "+search_message.getGroup_type());
		
		 if(search_message.getGroup_type().equals("1")||search_message.getGroup_type().equals("4")) {
			 try {
				direct_join(new String(group_account,"UTF-8"),new String(native_account,"UTF-8"));
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			 System.out.println("direct_join");
			 search_message = null;
			 return;
		 }
		 
		 System.out.println("转发 加群请求");
		 
		ArrayList<String> all_account = null;
		try {
			all_account = Group_member_generate.get_administer_array(new String(group_account,"UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Connection login_connection = Connection_Pool.get_login_connection();
		String account = null;
		boolean online = false;
		int from_account = 0;
		try {
			from_account = Integer.parseInt(new String(native_account,"UTF-8"));
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		buf.readerIndex(0);
		byte[] content = new byte[buf.readableBytes()];
		buf.readBytes(content);
		
		for(int i=0;i<all_account.size();i++) {
			
			account = all_account.get(i);
			online = Ping_Pong_Handle.all_users.get(Integer.parseInt(account))==null?false:true;
			
			if(online) {Ping_Pong_Handle.all_users.get(Integer.parseInt(account)).writeAndFlush(search_message);}
			else {Off_message_generage.put_off_message(account, System.currentTimeMillis(),1,from_account, content);}
		} // for
		
		Connection_Pool.close_Resourse(login_connection, null, null);
		 search_message = null;
  }  // decode_type5
  
   public void direct_join(String group_account,String nati_account) {
	   
	        Group_info_message group_info_message = null;
	 		try {
	 			group_info_message = Group_info_generate.get_group_info(Integer.parseInt(group_account));
	 		} catch (NumberFormatException e) {
	 			// TODO Auto-generated catch block
	 			e.printStackTrace();
	 		}
	 		 
	 		 String ip_port = group_info_message.getIp_port();
	 		 String join_group_name = group_info_message.getGroup_name();
	 		 
	 		 Group_member_generate.put_new_member(group_account,nati_account);
	 		 Link_man_generate.put_link_group(nati_account, group_account, join_group_name,"成员", ip_port, 3742762088000l);
	 		
	 			 Channel channel = Ping_Pong_Handle.all_users.get(Integer.parseInt(nati_account));
	 			 
	 			 Link_info link_info2 = new Link_info(2);
	 			 link_info2.Init_specified_respose_head_image(group_account);
	 			 channel.writeAndFlush(link_info2);
	 			
	 			 Link_info link_info5 = new Link_info(5);
	 			 link_info5.Init_specified_link_man(nati_account, group_account);
	 			 channel.writeAndFlush(link_info5);			
	 			
	 			Group_search_message search_message = new Group_search_message(6);
	 			search_message.setAccept(true);
			    search_message.setGroup_account(group_account);
				search_message.setNative_account(nati_account);	 				 			  
	 			channel.writeAndFlush(search_message);
	 		
   }
  public void decode_type6(ByteBuf buf, List<Object> list) {
	   
	    boolean accept = false;
		byte[] group_account = null;
		byte[] native_account = null;
		
		accept = buf.readBoolean();
		group_account = new byte[buf.readInt()];
		buf.readBytes(group_account);
		native_account = new byte[buf.readInt()];
		buf.readBytes(native_account);
		
//		Group_search_message search_message = new Group_search_message(6);
//		try {
//		      search_message.setAccept(accept);
//		      search_message.setGroup_account(new String(group_account,"UTF-8"));
//			  search_message.setNative_account(new String(native_account,"UTF-8"));
//		} catch (UnsupportedEncodingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
	//	list.add(search_message);
		
		boolean online = false;
		String ip_port = null;
		String gro_account = null;
		String nati_account = null;
		Channel channel = null;
		try {
			gro_account = new String(group_account,"UTF-8");
			nati_account =  new String(native_account,"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	 	
		
	if(accept) {
	     Group_info_message group_info_message = null;
		try {
			group_info_message = Group_info_generate.get_group_info(Integer.parseInt(new String(group_account,"UTF-8")));
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 channel = Ping_Pong_Handle.all_users.get(Integer.parseInt(nati_account));
		 online  = channel==null?false:true;
		 ip_port = group_info_message.getIp_port();
		 String join_group_name = group_info_message.getGroup_name();
		 
		 Group_member_generate.put_new_member(gro_account,nati_account);
		 Link_man_generate.put_link_group(nati_account, gro_account, join_group_name,"成员", ip_port, 3742762088000l);
		 
		if(online) {
			
//			 Link_info link_info = new Link_info(2);
//			 link_info.Init_specified_respose_head_image(gro_account);
//			 
//			 Link_info link_info2 = new Link_info(5);
//			 link_info2.Init_specified_link_man(nati_account, gro_account);
//			 
//			 channel.writeAndFlush(link_info);
//			 channel.writeAndFlush(link_info2);			 
//			 channel.writeAndFlush(search_message);
			 buf.retain();
			 channel.writeAndFlush(buf);
		}
		else {
			buf.readerIndex(0);
			byte[] content = new byte[buf.readableBytes()];
			buf.readBytes(content);
			
			Off_message_generage.put_off_message(nati_account, System.currentTimeMillis(), 1, 1, content);
		}
	}  // if(accept)
  }  // decode_type6
   public void decode_type7(ByteBuf buf, List<Object> list) {
	   
		byte[] group_account = null;
		byte[] native_account = null;
		
		group_account = new byte[buf.readInt()];
		buf.readBytes(group_account);
		native_account = new byte[buf.readInt()];
		buf.readBytes(native_account);
		
		Group_search_message search_message = new Group_search_message(7);
		try {
		      search_message.setGroup_account(new String(group_account,"UTF-8"));
			  search_message.setNative_account(new String(native_account,"UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		list.add(search_message);
  }  // decode_type6
}
