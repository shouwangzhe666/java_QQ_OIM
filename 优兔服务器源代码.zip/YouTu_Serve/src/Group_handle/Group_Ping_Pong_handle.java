package Group_handle;

import java.sql.Connection;
import java.util.ArrayList;
import database_generat.Group_member_generate;
import database_generat.Group_message_generate;
import group_message.Group_Ping_Pong;
import group_message.Group_chat_message;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import serve.Group_Chat_Serve;

public class Group_Ping_Pong_handle extends SimpleChannelInboundHandler<Group_Ping_Pong>{

	    Group_Chat_Serve chat_Serve = null;
	    String group_account = null;
	    int member_account = 0;
	    boolean online = false;
	    
	    public Group_Ping_Pong_handle(String group_account,Group_Chat_Serve chat_Serve) {
	    	
			this.group_account = group_account;
			this.chat_Serve = chat_Serve;
		}
	    
		@Override
		protected void messageReceived(ChannelHandlerContext ctx, Group_Ping_Pong ping_Pong) throws Exception {
			
		       int account = ping_Pong.getMember_account();
		       
		      if(account!=0&&!online) {		
		    	  
		    	  online = true;
		    	  this.member_account = account;
		    	  chat_Serve.put_user(member_account, ctx.channel());
		    	  
		    	// send all Off_message
		    	  
		    	    Connection connection = chat_Serve.get_group_connection();
		    	    
		    	    ArrayList<byte[]> all_message = Group_message_generate.get_batched_message(connection,group_account, member_account);
			  		PooledByteBufAllocator pooledByteBufAllocator = new PooledByteBufAllocator();
			  		ByteBuf buf = null;
			  		byte[] by = null;
			  		
			  		chat_Serve.return_group_connection(connection);
			  		
			  		Group_chat_message chat_message = new Group_chat_message(12, member_account, 0, "1", "1", 1);
			  		chat_message.setAll_shutup(chat_Serve.isAll_shutup());
			  		chat_message.setTemp_chat(chat_Serve.isTemp_chat());
			  		ctx.writeAndFlush(chat_message);
			  		
			  		for(int i=0;i<all_message.size();i++) {
			  			
			  			by = all_message.get(i);
			  			buf = pooledByteBufAllocator.heapBuffer(1024, 1024000);
			  			buf.writeBytes(by);
			  			ctx.writeAndFlush(buf);
			  		}	 
		      }    			  		
		  }
		     
		@Override
		public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {		
		
			ctx.channel().close().sync();
//			System.out.println("服务端 发生异常。。。");
//			cause.printStackTrace();
		}
		
		@Override
		public void channelInactive(ChannelHandlerContext ctx) throws Exception {
		
//		    System.out.println("服务端  Ping_Pong_Handle Inactive。。。");
		   
		    if(member_account!=0) {
		     chat_Serve.remove_user(member_account);
		    
		    Connection connection = chat_Serve.get_group_connection();
		    
		    String last_time = String.valueOf(System.currentTimeMillis());
		    Group_member_generate.alter_member_info(connection,group_account,String.valueOf(member_account), "last_time",last_time);
		    
		    chat_Serve.return_group_connection(connection);
		    
		    }
		 	ctx.channel().close().sync();
			
		}
		
		@Override
		public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
			
			if(evt instanceof IdleStateEvent) {
				IdleStateEvent idleStateEvent = (IdleStateEvent) evt;
				
				if(idleStateEvent.state().equals(IdleState.READER_IDLE)) {
				
						System.out.println("Group服务端某客户心跳超时");
						ctx.channel().close().sync();
				} // if
				if(idleStateEvent.state().equals(IdleState.WRITER_IDLE)) {
					  
					 ctx.channel().writeAndFlush(new Group_Ping_Pong(0));
				}
			} // if
	}
}
