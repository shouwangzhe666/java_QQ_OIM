package Group_handle;

import group_message.Group_file_message;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

public class Group_file_message_handle extends SimpleChannelInboundHandler<Group_file_message>{

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Group_file_message file_message) throws Exception {
		
		int type = file_message.getType();
		
		if(type==1) {handle_type1(ctx,file_message);}
		else if(type==2) {handle_type2(ctx,file_message);}
		
	}

public void handle_type1(ChannelHandlerContext ctx,Group_file_message file_message) {
	
}
public void handle_type2(ChannelHandlerContext ctx,Group_file_message file_message) {
		// server accept
	}

}
