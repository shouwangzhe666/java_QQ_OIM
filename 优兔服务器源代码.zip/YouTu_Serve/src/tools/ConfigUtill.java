package tools;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class ConfigUtill {
	
	String path = null;
	BufferedReader reader = null;
	String server_ip = "192.168.31.203";
	String from_port = "10000";
	String to_port = "60000";
	String send_email = "xxxxxx@qq.com";
	String send_password = "abcdefg";
	
	public ConfigUtill() {
		
		path = System.getProperty("user.dir")+"\\Server_Config.txt";
		try {
			reader = new BufferedReader(new InputStreamReader(new FileInputStream(path)));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(0);
		}
		
		try {
			server_ip = reader.readLine().split(":")[1].trim();
			from_port = reader.readLine().split(":")[1].trim();
			to_port = reader.readLine().split(":")[1].trim();
			send_email = reader.readLine().split(":")[1].trim();
			send_password = reader.readLine().split(":")[1].trim();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(0);
		}
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public BufferedReader getReader() {
		return reader;
	}

	public void setReader(BufferedReader reader) {
		this.reader = reader;
	}

	public String getServer_ip() {
		return server_ip;
	}

	public void setServer_ip(String server_ip) {
		this.server_ip = server_ip;
	}

	public String getFrom_port() {
		return from_port;
	}

	public void setFrom_port(String from_port) {
		this.from_port = from_port;
	}

	public String getTo_port() {
		return to_port;
	}

	public void setTo_port(String to_port) {
		this.to_port = to_port;
	}

	public String getSend_email() {
		return send_email;
	}

	public void setSend_email(String send_email) {
		this.send_email = send_email;
	}

	public String getSend_password() {
		return send_password;
	}

	public void setSend_password(String send_password) {
		this.send_password = send_password;
	}

}
