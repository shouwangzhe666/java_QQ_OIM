package tools;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;


public class Icon_tools {

public static byte[] get_Big_HeadIcon_Bytes(String account) {
	
	String icon_path = "C:\\UTO_server\\image\\private_head_image\\big_head_image\\"+account+".png";
	if(!new File(icon_path).exists()) {icon_path = "C:\\UTO_server\\image\\private_head_image\\big_head_image\\default_image.png";}
	return get_IconBytes(icon_path);
	
}
public static byte[] get_Small_HeadIcon_Bytes(String account) {
	
	String icon_path = "C:\\UTO_server\\image\\private_head_image\\small_head_image\\"+account+".png";
	if(!new File(icon_path).exists()) {icon_path = "C:\\UTO_server\\image\\private_head_image\\small_head_image\\default_image.png";}
	return get_IconBytes(icon_path);
	
}

public static byte[] get_IconBytes(String icon_path) {
		
    	FileInputStream fileInputStream = null;
    	try {
			fileInputStream = new FileInputStream(icon_path);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	
    	ByteBuf buf = Unpooled.buffer(50*1024,2*1024*1024);
    	byte[] by = new byte[1024];
    	int len = 0;
    	
    	try {
			while((len = fileInputStream.read(by))!=-1) {
				buf.writeBytes(by, 0, len);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	by = new byte[buf.readableBytes()];
    	buf.readBytes(by);
    	
    	try {
			fileInputStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	buf.release();
    	
    	return by;
	}
	
 public static boolean Write_image(byte[] icon_bytes,String out_file) {
		
		File_tool.create_new_file(out_file);
		
		FileOutputStream fileOutputStream = null;
		try {
			fileOutputStream = new FileOutputStream(out_file);
		
		} catch (FileNotFoundException e) {
			System.out.println("FileNotFoundException");
			return false;
		}
		try {
			fileOutputStream.write(icon_bytes, 0, icon_bytes.length);
		} catch (IOException e) {
			System.out.println("write iconbytes error !");
			try {
				fileOutputStream.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return false;
		}
		try {
			fileOutputStream.close();
		} catch (IOException e) {
			return false;
		}
		
		return true;
}
 
 public static boolean compress_head_image(String account,byte[] icon_bytes) {
	 
	 System.out.println("compress_head_image account: "+account);
	 
	 String big_head_path = "C:\\UTO_server\\image\\private_head_image\\big_head_image\\"+account+".png";
	 String smal_head_path = "C:\\UTO_server\\image\\private_head_image\\small_head_image\\"+account+".png";
	
	 File_tool.create_new_file(smal_head_path);
	
	 BufferedImage bufferedImage = get_head_image(new ImageIcon(icon_bytes), 40);
	 try {
		ImageIO.write(bufferedImage, "png", new FileOutputStream(smal_head_path));
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return true;
 }
 
 public static BufferedImage get_head_image(ImageIcon imageIcon,int icon_width) {
		
		BufferedImage ori_image = new BufferedImage(imageIcon.getIconWidth(), imageIcon.getIconHeight(), BufferedImage.TYPE_4BYTE_ABGR);
		Graphics2D g2  = (Graphics2D) ori_image.getGraphics();
		g2.drawImage(imageIcon.getImage(), 0, 0, null);
		g2.dispose();
		
		 BufferedImage formatAvatarImage = new BufferedImage(icon_width, icon_width, BufferedImage.TYPE_4BYTE_ABGR);
	        Graphics2D graphics =(Graphics2D) formatAvatarImage.createGraphics();
	        //把图片切成一个圓
	            graphics.setStroke(new BasicStroke(0.1f));
	            graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	            //留一个像素的空白区域，这个很重要，画圆的时候把这个覆盖
	            int border = 1;
	            //图片是一个圆型
	            Ellipse2D.Double shape = new Ellipse2D.Double(0, 0,icon_width, icon_width);
	            //需要保留的区域
	            graphics.setClip(shape);
	            graphics.drawImage(ori_image, 0, 0,icon_width, icon_width, null);
	            graphics.dispose();
	          
	            Graphics2D graphics1 = (Graphics2D)formatAvatarImage.createGraphics();
	            graphics1.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	          
	            //画笔是4.5个像素，BasicStroke的使用可以查看下面的参考文档
	            //使画笔时基本会像外延伸一定像素，具体可以自己使用的时候测试
	            Stroke s = new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
	            graphics1.setStroke(s);
	            
	            int average_rgb = get_average_rgb(ori_image, icon_width/2);
	            graphics1.setColor(new Color(average_rgb));
	            graphics1.drawOval(0,0, icon_width-1, icon_width-1);
	           
	            graphics1.dispose();
	            
	            return formatAvatarImage;
	            
	            }
	
public static int get_average_rgb(BufferedImage ori_image,int ovl_r) {
	  //get_average_rgb of rang of the circle of ori_image
	  
	    int width = ori_image.getWidth();
	    int height = ori_image.getHeight();
	    
	    int o_x = width/2;
	    int o_y = height/2;
	    int b_x = 0;
	    int b_y = 0;
	    int average_rgb = 0;
	    
	    for(int i=0;i<360;i++) {
	    	b_x = get_point_x(o_x, o_x-1, i);
	    	b_y = get_point_y(o_y, o_x-1, i);
	    	average_rgb+=ori_image.getRGB(b_x, b_y);
	    }
	    
	    return average_rgb/360;
}

public static  int get_point_x(int o_x,int r,int angle) {
		// get point_x of circle 
		int x1   =   (int) (o_x + r *Math.cos(Math.toRadians(angle)));
		return x1;
	}
	
public static  int get_point_y(int o_y,int r,int angle) {
	// get point_y of circle 
		int y1   =   (int) (o_y + r *Math.sin(Math.toRadians(angle)));
		return y1;
	}

public static void main(String[] args) {
	 
	    ImageIcon imageIcon = new ImageIcon("C:\\UTO_server\\image\\private_head_image\\big_head_image\\default_image.png");
	    BufferedImage bufferedImage = Icon_tools.get_head_image(imageIcon, 40);
	    try {
		 boolean scuess =ImageIO.write(bufferedImage, "png", new FileOutputStream("C:\\UTO_server\\image\\private_head_image\\small_head_image\\default_image.png"));
		 System.out.println("scuess? "+scuess);
		 
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
}
