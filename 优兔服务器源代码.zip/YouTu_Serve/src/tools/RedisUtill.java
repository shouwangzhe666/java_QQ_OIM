package tools;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class RedisUtill {

	   static JedisPool jedisPool;//非切片连接池
       static {
    	    //  初始化非切片池
    	    JedisPoolConfig config = new JedisPoolConfig();
	        config.setMaxActive(1000); 
	        config.setMaxIdle(1000); 
	        config.setMaxWait(1000l); 
	        config.setTestOnBorrow(false); 
	        
	        jedisPool = new JedisPool(config,"localhost",6379);
       }
	 
  public static void put_register_info(String email,String password) {
	    	
	    	try {
	    		Jedis jedis = jedisPool.getResource(); 
	    		jedis.setex(email,300,password);
		    	jedisPool.returnResource(jedis);
		    	
			} catch (Exception e) {			
				  e.printStackTrace();
				  System.out.println("没有打开redis-server!");
				  
			}
	    	
	    }
	    
  public static String get_register_info(String email) {
	    	Jedis jedis = jedisPool.getResource(); 
	    	String passward = jedis.get(email);
	    	jedisPool.returnResource(jedis);
	    	return passward;
	    }
//  public static void set_Account_IP(String account,String ip) {
//  	Jedis jedis = jedisPool.getResource(); 
//  	jedis.hset("accountip", account, ip);
//  	jedisPool.returnResource(jedis);
//}
//  
//public static String get_Account_IP(String account) {
//	Jedis jedis = jedisPool.getResource(); 
//  	String ip = jedis.hget("accountip", account);
//  	jedisPool.returnResource(jedis);
//  	return ip;
//  }	    
  public static void set_IP_Info(String ip,String RemoteIp) {
	    	Jedis jedis = jedisPool.getResource(); 
	    	jedis.hset("ip", ip, RemoteIp);
	    	jedisPool.returnResource(jedis);
	  }
	    
  public static String get_Ip_Info(String ip) {
    	    Jedis jedis = jedisPool.getResource(); 
	    	String ipInfo = jedis.hget("ip",ip);
	    	jedisPool.returnResource(jedis);
	    	return ipInfo;
	    }
}
