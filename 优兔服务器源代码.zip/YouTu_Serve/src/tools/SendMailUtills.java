package tools;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.GeneralSecurityException;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Header;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.sun.mail.util.MailSSLSocketFactory;

public class SendMailUtills {


    /**
     * 发送邮件到自己的163邮箱
     * @param title 需要传输的标题
     * @param body 需要传输的内容
     * @return
     */

	  /**
     * 发送邮件，获取参数，和标题还有内容
     * @param props 参数
     * @param title 标题
     * @param body 内容
     * @return
     */
    private  static Boolean send(Properties props, String title, String body){
        //发送邮件地址
        final String username=props.getProperty("username");
        //发送邮件名称
        final String password=props.getProperty("password");
        //接收邮件地址
        String to=props.getProperty("to");

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {
            Message message = new MimeMessage(session);

            message.setFrom(new InternetAddress(username));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            message.setSubject(title);
            message.setContent(body,"text/html;charset=utf-8");

            Transport.send(message);
        } catch (AddressException e) {
            e.printStackTrace();
        } catch (MessagingException e) {
            e.printStackTrace();
        }


        return true;
    }
    
    /**
     * 获取系统当前的时间
     * 以传入时间格式返回，传空返回默认格式
     * @param format 时间格式
     * @return
     */
    private  static  String getTitleTimeFormat(String format){
        if (format==null){
            format="yyyy-MM-dd HH:mm:ss/SSS";
        }
        SimpleDateFormat df = new SimpleDateFormat(format);//设置日期格式
        return df.format(new Date());// new Date()为获取当前系统时间
    }

    /**
     * 发送邮件到自己的163邮箱
     * @param title 需要传输的标题
     * @param body 需要传输的内容
     * @return
     */
    
    public  static  boolean SendMail_With163(String send_email,String send_password,String to_email,String title, String body) {

        //设置参数
        Properties props = new Properties();
        props.put("mail.smtp.ssl.enable", "true");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.163.com");
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.port", 465);
        //自定义信息
        props.put("username", send_email);//你的邮箱
        props.put("password", send_password);//你的密码
        props.put("to", to_email);//接收的邮箱

        return send(props,title,body);
    }
  
    public static void SendMail_WithQQ( String SendQQ_email,String SendQQ_password,String to_email,String title,String content) {    	

  	  // 收件人邮箱,不仅仅QQ邮箱
      String to = to_email;

      // 发件人电子邮箱,你生成授权码的QQ邮箱
      String from = SendQQ_email;

      // 指定发送邮件的主机为 smtp.qq.com
      String host = "smtp.qq.com";  //QQ 邮件服务器

      // 获取系统属性
      Properties properties = System.getProperties();

      // 设置邮件服务器
      properties.setProperty("mail.smtp.host", host);

      properties.put("mail.smtp.auth", "true");
  //    properties.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
      MailSSLSocketFactory sf=null;
		try {
			sf = new MailSSLSocketFactory();
		} catch (GeneralSecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      sf.setTrustAllHosts(true);
      properties.put("mail.smtp.ssl.enable", "true");
      properties.put("mail.smtp.ssl.socketFactory", sf);
      // 获取默认session对象
      Session session = Session.getDefaultInstance(properties, new Authenticator(){
          public PasswordAuthentication getPasswordAuthentication()
          {       	 
        	  
              return new PasswordAuthentication(SendQQ_email, SendQQ_password); //登录邮箱及授权码
          }
      });

      try{
          // 创建默认的 MimeMessage 对象
          MimeMessage message = new MimeMessage(session);

          // Set From: 头部头字段
          message.setFrom(new InternetAddress(from));

          // Set To: 头部头字段
          message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

          // Set Subject: 头部头字段
          message.setSubject(title);

          // 设置消息体
          MimeBodyPart textPart = new MimeBodyPart();
          textPart.setContent(content, "text/plain; charset=utf-8"); 
          
          MimeBodyPart filePart = new MimeBodyPart();
          DataHandler dh = new DataHandler(new FileDataSource("E:\\workspace\\优兔服务器源代码.zip"));
          filePart.setDataHandler(dh);
        
          Multipart mp = new MimeMultipart("alternative");//mixed related alternative
          mp.addBodyPart(textPart);
          mp.addBodyPart(filePart);
//          message.setText(content);
//          message.setText(content, "UTF-8");
//           message.setContent(content, "text/plain; charset=utf-8");
            message.setContent(mp, "multipart/ALTERNATIVE");
          // 发送消息
          Transport.send(message);
          System.out.println("Sent message successfully");
      }catch (MessagingException mex) {
          mex.printStackTrace();
      }
  }

    public static void main(String[] args) {
    

    			
	}
}
