package private_encode_pack;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import message_log_regis.Register_message;

public class Register_encoder extends MessageToByteEncoder<Register_message>{

	@Override
	protected void encode(ChannelHandlerContext ctx, Register_message message, ByteBuf buf) throws Exception {
		
		int step = message.getStep();
		if(step==1) {encode_step1(message, buf);}
		else if(step==2) {encode_step2(message, buf);}
		else if(step==3) {encode_step3(message, buf);}
		else if(step==4) {encode_step4(message, buf);}
		message = null;
	}

	public void encode_step1(Register_message message, ByteBuf buf) {
		
		byte[] email = null;
		byte[] password = null;
		try {
			 email = message.getEmail().getBytes("UTF-8");
			 password = message.getPassword().getBytes("UTF-8");
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		buf.writeInt(311);
		buf.writeInt(1);
		
		buf.writeInt(email.length);
		buf.writeBytes(email);
		
		buf.writeInt(password.length);
		buf.writeBytes(password);
		
	}
	
public void encode_step2(Register_message message, ByteBuf buf) {
		
	byte[] verify_code = null;
	
	try {
		verify_code = message.getVerify_code().getBytes("UTF-8");
	
	} catch (Exception e) {
		// TODO: handle exception
	}
	
	buf.writeInt(311);
	buf.writeInt(2);
	
	buf.writeInt(verify_code.length);
	buf.writeBytes(verify_code);
	
	}

public void encode_step3(Register_message message, ByteBuf buf) {
	
	byte[] head_icon = null;
	byte[] name = null;
	byte[] sex=null;
	byte[] birth=null;
	byte[] blood=null;
	byte[] home=null;
	byte[] phone=null;

	byte[] e_mail=null;
	byte[] signature=null;
	byte[] state=null;
	
	try {
		head_icon = message.getHead_icon();
		name = message.getName().getBytes("UTF-8");
		sex = message.getSex().getBytes("UTF-8");
		birth = message.getBirth().getBytes("UTF-8");
		blood = message.getBlood().getBytes("UTF-8");
		home = message.getHome().getBytes("UTF-8");
		phone = message.getPhone().getBytes("UTF-8");
		e_mail = message.getEmail().getBytes("UTF-8");
		signature = message.getSignature().getBytes("UTF-8");
		state = message.getState().getBytes("UTF-8");
	} catch (Exception e) {
		// TODO: handle exception
	}
	
	buf.writeInt(311);
	buf.writeInt(3);
	
	buf.writeInt(head_icon.length);
	buf.writeBytes(head_icon);
	
	buf.writeInt(name.length);
	buf.writeBytes(name);
	
	buf.writeInt(sex.length);
	buf.writeBytes(sex);
	
	buf.writeInt(birth.length);
	buf.writeBytes(birth);
	
	buf.writeInt(blood.length);
	buf.writeBytes(blood);
	
	buf.writeInt(home.length);
	buf.writeBytes(home);
	
	buf.writeInt(phone.length);
	buf.writeBytes(phone);
	
	buf.writeInt(e_mail.length);
	buf.writeBytes(e_mail);
	
	buf.writeInt(signature.length);
	buf.writeBytes(signature);
	
	buf.writeInt(state.length);
	buf.writeBytes(state);
}

public void encode_step4(Register_message message, ByteBuf buf) {
	
	byte[] account = null;
	byte[] password = null;	
	byte[] ip = null;
	int port = 0;
	
	try {
		account = message.getAccount().getBytes("UTF-8");
		password = message.getPassword().getBytes("UTF-8");
		ip = message.getIp().getBytes("UTF-8");
		port = message.getPort();
	} catch (Exception e) {
		
	}
	
	buf.writeInt(311);
	buf.writeInt(4);
	
	buf.writeInt(account.length);
	buf.writeBytes(account);
	
	buf.writeInt(password.length);
	buf.writeBytes(password);
	
	buf.writeInt(ip.length);
	buf.writeBytes(ip);
	
	buf.writeInt(port);
}
}
