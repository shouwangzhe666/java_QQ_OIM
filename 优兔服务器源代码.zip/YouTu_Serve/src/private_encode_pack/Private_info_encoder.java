package private_encode_pack;

import java.io.UnsupportedEncodingException;
import private_message.Private_info;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

public class Private_info_encoder extends MessageToByteEncoder<Private_info>{

	@Override
	protected void encode(ChannelHandlerContext ctx, Private_info private_info, ByteBuf buf) throws Exception {
	
		int type = private_info.getType();
	
		if(type==1) {encode_type1(private_info, buf);}
		else if(type==2) {encode_type2(private_info, buf);}
		else if(type==3) {encode_type3(private_info, buf);}
		else if(type==4) {encode_type4(private_info, buf);}
	}

	 public void encode_type1(Private_info message, ByteBuf buf) {
			
		 buf.writeInt(331);
		 buf.writeInt(1);
		   
		 private_info_encode(message, buf);
		 
		 try {
			 byte[] ip = message.getIp().getBytes("UTF-8");
			 buf.writeInt(ip.length);
			 buf.writeBytes(ip);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	 public void encode_type2(Private_info message, ByteBuf buf) {
		 			
		 buf.writeInt(331);
		 buf.writeInt(2);
		 
		 boolean scuess = false;
		 byte[] result = null;
		 
		 scuess = message.isScuess();
		 
		 try {
			 result = message.getResult().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 buf.writeBoolean(scuess);
		 buf.writeInt(result.length);
		 buf.writeBytes(result);
		 
	 }
	 
	 public void encode_type3(Private_info message, ByteBuf buf) {
			
		 byte[] account = null;
		 try {
			account = message.getCount().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 buf.writeInt(331);
		 buf.writeInt(3);
		   
		 buf.writeInt(account.length);
		 buf.writeBytes(account);
		}
	 
	   public void encode_type4(Private_info message, ByteBuf buf) {
		
		   buf.writeInt(331);
		   buf.writeInt(4);
			 
		   private_info_encode(message, buf);
	}
	   
	public void private_info_encode(Private_info message, ByteBuf buf) {
		
		byte[] account = null;
		byte[] head_icon = null;
		byte[] name = null;
		byte[] sex=null;
		byte[] birth=null;
		byte[] blood=null;
		byte[] home=null;
		byte[] phone=null;

		byte[] e_mail=null;
		byte[] signature=null;
		byte[] state=null;
		
		try {
			account = message.getCount().getBytes("UTF-8");
			head_icon = message.getIcon_bytes();
			name = message.getName().getBytes("UTF-8");
			sex = message.getSex().getBytes("UTF-8");
			birth = message.getBirth().getBytes("UTF-8");
			blood = message.getBlood().getBytes("UTF-8");
			
			home = message.getHome().getBytes("UTF-8");
			phone = message.getPhone().getBytes("UTF-8");
			e_mail = message.getE_mail().getBytes("UTF-8");
			signature = message.getSignature().getBytes("UTF-8");
			state = message.getState().getBytes("UTF-8");
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		buf.writeInt(account.length);
		buf.writeBytes(account);
		
		buf.writeInt(head_icon.length);
		buf.writeBytes(head_icon);
		
		buf.writeInt(name.length);
		buf.writeBytes(name);
		
		buf.writeInt(sex.length);
		buf.writeBytes(sex);
		
		buf.writeInt(birth.length);
		buf.writeBytes(birth);
		 
		buf.writeInt(blood.length);
		buf.writeBytes(blood);
		
		buf.writeInt(home.length);
		buf.writeBytes(home);
		
		buf.writeInt(phone.length);
		buf.writeBytes(phone);
		
		buf.writeInt(e_mail.length);
		buf.writeBytes(e_mail);
		
		buf.writeInt(signature.length);
		buf.writeBytes(signature);
		
		buf.writeInt(state.length);
		buf.writeBytes(state);
		
	}
  
}
