package private_encode_pack;

import java.io.UnsupportedEncodingException;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import private_message.Apply_Message;

public class Apply_encoder extends MessageToByteEncoder<Apply_Message>{

	@Override
	protected void encode(ChannelHandlerContext arg0, Apply_Message apply_Message, ByteBuf buf) throws Exception {
		
		general_encode(apply_Message, buf);
		
		if(apply_Message.getProtocal_code()==131) {encode_fileType(apply_Message, buf);}
	}

	public void encode_fileType(Apply_Message apply_Message, ByteBuf buf) {
		byte[] file_name = null;
		try {
			 file_name = apply_Message.getFile_name().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   buf.writeLong(apply_Message.getFile_code());
	   buf.writeInt(file_name.length);
	   buf.writeBytes(file_name);
	   buf.writeLong(apply_Message.getFile_size());
	   buf.writeLong(apply_Message.getFilebin_location());
	}
	public void general_encode(Apply_Message apply_Message, ByteBuf buf) {
		byte[] request_ip = null;
		byte[] reply_ip = null;
		
		try {
			request_ip = apply_Message.getRequest_ip().getBytes("UTF-8");
			reply_ip = apply_Message.getReply_ip().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		buf.writeInt(apply_Message.getProtocal_code());
		buf.writeInt(apply_Message.getType());
		buf.writeInt(apply_Message.getFrom_account());
		buf.writeInt(apply_Message.getTo_account());
		buf.writeInt(apply_Message.getP2p_type());
		buf.writeInt(apply_Message.getTcp_server_port());
		buf.writeInt(apply_Message.getUdp_server_port1());
		buf.writeInt(apply_Message.getUdp_server_port2());
		buf.writeBoolean(apply_Message.isAccept());
		
		buf.writeInt(request_ip.length);
		buf.writeBytes(request_ip);
		buf.writeInt(reply_ip.length);
		buf.writeBytes(reply_ip);
	}
}
