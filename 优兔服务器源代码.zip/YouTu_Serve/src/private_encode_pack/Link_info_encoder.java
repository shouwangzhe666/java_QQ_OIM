package private_encode_pack;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.print.attribute.standard.Sides;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import private_message.Link_info;

public class Link_info_encoder extends MessageToByteEncoder<Link_info>{
        
	          // client
	@Override
	protected void encode(ChannelHandlerContext arg0, Link_info link_info, ByteBuf buf) throws Exception {
		
		int type = link_info.getType();
		
		if(type==1) {encode_type1(link_info, buf);}
		else if(type==2) {encode_type2(link_info, buf);}
		else if(type==3) {encode_type3(link_info, buf);}
		else if(type==4) {encode_type4(link_info, buf);}
		else if(type==5) {encode_type5(link_info, buf);}
		else if(type==6) {encode_type6(link_info, buf);}
		else if(type==7) {encode_type7(link_info,buf);}
		else if(type==8) {encode_type8(link_info, buf);}
		else if(type==9) {encode_type9(link_info, buf);}
		else if(type==10) {encode_type10(link_info, buf);}
		
	}

	public void encode_type1( Link_info link_info, ByteBuf buf) {
		
		ArrayList<Integer> own_image = link_info.get_own_image();
		
		buf.writeInt(121);   // protocal_code
		buf.writeInt(1);     // type
		
		buf.writeInt(link_info.getGroup_account()); // the Group_account
		buf.writeInt(own_image.size());    // the quantity of account
		
		int account = 0;
		
		for(int i=0;i<own_image.size();i++) {
			
			account = own_image.get(i);	
			buf.writeInt(account);	
		}
		}

	public void encode_type2( Link_info link_info, ByteBuf buf) {
			
		ArrayList<ArrayList<Object>> all_head_icon_byte = link_info.get_all_respose_head_image();
		ArrayList<Object> temp_array = null;
		int account = 0;
		byte[] by1 = null;
		byte[] by2 = null;
		
		buf.writeInt(121);   // protocal_code
		buf.writeInt(2);     // type
		
		buf.writeInt(all_head_icon_byte.size());       // write the size
		
		for(int i=0;i<all_head_icon_byte.size();i++) {
			
			temp_array = all_head_icon_byte.get(i);
			
			account = (int) temp_array.get(0);
			by2 = (byte[]) temp_array.get(1);
			
			buf.writeInt(account);
			buf.writeInt(by2.length);
			buf.writeBytes(by2);
			
		} // for
}
public void encode_type3( Link_info link_info, ByteBuf buf) {
	
	String account = link_info.getAccount();
	byte[] by1 = null;
	try {
		 by1 = account.getBytes("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	byte[] icon_bytes = link_info.getHead_icon_bytes();
	
	buf.writeInt(121);
	buf.writeInt(3);
	
	buf.writeInt(by1.length);
	buf.writeBytes(by1);
	
	buf.writeInt(icon_bytes.length);
	buf.writeBytes(icon_bytes);
	
}
public void encode_type4( Link_info link_info, ByteBuf buf) {
	
	 ArrayList<String> all_group = link_info.getAll_group();
	 String group = null;
	 byte[] by = null;
	 
	 buf.writeInt(121);
	 buf.writeInt(4);
	 buf.writeInt(all_group.size());
	 
	 for(int i=0;i<all_group.size();i++) {
		 
		 group = all_group.get(i);
		 try {
			by = group.getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 buf.writeInt(by.length);
		 buf.writeBytes(by);
		
	 }
}
public void encode_type5( Link_info link_info, ByteBuf buf) {
	
	ArrayList<ArrayList<String>> all_link_man = link_info.getAll_link_man();
	ArrayList<String> row_list = null;
	
	 buf.writeInt(121);
	 buf.writeInt(5);
	 buf.writeInt(all_link_man.size());
	 
	 byte[] type = null;
	 byte[] link_account = null;
	 byte[] remark = null;
	 byte[] signature = null;
	 byte[] group_name = null;
	 byte[] group_names = null;
	 byte[] inform_type = null;
	 byte[] state = null;
	 byte[] id = null;
	 byte[] ip_port = null;
	 byte[] join_time = null;
	 byte[] out_time = null;
	 
	 for(int i=0;i<all_link_man.size();i++) {
		 
		 row_list = all_link_man.get(i);
		 try {
			type = row_list.get(0).getBytes("UTF-8");
			link_account = row_list.get(1).getBytes("UTF-8");
			remark = row_list.get(2).getBytes("UTF-8");
			signature = row_list.get(3).getBytes("UTF-8");
			group_name = row_list.get(4).getBytes("UTF-8");
			group_names = row_list.get(5).getBytes("UTF-8");
			inform_type = row_list.get(6).getBytes("UTF-8");
			state = row_list.get(7).getBytes("UTF-8");
			id = row_list.get(8).getBytes("UTF-8");
			ip_port = row_list.get(9).getBytes("UTF-8");
			join_time = row_list.get(10).getBytes("UTF-8");
			out_time = row_list.get(11).getBytes("UTF-8");
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 buf.writeInt(type.length);
		 buf.writeBytes(type);
		 buf.writeInt(link_account.length);
		 buf.writeBytes(link_account);
		 buf.writeInt(remark.length);
		 buf.writeBytes(remark);
		 buf.writeInt(signature.length);
		 buf.writeBytes(signature);
		 buf.writeInt(group_name.length);
		 buf.writeBytes(group_name);
		 buf.writeInt(group_names.length);
		 buf.writeBytes(group_names);
		 buf.writeInt(inform_type.length);
		 buf.writeBytes(inform_type);
		 buf.writeInt(state.length);
		 buf.writeBytes(state);
		 buf.writeInt(id.length);
		 buf.writeBytes(id);
		 buf.writeInt(ip_port.length);
		 buf.writeBytes(ip_port);
		 buf.writeInt(join_time.length);
		 buf.writeBytes(join_time);
		 buf.writeInt(out_time.length);
		 buf.writeBytes(out_time);
	 }  // for
}

public void encode_type6( Link_info link_info, ByteBuf buf) {
	
	String account = link_info.getAccount();
	byte[] by = null;
	  try {
		by = account.getBytes("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	  buf.writeInt(121);
	  buf.writeInt(6);
	  
	  buf.writeInt(by.length);
	  buf.writeBytes(by);
}
public void encode_type7( Link_info link_info,ByteBuf buf) {
	
	byte[] account = null;
	byte[] head_icon_bytes = null;
	byte[] name = null;
	byte[] signature = null;       
	try {
		 account =  link_info.getAccount().getBytes("UTF-8");
		 head_icon_bytes = link_info.getHead_icon_bytes();
		 name = link_info.getName().getBytes("UTF-8");
		 signature = link_info.getSignature().getBytes("UTF-8");
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
     buf.writeInt(121);
     buf.writeInt(7);
     
     buf.writeInt(account.length);
     buf.writeBytes(account);
     buf.writeInt(head_icon_bytes.length);
     buf.writeBytes(head_icon_bytes);
     buf.writeInt(name.length);
     buf.writeBytes(name);
     buf.writeInt(signature.length);
     buf.writeBytes(signature);
    
}
public void encode_type8( Link_info link_info, ByteBuf buf) {
	
	byte[] account = null;
	byte[] link_account = null;
	byte[] head_icon_bytes = null;
	byte[] name = null;
	byte[] verify_message = null; 
	long system_time = 0l;
	try {
		 account =  link_info.getAccount().getBytes("UTF-8");
		 link_account =  link_info.getLink_count().getBytes("UTF-8");
		 head_icon_bytes = link_info.getHead_icon_bytes();
		 name = link_info.getName().getBytes("UTF-8");
		 verify_message = link_info.get_verify_message().getBytes("UTF-8");
		 system_time = link_info.getSystem_time();
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
     buf.writeInt(121);
     buf.writeInt(8);
     
     buf.writeInt(account.length);
     buf.writeBytes(account);
     buf.writeInt(link_account.length);
     buf.writeBytes(link_account);
     
     buf.writeInt(head_icon_bytes.length);
     buf.writeBytes(head_icon_bytes);
     buf.writeInt(name.length);
     buf.writeBytes(name);
     buf.writeInt(verify_message.length);
     buf.writeBytes(verify_message);
     buf.writeLong(system_time);
    
}
public void encode_type9( Link_info link_info, ByteBuf buf) {
	
	byte[] account = null;
	byte[] link_account = null;
	byte[] head_icon_bytes = null;
	byte[] name = null;
	boolean accept = false;
	long system_time = 0l;
	try {
		 account =  link_info.getAccount().getBytes("UTF-8");
		 link_account = link_info.getLink_count().getBytes("UTF-8");
		 head_icon_bytes = link_info.getHead_icon_bytes();
		 name = link_info.getName().getBytes("UTF-8");
		 accept = link_info.isAccept();
		 system_time = link_info.getSystem_time();
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
     buf.writeInt(121);
     buf.writeInt(9);
     
     buf.writeInt(account.length);
     buf.writeBytes(account);
     buf.writeInt(link_account.length);
     buf.writeBytes(link_account);
     
     buf.writeInt(head_icon_bytes.length);
     buf.writeBytes(head_icon_bytes);
     buf.writeInt(name.length);
     buf.writeBytes(name);
     buf.writeBoolean(accept);
     buf.writeLong(system_time);
}
public void encode_type10( Link_info link_info,ByteBuf buf) {
	
	 buf.writeInt(121);
    buf.writeInt(10);
    buf.writeInt(link_info.getGroup_account());
}
}
