package private_encode_pack;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import message_log_regis.Ping_Pong;

public class Ping_Pong_encoder extends MessageToByteEncoder<Ping_Pong>{

	@Override
	protected void encode(ChannelHandlerContext arg0, Ping_Pong arg1, ByteBuf buf) throws Exception {

		buf.writeInt(310);
		buf.writeInt(arg1.get_account());
	}

}
