package udp_pack;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;

public class UDP_P4P_Client {
    
	InetAddress server_address = null;
	InetAddress remote_address = null;
	
	int server_port = 0;
	String remote_ip = null;
	
	boolean first = true;
	volatile boolean transfer = false;
	volatile boolean start1 = true;
	volatile boolean start2 = true;
	
	volatile boolean scuess0 = false;
	volatile boolean scuess1 = false;
	volatile boolean scuess2 = false;
	volatile boolean scuess3 = false;
	volatile boolean scuess4 = false;
	
	DatagramSocket socket1 = null;
	DatagramSocket socket2 = null;
	DatagramSocket socket3 = null;
	DatagramSocket socket4 = null;
	
	volatile int[] ports = null;
	volatile int number = 0;
	Object sync = null;
	 
	public UDP_P4P_Client(int server_port,boolean first) {
		
		this.server_port = server_port;
		this.first = first;
		sync = new Object();
		Init_socket(server_port);
		start_connect();
		
	}
	
	public void Init_socket(int server_port) {
		 // 115.28.186.188
	     // 192.168.31.203
		try {
			this.server_address = InetAddress.getByName("115.28.186.188");
		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		this.server_port = server_port;
		
		ports = new int[8];
	
		try {
			socket1 = new DatagramSocket();
			socket2 = new DatagramSocket();
			socket3 = new DatagramSocket();
			socket4 = new DatagramSocket();
			
			ports[0] = socket1.getLocalPort();
			ports[1] = socket2.getLocalPort();
			ports[2] = socket3.getLocalPort();
			ports[3] = socket4.getLocalPort();
			
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void start_connect() {
		
		  new Connect_Send_thread(socket1, "1").start();
		  new Connect_Send_thread(socket2, "2").start();
		  new Connect_Send_thread(socket3, "3").start();
		  new Connect_Send_thread(socket4, "4").start();
		  
		  new Connect_Receive_thread(socket1).start();
		  new Connect_Receive_thread(socket2).start();
		  new Connect_Receive_thread(socket3).start();
		  new Connect_Receive_thread(socket4).start();
	}
	
	
	private class Connect_Send_thread extends Thread{
		DatagramSocket socket = null;
		byte[] num = null;
		DatagramPacket packet = null;
		
		public Connect_Send_thread(DatagramSocket socket,String num) {
		    this.socket = socket;
		    try {
				this.num = num.getBytes("UTF-8");
				packet = new DatagramPacket(this.num,this.num.length,server_address, server_port);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   
		}
		@Override
		public void run() {
			// while(start1) {
			 for(int i=0;i<3;i++) {
				 try {
					socket.send(packet);
				} catch (IOException e) {
					// TODO Auto-generated catch block
				//	e.printStackTrace();
					break;
				}
				 try {
					Thread.sleep(250);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 } // while(strat1)
		}
	}
   private class Connect_Receive_thread extends Thread{
	    DatagramSocket socket = null;
		byte[] num = null;
		DatagramPacket packet = null;
		String string = null;
		volatile boolean strat1 = false;
		volatile boolean strat2 = false;
		
		public Connect_Receive_thread(DatagramSocket socket) {
			 this.socket = socket;
			 num = new byte[1024];
			 packet = new DatagramPacket(num, num.length);
		}
		
		@Override
		public void run() {
			 while(start2) {
				 
				 packet = new DatagramPacket(num, num.length);
				 try {
					socket.receive(packet);
				} catch (IOException e) {
					// TODO Auto-generated catch block
				//	e.printStackTrace();
					break;
				}
				 try {
					string = new String(packet.getData(), "UTF-8");
					string = string.trim();
					
				System.out.println("sender Connect_Receive_thread: "+string);
				
					if(string.matches("\\d+:\\d+.\\d+.\\d+.\\d+:\\d+")) {
						
						resolver_addr(string);				
					}
					else if(string.equals("11111111111111111111111")) {scuess1 = true;}
					else if(string.equals("22222222222222222222222")) {scuess2 = true;}
					else if(string.equals("33333333333333333333333")) {scuess3 = true;}
					else if(string.equals("44444444444444444444444")) {scuess4 = true;}
				  
					if(scuess0&&scuess1&&scuess2&&scuess3&&scuess4) {
						
						 start_video();
					 }
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 } // while(strat1)
		}
		
		 private void resolver_addr(String addr) {
			   String[] strings = addr.split(":");
			   int num = Integer.parseInt(strings[0]);
			   String ip = strings[1];
			   int port = Integer.parseInt(strings[2]);
			   
			   valuation_addr(num, ip, port);
 }
		 private void valuation_addr(int num,String ip,int port) {
			      remote_ip = ip;
			    
			    if(num==1) {ports[4]=port;}
			    else if(num==2) {ports[5]=port;}
			    else if(num==3) {ports[6]=port;}
			    else if(num==4) {ports[7]=port;}
			    
			    int total = ports[4]*ports[5]*ports[6]*ports[7];			 
			    
			  if(total!=0) {
	           
				synchronized (sync) {
				
			     if(number==0) {			    	 
			    	 number++;
//			    	 System.out.println(remote_ip);
//			    	 System.out.println(remote1+","+remote2+","+remote3+","+remote4);
			    	try {
						remote_address = InetAddress.getByName(remote_ip);
					} catch (UnknownHostException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}	 
			    	
						System.out.println("start VA_Pack_TCP...");
						scuess0 = true;
						start1 = false;
										
						start_burrow();	 
						new Check_thread().start();
			    }
			   }
			 } // if
		   }
   private void start_burrow() {
	   
//			try {
//				Thread.sleep(1000);
//			} catch (InterruptedException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			}
			
			new Burrow_Send_thread(socket1, ports[4],"11111111111111111111111").start();
			new Burrow_Send_thread(socket2, ports[5],"22222222222222222222222").start();
			new Burrow_Send_thread(socket3, ports[6],"33333333333333333333333").start();
			new Burrow_Send_thread(socket4, ports[7],"44444444444444444444444").start();		
	}
		
	private void start_video() {
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
		synchronized (sync) {
			if(!transfer) {
				System.out.println("start_video");
				transfer = true;
				close_socket();	
				
				start2 = false;
				sync.notifyAll();
			}
		}								
	} // start_video
	}
   
   private class Burrow_Send_thread extends Thread{
	   DatagramSocket  socket = null;
	   byte[] by = null;
	   DatagramPacket packet = null;
	   
	   public Burrow_Send_thread(DatagramSocket socket,int remote_port,String message) {
		       this.socket  = socket;
		       try {
				by = message.getBytes("UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		       try {
				packet = new DatagramPacket(by, by.length, InetAddress.getByName(remote_ip), remote_port);
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	   @Override
	public void run() {
		for(int i=0;i<20;i++) {
			try {
				socket.send(packet);
			} catch (IOException e) {
				// TODO Auto-generated catch block
		//		e.printStackTrace();
				break;
			}
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		} // for
	}
   }
   public String get_remoteIP() {
	   return remote_ip;
   }
   public void close_socket() {
	   if(!socket1.isClosed()) {socket1.close();}
	   if(!socket2.isClosed()) {socket2.close();}
	   if(!socket3.isClosed()) {socket3.close();}
	   if(!socket4.isClosed()) {socket4.close();}
   }
   public int[] get_ports(int seconds) {
	   int num = 0;
	   
	   synchronized(sync) {
		   while(start2) {
	//		System.out.println(start2);
			   try {
				sync.wait(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			   num++;
			   if(num>seconds) {
				   start1 = false;
				   start2 = false;
				   close_socket();
				   return null;
				}
		   }
	   }
	   
	   return ports;
   }
   private class Check_thread extends Thread{
	   @Override
	public void run() {
		   
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
			 close_socket();
			 
		 if(first&&start2) {
			System.out.println("Check_thread start");
			UDP_P4P_Client client2 = new UDP_P4P_Client(server_port, false);
			ports = client2.get_ports(15);
			synchronized (sync) {
				if(ports!=null) {start2 = false;}
			}
			
		  }
		
	} // run
   }
   private static class Sender_thread extends Thread{
	   DatagramSocket socket = null;
	   byte[] by = null;
	   DatagramPacket packet = null;
	   InetAddress remote_addr = null;
	   int remote_port = 0;
	   
	   public Sender_thread(DatagramSocket socket,String remote_ip,int remote_port) {
		   
		   this.socket = socket;
	      try {
			by = "hello".getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      try {
			remote_addr = InetAddress.getByName(remote_ip);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	      this.remote_port = remote_port;
	}
	   @Override
	public void run() {
		    while(true) {
		    	packet = new DatagramPacket(by, by.length, remote_addr, remote_port);
		   // 	System.out.println("send");
		    	try {
					socket.send(packet);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    	try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    }
	}
   }
   private static class Recever_thread extends Thread{
	   DatagramSocket socket = null;
	   DatagramPacket packet = null;
	   byte[] by = null;
	   String messasge = null;
	   
	   public Recever_thread(DatagramSocket socket) {
		         this.socket = socket;
		         by = new byte[1024];
	}
	   @Override
	public void run() {
		while(true) {
			packet = new DatagramPacket(by, by.length);
			try {
				socket.receive(packet);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				messasge = new String(packet.getData(),"UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			messasge = messasge.trim();
			System.out.println("messasge: "+messasge);
		}
	}
   }
	public static void main(String[] args) {
		  // 115.28.186.188
		  // 192.168.31.203
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("server port:");
		
		int server_port = scanner.nextInt();
		
		long time = System.currentTimeMillis();
		
		UDP_P4P_Client udp_P4P_Client =  new UDP_P4P_Client(server_port,true);
		
		int[] ports = udp_P4P_Client.get_ports(60);
		System.out.println(System.currentTimeMillis()-time);
		
		if(ports!=null) {System.out.println("scuess !");}
		else {System.err.println("failed !");}
		
		String remote_ip = udp_P4P_Client.get_remoteIP();
		System.out.println(remote_ip);
//		for(int i=0;i<ports.length;i++) {
//			if(ports[i]>65535) {System.err.println(ports[i]);}
//			else {System.out.println(ports[i]);}
//		}		
		DatagramSocket socket = null;
		try {
			socket = new DatagramSocket(ports[0]);
		} catch (SocketException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		new Sender_thread(socket, remote_ip, ports[4]).start();
		new Recever_thread(socket).start();
		
	    try {
			Thread.sleep(60000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
