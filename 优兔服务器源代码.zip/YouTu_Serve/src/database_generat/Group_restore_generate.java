package database_generat;

import java.io.IOException;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.SocketException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Timer;

import serve.Group_Chat_Serve;
import serve.Private_Chat_Serve;

public class Group_restore_generate {

	// restore the information of a chat-group
 
 public static void restart_all_group_server() {
	 
	 ArrayList<ArrayList<String>> all_groups = get_all_groups();
	 ArrayList<String> row_list = null;
	 String group_account = null;
	 String portstring = null;
	 int port = 0;
	 
	 System.out.println(all_groups.size());
	 
	 for(int i=0;i<all_groups.size();i++) {
		 
		 row_list = all_groups.get(i);
		 group_account = row_list.get(0);
		 portstring = row_list.get(1);
		 port = Integer.parseInt(portstring);
		 // start group_chat server....
		 new Group_Start_thread(group_account, port).start();
		 Private_Chat_Serve.add_group();
	 }
 }
 
 private static class Group_Start_thread extends Thread{
	 
	 String group_account = null;
	 int port = 0;
	 
	 public Group_Start_thread( String group_account,int port) {
		     
		  this.group_account = group_account;
		  this.port = port;
	}
	 @Override
	public void run() {
	
		 System.out.println("启动  Group_Chat_Serve group_account："+group_account+"  port:"+port);
		 new Group_Chat_Serve(group_account).start_serve(port);
	}
 }

 public static String get_group_type(String group_account) {
	 
	 Connection connection=Connection_Pool.get_group_connection();
     PreparedStatement preparedStatement=null;
     ResultSet resultSet = null;
	   
	   String sql = "select type from tb_restore where account=?";
	   String group_type = "0";
	   try {		
		
		   preparedStatement = connection.prepareStatement(sql);
		   preparedStatement.setString(1, group_account);
		   resultSet = preparedStatement.executeQuery();
	} catch (Exception e) {
		Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		return group_type;
	}
	   try {
		while(resultSet.next()) {
			   group_type = resultSet.getString(1);
		   }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
	   return group_type;
 }
public static String get_ip_port(String group_account) {
	 
	 Connection connection=Connection_Pool.get_group_connection();
     PreparedStatement preparedStatement=null;
     ResultSet resultSet = null;
	   
	   String sql = "select ip_port from tb_restore where account=?";
	   String ip_port = "0";
	   try {		
		
		   preparedStatement = connection.prepareStatement(sql);
		   preparedStatement.setString(1, group_account);
		   resultSet = preparedStatement.executeQuery();
	} catch (Exception e) {
		Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		return ip_port;
	}
	   try {
		while(resultSet.next()) {
			ip_port = resultSet.getString(1);
		   }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
	   return ip_port;
 }
 public static boolean put_new_group(String account,String ip_port,String type) {
	 
	 Connection connection=Connection_Pool.get_group_connection();
     PreparedStatement preparedStatement=null;
     ResultSet resultSet = null;
		
     String sql = "insert into tb_restore values(?,?,?)";
	 
	   try {
		connection.setAutoCommit(false);
		
		preparedStatement = connection.prepareStatement(sql);
		
		preparedStatement.setString(1, account);
		preparedStatement.setString(2, ip_port);
		preparedStatement.setString(3, type);
		
		preparedStatement.executeUpdate();
		connection.commit();
		
	} catch (Exception e) {
		
		try {
			connection.rollback();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		return false;
	}
	   
	  Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
	
	   return true;
 }
 
 public static boolean delete_group(String account) {
	 Connection connection=Connection_Pool.get_group_connection();
     PreparedStatement preparedStatement=null;
     ResultSet resultSet = null;
     
     String sql = "delete from tb_restore where account=?";
	   
	   
	   try {
		connection.setAutoCommit(false);
		
		preparedStatement = connection.prepareStatement(sql);
		
		preparedStatement.setInt(1, Integer.parseInt(account));
		
		preparedStatement.executeUpdate();
		connection.commit();
		
	} catch (Exception e) {
		
		try {
			connection.rollback();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		return false;
	}
	
	    Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
	 return true;
 }
 
 public static ArrayList<ArrayList<String>> get_all_groups(){
	 
	 Connection connection=Connection_Pool.get_group_connection();
     PreparedStatement preparedStatement=null;
     ResultSet resultSet = null;
     
	   ArrayList<ArrayList<String>> all_groups = new ArrayList<>();
	   ArrayList<String> group = null;
	   
	   String sql = "select * from tb_restore";
	   String group_account = null;
	   String port = null;
	   
	   try {		
		
		   preparedStatement = connection.prepareStatement(sql);
		   resultSet = preparedStatement.executeQuery();
	} catch (Exception e) {
		Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		return all_groups;
	}
	   
	   int i=0;
	   
	   try {
		while(resultSet.next()) {
			   i++;
			   if(i==1) {continue;}
			   
			group = new ArrayList<>();
			group_account = resultSet.getString(1);
			port = resultSet.getString(2);
			port = port.split(",")[1];
			group.add(group_account);
			group.add(port);
			
			all_groups.add(group);
		   }
	} catch (SQLException e) {
		Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		return all_groups;
	}
	   
	   Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
	   return all_groups;
 }
 
 public static String get_and_Init_new_group(String group_type,String group_name,String group_ower_account) {
	 
	 Connection connection = Connection_Pool.get_group_connection();
	 
	 int group_account = Group_restore_generate.get_new_group_account(connection);
	 String ip = Group_restore_generate.get_ip();
	 int port = get_new_group_port();
	 String ip_port = ip+","+port;
//	 String info = group_account+","+ip+","+port;	
	
	String count = String.valueOf(group_account);
	// the String type of the group account
	
	    boolean b0 = Group_restore_generate.put_new_group(count, ip_port,group_type);
	    boolean b1 = Group_member_generate.create_member_table(count);
		boolean b2 = Group_message_generate.create_message_table(count);
		boolean b3 = Group_notice_generate.create_notice_table(count);
		boolean b4 = Group_icon_generate.create_icon_table(count);
		boolean b5 = Group_file_generate.create_file_table(count);
		boolean b6 = Group_info_generate.create_info_table(count);
		boolean b7 = Group_member_generate.put_group_ower(count,group_ower_account);
		boolean b8 = Group_info_generate.Init_group_info_table(count, group_type, group_name);
		boolean b9 = Link_man_generate.put_link_group(group_ower_account, count,group_name, "群主", ip_port, 3742762088000l);
		
	    boolean scuess = b0&&b1&&b2&&b3&&b4&&b5&&b6&&b7&&b8&&b9;	
	    
	    if(!scuess) {return null;}
	    
	    //timming to truncate_timedOut_message
		 new Timer().schedule(new Truncate_timer_task(count), 259500000, 259500000);
		
		 // start group_chat server....
		new Thread() {
			public void run() {
				 new Group_Chat_Serve(count).start_serve(port);
		};}.start();
		 
		Private_Chat_Serve.add_group();
		Private_Chat_Serve.update_frame_info();
		
		return count;		
 }
 public static int get_new_group_account(Connection connection) {
	
	 if(connection==null) {Connection_Pool.get_group_connection();}
	 PreparedStatement preparedStatement=null;
     ResultSet resultSet = null;
     
     int randow_groupaccount = (int)(Math.random()*888888888+111111111);
	 String sql = "select account from tb_restore where account=?";
	 
	 try {
		preparedStatement = connection.prepareStatement(sql);
		preparedStatement.setString(1, String.valueOf(randow_groupaccount));
		resultSet = preparedStatement.executeQuery();
		if(resultSet.next()) {return get_new_group_account(connection);}
		else {Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 
	 return randow_groupaccount;
 }
 
 public static String get_ip() {
	 
	 Connection connection=Connection_Pool.get_group_connection();
     PreparedStatement preparedStatement=null;
     ResultSet resultSet = null;
     String ip = null;
     
     String sql = "select account from tb_restore limit 1";
     try {
		preparedStatement = connection.prepareStatement(sql);
		resultSet = preparedStatement.executeQuery();
		if(resultSet.next()) {ip = resultSet.getString(1);}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
    return ip;
     
 }
 public static int get_new_group_port() {
	 
	 int free_port = 0;
		try {
			DatagramSocket datagramSocket = new DatagramSocket();
			free_port = datagramSocket.getLocalPort();
			datagramSocket.close();
		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	 return free_port;
 }
 
 public static void Init_first_data(String ip,String from_port,String to_port) {
	 // insert the first row data which contains the default ip and the rang of port;
	 
	 Connection connection=Connection_Pool.get_group_connection();
     PreparedStatement preparedStatement=null;
     ResultSet resultSet = null;
     
     String sqll = "select * from tb_restore limit 1";
     try {
		preparedStatement = connection.prepareStatement(sqll);
		resultSet = preparedStatement.executeQuery();
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
    
     
     try {
		if(resultSet.next()) {
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);return;}
	} catch (SQLException e1) {
		
		e1.printStackTrace();
	}
    try {
		resultSet.close();
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
    		 
	 String key = ip;
	 String value = from_port+","+to_port;
	 String sql = "insert into tb_restore values(?,?,?)";
	 
	   try {
		connection.setAutoCommit(false);
		
		preparedStatement = connection.prepareStatement(sql);
		
		preparedStatement.setString(1,key);
		preparedStatement.setString(2, value);
		preparedStatement.setString(3, "1");
				
		preparedStatement.executeUpdate();
		connection.commit();
		
	} catch (Exception e) {
		try {
			connection.rollback();
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		} catch (Exception e2) {
			// TODO: handle exception
		}				
	}
	
	   Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
 }
	
	public static void main(String[] args) {
		
      Group_restore_generate.restart_all_group_server();
     
	}
}
