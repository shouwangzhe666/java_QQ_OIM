package database_generat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import group_message.Group_info_message;
import tools.File_tool;
import tools.Icon_tools;

public class Group_icon_generate {
		
  public static String get_create_table_sql(String group_account) {
			 
		String	 table_sql = "CREATE TABLE `tb_icon_"+group_account+"` (\r\n" + 
						"`sender`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
						"`send_time`  bigint(20) NOT NULL " + 
						")\r\n" + 
						"ENGINE=InnoDB\r\n" + 
						"DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci\r\n" + 
						"ROW_FORMAT=DYNAMIC";
		return table_sql;
	}
	  
	public static boolean put_new_icon(Group_info_message group_info) {

	    Connection connection=Connection_Pool.get_group_connection();
	    PreparedStatement preparedStatement=null;
	    ResultSet resultSet = null;
	    
	    int group_account = group_info.getGroup_account();
	    String sender = group_info.getSender();
	    long send_time = group_info.getSend_time();
	    byte[] icon_bytes = group_info.getGroup_icon();
	    String icon_path = "D:\\UTO_server\\group_"+group_account+"\\icon\\"+send_time+".png";
	    		
		   String sql = "insert into tb_icon_"+group_account+" values(?,?)";
		 		   
		   try {
			   Icon_tools.Write_image(icon_bytes,icon_path);
			   
			connection.setAutoCommit(false);			
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setString(1, sender);
			preparedStatement.setLong(2, send_time);
		
			preparedStatement.executeUpdate();
			connection.commit();
			
		} catch (Exception e) {
			
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return false;
		}
		
		 Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		 return true;
		   
	   }
	  
	  public static boolean delete_icon(Group_info_message group_info) {
		    Connection connection=Connection_Pool.get_group_connection();
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
		    int group_account = group_info.getGroup_account();
		    long send_time = group_info.getSend_time();
		    
		   String icon_path = "D:\\UTO_server\\group_"+group_account+"\\icon\\"+send_time+".png";
	       String sql = "delete from tb_icon_"+group_account+" where send_time=?";
		  
		   try {
			   File_tool.delete_file(icon_path);
			   
			connection.setAutoCommit(false);			
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setLong(1, send_time);
			
			preparedStatement.executeUpdate();
			connection.commit();
			
		} catch (Exception e) {
			
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return false;
		}
		
		 Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		 return true;
	   }
	  
 public static Group_info_message get_all_icons(int group_account){
	 
		    Connection connection=Connection_Pool.get_group_connection();
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
		   ArrayList<ArrayList<Object>> all_icons = new ArrayList<>();
		   ArrayList<Object> icon = null;
		   long send_time = 0l;
		   byte[] icon_bytes = null;
		   String icon_path = "D:\\UTO_server\\group_"+group_account+"\\icon\\";
		   
		   String sql = "select * from tb_icon_"+group_account;
		   
		   try {				
			   preparedStatement = connection.prepareStatement(sql);
			   resultSet = preparedStatement.executeQuery();
		} catch (Exception e) {
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return null;
		}
		   
		   try {
			while(resultSet.next()) {
				   
				icon = new ArrayList<>();
				
				send_time = resultSet.getLong(2);
				icon_bytes = Icon_tools.get_IconBytes(icon_path+send_time+".png");
				
				icon.add(icon_bytes);
				icon.add(resultSet.getString(1));
				icon.add(send_time);
				
				all_icons.add(icon);
			   }
		} catch (SQLException e) {
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return null;
		}		   
		  Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		  
		  Group_info_message group_info_message = new Group_info_message(44, group_account);
		  group_info_message.setAll_icons(all_icons);
		  
		   return group_info_message;
	   }
	  
	public static boolean create_icon_table(String group_account) {
		    Connection connection=Connection_Pool.get_group_connection();
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
			
		    String create_sql = get_create_table_sql(group_account);
			
			try {
				connection.setAutoCommit(false);
				try {
					preparedStatement = connection.prepareStatement(create_sql);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				preparedStatement.executeUpdate();
				
				connection.commit();
			} catch (Exception e) {
			
				try {
					connection.rollback();
					Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				} catch (Exception e2) {
					// TODO: handle exception
				}
				
				return false;
			}
			
			try {
				connection.rollback();
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			} catch (Exception e2) {
				// TODO: handle exception
			}
			
			return true;
		}
	
	   public static void main(String[] args) {
		   String icon_path = "D:\\UTO_server\\group_100000000\\icon\\1571464267886.png";		  
		 
			 boolean scuess =  File_tool.delete_file(icon_path);
			 System.out.println(scuess);
	}
}
