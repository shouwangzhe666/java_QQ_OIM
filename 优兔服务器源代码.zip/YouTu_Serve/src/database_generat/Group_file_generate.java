package database_generat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import group_message.Group_info_message;
import tools.File_tool;

public class Group_file_generate {
	
   public static String get_create_table_sql(String group_account) {
		  //tb_file_
		 String table_sql = "CREATE TABLE `tb_file_"+group_account+"` (\r\n" + 
		 		"`name`  varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
		 		"`size`  bigint(20) NOT NULL ,\r\n" + 
		 		"`sender`  varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
		 		"`send_time`  bigint(20) NOT NULL \r\n" + 
		 		")\r\n" + 
		 		"ENGINE=InnoDB\r\n" + 
		 		"DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci\r\n" + 
		 		"ROW_FORMAT=DYNAMIC";
		 
		 return table_sql;
	  }
	  
	 public static boolean put_new_file(int group_account,String file_name,long file_size,String sender,long send_time) {
		  
		    Connection connection=Connection_Pool.get_group_connection();
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
		   String sql = "insert into tb_file_"+group_account+" values(?,?,?,?)";		   
		   
		   try {
			connection.setAutoCommit(false);
			
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setString(1, file_name);
			preparedStatement.setLong(2, file_size);
			preparedStatement.setString(3,sender);
			preparedStatement.setLong(4,send_time);
		
			preparedStatement.executeUpdate();
			connection.commit();
			
		} catch (Exception e) {
			
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return false;
		}
		
		Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		 return true;
		   
	   }
	  
	public static boolean delete_file(int group_account,long send_time) {
		Connection connection=Connection_Pool.get_group_connection();
	    PreparedStatement preparedStatement=null;
	    ResultSet resultSet = null;	    
	
	       String sql = "delete from tb_file_"+group_account+" where send_time=?";
	       String file_name = get_file_name(connection, group_account, send_time);
	       String file_path = "D:\\UTO_server\\group_"+group_account+"\\file\\"+file_name;
	       
		   try {
			  boolean s = File_tool.delete_file(file_path);
			
			connection.setAutoCommit(false);			
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setLong(1,send_time);
			
			preparedStatement.executeUpdate();
			connection.commit();
			
		} catch (Exception e) {
			
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return false;
		}
		
		 Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		 return true;
	   }
	  
	public static boolean alter_file_name(Group_info_message group_info_message) {
		    Connection connection=Connection_Pool.get_group_connection();
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    boolean scuess = false;
		    
		    int group_account = group_info_message.getGroup_account();
		    String new_file_name = group_info_message.getFile_name();
		    long send_time = group_info_message.getSend_time();
		    
	       String sql = "update tb_file_"+group_account+" set name=? where send_time=?";
	       String file_name = get_file_name(connection, group_account, send_time);
	       String file_path = "D:\\UTO_server\\group_"+group_account+"\\file\\"+file_name;
	     
		   try {
			   scuess = File_tool.rename_file(file_path, new_file_name);
			   
			connection.setAutoCommit(false);			
			preparedStatement = connection.prepareStatement(sql);
						
		    preparedStatement.setString(1, new_file_name);
			preparedStatement.setLong(2,send_time);
			
			preparedStatement.executeUpdate();
			connection.commit();
			
		} catch (Exception e) {
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return false;
		}
		
		 Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		 return scuess;
	   }
	
 public static String get_file_name(Connection connection,int group_account,long send_time) {
	    PreparedStatement preparedStatement=null;
	    ResultSet resultSet = null;
	    String file_name = null;
	    
        String sql = "select name from tb_file_"+group_account+" where send_time=?";
	   			
		try {
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setLong(1,send_time);				
			resultSet = preparedStatement.executeQuery();
			
			    while(resultSet.next()) {
			    	 file_name = resultSet.getString(1);
			    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}						   
	    
	 return file_name;
 }	  
 public static Group_info_message get_all_file(int group_account){
		    Connection connection=Connection_Pool.get_group_connection();
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
		   ArrayList<ArrayList<Object>> all_files = new ArrayList<>();
		   ArrayList<Object> file = null;
		   
		   String sql = "select * from tb_file_"+group_account;
		   
		   try {					
			   preparedStatement = connection.prepareStatement(sql);
			   resultSet = preparedStatement.executeQuery();
		} catch (Exception e) {
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return null;
		}
		   
		   try {
			while(resultSet.next()) {
				   
				file = new ArrayList<>();
				
				file.add(resultSet.getString(1));
				file.add(resultSet.getLong(2));
				file.add(resultSet.getString(3));
				file.add(resultSet.getLong(4));
				
				all_files.add(file);
			   }
		} catch (SQLException e) {
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return null;
		}		   
		  Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		  
		  Group_info_message group_info_message = new Group_info_message(54, group_account);
		  group_info_message.setAll_files(all_files);
		  
		   return group_info_message;
	   }
	  
	public static boolean create_file_table(String account) {
			
		Connection connection=Connection_Pool.get_group_connection();
	    PreparedStatement preparedStatement=null;
	    ResultSet resultSet = null;
			
	    String table_sql = get_create_table_sql(account);
	    
			try {
				connection.setAutoCommit(false);
				try {
					preparedStatement = connection.prepareStatement(table_sql);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				preparedStatement.executeUpdate();
				
				connection.commit();
			} catch (Exception e) {
			
				try {
					connection.rollback();
					
				} catch (Exception e2) {
					// TODO: handle exception
				}
				 Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				return false;
			}
			
			 Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return true;
		}
	  
}
