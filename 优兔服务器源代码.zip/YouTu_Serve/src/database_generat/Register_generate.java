package database_generat;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Register_generate {

	// 经实测，全部合格
public static String getAnd_Init_new_user(String name,String password,String email) {
	
	Connection connection = Connection_Pool.get_login_connection();
		
	int random_account = (int)(Math.random()*90000000+10000000);
//	int random_account = 10000001;  // 开设指定账号
	
	String new_account = String.valueOf(random_account);
	int resultSet = check_random_account(random_account, connection);
	
	if(resultSet==1) { Init_related_table(new_account, password, name, email);}	
	if(resultSet==1||resultSet==2) { Init_related_info(new_account, password, name, email);}
	if(resultSet==3) {return getAnd_Init_new_user(name, password, email);}
	
	Connection_Pool.close_Resourse(connection, null, null);    	
	connection = null;
	
    return new_account;
}
public static int check_random_account(int random_account,Connection connection) {
	PreparedStatement preparedStatement=null;
	ResultSet resultSet = null;
	
	String tb_name = "tb_"+(random_account/100);
	String sql = "select account from "+tb_name+" where account=?";
	try {
		preparedStatement = connection.prepareStatement(sql);
		preparedStatement.setInt(1,random_account);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		resultSet = preparedStatement.executeQuery();
	} catch (SQLException e) {
	//	e.printStackTrace();
		return 1;
	}
	try {
		if(!resultSet.next()) {return 2;}
		else {return 3;}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally {
		Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
	}
	return -1;
}

public static boolean Init_related_table(String account,String password,String name,String email) {	
	
	String tb_name = "tb_"+account.substring(0, account.length()-2)+"00";
		
	boolean b1 =  Login_generate.Init_login_table(tb_name);
	boolean b2 =  Private_info_generate.Init_info_table(tb_name);
	
	tb_name = "tb_"+account;
	
	boolean b3 = Off_message_generage.Init_off_table(tb_name);
	boolean b4 = Link_man_generate.Init_link_table(tb_name);                                          
	
    return b1&&b2&&b3&&b4;
}

public static boolean Init_related_info(String account,String password,String name,String email) {
	
	boolean b1 = Login_generate.put_new_user(account, password, email);
	boolean b2 = Private_info_generate.put_new_info(Integer.parseInt(account), "default_head_icon.jpg", name, "未知", "未知", "未知", "未知", "未知", email, "未知", "未知");
	
	boolean b3 = Link_man_generate.put_new_group(account, true,"我的好友");
	boolean b4 = Link_man_generate.put_new_group(account, false,"我的群聊");
	
	return b1&&b2&&b3&&b4;
}
public static boolean check_email_exist(String email) {
	
	Connection connection = Connection_Pool.get_login_connection();
	PreparedStatement preparedStatement=null;
	ResultSet resultSet = null;
	String sql = null;
	  
	   ArrayList<String> all_talbes = get_all_tables();
	   String table_name = null;
	   
	   for(int i=0;i<all_talbes.size();i++) {
		   
		   table_name = all_talbes.get(i);
		   sql = "select account from "+table_name+" where email =?";
		   try {
				preparedStatement = connection.prepareStatement(sql);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   try {
			preparedStatement.setString(1, email);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		   try {
			resultSet = preparedStatement.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		   try {
			if(resultSet.next()) {
				Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		   Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		  
	   }  // for	   
	 	   
	return false;	
}
public static ArrayList<String> get_all_tables(){
	
	Connection connection=Connection_Pool.get_login_connection();
	PreparedStatement preparedStatement=null;
	ResultSet resultSet = null;
	
	DatabaseMetaData metaData=null;
	try {
		metaData = connection.getMetaData();
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	try {
		resultSet = metaData.getTables("db_login", null, null, new String[] {"table"});
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	ArrayList<String> all_tables = new ArrayList<>();
	String table_name = null;
	
	try {
		while(resultSet.next()) {
			table_name = resultSet.getString(3);			
			if(table_name.equals("test_table")) {continue;}
			all_tables.add(table_name);
		
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	metaData = null;
	table_name=null;
	Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
	
	return all_tables;
}

 public static void delete_all_login() {
	 
	 Connection connection=Connection_Pool.get_login_connection();
	 PreparedStatement preparedStatement=null;
	 ResultSet resultSet = null;
	 String sql = "delete from tb_10000000 where account >10000000";
	 
	 try {
		preparedStatement = connection.prepareStatement(sql);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 try {
		preparedStatement.executeLargeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	 
	 Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
 }
public static void main(String[] args) {
        
	ArrayList<String> arrayList = get_all_tables();
	System.out.println(arrayList.size());
}
}
