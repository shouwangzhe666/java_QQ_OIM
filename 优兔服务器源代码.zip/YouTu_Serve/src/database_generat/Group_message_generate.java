package database_generat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Group_message_generate {
     			//"tb_message_"+group_account
  public static String get_create_table_sql(String group_account) {
				 
	  String table_sql = "CREATE TABLE `tb_message_"+group_account+"` (\r\n" + 
			 "`send_time`  bigint(20) NOT NULL ," + 
	  		"`content`  mediumblob NOT NULL \r\n" + 
	  		")\r\n" + 
	  		"ENGINE=InnoDB\r\n" + 
	  		"DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci\r\n" + 
	  		"ROW_FORMAT=DYNAMIC";	
	  return table_sql;
	 }
  
	public static boolean put_group_message( Connection connection,String group_account,long send_time,byte[] content) {
		
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
			String sql = "insert into tb_message_"+group_account+" values(?,?)";
			
			try {
				connection.setAutoCommit(false);
				
				preparedStatement = connection.prepareStatement(sql);
				
				preparedStatement.setLong(1, send_time);
				preparedStatement.setBytes(2, content);
				
				preparedStatement.executeUpdate();
		        connection.commit();
		        
			} catch (Exception e) {
			   try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			 Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
			   return false;
			}
			
			Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
			 return true;
		}
		
		
	public static boolean delete_gorup_message(String group_account,long send_time) {
		 Connection connection=Connection_Pool.get_group_connection();
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
            String sql = "delete from tb_message_"+group_account+" where send_time=?";
			
			
			try {
				connection.setAutoCommit(false);
				
				preparedStatement = connection.prepareStatement(sql);
				
				preparedStatement.setLong(1, send_time);
				
				preparedStatement.executeUpdate();
				 connection.commit();
				 
			} catch (Exception e) {
			   try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();}
			   Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			   return false;
			}
			
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			 return true;
		}
		
	public static boolean truncate_timedOut_message(String group_account) {
		
		 Connection connection=Connection_Pool.get_group_connection();
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
		 String sql = "delete from tb_message_"+group_account+" where send_time<?";
		 long bound_time = System.currentTimeMillis()-259200000;	
		 
			try {
				connection.setAutoCommit(false);
				
				preparedStatement = connection.prepareStatement(sql);
				
				preparedStatement.setLong(1, bound_time);
				
				preparedStatement.executeUpdate();
				 connection.commit();
				 
			} catch (Exception e) {
			   try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			   Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			   return false;
			}
			
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			 return true;
	}
	
	public static boolean delete_all_message(String group_account) {
		 Connection connection=Connection_Pool.get_group_connection();
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
		 String sql = "delete from tb_message_"+group_account;
		 long bound_time = System.currentTimeMillis()-259200000;	
		 
			try {
				connection.setAutoCommit(false);
				
				preparedStatement = connection.prepareStatement(sql);										
				preparedStatement.executeUpdate();
				 connection.commit();
				 
			} catch (Exception e) {
			   try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			  Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			   return false;
			}
			
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			 return true;
	}
	
	public static ArrayList<byte[]> get_batched_message(Connection connection,String group_account,int member_account){
		
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
		 long send_time = Group_member_generate.get_last_time(connection,group_account, member_account);
		
		ArrayList<byte[]> all_content = new ArrayList<>();
		byte[] by = null;
		String sql = "select content from tb_message_"+group_account+" where send_time>?";
		
		try {
			 preparedStatement = connection.prepareStatement(sql);
             preparedStatement.setLong(1, send_time);
			 resultSet = preparedStatement.executeQuery();
			 
		} catch (Exception e) {
			Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
			return all_content;
		}
		
		try {
			while(resultSet.next()) {
			
				by = resultSet.getBytes(1);
				all_content.add(by);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
		return all_content;
	}
	
	public static boolean create_message_table(String group_account) {
			
		 Connection connection=Connection_Pool.get_group_connection();
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
		    String table_sql = get_create_table_sql(group_account);
			
			try {
				connection.setAutoCommit(false);
				try {
					preparedStatement = connection.prepareStatement(table_sql);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				preparedStatement.executeUpdate();
				
				connection.commit();
			} catch (Exception e) {
			         e.printStackTrace();
			         
				try {
					connection.rollback();
					Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				} catch (Exception e2) {
					// TODO: handle exception
				}
				
				return false;
			}
			
			try {
				connection.rollback();
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			} catch (Exception e2) {
				// TODO: handle exception
			}
			
			return true;
		}
	
	public static void main(String[] args) {
		
		String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(0l));
		System.out.println("last_time: "+time);
	}
}
