package database_generat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import group_message.Group_info_message;

public class Group_notice_generate {

	public static String get_create_table_sql(String group_account) {
			
		String table_sql = "CREATE TABLE `tb_notice_"+group_account+"` (\r\n" +  
				"`content`  varchar(600) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`sender`  varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`send_time`  bigint(20) NOT NULL " + 
				")\r\n" + 
				"ENGINE=InnoDB\r\n" + 
				"DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci\r\n" + 
				"ROW_FORMAT=DYNAMIC";
		
		       return table_sql;
		}
	  
 public static boolean put_new_notice(String group_account,String content,String sender_name,long send_time) {
		  Connection connection=Connection_Pool.get_group_connection();
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
		   String sql = "insert into tb_notice_"+group_account+" values(?,?,?)";
		   
		   
		   try {
			connection.setAutoCommit(false);
			
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setString(1, content);
			preparedStatement.setString(2, sender_name);
			preparedStatement.setLong(3, send_time);
		
			preparedStatement.executeUpdate();
			connection.commit();
			
		} catch (Exception e) {
			
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return false;
		}
		
		 Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		 return true;
		   
	   }
	  
	public static boolean delete_notice(String group_account,long send_time) {
		 Connection connection=Connection_Pool.get_group_connection();
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
	       String sql = "delete from tb_notice_"+group_account+" where send_time=?";
		  
		   
		   try {
			connection.setAutoCommit(false);
			
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setLong(1, send_time);
			
			preparedStatement.executeUpdate();
			connection.commit();
			
		} catch (Exception e) {
			
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return false;
		}
		
		Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		 return true;
	   }
	  
 public static boolean alter_notice_info(String group_account,String content,long send_time) {
	    Connection connection=Connection_Pool.get_group_connection();
	    PreparedStatement preparedStatement=null;
	    ResultSet resultSet = null;
	    
	       String sql = "update tb_notice_"+group_account+" set content=? where send_time=?";
		   
		   
		   try {
			connection.setAutoCommit(false);
			
			preparedStatement = connection.prepareStatement(sql);
						
		    preparedStatement.setString(1, content);
		    preparedStatement.setLong(2, send_time);
			
			preparedStatement.executeUpdate();
			connection.commit();
			
		} catch (Exception e) {
			
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return false;
		}
		
		 Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		 return true;
	   }
	  
 public static Group_info_message get_all_notices(String group_account){
	    Connection connection=Connection_Pool.get_group_connection();
	    PreparedStatement preparedStatement=null;
	    ResultSet resultSet = null;
	    
		   ArrayList<ArrayList<Object>> all_notices = new ArrayList<>();
		   ArrayList<Object> notice = null;
		   
		   String sql = "select * from tb_notice_"+group_account;
		   
		   try {		
			 
			   preparedStatement = connection.prepareStatement(sql);
			   resultSet = preparedStatement.executeQuery();
		} catch (Exception e) {
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return null;
		}
		   
		   try {
			while(resultSet.next()) {
				   
				notice = new ArrayList<>();
			
				notice.add(resultSet.getString(1));
				notice.add(resultSet.getString(2));
				notice.add(resultSet.getLong(3));
				
				all_notices.add(notice);
			   }
		} catch (SQLException e) {
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return null;
		}		   
		   Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		   
		   Group_info_message group_info_message = new Group_info_message(34,Integer.parseInt(group_account));
		   group_info_message.setAll_notices(all_notices);
		   
		   return group_info_message;
	   }
	  
	public static boolean create_notice_table(String group_account) {
		 Connection connection=Connection_Pool.get_group_connection();
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
		    String table_sql = get_create_table_sql(group_account);
			
			try {
				connection.setAutoCommit(false);
				try {
					preparedStatement = connection.prepareStatement(table_sql);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				preparedStatement.executeUpdate();
				
				connection.commit();
			} catch (Exception e) {
			
				try {
					connection.rollback();
					 Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				} catch (Exception e2) {
					// TODO: handle exception
				}
				
				return false;
			}
			
			try {
				connection.rollback();
				 Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			} catch (Exception e2) {
				// TODO: handle exception
			}
			
			return true;
		}
}
