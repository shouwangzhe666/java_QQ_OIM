package database_generat;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import group_message.Group_info_message;
import tools.File_tool;
import tools.Icon_tools;

public class Group_info_generate {
	
	public static String get_create_table_sql(String group_account) {
			
	String	table_sql = "CREATE TABLE `tb_info_"+group_account+"` (\r\n" + 
				"`name`  varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ,\r\n" + 
				"`value`  varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL \r\n" + 
				")\r\n" + 
				"ENGINE=InnoDB\r\n" + 
				"DEFAULT CHARACTER SET=utf8 COLLATE=utf8_general_ci\r\n";
	  
	           return table_sql;
		}

 public static boolean Init_group_info_table(String group_account,String group_type,String group_name) {
	 Connection connection=Connection_Pool.get_group_connection();
	
	 boolean b1 = put_group_info(connection, group_account, "group_name", group_name);
	 boolean b2 = put_group_info(connection, group_account, "group_type", group_type); // 1 or 2
	 boolean b3 = put_group_info(connection, group_account, "pay_days", "1");
	 boolean b4 = put_group_info(connection, group_account, "pay_money", "1");
	 boolean b5 = put_group_info(connection, group_account, "question", "请输入验证信息");
	 boolean b6 = put_group_info(connection, group_account, "answer", "无");
	 
	 boolean b7 = put_group_info(connection, group_account, "temporary_chat", "false");
	 boolean b8 = put_group_info(connection, group_account, "stop_all", "false");
	 boolean b9 = put_group_info(connection, group_account, "file_unload", "false");
	 boolean b10 = put_group_info(connection, group_account, "file_load", "false");
	 boolean b11 = put_group_info(connection, group_account, "icon_unload", "false");
	
	 long time = System.currentTimeMillis();
	 String build_time = new SimpleDateFormat("yyyy年MM月dd日。").format(time);
	 boolean b12 = put_group_info(connection, group_account, "group_introduce","本群创建于 "+build_time);
	 
	 String ip_port =  Group_restore_generate.get_ip_port(group_account);
	 boolean b13 = put_group_info(connection, group_account, "ip_port", ip_port);
	 
	 File_tool.create_file_folder("D:\\UTO_server\\group_"+group_account+"\\file");
	 File_tool.create_file_folder("D:\\UTO_server\\group_"+group_account+"\\icon");
	 
	 boolean scuess = b1&&b2&&b3&&b4&&b5&&b6&&b7&&b8&&b9&&b10&&b11&&b12&&b13;
	 System.out.println(b13);
	 System.out.println(scuess);
	// write group_head_image ...
	 
	 Connection_Pool.close_Resourse(connection, null, null);
	 
	return scuess;
	 
 }
 public static boolean put_group_info( Connection connection,String group_account,String name,String value) {
	 		   
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
		   String sql = "insert into tb_info_"+group_account+" values(?,?)";		   
		   
		   try {
			connection.setAutoCommit(false);
			
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setString(1, name);
			preparedStatement.setString(2, value);			
		
			preparedStatement.executeUpdate();
			connection.commit();
			
		} catch (Exception e) {
			
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
			return false;
		}
		
		Connection_Pool.close_Resourse(null, preparedStatement, resultSet);
		 return true;
		   
	   }
 
 public static void alter_group_info(Group_info_message group_info) {
	 
	  String group_account = String.valueOf(group_info.getGroup_account());
	  Connection connection = Connection_Pool.get_group_connection();
	  
	update_group_info(connection, group_account, "group_name", group_info.getGroup_name());
	update_group_info(connection, group_account, "group_type", String.valueOf(group_info.getGroup_type()));
	update_group_info(connection, group_account, "pay_days", String.valueOf(group_info.getPay_days()));
	update_group_info(connection, group_account, "pay_money",String.valueOf(group_info.getPay_money()));
	update_group_info(connection, group_account, "question", group_info.getQuestion());
	update_group_info(connection, group_account, "answer", group_info.getAnswer());
	  
	update_group_info(connection, group_account, "temporary_chat",String.valueOf(group_info.isTemporary_chat()));
	update_group_info(connection, group_account, "stop_all",String.valueOf(group_info.isStop_all_chat()));
	update_group_info(connection, group_account, "file_unload",String.valueOf(group_info.isFile_upload_all()));
	update_group_info(connection, group_account, "file_load",String.valueOf(group_info.isFile_load_all()));
	update_group_info(connection, group_account, "icon_unload",String.valueOf(group_info.isIcon_upload_all()));
	update_group_info(connection, group_account, "group_introduce", group_info.getGroup_introduce());
	  
	  byte[] group_head_bytes = group_info.getGroup_head_icon();
	  Icon_tools.Write_image(group_head_bytes,"D:\\UTO_server\\image\\private_head_image\\big_head_image\\"+group_account+".png");
	  Icon_tools.compress_head_image(group_account, group_head_bytes);
	  
	  Connection_Pool.close_Resourse(connection, null, null);
 }   	  
 public static boolean update_group_info(Connection connection,String group_account,String name,String value) {
	   
	    PreparedStatement preparedStatement=null;
	    
	       String sql = "update tb_info_"+group_account+" set value=? where name='"+name+"'";
		   
		   try {
			connection.setAutoCommit(false);
			
			preparedStatement = connection.prepareStatement(sql);						
		    preparedStatement.setString(1, value);
			
			preparedStatement.executeUpdate();
			connection.commit();
			
		} catch (Exception e) {
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			return false;
		}
		 return true;
	   }
  
  public static Group_info_message get_group_info(int group_account){
	  
	    Connection connection=Connection_Pool.get_group_connection();
	    PreparedStatement preparedStatement=null;
	    ResultSet resultSet = null;
	    
		   ArrayList<String> arrayList = new ArrayList<>();
		   String value = null;
		   
		   String sql = "select * from tb_info_"+group_account;
		   
		   try {					  
			   preparedStatement = connection.prepareStatement(sql);
			   resultSet = preparedStatement.executeQuery();
		} catch (Exception e) {
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return null;
		}
		   
		   try {
			while(resultSet.next()) {
				   
				value = resultSet.getString(2);
				arrayList.add(value);
			   }
		} catch (SQLException e) {
			Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			return null;
		}
		   
		   Group_info_message group_info = new Group_info_message(14, group_account);
		   
		   byte[] group_head_bytes = Icon_tools.get_Big_HeadIcon_Bytes(String.valueOf(group_account));
		   group_info.setGroup_head_icon(group_head_bytes);
		   
		   group_info.setGroup_name(arrayList.get(0));
		   group_info.setGroup_type(Integer.parseInt(arrayList.get(1)));
		   group_info.setPay_days(Integer.parseInt(arrayList.get(2)));
		   group_info.setPay_money(Integer.parseInt(arrayList.get(3)));
		   group_info.setQuestion(arrayList.get(4));
		   group_info.setAnswer(arrayList.get(5));
		   
		   group_info.setTemporary_chat(Boolean.parseBoolean(arrayList.get(6)));
		   group_info.setStop_all_chat(Boolean.parseBoolean(arrayList.get(7)));
		   group_info.setFile_upload_all(Boolean.parseBoolean(arrayList.get(8)));
		   group_info.setFile_load_all(Boolean.parseBoolean(arrayList.get(9)));
		   group_info.setIcon_upload_all(Boolean.parseBoolean(arrayList.get(10)));
		   group_info.setGroup_introduce(arrayList.get(11));
		   group_info.setIp_port(arrayList.get(12));
		   
		   Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
		   return group_info;
	   }
	  
	public static boolean create_info_table(String group_account) {
		  Connection connection=Connection_Pool.get_group_connection();
		    PreparedStatement preparedStatement=null;
		    ResultSet resultSet = null;
		    
			String table_sql = get_create_table_sql(group_account);
			
			try {
				connection.setAutoCommit(false);
				try {
					preparedStatement = connection.prepareStatement(table_sql);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				preparedStatement.executeUpdate();
				
				connection.commit();
			} catch (Exception e) {
			
				try {
					connection.rollback();
					Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
				} catch (Exception e2) {
					// TODO: handle exception
				}
				
				return false;
			}
			
			try {
				connection.rollback();
				Connection_Pool.close_Resourse(connection, preparedStatement, resultSet);
			} catch (Exception e2) {
				// TODO: handle exception
			}
			
			return true;
		}
	
	   public static void main(String[] args) {
		
		  Group_info_message group_info_message = Group_info_generate.get_group_info(100000000);
		  String ip_port = group_info_message.getIp_port();
		  System.out.println(ip_port);
	}
}
