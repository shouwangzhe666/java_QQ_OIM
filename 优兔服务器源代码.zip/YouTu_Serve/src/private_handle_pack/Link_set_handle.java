package private_handle_pack;

import database_generat.Link_man_generate;
import database_generat.Login_generate;
import database_generat.Off_message_generage;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import private_encode_pack.Link_set_encoder;
import private_message.Link_set;

public class Link_set_handle extends SimpleChannelInboundHandler<Link_set>{

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Link_set link_set) throws Exception {
		
		int type = link_set.getType();
		if(type==1) {handle_type1(link_set);}
		else if(type==2) {handle_type2(link_set);}
		else if(type==3) {handle_type3(link_set);}
		else if(type==4) {handle_type4(link_set);}
		else if(type==5) {handle_type5(link_set);}
		else if(type==6) {handle_type6(link_set);}
		else if(type==7) {handle_type7(link_set);}
		else if(type==8) {handle_type8(link_set);}
		else if(type==9) {handle_type9(link_set);}
	}

public void handle_type1( Link_set link_set) {
	
	String native_account = link_set.getNative_count();
	boolean privat = link_set.isPrivat();
	String new_group = link_set.getNew_group();
		
	Link_man_generate.put_new_group(native_account, privat, new_group);
}
public void handle_type2(Link_set link_set) {
	
	String native_account = link_set.getNative_count();
	boolean privat = link_set.isPrivat();
	String old_group = link_set.getOld_group();
	String new_group = link_set.getNew_group();
	
	Link_man_generate.rename_group_name(native_account, privat, old_group, new_group);
}
public void handle_type3(Link_set link_set) {
	
	String native_account = link_set.getNative_count();
	boolean privat = link_set.isPrivat();
	String old_group = link_set.getOld_group();
	String new_group = link_set.getNew_group();
	
	Link_man_generate.delete_group_name(native_account, privat, old_group, new_group);
}
public void handle_type4(Link_set link_set) {
	
	String native_account = link_set.getNative_count();
	String link_account = link_set.getLink_account();
	String new_group = link_set.getNew_group();
	
	Link_man_generate.alter_link_man(native_account, link_account, "group_name", new_group);
}
public void handle_type5(Link_set link_set) {
	
	String native_account = link_set.getNative_count();
	String link_account = link_set.getLink_account();
	
	boolean d1 = Link_man_generate.delete_link_man(native_account, link_account);
	boolean d2 = Link_man_generate.delete_link_man(link_account, native_account);
	
	System.out.println("delete1 scuess? "+d1);
	System.out.println("delete2 scuess? "+d2);
	// inform the deleted link_man to delete the related restore
	if(link_account.length()==8) {
	
	boolean online = Ping_Pong_Handle.all_users.get(Integer.parseInt(link_account))==null?false:true;
	
	if(online) {Ping_Pong_Handle.all_users.get(Integer.parseInt(link_account)).writeAndFlush(link_set);}
	else {
		ByteBuf buf = Unpooled.buffer(1024, 102400);
		new Link_set_encoder().encode_type5(link_set,buf);
		byte[] by = new byte[buf.readableBytes()];
		buf.readBytes(by);
		Off_message_generage.put_off_message(link_account, System.currentTimeMillis(), 10, Integer.parseInt(native_account), by);
	}
	} // link_account.length()==8
}
public void handle_type6(Link_set link_set) {
	
	String native_account = link_set.getNative_count();
	String link_account = link_set.getLink_account();
	String new_remark = link_set.getNew_remark();
	
	Link_man_generate.alter_link_man(native_account, link_account, "remark", new_remark);
}
public void handle_type7(Link_set link_set) {
	
	String native_account = link_set.getNative_count();
	String link_account = link_set.getLink_account();
	String inform_type = link_set.getInform_type();
	
	Link_man_generate.alter_link_man(native_account, link_account, "inform_type", inform_type);
}
public void handle_type8(Link_set link_set) {
	
	String native_account = link_set.getNative_count();
	String state = link_set.getState();
	
	Login_generate.set_state(native_account, state);
}

public void handle_type9(Link_set link_set) {
	
	String native_account = link_set.getNative_count();
	String link_account = link_set.getLink_account();
	
   boolean scuess =   Link_man_generate.join_blacklist(native_account, link_account);
	
   System.out.println("blacklist scuess ? "+scuess);
  
}
public static void main(String[] args) {
	 
	String account = "10000001";
	String link_account = "10000002";
	
//	Link_man_generate.join_blacklist(account, link_account);
	Link_man_generate.delete_blacklist(account, link_account);
}
}
