package private_handle_pack;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import database_generat.Link_man_generate;
import database_generat.Login_generate;
import database_generat.Off_message_generage;
import database_generat.Private_info_generate;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import private_message.Private_info;
import tools.Icon_tools;

public class Private_info_handle extends SimpleChannelInboundHandler<Private_info>{

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Private_info private_info) throws Exception {
		
		int type = private_info.getType();
		
		if(type==1) {
						
			String account = private_info.getCount();
			String new_email = private_info.getE_mail();
			Login_generate.set_email(account, new_email);
			
			String out_file = "D:\\UTO_server\\image\\private_head_image\\big_head_image\\"+account+".png";
			byte[] icon_byte = private_info.getIcon_bytes();
			
			// operation of updating the private_info
			
			boolean b1 = false;
			boolean b2 = false;
			boolean b3 = false;
			
			 b1 = Icon_tools.Write_image(icon_byte, out_file);
			 b2 = Icon_tools.compress_head_image(account,icon_byte);
			 b3 = Private_info_generate.update_info(private_info);
			 byte[] small_iconbytes = Icon_tools.get_Small_HeadIcon_Bytes(account);
			 
			String result = b1&&b2&&b3?"恭喜您资料编辑成功！":"对不起，资料编辑失败，请稍后再试！";
			
			Private_info message = new Private_info();
			message.setType(2);
			message.setScuess(b1&&b2);
			message.setResult(result);
			
			ctx.writeAndFlush(message);
			
			// operation of updating related link_man's head_image
			
			ArrayList<Integer> all_link_man = Link_man_generate.get_all_Private_link_man(account);
			byte[] bytes = encode_HeadIcon_updateMessage(private_info,small_iconbytes);  // get bytes of link_info(type==3)
			ByteBuf b = new PooledByteBufAllocator(false).directBuffer(1024, 1024*30);
			b.writeBytes(bytes);
			
			for(int i=0;i<all_link_man.size();i++) {
				
				 int link_account = all_link_man.get(i);
				 Channel channel = Ping_Pong_Handle.all_users.get(link_account);
				 
				if(channel!=null) {
					ByteBuf buf = b.duplicate();
					buf.retain();
					channel.writeAndFlush(buf);
				}
				else {
					Off_message_generage.put_off_message(String.valueOf(link_account), System.currentTimeMillis(), 3, Integer.parseInt(account),bytes);
				}
			} // for
		}
		
		else if(type==3) {
			
			String account = private_info.getCount();
			Private_info meInfo = Private_info_generate.get_info(account);
			
			if(meInfo==null) {				
				// the account is not exist 
				meInfo = new Private_info(account, new byte[0], "", "", "", "", "", "", "", "", "");
				meInfo.setType(4);
				ctx.writeAndFlush(meInfo);
				return;
			}		
			meInfo.setType(4);
			
			byte[] icon_bytes = Icon_tools.get_Big_HeadIcon_Bytes(account);
			meInfo.set_icon_bytes(icon_bytes);
			
			ctx.writeAndFlush(meInfo);
		}
	}
	
	public byte[] encode_HeadIcon_updateMessage(Private_info info,byte[] small_iconbytes) {
		
		String account = info.getCount();
		byte[] by1 = null;
		try {
			 by1 = account.getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ByteBuf buf = Unpooled.buffer(1024, 1024*20);
		
		buf.writeInt(121);
		buf.writeInt(3);
		
		buf.writeInt(by1.length);
		buf.writeBytes(by1);
		
		buf.writeInt(small_iconbytes.length);
		buf.writeBytes(small_iconbytes);
		
		byte[] bytes = new byte[buf.readableBytes()];
		buf.readBytes(bytes);
		
		return bytes;
	}
}
