package private_handle_pack;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import private_message.Private_Chat_Message;

public class Chat_handle extends SimpleChannelInboundHandler<Private_Chat_Message>{

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Private_Chat_Message chat_Message) throws Exception {
		
		int from_account = chat_Message.getFrom_account();
		int to_account = chat_Message.getTo_account();
		
//		boolean online = Login_generate.is_online(String.valueOf(to_account));
//		 
//		if(online) {
//			Ping_Pong_Handle.all_users.get(to_account).writeAndFlush(chat_Message);
//		}
//		else {
//			if(chat_Message.getType()==3) {
//				long time_code  = chat_Message.getTime_code();
//				Off_message_generage.delete_off_message(String.valueOf(to_account), time_code);
//			} // remove_message
//			else {
//				
//			 byte[] content = chat_Message.getBytes();			
//			Off_message_generage.put_off_message(String.valueOf(to_account),chat_Message.getSend_time(),1, from_account, content);
//			}  // normal_chat_message
//		} // off_line
		
	}

}
