package private_handle_pack;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import private_message.Apply_Message;
import tcp_pack.TCP_P2P_Server;
import tcp_pack.TCP_P4P_Server;
import tcp_pack.TCP_Transfer_Server;
import udp_pack.UDP_P4P_Server;

public class Apply_handle  extends SimpleChannelInboundHandler<Apply_Message>{

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Apply_Message apply_Message) throws Exception {
		
		int protocal_code = apply_Message.getProtocal_code();
		
		if(protocal_code==131) {handle_file(ctx,apply_Message);}
		else if(protocal_code==132) {handle_video_chat(ctx,apply_Message);}
		else if(protocal_code==133) {handle_audio_chat(ctx,apply_Message);}
		else if(protocal_code==134) {handle_constant(ctx,apply_Message);}
		else if(protocal_code==135) {handle_audio(ctx,apply_Message);}
		
		Ping_Pong_Handle.all_users.get(apply_Message.getTo_account()).writeAndFlush(apply_Message);
	}
public void handle_file(ChannelHandlerContext ctx,Apply_Message apply_Message) {

		 if(apply_Message.getType()==2&&apply_Message.isAccept()) {
			 if(apply_Message.getP2p_type()==1) {
				
					int tcp_server_port = start_TCP_P2P_Server();
					apply_Message.setTcp_server_port(tcp_server_port);
			 } //P2p_type()==1
			 else if(apply_Message.getP2p_type()==2) {
				    int tcp_server_port = start_TCP_P4P_Server(apply_Message.getRequest_ip());
					apply_Message.setTcp_server_port(tcp_server_port);
			 } //P2p_type()==2
			 else if(apply_Message.getP2p_type()==3) {
				    TCP_Transfer_Server server = new TCP_Transfer_Server();
				    server.start();
				    int tcp_server_port = server.getPort();
					apply_Message.setTcp_server_port(tcp_server_port);
			 } //P2p_type()==3
			 
			 Apply_Message message3 = copy_Apply_Message(apply_Message);
			 ctx.writeAndFlush(message3);
		}		 
}
public void handle_video_chat(ChannelHandlerContext ctx,Apply_Message apply_Message) {
	 if(apply_Message.getType()==2&&apply_Message.isAccept()) {
		 int p2p_type = apply_Message.getP2p_type();
		 
		 if(p2p_type==1) {
				
				int udp_server_port = start_UDP_P2P_Server(p2p_type);
				apply_Message.setUdp_server_port1(udp_server_port);
				
				 Apply_Message message3 = copy_Apply_Message(apply_Message);
				 ctx.writeAndFlush(message3);
		 } //P2p_type()==1
		 else if(apply_Message.getP2p_type()==2) {
			  int tcp_server_port = start_TCP_P4P_Server(apply_Message.getRequest_ip());
				apply_Message.setTcp_server_port(tcp_server_port);
				
			    int[] ports = start_UDP_P4P_Server(apply_Message.getRequest_ip(),apply_Message.getReply_ip());
				apply_Message.setUdp_server_port1(ports[0]);
				
				Apply_Message message3 = copy_Apply_Message(apply_Message);
				message3.setUdp_server_port2(ports[1]);
				ctx.writeAndFlush(message3);
		 } //P2p_type()==2		
	}
}
public void handle_audio_chat(ChannelHandlerContext ctx,Apply_Message apply_Message) {
	 if(apply_Message.getType()==2&&apply_Message.isAccept()) {
		 int p2p_type = apply_Message.getP2p_type();
		 
		 if(p2p_type==1) {
				
				int udp_server_port = start_UDP_P2P_Server(p2p_type);
				apply_Message.setUdp_server_port1(udp_server_port);
				
				 Apply_Message message3 = copy_Apply_Message(apply_Message);
				 ctx.writeAndFlush(message3);
		 } //P2p_type()==1
		 else if(apply_Message.getP2p_type()==2) {
			 
			    int[] ports = start_UDP_P4P_Server(apply_Message.getRequest_ip(),apply_Message.getReply_ip());
				apply_Message.setUdp_server_port1(ports[0]);
				
				Apply_Message message3 = copy_Apply_Message(apply_Message);
				message3.setUdp_server_port2(ports[1]);
				ctx.writeAndFlush(message3);
		 } //P2p_type()==2	
		 else if(apply_Message.getP2p_type()==3) {
			     int[] ports = start_UDP_AudioChat_Server();
				 apply_Message.setUdp_server_port1(ports[0]);
				
				Apply_Message message3 = copy_Apply_Message(apply_Message);
				message3.setUdp_server_port2(ports[1]);
				ctx.writeAndFlush(message3);
		 } //P2p_type()==3
	}
}
public void handle_constant(ChannelHandlerContext ctx,Apply_Message apply_Message) {
	if(apply_Message.getType()==2&&apply_Message.isAccept()) {
		 if(apply_Message.getP2p_type()==1) {
			
				int tcp_server_port = start_TCP_P2P_Server();
				apply_Message.setTcp_server_port(tcp_server_port);
		 } //P2p_type()==1
		 else if(apply_Message.getP2p_type()==2) {
			  int tcp_server_port = start_TCP_P4P_Server(apply_Message.getRequest_ip());
				apply_Message.setTcp_server_port(tcp_server_port);
		 } //P2p_type()==2
		 else if(apply_Message.getP2p_type()==3) {
			    TCP_Transfer_Server server = new TCP_Transfer_Server();
			    server.start();
			    int tcp_server_port = server.getPort();
				apply_Message.setTcp_server_port(tcp_server_port);
		 } //P2p_type()==3
		 
		 Apply_Message message3 = copy_Apply_Message(apply_Message);
		 ctx.writeAndFlush(message3);
	}		 
}
public void handle_audio(ChannelHandlerContext ctx,Apply_Message apply_Message) {
	
	System.out.println("handle_audio  P2p_type: "+apply_Message.getP2p_type());
	
	if(apply_Message.getType()==1) {            // audio request
		 if(apply_Message.getP2p_type()==1) {
			
				int tcp_server_port = start_TCP_P2P_Server();
				apply_Message.setTcp_server_port(tcp_server_port);
		 } //P2p_type()==1
		 else if(apply_Message.getP2p_type()==2) {
			  int tcp_server_port = start_TCP_P4P_Server(apply_Message.getRequest_ip());
				apply_Message.setTcp_server_port(tcp_server_port);
		 } //P2p_type()==2
		 else if(apply_Message.getP2p_type()==3) {
			    TCP_Transfer_Server server = new TCP_Transfer_Server();
			    server.start();
			    int tcp_server_port = server.getPort();
				apply_Message.setTcp_server_port(tcp_server_port);
		 } //P2p_type()==3
		 Apply_Message message2 = copy_Apply_Message(apply_Message);
		 message2.setType(2);
		 ctx.writeAndFlush(message2);
	}		 
}
public Apply_Message copy_Apply_Message(Apply_Message apply_Message) {
	
	Apply_Message message = new Apply_Message(apply_Message.getProtocal_code(), 3, apply_Message.getTo_account(), apply_Message.getFrom_account(), apply_Message.getP2p_type(), apply_Message.getTcp_server_port(), apply_Message.getUdp_server_port1(), apply_Message.getUdp_server_port2(), apply_Message.isAccept(), apply_Message.getRequest_ip(), apply_Message.getReply_ip());
	message.setFile_code(apply_Message.getFile_code());
	message.setFile_name(apply_Message.getFile_name());
	message.setFile_size(apply_Message.getFile_size());
	message.setFilebin_location(apply_Message.getFilebin_location());
	return message;
}
public int start_TCP_P2P_Server() {
	
	    TCP_P2P_Server p2p_Server = new TCP_P2P_Server();
		p2p_Server.start();
		int tcp_server_port = p2p_Server.get_server_port();
		
		return tcp_server_port;
}

public int start_TCP_P4P_Server(String request_ip) {
    TCP_P4P_Server p4p_Server = new TCP_P4P_Server();
	p4p_Server.start();
	int tcp_server_port = p4p_Server.get_server_port();
	
	Apply_Message apply_Message = new Apply_Message(136, 1, 1, 1, 1, tcp_server_port, 1, 1, true,"1","1");
	Channel channel = Ping_Pong_Handle.get_diffentChannel(request_ip);
	channel.writeAndFlush(apply_Message);
	
return tcp_server_port;
}
public int start_UDP_P2P_Server(int p2p_type) {
	
	UDP_P4P_Server server1 = new UDP_P4P_Server();
	server1.start();			
	int udp_server_port1 = server1.get_server_port();
	
    return udp_server_port1;
}
public int[] start_UDP_P4P_Server(String ip1,String ip2) {
	
	UDP_P4P_Server server1 = new UDP_P4P_Server();
	server1.start();			
	int udp_server_port1 = server1.get_server_port();
	
    UDP_P4P_Server server2 = new UDP_P4P_Server();
    server2.start();
	int udp_server_port2 = server2.get_server_port();
		
	int[] server_ports = new int[2];
	server_ports[0] = udp_server_port1;
	server_ports[1] = udp_server_port2;
		
	Apply_Message apply_Message = new Apply_Message(137, 1, 1, 1, 1, 1, udp_server_port1, udp_server_port2, true,ip1,ip2);
	
	Channel channel = Ping_Pong_Handle.get_diffentChannel(ip1);
	channel.writeAndFlush(apply_Message);
	
    return server_ports;
}
public int[] start_UDP_AudioChat_Server() {
	
	UDP_P4P_Server server1 = new UDP_P4P_Server();
	server1.start();			
	int udp_server_port1 = server1.get_server_port();
	
    UDP_P4P_Server server2 = new UDP_P4P_Server();
    server2.start();
	int udp_server_port2 = server2.get_server_port();
		
	int[] server_ports = new int[2];
	server_ports[0] = udp_server_port1;
	server_ports[1] = udp_server_port2;
		
	Apply_Message apply_Message = new Apply_Message(137, 1, 1, 1, 1, 1, udp_server_port1, udp_server_port2, true,"1","2");
	
	Channel channel = Ping_Pong_Handle.get_ServerChannel();
	channel.writeAndFlush(apply_Message);
	
    return server_ports;
}
}
