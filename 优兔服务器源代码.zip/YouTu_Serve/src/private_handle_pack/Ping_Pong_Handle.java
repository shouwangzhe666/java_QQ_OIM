package private_handle_pack;

import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import com.sun.java.util.Redis;

import database_generat.Link_man_generate;
import database_generat.Login_generate;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import message_log_regis.Ping_Pong;
import serve.Private_Chat_Serve;
import tools.RedisUtill;

public class Ping_Pong_Handle extends SimpleChannelInboundHandler<Ping_Pong>{
    
    int i =0 ;
    int account = 0;
    boolean login_online = false;
    public static ConcurrentHashMap<Integer, Channel> all_users = null;
	static {
		all_users = new ConcurrentHashMap<Integer, Channel>();
	}
	
    public Ping_Pong_Handle() { 
    	
	}
    public static Channel get_diffentChannel(String request_ip) {
    	 
    	  ArrayList<Channel> all_channels = new ArrayList<>(all_users.values());
    	  int size = all_channels.size();
    	  
    	  for(int i=0;i<size;i++) {
    		  int index = (int)(Math.random()*(size-1)+1);
    		  Channel channel = all_channels.get(index);
    		  String ip = channel.toString().substring(18, 31);
    		  if(ip.equals(request_ip)||ip.equals("115.28.186.188")) {continue;}
    		  else {
    			  String remoteIp = RedisUtill.get_Ip_Info(ip);
    			  if(remoteIp==null||remoteIp.endsWith("0000")) {continue;}
    			  else {return channel;}
    		  }
    	  }
    	  
    	  return all_users.get(10000001);
    }
   
    public static Channel  get_ServerChannel() {
    	 return all_users.get(10000001);
    }
	@Override
	protected void messageReceived(ChannelHandlerContext ctx, Ping_Pong ping_Pong) throws Exception {
		
		   i=0;
	       ctx.writeAndFlush(new Ping_Pong());
	       account = ping_Pong.get_account();
	      
	      if(account!=0&&!login_online) {
	    	
	    	  login_online = true;
	    	  Ping_Pong_Handle.all_users.put(account, ctx.channel());
	    	  Login_generate.set_online(String.valueOf(account), "1");	    	 
	    	  Private_Chat_Serve.update_online();
	    	  
			  String state ="在线";
			  String remote_ip = "1";					 
					    
			  Channel channel = Ping_Pong_Handle.all_users.get(account);
			if(channel!=null) {
					remote_ip = channel.remoteAddress().toString().substring(1);
					remote_ip = remote_ip.split(":")[0].trim();
			}
			 Redis.startRedis();
			 Login_generate.set_state(String.valueOf(account), state);	
			 Link_man_generate.update_related_LinkState(String.valueOf(account), state);
		}
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {		
	
//		System.out.println("服务端 发生异常。。。");
//		cause.printStackTrace();
	}
	
	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
	
	//    System.out.println("服务端  Ping_Pong_Handle Inactive。。。");
	   
		boolean sameOne = Ping_Pong_Handle.all_users.get(account)==ctx.channel();
		
	    if(login_online&&sameOne) {
	    	
	    	Ping_Pong_Handle.all_users.remove(account);
	    	Login_generate.set_online(String.valueOf(account), "0");
	    	Private_Chat_Serve.update_online();
	    	
	    	    String state ="离线";
			    String remote_ip = "1";					 
			    
			    Login_generate.set_state(String.valueOf(account), state);
			    Link_man_generate.update_related_LinkState(String.valueOf(account), state);
//			    String ip = RedisUtill.get_Account_IP(String.valueOf(account));
//			    RedisUtill.set_IP_Info(ip, "0000");
	    }
	
	}
	
	@Override
	public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
		
		if(evt instanceof IdleStateEvent) {
			IdleStateEvent idleStateEvent = (IdleStateEvent) evt;
			
			if(idleStateEvent.state().equals(IdleState.READER_IDLE)) {
			
					System.out.println("服务端某客户心跳超时");
					ctx.channel().close().sync();
			} // if
			else if(idleStateEvent.state().equals(IdleState.WRITER_IDLE)) {
				ctx.writeAndFlush(new Ping_Pong());
			}
		}
	}
	
}
