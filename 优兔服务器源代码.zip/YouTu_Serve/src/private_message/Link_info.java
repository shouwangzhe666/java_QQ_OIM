package private_message;

import java.awt.Image;
import java.io.File;
import java.util.ArrayList;
import database_generat.Link_man_generate;
import tools.Icon_tools;
public class Link_info {
	
	/**
	 * type=1 头像请求
	 * type=2 头像回复/联系人应答回复
	 * type=3 头像更改
	 * 
	 * type=4 联系人分组（所有）
	 * type=5 联系人列表（所有）
	 * 
	 * type=6联系人搜索
	 * type=7 联系人消息返回
	 * type=8 联系人申请加入
	 * type=9 联系人加入应答
	 * 
	 * type=10 请求该群聊所有成员头像
	 */
	
	    int type = 1;
	    
	    //  type=1 头像请求
	    
		  ArrayList<Integer> own_image = null;
		   
		  public Link_info(int type) {
			this.type = type;
		}
		  
		  public void Init_reques_head_image() {
			   
			   ArrayList<Integer> own_image =  new ArrayList<>();
			   
			   File file = null;
		//	   String dir = "C:\\ProgramData\\UTO\\UTO_"+Main_Frame.getNative_count()+"\\image\\head_image";
			   String dir = "";
			   if(!new File(dir).exists()) {new File(dir).mkdirs();}
			   file = new File(dir);
			   
			   File[] files = file.listFiles();
			   String temp_path = null;
			   String account = null;
			   String regex_string = "//d{8,9}.png";
			   int index = 0;
			   
			   for(int i=0;i<files.length;i++) {
				   temp_path = file.getName();
				   if(temp_path.matches(regex_string)) {
		                 index = temp_path.lastIndexOf(".");
		                 account = temp_path.substring(0, index);
		                 own_image.add(Integer.parseInt(account));
				   }
			   }
			  
			   this.own_image =  own_image;
			   return;
		   }
		  
	   public ArrayList<Integer> get_own_image() {
		   
		    return own_image;
	   }
	   public void set_own_image(ArrayList<Integer> own_image) {
		   
		   this.own_image  = own_image;
	   }
    
      // type=2 头像回复
   
   ArrayList<ArrayList<Object>> all_head_icon_byte = null;
         
   public void Init_respose_head_image(ArrayList<Integer> lacked_account) {
	   
	   ArrayList<ArrayList<Object>> all_head_icon_byte = new ArrayList<>();
	   
	   int account = 0;
	   byte[] icon_bytes = null;
	   ArrayList<Object> row_list= null;
	   
	   for(int i=0;i<lacked_account.size();i++) {
		   
		   account = lacked_account.get(i);
		   icon_bytes = Icon_tools.get_Small_HeadIcon_Bytes(String.valueOf(account));
		   
		   row_list = new ArrayList<>();
		   row_list.add(account);
		   row_list.add(icon_bytes);
		   
		   all_head_icon_byte.add(row_list);
	   }
	   
	   this.all_head_icon_byte = all_head_icon_byte;
   }
   
  public void Init_specified_respose_head_image(String account) {
	   
	   ArrayList<ArrayList<Object>> all_head_icon_byte = new ArrayList<>();
	   ArrayList<Object> row_list= new ArrayList<>();
	 
	   byte[] icon_bytes = Icon_tools.get_Small_HeadIcon_Bytes(account);
	   row_list.add(Integer.parseInt(account));
	   row_list.add(icon_bytes);
	   
	   all_head_icon_byte.add(row_list);
	   this.all_head_icon_byte = all_head_icon_byte;
	   }

   public ArrayList<ArrayList<Object>>  get_all_respose_head_image() {
	   
	    return  this.all_head_icon_byte;
  }
   public void set_all_respose_head_image( ArrayList<ArrayList<Object>> all_head_icon_byte) {
	   this.all_head_icon_byte = all_head_icon_byte;
   }
   
   //  type=3 头像更改消息
   //   set type = 3 and set account to the update_account
			
	//  type=4 联系人分组（所有）
	
  
ArrayList<String> all_group = null;
   
public void Init_all_link_group(String account) {
	
	 ArrayList<String> all_group = Link_man_generate.get_all_Needed_groups(account);
	 this.all_group = all_group;
}

public ArrayList<String> getAll_group() {
	return all_group;
}

public void setAll_group(ArrayList<String> all_group) {
	this.all_group = all_group;
}

//type=5 联系人列表消息（所有）

ArrayList<ArrayList<String>> all_link_man = null;

public void Init_all_link_man(String account) {

 ArrayList<ArrayList<String>> all_link_man = Link_man_generate.get_all_link_man(account);
 this.all_link_man = all_link_man;
}

public void Init_specified_link_man(String account,String link_account) {
	
	ArrayList<ArrayList<String>> all_link_man = Link_man_generate.get_specified_link_man(account, link_account);
	this.all_link_man = all_link_man;
}
public ArrayList<ArrayList<String>> getAll_link_man() {
	return all_link_man;
}

 public void setAll_link_man(ArrayList<ArrayList<String>> all_link_man) {
	this.all_link_man = all_link_man;
}
 

//    type=6联系人搜索
// just set type = 6 and set the account to searching_account


//      type=7 联系人消息返回

		String account = null;
        byte[] head_icon_bytes = null;
        String name = null;
        String signature = null;       

		public byte[] getHead_icon_bytes() {
			return head_icon_bytes;
		}

		public void setHead_icon_bytes(byte[] head_icon_bytes) {
			this.head_icon_bytes = head_icon_bytes;
		}

		public String getAccount() {
			return account;
		}

		public void setAccount(String account) {
			this.account = account;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getSignature() {
			return signature;
		}

		public void setSignature(String signature) {
			this.signature = signature;
		}

//* type=8 联系人申请加入
		
	// account
	// link_account
	// head_icon_bytes
	// name
	// verify_message
	// system_time
		
	long system_time = 0l;	
	String verify_message = null;
	
	public void set_verify_message(String verify_message) {
		this.verify_message = verify_message;
	}
	public String get_verify_message() {
		return verify_message;
	}
		
//	 * type=9 联系人加入应答
	
	    // account
	    // link_account
		// head_icon_bytes
		// name
		// result_message
	    // system_time
	
	  boolean accept = true;
	
		public boolean isAccept() {
		return accept;
	}		
	public void setAccept(boolean accept) {
		this.accept = accept;
	}
	
	// type=10 请求该群聊所有成员头像
	// group_account
	
	int group_account = 0;
	
	public int getGroup_account() {
		return group_account;
	}

	public void setGroup_account(int group_account) {
		this.group_account = group_account;
	}
	public long getSystem_time() {
		return system_time;
	}

	public void setSystem_time(long system_time) {
		this.system_time = system_time;
	}
	   
	 String link_count = null;
	    String remark = null;
	    Image  link_image = null;
	    String group  = null;
		String []group_names = null;
				
		String inform_type = null;
		String state = null;
		String id = null;
		String remote_ip = null;
        String out_time = null;
     
     public Link_info(String link_count, String remark,String signature, String group, String[] group_names, String inform_type,
				String state,String id, String remote_ip,String out_time) {
			
			this.link_count = link_count;
			this.remark = remark;
			this.signature = signature;
			this.group = group;
			this.group_names = group_names;
			this.inform_type = inform_type;
			this.state = state;
			this.id = id;
			this.out_time = out_time;
			this.remote_ip = remote_ip;
			
	//		setLink_image( Icon_tools.get_client_head_image(link_count));
			
		}
		public int getType() {
			return type;
		}

		public void setType(int type) {
			this.type = type;
		}

		public String getLink_count() {
			return link_count;
		}

		public void setLink_count(String link_count) {
			this.link_count = link_count;
		}
         
		public Image getLink_image() {
			return link_image;
		}

		public void setLink_image(Image link_image) {
			this.link_image = link_image;
		}

		public String getRemark() {
			return remark;
		}

		public void setRemark(String remark) {
			this.remark = remark;
		}

		public String getGroup() {
			return group;
		}

		public void setGroup(String group) {
			this.group = group;
		}

		public String[] getGroup_names() {
			return group_names;
		}

		public void setGroup_names(String[] group_names) {
			this.group_names = group_names;
		}

		public String getInform_type() {
			return inform_type;
		}

		public void setInform_type(String inform_type) {
			this.inform_type = inform_type;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}
		
		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getOut_time() {
			return out_time;
		}

		public void setOut_time(String out_time) {
			this.out_time = out_time;
		}
		public String getRemote_ip() {
			return remote_ip;
		}
		public void setRemote_ip(String remote_ip) {
			this.remote_ip = remote_ip;
		} 				
}
