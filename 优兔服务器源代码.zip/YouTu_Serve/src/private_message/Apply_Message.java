package private_message;

public class Apply_Message {

	int protocal_code = 131;
	int type = 1;                   // type1  request
	int from_account = 0;           // type2  reply
	int to_account = 0;             // type3  reply`reply
	
	int p2p_type = 0;    //directly connect if p2p_type = 1 or indirectly connect if p2p_type = 2
	int tcp_server_port = 0;
	int udp_server_port1 = 0;
	int udp_server_port2 = 0;
	boolean accept = true;
	String request_ip = "";
	String reply_ip = "";
	
	long file_code = 0l;
	String file_name="";
	long file_size=0l;
	long filebin_location=0;
	/**
	 * protocal_code = 131; 文件发送
	 * 
	 * type1 file_code
	 *       file_name   //file request
	 *       file_size
	 *  
	 * type2 file_code
	 *       filebin_location   //client reply
	 *       accept     
	 *
	 * protocal_code = 132; 视频通话
	 * type1  request
	 * type2  reply
	 * 
	 * protocal_code = 133; 音频通话
	 * type1  request
	 * type2  reply
	 * 
	 * protocal_code = 134; 远程桌面
	 * type1  request
	 * type2  reply
	 * 
	 * protocal_code = 135; 语音消息
	 * file_code
	 * type1  request
	 * type2  reply
	 * 
	 * protocal_code = 136 TCP连接协助         request
	 * protocal_code = 137 UDP语音连接协助 request
	 */
	
	public Apply_Message(int protocal_code, int type, int from_account, int to_account, int p2p_type,
			int tcp_server_port, int udp_server_port1, int udp_server_port2, boolean accept, String request_ip,
			String reply_ip) {

		this.protocal_code = protocal_code;
		this.type = type;
		this.from_account = from_account;
		this.to_account = to_account;
		this.p2p_type = p2p_type;
		this.tcp_server_port = tcp_server_port;
		this.udp_server_port1 = udp_server_port1;
		this.udp_server_port2 = udp_server_port2;
		this.accept = accept;
		this.request_ip = request_ip;
		this.reply_ip = reply_ip;
	}
	
	public int getProtocal_code() {
		return protocal_code;
	}
	public void setProtocal_code(int protocal_code) {
		this.protocal_code = protocal_code;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getFrom_account() {
		return from_account;
	}
	public void setFrom_account(int from_account) {
		this.from_account = from_account;
	}
	public int getTo_account() {
		return to_account;
	}
	public void setTo_account(int to_account) {
		this.to_account = to_account;
	}
	public int getP2p_type() {
		return p2p_type;
	}
	public void setP2p_type(int p2p_type) {
		this.p2p_type = p2p_type;
	}
	public int getTcp_server_port() {
		return tcp_server_port;
	}
	public void setTcp_server_port(int tcp_server_port) {
		this.tcp_server_port = tcp_server_port;
	}	
	public int getUdp_server_port1() {
		return udp_server_port1;
	}
	public void setUdp_server_port1(int udp_server_port1) {
		this.udp_server_port1 = udp_server_port1;
	}
	public int getUdp_server_port2() {
		return udp_server_port2;
	}
	public void setUdp_server_port2(int udp_server_port2) {
		this.udp_server_port2 = udp_server_port2;
	}
	public boolean isAccept() {
		return accept;
	}
	public void setAccept(boolean accept) {
		this.accept = accept;
	}
	public String getRequest_ip() {
		return request_ip;
	}
	public void setRequest_ip(String request_ip) {
		this.request_ip = request_ip;
	}
	public String getReply_ip() {
		return reply_ip;
	}
	public void setReply_ip(String reply_ip) {
		this.reply_ip = reply_ip;
	}
	public long getFile_code() {
		return file_code;
	}
	public void setFile_code(long file_code) {
		this.file_code = file_code;
	}
	public String getFile_name() {
		return file_name;
	}
	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}
	public long getFile_size() {
		return file_size;
	}
	public void setFile_size(long file_size) {
		this.file_size = file_size;
	}
	public long getFilebin_location() {
		return filebin_location;
	}
	public void setFilebin_location(long filebin_location) {
		this.filebin_location = filebin_location;
	}
	
}
