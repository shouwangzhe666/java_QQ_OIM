package private_message;

public class Link_set{

	/**
	 *   分组调整信息
	 */
	
	int type = 1;
	boolean privat = true;
	String native_count = null;          
	String link_account = null;
	String old_group = null;
	String new_group = null;
	String new_remark = null;
	String inform_type = null;
	String state = null;
	String rmeote_ip = null;
	
	/**
	 * type=1 添加分组
	 * type=2 重命名分组
	 * type=3 删除分组
	 * 
	 * type=4 移动联系人分组
	 * type=5 删除联系人
	 * type=6 修改联系人备注
	 * 
	 * type=7 inform_type
	 * type=8 state  
	 * type=9 加入黑名单
	 * type=10 remoteip
	 * 
	 * @param private_group 私聊分组或群聊分组
	 * @param type        
	 * @param native_count   本人账号
	 * @param old_group       旧分组
	 * @param new_group       新分组
	 */
	
	public Link_set(int type) {
		this.type = type;
	}
	
	//  type=1 添加分组
	//  set native_account
	//  set private
	//  set_new_group
	
	// * type=2 重命名分组
    //  set native_account
    //  set private
	//  set old_group
	//  set_new_group
	
	// * type=3 删除分组
	//  set native_account
    //  set private
	//  set old_group
	//  set_new_group  ,move deleted link_man to the new group
	
	// type=4 移动联系人分组
    //  set native_account
	//  set link_account
	//  set new group
	
	//   type=5 删除联系人
	//   set native_account
	//   set link_account
	
	// type=6 修改联系人备注
    //   set native_account
	//   set link_account
	//   set new_remark
	
	// type=7 inform_type
	//   set native_account
	//   set link_account
	//   set inform_type
	
	//   type=8 state 
    //   set native_account
	//   set state
	
    //  type=9 加入黑名单
    //  set native_account
	//  set link_account
	
    //   type=10 remoteip 
    //   set native_account
	//   set remote_ip
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	
	public boolean isPrivat() {
		return privat;
	}

	public void setPrivat(boolean privat) {
		this.privat = privat;
	}
    
	public String getNew_remark() {
		return new_remark;
	}

	public void setNew_remark(String new_remark) {
		this.new_remark = new_remark;
	}

	public String getNative_count() {
		return native_count;
	}
	public void setNative_count(String native_count) {
		this.native_count = native_count;
	}
	public String getLink_account() {
		return link_account;
	}
	public void setLink_account(String link_account) {
		this.link_account = link_account;
	}
	public String getOld_group() {
		return old_group;
	}
	public void setOld_group(String old_group) {
		this.old_group = old_group;
	}
	public String getNew_group() {
		return new_group;
	}
	public void setNew_group(String new_group) {
		this.new_group = new_group;
	}

	public String getInform_type() {
		return inform_type;
	}

	public void setInform_type(String inform_type) {
		this.inform_type = inform_type;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}	
	public String getRmeote_ip() {
		return rmeote_ip;
	}
	public void setRmeote_ip(String rmeote_ip) {
		this.rmeote_ip = rmeote_ip;
	}	
}
