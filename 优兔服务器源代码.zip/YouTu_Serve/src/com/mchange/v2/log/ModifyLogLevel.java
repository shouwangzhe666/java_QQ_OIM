package com.mchange.v2.log;

import java.util.logging.Level;

public class ModifyLogLevel {
	public static void modifyInfoLevel(Level level) {
		
		// to solve the loger problem
		
		MLevel.INFO.level=level;
	}

	public static void main(String[] args) {
		
		
	}
}
