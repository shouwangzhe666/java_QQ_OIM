package private_decode_pack;

import java.io.UnsupportedEncodingException;
import java.util.List;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import message_log_regis.Login_pass_message;

public class Login_Pass_decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> arg) throws Exception {	    
		
		buf.readerIndex(0);
		if(buf.readableBytes()==0) {
	//		System.out.println("server Login_Pass_decoder return;");
			return;}
	
		int protocal_coding = buf.readInt();
		
		if(protocal_coding==312) {
		
		int type = buf.readInt();
		
		if(type==1) {decode_type1(buf, arg);}
		else if(type==2) {decode_type2(buf, arg);}
		else if(type==3) {decode_type3(buf, arg);}
		else if(type==4) {decode_type4(buf, arg);}
		else if(type==5) {decode_type5(buf, arg);}
		} // code = 312
		
		else {
			buf.retain();
			ctx.fireChannelRead(buf);
		}
	}

public void decode_type1(ByteBuf buf, List<Object> arg) {
		
		boolean NativeImage_exist = buf.readBoolean();
		
		int len1 = buf.readInt();
		byte[] b1 = new byte[len1];
		buf.readBytes(b1);
		
		int len2 = buf.readInt();
		byte[] b2 = new byte[len2];
		buf.readBytes(b2);
		
		Login_pass_message login_pass_message = null;
		try {
			login_pass_message = new Login_pass_message(1,new String(b1,"UTF-8"), new String(b2,"UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		login_pass_message.setType(1);
		login_pass_message.setNativeImage_exist(NativeImage_exist);
		
		arg.add(login_pass_message);
	}
	
	public void decode_type2(ByteBuf buf, List<Object> arg) {
		
		int len1 = buf.readInt();
		byte[] b1 = new byte[len1];
		buf.readBytes(b1);
		
		int len2 = buf.readInt();
		byte[] b2 = new byte[len2];
		buf.readBytes(b2);
		
		Login_pass_message login_pass_message = null;
		try {
			login_pass_message = new Login_pass_message(2,new String(b1,"UTF-8"),new String(b2,"UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		login_pass_message.setType(2);
		
		arg.add(login_pass_message);
	}
	
public void decode_type3(ByteBuf buf, List<Object> arg) {
		
	int len1 = buf.readInt();
	byte[] b1 = new byte[len1];
	buf.readBytes(b1);
	
	int len2 = buf.readInt();
	byte[] b2 = new byte[len2];
	buf.readBytes(b2);
	
	int len3 = buf.readInt();
	byte[] b3 = new byte[len3];
	buf.readBytes(b3);
	
	Login_pass_message login_pass_message = null;
	try {
		login_pass_message = new Login_pass_message(new String(b1,"UTF-8"), new String(b2,"UTF-8"),new String(b3,"UTF-8"));
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	login_pass_message.setType(3);
	
	arg.add(login_pass_message);
	}

public void decode_type4(ByteBuf buf, List<Object> arg) {
	
    int result_type = buf.readInt();
    boolean scuess  = buf.readBoolean();
    int len = buf.readInt();
    byte[] b1 = new byte[len];
    buf.readBytes(b1);
   
    Login_pass_message login_pass_message = null;
	try {
		login_pass_message = new Login_pass_message(scuess,new String(b1,"UTF-8"));
		login_pass_message.setType(4);
		login_pass_message.setResult_type(result_type);
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}		
	
	arg.add(login_pass_message);
}
public void decode_type5(ByteBuf buf, List<Object> arg) {
	 
	int tcp_port1 = buf.readInt();
	int tcp_port2 = buf.readInt();
	
	Login_pass_message login_pass_message = new Login_pass_message(tcp_port1, tcp_port2);
	arg.add(login_pass_message);
}
}
