package private_decode_pack;

import java.util.List;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import message_log_regis.Ping_Pong;

public class Ping_Pong_Decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext arg0, ByteBuf buf, List<Object> arg2) throws Exception {
		
		buf.readerIndex(0);
		if(buf.readableBytes()==0) {
			System.out.println("server Ping_Pong_Decoder return;");
			return;}
		
		int pro_code = buf.readInt();
		if(pro_code==310) {
			int account  = buf.readInt();
			arg2.add(new Ping_Pong(account));}
		else {
			buf.retain();
			arg0.fireChannelRead(buf);
		}
	}

}
