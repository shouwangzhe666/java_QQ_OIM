package private_decode_pack;

import java.util.List;

import database_generat.Login_generate;
import database_generat.Off_message_generage;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import private_handle_pack.Ping_Pong_Handle;
import private_message.Private_Chat_Message;

public class Private_Chat_Decoder extends ByteToMessageDecoder{

	@Override
	protected void decode(ChannelHandlerContext ctx, ByteBuf buf, List<Object> list) throws Exception {
	
		buf.readerIndex(0);
		if(buf.readableBytes()==0) {return;}
		
		int protocol_code = buf.readInt();
		
		if(protocol_code==111) {
			       				
		    Private_Chat_Message chat_Message  = general_decoder(buf);
			int type = chat_Message.getType();
			
			boolean online = chat_Message.isOnline();
			
			if(type==3) {
				long time_code  = chat_Message.getSend_time();
				Off_message_generage.delete_off_message(String.valueOf(chat_Message.getTo_account()), time_code);
				Off_message_generage.delete_off_message(String.valueOf(chat_Message.getFrom_account()), time_code);
			} // remove_message
			
			if(online) {
				
				if(type==1||type==2) {
				byte[] bytes = new byte[buf.readInt()];
				buf.readBytes(bytes);
				chat_Message.setBytes(bytes);}
				
				Ping_Pong_Handle.all_users.get(chat_Message.getTo_account()).writeAndFlush(chat_Message);
			}
			else {
				
				 buf.readerIndex(0);
				 byte[] content = new byte[buf.readableBytes()];
				 buf.readBytes(content);
				 Off_message_generage.put_off_message(String.valueOf(chat_Message.getTo_account()),chat_Message.getSend_time(),1, chat_Message.getFrom_account(), content);
				}  // off_line
			
		}
		else {
			buf.retain();
			ctx.fireChannelRead(buf);
		}
	}
   
	public Private_Chat_Message general_decoder(ByteBuf buf) {
		
		int type = buf.readInt();
		int from_account = buf.readInt();
		int to_account  = buf.readInt();
		long send_time = buf.readLong();
		
		boolean online = buf.readBoolean();
		boolean reply = buf.readBoolean();
		long time_code = buf.readLong();
				
		Private_Chat_Message chat_Message = new Private_Chat_Message(type, from_account, to_account, send_time);
		chat_Message.setOnline(online);
		chat_Message.setReply(reply);
		chat_Message.setTime_code(time_code);
		
		return chat_Message;
	}	
}
