package group_message;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

public class Group_chat_message implements Serializable{

	private static final long serialVersionUID = 1L;

	// protocal_code = 211
	
	int type = 1;
	int member_account = 0;
	long send_time = 0l;
	String group_id = null;
	String group_remark = null;
	
	boolean aite = false;
	boolean reply = false; 	
	boolean self = true;
	boolean open_shutup = true;
	boolean set_Administrator = false;
	boolean all_shutup = false;
	boolean temp_chat = false;
	
	int  aite_account = 0;
	long time_code = 0l;
	int shutup_minites = 0;	
	
	byte[] bytes = null;
	byte[] icon_bytes = null;
	StyledDocument document=null;
	
	 /**
     * short_type = 1 文字
     * short_type = 2 表情
     * 
     */

	/**
	 *  type = 1       表情文字
	 *  int member_account = 0;
	 *  long send_time = 0l;
     *  String id
     *  String group_remark 
     *  
	 *   ( reply? time_code)
	 *   (aite? aite_account?)
	 *   
	 *   
	 *  type = 2 图片 
	 *  int member_account = 0;
	 *  long send_time = 0l;
     *  String id
     *  String group_remark 
     *  
	 *   ( reply? time_code)
	 *   (aite? aite_account?)
	 *  
	 *  type = 3 撤销
	 *  int member_account = 0;
	 *  long send_time = 0l;
	 *  long time_code  
	 *  (slef?)
	 *  
	 *  type =4 禁言
	 *  int member_account = 0;
	 *  long send_time = 0l;
	 *  open_shutup ?
	 *  shutup_minites
	 *  
	 *  type = 5 设为管理员
	 *  int member_account = 0;
	 *  long send_time = 0l;
	 *  set_Administrator ?
     * 
     *  type = 6 设置ID (自定义身份)
	 *  int member_account = 0;
	 *  long send_time = 0l;
	 *  String group_id
	 *  
	 *  type = 7  踢出群聊
	 *  int member_account = 0;
	 *  long send_time = 0l;
	 *  
	 *   type=8  修改群成员昵称
	 *   group_remark
	 *  
	 *   type=9  修改群昵称
	 *   group_remark
	 *  
	 *   type10  成员头像
	 *   member_account
	 *   icon_bytes
	 *  
	 *  type=11  修改群头像
	 *  member_account
	 *  icon_bytes
	 *  
	 *  type=12  群设置
	 *  all_shutup
	 *  temp_chat
	 *   
	 * **/	
	
	public Group_chat_message(int type, int member_account, long send_time, String group_id, String group_remark,
			long time_code) {
		
		this.type = type;
		this.member_account = member_account;
		this.send_time = send_time;
		this.group_id = group_id;
		this.group_remark = group_remark;
		this.time_code = time_code;
	}
	
	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getMember_account() {
		return member_account;
	}

	public void setMember_account(int member_account) {
		this.member_account = member_account;
	}
	
	public long getSend_time() {
		return send_time;
	}

	public void setSend_time(long send_time) {
		this.send_time = send_time;
	}

	
	public String getGroup_id() {
		return group_id;
	}

	public void setGroup_id(String group_id) {
		this.group_id = group_id;
	}

	public String getGroup_remark() {
		return group_remark;
	}

	public void setGroup_remark(String group_remark) {
		this.group_remark = group_remark;
	}

	public boolean isAite() {
		return aite;
	}

	public void setAite(boolean aite) {
		this.aite = aite;
	}

	public boolean isReply() {
		return reply;
	}

	public void setReply(boolean reply) {
		this.reply = reply;
	}

	public boolean isSelf() {
		return self;
	}

	public void setSelf(boolean self) {
		this.self = self;
	}

	public boolean isOpen_shutup() {
		return open_shutup;
	}

	public void setOpen_shutup(boolean open_shutup) {
		this.open_shutup = open_shutup;
	}

	public boolean isSet_Administrator() {
		return set_Administrator;
	}

	public void setSet_Administrator(boolean set_Administrator) {
		this.set_Administrator = set_Administrator;
	}

	public int getAite_account() {
		return aite_account;
	}

	public void setAite_account(int aite_account) {
		this.aite_account = aite_account;
	}

	public boolean isAll_shutup() {
		return all_shutup;
	}

	public void setAll_shutup(boolean all_shutup) {
		this.all_shutup = all_shutup;
	}

	public boolean isTemp_chat() {
		return temp_chat;
	}

	public void setTemp_chat(boolean temp_chat) {
		this.temp_chat = temp_chat;
	}

	public long getTime_code() {
		return time_code;
	}

	public void setTime_code(long time_code) {
		this.time_code = time_code;
	}

	public int getShutup_minites() {
		return shutup_minites;
	}

	public void setShutup_minites(int shutup_minites) {
		this.shutup_minites = shutup_minites;
	}	

	public byte[] getIcon_bytes() {
		return icon_bytes;
	}

	public void setIcon_bytes(byte[] icon_bytes) {
		this.icon_bytes = icon_bytes;
	}

	public byte[] getBytes() {
		return bytes;
	}

	public void setBytes(byte[] bytes,boolean decode_face_text) {
		
		 this.bytes = bytes;
		 if(decode_face_text) {decode_face_text();}
	}

	public StyledDocument getDocument() {
		return document;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
public String transfer_minites(int shutup_minites) {
	
	if(shutup_minites<60) {return shutup_minites+"分钟";}
	else if(shutup_minites<60*24) {
		String string = (shutup_minites/60)+"小时";
		int m = shutup_minites%60;
		if(m>0) {string+=m+"分钟";}
		return string;}
	else {return (shutup_minites/1440)+"天";}
}
public void set_Icon(byte[] icon_bytes) {
		
	    ByteBuf buf = Unpooled.buffer(1024, 1024*2048);
		buf.writeInt(icon_bytes.length);
		buf.writeBytes(icon_bytes);
	
		this.bytes = new byte[buf.readableBytes()];
		buf.readBytes(this.bytes);
	}

	public ImageIcon get_Icon() {
	
		byte[] icon_bytes = get_iconbytes();
		
		return new ImageIcon(icon_bytes);
	}
	
	public byte[] get_iconbytes() {
		
		ByteBuf buf = Unpooled.copiedBuffer(bytes);
		buf.readerIndex(0);
		int len = buf.readInt();
		byte[] icon_bytes = new byte[len];
		buf.readBytes(icon_bytes);
		
		return icon_bytes;
	}
	
	public void decode_face_text() { // decode bytes into styledocment
		
		JTextPane jTextPane = new JTextPane();
		StyledDocument styledDocument = jTextPane.getStyledDocument();
		
		short type = 1;
		int len = 0;
		byte[] bytes = null;
		String text = null;
		ImageIcon face_icon = null;
		
		ByteBuf buf = Unpooled.copiedBuffer(this.bytes);
		buf.readerIndex(0);
		
		while(buf.readableBytes()>0) {
			
			type = buf.readShort();
			len  = buf.readInt();
			
			bytes = new byte[len];
			buf.readBytes(bytes);
			
			try {
				text = new String(bytes,"UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if(type==1) {
				
				try {
					styledDocument.insertString(styledDocument.getLength(), text,null);
				} catch (BadLocationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}     // type=1
			else if(type==2){
				
				face_icon = new ImageIcon(getClass().getResource("/little_emoji/"+text));
				jTextPane.insertIcon(face_icon);
			}  // type=2
		}  // while
		
		this.document = styledDocument;
	}
	
	public void setDocument(StyledDocument document) {   // encode styledocment into this.bytes
		this.document = document;
		
		ByteBuf buf = Unpooled.buffer(1024, 1024*2048);
		String type="";
		String temp_text="";
		String text = "";
		byte[] text_bytes = null;
		byte[] icon_bytes = null;
		
		for(int i=0;i<document.getLength();i++) {
  		 
  		  type= document.getCharacterElement(i).getName();
  		 
  		if(type.equals("content")){
 			 
 			 try {
 				temp_text =document.getText(i, 1);
				} catch (BadLocationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
 			 
 			   text+=temp_text;
 			   
 			  // if up to the end of message 
 			  if(i==document.getLength()-1) {
 	  			  
 		  			try {
 						text_bytes = text.getBytes("UTF-8");
 					} catch (UnsupportedEncodingException e1) {
 						// TODO Auto-generated catch block
 						e1.printStackTrace();
 					}
 		  			
 		  			buf.writeShort(1);
 		  			buf.writeInt(text_bytes.length);
 		  			buf.writeBytes(text_bytes);
 		  			text = "";
 		  			
 		  			break;
 		  		  }
 		 } // if text
  		
  		else if(type.equals("icon")) {
  			 
  			// first to add text into the buf
  			
  			try {
				text_bytes = text.getBytes("UTF-8");
			} catch (UnsupportedEncodingException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
  			
  			buf.writeShort(1);
  			buf.writeInt(text_bytes.length);
  			buf.writeBytes(text_bytes);
  			text = "";
  			
  		// second to add icon_name into the buf
  			
  			 Icon icon =StyleConstants.getIcon(document.getCharacterElement(i).getAttributes());
   			 ImageIcon imageIcon =(ImageIcon) icon;
   			 
   		  String all_path=imageIcon.getDescription();
   		  int last_indext = all_path.lastIndexOf("/");
   		  String icon_name = all_path.substring(last_indext+1);
   		
  		  try {
  			icon_bytes = icon_name.getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  		  
   		  buf.writeShort(2);
   		  buf.writeInt(icon_bytes.length);
   		  buf.writeBytes(icon_bytes);
   		  
  		 } // if face_icon
  		 
   }// for循环
		
		this.bytes = new byte[buf.readableBytes()];
		buf.readBytes(this.bytes);
	}
	
	  public String get_popu_message() {
		  
		  if(type==2) {return this.group_remark+": 图片";}
		  else if(type==3) {
			  if(self) { return this.group_remark+"撤回了一条消息";}
			  else {return this.group_remark+"被撤回了一条消息";}
		  } // type==3
		 
		  else if(type==4) {
			  if(open_shutup) {return this.group_remark+"被禁言"+transfer_minites(this.shutup_minites);}
			  else {return this.group_remark+"已被允许发言";}
		  }
		  else if(type==5) {
			  if(set_Administrator) {return this.group_remark+"被设为管理员";}
			  else {return this.group_remark+"被取消管理员身份";}
		  }
		  else if(type==6) {return this.group_remark+"被授予“"+group_id+"”勋章";}
		  else if(type==7) {return this.group_remark+"已被踢出群聊";}
		  
			String popu_message = "";
			String type="";
			String text="";
			 
			for(int i=0;i<document.getLength();i++) {
	  		 
	  		  type= document.getCharacterElement(i).getName();
	  		 
	  		 
	  		 if(type.equals("icon")) {
	  			 
	  			 popu_message+="[表情]";
	  			 
	  		 } // if
	  		 
	  		 else  if(type.equals("content")){
	  			 
	  			 try {
						text =document.getText(i, 1);
					} catch (BadLocationException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	  			 
	  			 popu_message+=text; 	
	  			 
	  		 } // if
	  		 	
	   }// for循环

			return group_remark+": "+popu_message;
		}
}
