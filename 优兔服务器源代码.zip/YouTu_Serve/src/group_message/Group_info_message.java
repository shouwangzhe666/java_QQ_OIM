package group_message;

import java.util.ArrayList;

public class Group_info_message {
     
	int type = 1;
	int group_account = 0;
	
	// group_home_pane,group_set_pane
	// type=13 alter group_info
	// type=14 get group_info
	
	byte[] group_head_icon = null;
	String group_name = null;
	String group_introduce = null;
	
	int group_type = 1;
	int pay_days = 31;
	int pay_money = 1;
	String question = null;
	String answer = null;
	
	boolean temporary_chat = false;  
	boolean stop_all_chat = false;
	
	boolean file_upload_all = false;
	boolean file_load_all = false;
	boolean icon_upload_all = false;
	
	// type=24 
	ArrayList<ArrayList<Object>> all_members = null;
	
	// type==31  notice
	String sender = null;
	String content = null;
	
	// type=32
	long send_time = 0l;
	
	// type=33
	// sender,
	// content,
	// send_time
	
	// type==34 
	 ArrayList<ArrayList<Object>> all_notices = null;
		
	// type==41
	byte[] group_icon = null;
	// sender
	 
	// type==42    
	// send_time
	 
	// type==44 group_icon
	ArrayList<ArrayList<Object>> all_icons = null;
	
	// type=52
	// send_time
	
	// type=53
	// send_time
	// new_file_name
	
	// type=54 group_file
	ArrayList<ArrayList<Object>> all_files = null;
	
	// type=55 group_file unload
		String file_name = null;
		long file_size = 0l;
		// sender
		// send_time 
		
	 // type==56 group_file load
	//file_name
		long start_position = 0l;
		// send_time 

	// type=57 file_unload 
	// type=58 file_load 
	String ip_port = null;	
	// send_time 
	
	public Group_info_message(int type, int group_account) {
		
		this.type = type;
		this.group_account = group_account;
	}
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}

	public int getGroup_account() {
		return group_account;
	}

	public byte[] getGroup_head_icon() {
		return group_head_icon;
	}

	public void setGroup_head_icon(byte[] group_head_icon) {
		this.group_head_icon = group_head_icon;
	}

	public byte[] getGroup_icon() {
		return group_icon;
	}

	public void setGroup_icon(byte[] group_icon) {
		this.group_icon = group_icon;
	}

	public void setGroup_account(int group_account) {
		this.group_account = group_account;
	}

	public String getGroup_name() {
		return group_name;
	}

	public void setGroup_name(String group_name) {
		this.group_name = group_name;
	}

	public String getGroup_introduce() {
		return group_introduce;
	}

	public void setGroup_introduce(String group_introduce) {
		this.group_introduce = group_introduce;
	}

	public ArrayList<ArrayList<Object>> getAll_members() {
		return all_members;
	}

	public void setAll_members(ArrayList<ArrayList<Object>> all_members) {
		this.all_members = all_members;
	}

	public ArrayList<ArrayList<Object>> getAll_notices() {
		return all_notices;
	}

	public void setAll_notices(ArrayList<ArrayList<Object>> all_notices) {
		this.all_notices = all_notices;
	}

	public ArrayList<ArrayList<Object>> getAll_icons() {
		return all_icons;
	}

	public void setAll_icons(ArrayList<ArrayList<Object>> all_icons) {
		this.all_icons = all_icons;
	}

	public ArrayList<ArrayList<Object>> getAll_files() {
		return all_files;
	}

	public void setAll_files(ArrayList<ArrayList<Object>> all_files) {
		this.all_files = all_files;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public long getSend_time() {
		return send_time;
	}

	public void setSend_time(long send_time) {
		this.send_time = send_time;
	}

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public long getFile_size() {
		return file_size;
	}

	public void setFile_size(long file_size) {
		this.file_size = file_size;
	}

	public long getStart_position() {
		return start_position;
	}

	public void setStart_position(long start_position) {
		this.start_position = start_position;
	}

	public int getGroup_type() {
		return group_type;
	}

	public void setGroup_type(int group_type) {
		this.group_type = group_type;
	}

	public int getPay_days() {
		return pay_days;
	}

	public void setPay_days(int pay_days) {
		this.pay_days = pay_days;
	}

	public int getPay_money() {
		return pay_money;
	}

	public void setPay_money(int pay_money) {
		this.pay_money = pay_money;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public boolean isTemporary_chat() {
		return temporary_chat;
	}

	public void setTemporary_chat(boolean temporary_chat) {
		this.temporary_chat = temporary_chat;
	}

	public boolean isStop_all_chat() {
		return stop_all_chat;
	}

	public void setStop_all_chat(boolean stop_all_chat) {
		this.stop_all_chat = stop_all_chat;
	}

	public boolean isFile_upload_all() {
		return file_upload_all;
	}

	public void setFile_upload_all(boolean file_upload_all) {
		this.file_upload_all = file_upload_all;
	}

	public boolean isFile_load_all() {
		return file_load_all;
	}

	public void setFile_load_all(boolean file_load_all) {
		this.file_load_all = file_load_all;
	}

	public boolean isIcon_upload_all() {
		return icon_upload_all;
	}

	public void setIcon_upload_all(boolean icon_upload_all) {
		this.icon_upload_all = icon_upload_all;
	}

	public String getIp_port() {
		return ip_port;
	}

	public void setIp_port(String ip_port) {
		this.ip_port = ip_port;
	}
	
}
